import { _ as e, g as t, m as n, p as r } from "./i18n-BRf-wfgm.js";
//#region src/domains/consent/consent-persistence.ts
var i = "2026-06-08", a = "2026-06-22", o = "2026-06-08", s = {
	tos: i,
	privacyPolicy: a,
	aiDataSharing: a
};
function c(e, t) {
	return `device:consent:${e}:${t}`;
}
function l(e) {
	switch (e) {
		case "tos": return s.tos;
		case "privacy_policy": return s.privacyPolicy;
		case "ai_data_sharing": return s.aiDataSharing;
	}
}
var u = /^\d{4}-\d{2}-\d{2}$/;
function d(e, t) {
	let r = n(c(e, t), "");
	return u.test(r) ? r : "";
}
function f(e, t) {
	return _(d(e, t), l(e));
}
function p(e) {
	return `device:consent:ai:v${o}:${e}`;
}
function m(n, i, a) {
	let o = `device:consent:${n}:v`, s = `:${i}`, l = [], f = "";
	for (let e = 0; e < localStorage.length; e++) {
		let t = localStorage.key(e);
		if (!t || !t.startsWith(o) || !t.endsWith(s)) continue;
		let n = t.slice(o.length, t.length - s.length);
		u.test(n) && (l.push(t), r(t, !1) && n > f && (f = n));
	}
	if (f) for (let t of a) d(t, i) || e(c(t, i), f);
	for (let e of l) t(e);
}
function h(n) {
	if (typeof window > "u" || !n) return {
		tos: !1,
		privacy: !1
	};
	try {
		m("tos", n, ["tos"]), m("privacy", n, ["privacy_policy", "ai_data_sharing"]), r(p(n), !1) && t(p(n));
		let a = f("tos", n), o = f("privacy_policy", n) && f("ai_data_sharing", n);
		if (a || o) return {
			tos: a,
			privacy: o
		};
		let s = r("cadet:onboarding:tosAccepted", !1), l = r("cadet:onboarding:aiDataConsent", !1);
		return s || l ? (s && e(c("tos", n), i), {
			tos: s && f("tos", n),
			privacy: !1
		}) : {
			tos: !1,
			privacy: !1
		};
	} catch {
		return {
			tos: !1,
			privacy: !1
		};
	}
}
function g(n, r, i) {
	if (!(typeof window > "u" || !n)) try {
		r ? e(c("tos", n), l("tos")) : t(c("tos", n)), i ? (e(c("privacy_policy", n), l("privacy_policy")), e(c("ai_data_sharing", n), l("ai_data_sharing"))) : (t(c("privacy_policy", n)), t(c("ai_data_sharing", n)));
	} catch {}
}
function _(e, t) {
	return e >= t;
}
function v(e) {
	g(e.userId, e.tos, e.privacy);
}
function y(e) {
	let t = h(e), n = typeof window < "u" && e != null && [
		["tos", e],
		["privacy_policy", e],
		["ai_data_sharing", e]
	].some(([e, t]) => d(e, t) !== "");
	return {
		...t,
		hasConsentRecord: n
	};
}
//#endregion
export { v as i, i as n, y as r, a as t };
