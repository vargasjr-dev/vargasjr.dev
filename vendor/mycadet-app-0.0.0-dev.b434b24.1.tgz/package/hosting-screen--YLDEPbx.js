import { c as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n as t } from "./loader-circle-Ch7lYSrj.js";
import { t as n } from "./arrow-left-Cq7kfIgc.js";
import { t as r } from "./check-DPXe7vV_.js";
import { t as i } from "./external-anchor--Bf99ulE.js";
import { r as a } from "./i18n-BRf-wfgm.js";
import { t as o } from "./button-BrPHE1Q9.js";
import { n as s, t as c } from "./routes-DW44XTQk.js";
import { t as l } from "./auth-store-Bx-RKZJ9.js";
import { t as u } from "./account-shell-D0S9QH7J.js";
import { t as d } from "./radio-card-nav-CdLpHF6H.js";
import { t as f } from "./onboarding-destination-BVBsT8nb.js";
import { t as p } from "./onboarding-navigation-Bp-9lTqG.js";
import { n as m } from "./provider-key-W64jwzTy.js";
import { useState as h } from "react";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
var v = t("cloud", [["path", {
	d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
	key: "p7xjir"
}]]), y = t("container", [
	["path", {
		d: "M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z",
		key: "1t2lqe"
	}],
	["path", {
		d: "M10 21.9V14L2.1 9.1",
		key: "o7czzq"
	}],
	["path", {
		d: "m10 14 11.9-6.9",
		key: "zm5e20"
	}],
	["path", {
		d: "M14 19.8v-8.1",
		key: "159ecu"
	}],
	["path", {
		d: "M18 17.5V9.4",
		key: "11uown"
	}]
]), b = t("laptop", [["path", {
	d: "M18 5a2 2 0 0 1 2 2v8.526a2 2 0 0 0 .212.897l1.068 2.127a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45l1.068-2.127A2 2 0 0 0 4 15.526V7a2 2 0 0 1 2-2z",
	key: "1pdavp"
}], ["path", {
	d: "M20.054 15.987H3.946",
	key: "14rxg9"
}]]), x = [
	{
		mode: "cloud",
		label: "Cadet Cloud",
		subtitle: "Always on, 24/7, even when your computer is off. Runs on Cadet's secure infrastructure.",
		icon: /* @__PURE__ */ g(v, { className: "h-5 w-5 shrink-0" })
	},
	{
		mode: "local",
		label: "Local",
		subtitle: "Runs directly on your machine. Your data never leaves your computer.",
		icon: /* @__PURE__ */ g(b, { className: "h-5 w-5 shrink-0" })
	},
	{
		mode: "docker",
		label: "Docker",
		subtitle: "Runs in a Docker container on your machine — an isolated environment with its own filesystem.",
		icon: /* @__PURE__ */ g(y, { className: "h-5 w-5 shrink-0" })
	}
];
function S() {
	let { t } = a("account"), r = e(), v = l((e) => e.cloudSession === "present"), [y, b] = h(v ? "cloud" : "local"), S = v ? x : x.filter((e) => e.mode !== "cloud");
	return /* @__PURE__ */ g(u, { children: /* @__PURE__ */ _("div", {
		className: "flex w-full flex-col items-center text-center text-[var(--content-default)]",
		children: [
			/* @__PURE__ */ g("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: t("hostingScreen.title")
			}),
			/* @__PURE__ */ _("p", {
				className: "mt-3 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: [
					t("hostingScreen.body"),
					" ",
					/* @__PURE__ */ g(i, {
						href: c(s.docs.hostingOptions),
						tone: "quiet",
						glyph: !1,
						children: t("hostingScreen.needHelp")
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				role: "radiogroup",
				"aria-label": t("hostingScreen.optionsAriaLabel"),
				onKeyDown: d,
				className: "mt-8 grid w-full gap-2",
				children: S.map((e) => /* @__PURE__ */ g(C, {
					option: e,
					selected: y === e.mode,
					tabStop: y === e.mode,
					onSelect: () => b(e.mode)
				}, e.mode))
			}),
			/* @__PURE__ */ g("div", {
				className: "mt-8 w-full",
				children: /* @__PURE__ */ g(o, {
					variant: "primary",
					size: "large",
					fullWidth: !0,
					onClick: () => {
						y === "cloud" ? (m(null), r(`${s.onboarding.hatching}?hosting=${y}&${f}=1`, p)) : r(`${s.account.onboarding.apiKey}?hosting=${y}`, p);
					},
					children: t("actions.continue")
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "mt-3",
				children: /* @__PURE__ */ g(o, {
					variant: "ghost",
					size: "compact",
					className: "text-[var(--content-tertiary)]",
					leftIcon: /* @__PURE__ */ g(n, {}),
					onClick: () => {
						r(s.account.selectAssistant, p);
					},
					children: t("actions.back")
				})
			})
		]
	}) });
}
function C({ option: e, selected: t, tabStop: n, onSelect: i }) {
	return /* @__PURE__ */ _("div", {
		role: "radio",
		"aria-checked": t,
		tabIndex: n ? 0 : -1,
		onClick: i,
		onKeyDown: (e) => {
			(e.key === "Enter" || e.key === " ") && (e.preventDefault(), i());
		},
		className: [
			"group flex w-full items-center gap-3 rounded-lg border p-3 text-left",
			"transition-all duration-200 ease-out",
			"cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--primary-base)]",
			t ? "border-[var(--primary-base)] bg-[var(--surface-lift)]" : "border-[var(--border-base)] bg-[var(--surface-lift)]/60 hover:border-[var(--border-element)] hover:bg-[var(--surface-lift)]"
		].join(" "),
		children: [
			/* @__PURE__ */ g("div", {
				className: ["flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors duration-200", t ? "bg-[var(--primary-base)] text-[var(--surface-base)]" : "bg-[var(--surface-active)]/40 text-[var(--content-secondary)]"].join(" "),
				children: e.icon
			}),
			/* @__PURE__ */ _("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ g("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ g("span", {
						className: "text-body-medium-default text-[var(--content-default)]",
						children: e.label
					})
				}), /* @__PURE__ */ g("span", {
					className: "mt-1 line-clamp-2 text-label-medium-default leading-[14px] text-[var(--content-tertiary)]",
					children: e.subtitle
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: ["flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 transition-all duration-200", t ? "border-[var(--primary-base)] bg-[var(--primary-base)]" : "border-[var(--border-element)] group-hover:border-[var(--content-tertiary)]"].join(" "),
				children: t && /* @__PURE__ */ g(r, {
					className: "h-3 w-3 text-[var(--surface-base)]",
					strokeWidth: 3
				})
			})
		]
	});
}
//#endregion
export { S as HostingScreen };
