//#region src/components/account/radio-card-nav.ts
var e = new Set(["ArrowDown", "ArrowRight"]), t = new Set(["ArrowUp", "ArrowLeft"]);
function n(n) {
	if (!e.has(n.key) && !t.has(n.key)) return;
	let r = n.target.closest("[role=\"radio\"]");
	if (!r) return;
	let i = Array.from(n.currentTarget.querySelectorAll("[role=\"radio\"]")), a = i.indexOf(r);
	if (a < 0) return;
	let o = i[(a + (e.has(n.key) ? 1 : -1) + i.length) % i.length];
	n.preventDefault(), o.focus();
}
//#endregion
export { n as t };
