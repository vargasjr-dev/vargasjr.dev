Object.freeze({ status: "aborted" });
function e(e, t, n) {
	function r(n, r) {
		if (n._zod || Object.defineProperty(n, "_zod", {
			value: {
				def: r,
				constr: o,
				traits: /* @__PURE__ */ new Set()
			},
			enumerable: !1
		}), n._zod.traits.has(e)) return;
		n._zod.traits.add(e), t(n, r);
		let i = o.prototype, a = Object.keys(i);
		for (let e = 0; e < a.length; e++) {
			let t = a[e];
			t in n || (n[t] = i[t].bind(n));
		}
	}
	let i = n?.Parent ?? Object;
	class a extends i {}
	Object.defineProperty(a, "name", { value: e });
	function o(e) {
		var t;
		let i = n?.Parent ? new a() : this;
		r(i, e), (t = i._zod).deferred ?? (t.deferred = []);
		for (let e of i._zod.deferred) e();
		return i;
	}
	return Object.defineProperty(o, "init", { value: r }), Object.defineProperty(o, Symbol.hasInstance, { value: (t) => n?.Parent && t instanceof n.Parent ? !0 : t?._zod?.traits?.has(e) }), Object.defineProperty(o, "name", { value: e }), o;
}
var t = class extends Error {
	constructor() {
		super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
	}
}, n = class extends Error {
	constructor(e) {
		super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
	}
}, r = {};
function i(e) {
	return e && Object.assign(r, e), r;
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/util.js
function a(e) {
	let t = Object.values(e).filter((e) => typeof e == "number");
	return Object.entries(e).filter(([e, n]) => t.indexOf(+e) === -1).map(([e, t]) => t);
}
function o(e, t) {
	return typeof t == "bigint" ? t.toString() : t;
}
function s(e) {
	return { get value() {
		{
			let t = e();
			return Object.defineProperty(this, "value", { value: t }), t;
		}
		throw Error("cached value already set");
	} };
}
function c(e) {
	return e == null;
}
function l(e) {
	let t = +!!e.startsWith("^"), n = e.endsWith("$") ? e.length - 1 : e.length;
	return e.slice(t, n);
}
function u(e, t) {
	let n = (e.toString().split(".")[1] || "").length, r = t.toString(), i = (r.split(".")[1] || "").length;
	if (i === 0 && /\d?e-\d?/.test(r)) {
		let e = r.match(/\d?e-(\d?)/);
		e?.[1] && (i = Number.parseInt(e[1]));
	}
	let a = n > i ? n : i;
	return Number.parseInt(e.toFixed(a).replace(".", "")) % Number.parseInt(t.toFixed(a).replace(".", "")) / 10 ** a;
}
var d = Symbol("evaluating");
function f(e, t, n) {
	let r;
	Object.defineProperty(e, t, {
		get() {
			if (r !== d) return r === void 0 && (r = d, r = n()), r;
		},
		set(n) {
			Object.defineProperty(e, t, { value: n });
		},
		configurable: !0
	});
}
function p(e, t, n) {
	Object.defineProperty(e, t, {
		value: n,
		writable: !0,
		enumerable: !0,
		configurable: !0
	});
}
function m(...e) {
	let t = {};
	for (let n of e) Object.assign(t, Object.getOwnPropertyDescriptors(n));
	return Object.defineProperties({}, t);
}
function ee(e) {
	return JSON.stringify(e);
}
function te(e) {
	return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var ne = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
function h(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var re = s(() => {
	if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
	try {
		return Function(""), !0;
	} catch {
		return !1;
	}
});
function g(e) {
	if (h(e) === !1) return !1;
	let t = e.constructor;
	if (t === void 0 || typeof t != "function") return !0;
	let n = t.prototype;
	return !(h(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function ie(e) {
	return g(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
var ae = new Set([
	"string",
	"number",
	"symbol"
]);
function _(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function v(e, t, n) {
	let r = new e._zod.constr(t ?? e._zod.def);
	return (!t || n?.parent) && (r._zod.parent = e), r;
}
function y(e) {
	let t = e;
	if (!t) return {};
	if (typeof t == "string") return { error: () => t };
	if (t?.message !== void 0) {
		if (t?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
		t.error = t.message;
	}
	return delete t.message, typeof t.error == "string" ? {
		...t,
		error: () => t.error
	} : t;
}
function oe(e) {
	return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
var se = {
	safeint: [-(2 ** 53 - 1), 2 ** 53 - 1],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function ce(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".pick() cannot be used on object schemas containing refinements");
	return v(e, m(e._zod.def, {
		get shape() {
			let e = {};
			for (let r in t) {
				if (!(r in n.shape)) throw Error(`Unrecognized key: "${r}"`);
				t[r] && (e[r] = n.shape[r]);
			}
			return p(this, "shape", e), e;
		},
		checks: []
	}));
}
function le(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".omit() cannot be used on object schemas containing refinements");
	return v(e, m(e._zod.def, {
		get shape() {
			let r = { ...e._zod.def.shape };
			for (let e in t) {
				if (!(e in n.shape)) throw Error(`Unrecognized key: "${e}"`);
				t[e] && delete r[e];
			}
			return p(this, "shape", r), r;
		},
		checks: []
	}));
}
function ue(e, t) {
	if (!g(t)) throw Error("Invalid input to extend: expected a plain object");
	let n = e._zod.def.checks;
	if (n && n.length > 0) {
		let n = e._zod.def.shape;
		for (let e in t) if (Object.getOwnPropertyDescriptor(n, e) !== void 0) throw Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return v(e, m(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return p(this, "shape", n), n;
	} }));
}
function de(e, t) {
	if (!g(t)) throw Error("Invalid input to safeExtend: expected a plain object");
	return v(e, m(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return p(this, "shape", n), n;
	} }));
}
function fe(e, t) {
	return v(e, m(e._zod.def, {
		get shape() {
			let n = {
				...e._zod.def.shape,
				...t._zod.def.shape
			};
			return p(this, "shape", n), n;
		},
		get catchall() {
			return t._zod.def.catchall;
		},
		checks: []
	}));
}
function pe(e, t, n) {
	let r = t._zod.def.checks;
	if (r && r.length > 0) throw Error(".partial() cannot be used on object schemas containing refinements");
	return v(t, m(t._zod.def, {
		get shape() {
			let r = t._zod.def.shape, i = { ...r };
			if (n) for (let t in n) {
				if (!(t in r)) throw Error(`Unrecognized key: "${t}"`);
				n[t] && (i[t] = e ? new e({
					type: "optional",
					innerType: r[t]
				}) : r[t]);
			}
			else for (let t in r) i[t] = e ? new e({
				type: "optional",
				innerType: r[t]
			}) : r[t];
			return p(this, "shape", i), i;
		},
		checks: []
	}));
}
function me(e, t, n) {
	return v(t, m(t._zod.def, { get shape() {
		let r = t._zod.def.shape, i = { ...r };
		if (n) for (let t in n) {
			if (!(t in i)) throw Error(`Unrecognized key: "${t}"`);
			n[t] && (i[t] = new e({
				type: "nonoptional",
				innerType: r[t]
			}));
		}
		else for (let t in r) i[t] = new e({
			type: "nonoptional",
			innerType: r[t]
		});
		return p(this, "shape", i), i;
	} }));
}
function b(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue !== !0) return !0;
	return !1;
}
function x(e, t) {
	return t.map((t) => {
		var n;
		return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
	});
}
function S(e) {
	return typeof e == "string" ? e : e?.message;
}
function C(e, t, n) {
	let r = {
		...e,
		path: e.path ?? []
	};
	return e.message || (r.message = S(e.inst?._zod.def?.error?.(e)) ?? S(t?.error?.(e)) ?? S(n.customError?.(e)) ?? S(n.localeError?.(e)) ?? "Invalid input"), delete r.inst, delete r.continue, t?.reportInput || delete r.input, r;
}
function w(e) {
	return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function T(...e) {
	let [t, n, r] = e;
	return typeof t == "string" ? {
		message: t,
		code: "custom",
		input: n,
		inst: r
	} : { ...t };
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/errors.js
var he = (e, t) => {
	e.name = "$ZodError", Object.defineProperty(e, "_zod", {
		value: e._zod,
		enumerable: !1
	}), Object.defineProperty(e, "issues", {
		value: t,
		enumerable: !1
	}), e.message = JSON.stringify(t, o, 2), Object.defineProperty(e, "toString", {
		value: () => e.message,
		enumerable: !1
	});
}, ge = e("$ZodError", he), _e = e("$ZodError", he, { Parent: Error });
function ve(e, t = (e) => e.message) {
	let n = {}, r = [];
	for (let i of e.issues) i.path.length > 0 ? (n[i.path[0]] = n[i.path[0]] || [], n[i.path[0]].push(t(i))) : r.push(t(i));
	return {
		formErrors: r,
		fieldErrors: n
	};
}
function ye(e, t = (e) => e.message) {
	let n = { _errors: [] }, r = (e) => {
		for (let i of e.issues) if (i.code === "invalid_union" && i.errors.length) i.errors.map((e) => r({ issues: e }));
		else if (i.code === "invalid_key") r({ issues: i.issues });
		else if (i.code === "invalid_element") r({ issues: i.issues });
		else if (i.path.length === 0) n._errors.push(t(i));
		else {
			let e = n, r = 0;
			for (; r < i.path.length;) {
				let n = i.path[r];
				r === i.path.length - 1 ? (e[n] = e[n] || { _errors: [] }, e[n]._errors.push(t(i))) : e[n] = e[n] || { _errors: [] }, e = e[n], r++;
			}
		}
	};
	return r(e), n;
}
function be(e) {
	let t = [], n = e.map((e) => typeof e == "object" ? e.key : e);
	for (let e of n) typeof e == "number" ? t.push(`[${e}]`) : typeof e == "symbol" ? t.push(`[${JSON.stringify(String(e))}]`) : /[^\w$]/.test(e) ? t.push(`[${JSON.stringify(e)}]`) : (t.length && t.push("."), t.push(e));
	return t.join("");
}
function xe(e) {
	let t = [], n = [...e.issues].sort((e, t) => (e.path ?? []).length - (t.path ?? []).length);
	for (let e of n) t.push(`✖ ${e.message}`), e.path?.length && t.push(`  → at ${be(e.path)}`);
	return t.join("\n");
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/parse.js
var E = (e) => (n, r, a, o) => {
	let s = a ? Object.assign(a, { async: !1 }) : { async: !1 }, c = n._zod.run({
		value: r,
		issues: []
	}, s);
	if (c instanceof Promise) throw new t();
	if (c.issues.length) {
		let t = new (o?.Err ?? e)(c.issues.map((e) => C(e, s, i())));
		throw ne(t, o?.callee), t;
	}
	return c.value;
}, D = (e) => async (t, n, r, a) => {
	let o = r ? Object.assign(r, { async: !0 }) : { async: !0 }, s = t._zod.run({
		value: n,
		issues: []
	}, o);
	if (s instanceof Promise && (s = await s), s.issues.length) {
		let t = new (a?.Err ?? e)(s.issues.map((e) => C(e, o, i())));
		throw ne(t, a?.callee), t;
	}
	return s.value;
}, O = (e) => (n, r, a) => {
	let o = a ? {
		...a,
		async: !1
	} : { async: !1 }, s = n._zod.run({
		value: r,
		issues: []
	}, o);
	if (s instanceof Promise) throw new t();
	return s.issues.length ? {
		success: !1,
		error: new (e ?? ge)(s.issues.map((e) => C(e, o, i())))
	} : {
		success: !0,
		data: s.value
	};
}, Se = /* @__PURE__ */ O(_e), k = (e) => async (t, n, r) => {
	let a = r ? Object.assign(r, { async: !0 }) : { async: !0 }, o = t._zod.run({
		value: n,
		issues: []
	}, a);
	return o instanceof Promise && (o = await o), o.issues.length ? {
		success: !1,
		error: new e(o.issues.map((e) => C(e, a, i())))
	} : {
		success: !0,
		data: o.value
	};
}, Ce = /* @__PURE__ */ k(_e), we = (e) => (t, n, r) => {
	let i = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
	return E(e)(t, n, i);
}, Te = (e) => (t, n, r) => E(e)(t, n, r), Ee = (e) => async (t, n, r) => {
	let i = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
	return D(e)(t, n, i);
}, De = (e) => async (t, n, r) => D(e)(t, n, r), Oe = (e) => (t, n, r) => {
	let i = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
	return O(e)(t, n, i);
}, ke = (e) => (t, n, r) => O(e)(t, n, r), Ae = (e) => async (t, n, r) => {
	let i = r ? Object.assign(r, { direction: "backward" }) : { direction: "backward" };
	return k(e)(t, n, i);
}, je = (e) => async (t, n, r) => k(e)(t, n, r), Me = /^[cC][^\s-]{8,}$/, Ne = /^[0-9a-z]+$/, Pe = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, Fe = /^[0-9a-vA-V]{20}$/, Ie = /^[A-Za-z0-9]{27}$/, Le = /^[a-zA-Z0-9_-]{21}$/, Re = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, ze = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Be = (e) => e ? RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, Ve = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, He = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Ue() {
	return new RegExp(He, "u");
}
var We = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ge = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Ke = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, qe = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Je = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Ye = /^[A-Za-z0-9_-]*$/, Xe = /^\+[1-9]\d{6,14}$/, Ze = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Qe = /* @__PURE__ */ RegExp(`^${Ze}$`);
function $e(e) {
	let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
	return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function et(e) {
	return RegExp(`^${$e(e)}$`);
}
function tt(e) {
	let t = $e({ precision: e.precision }), n = ["Z"];
	e.local && n.push(""), e.offset && n.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
	let r = `${t}(?:${n.join("|")})`;
	return RegExp(`^${Ze}T(?:${r})$`);
}
var nt = (e) => {
	let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
	return RegExp(`^${t}$`);
}, rt = /^-?\d+$/, it = /^-?\d+(?:\.\d+)?$/, at = /^(?:true|false)$/i, ot = /^null$/i, st = /^[^A-Z]*$/, ct = /^[^a-z]*$/, A = /* @__PURE__ */ e("$ZodCheck", (e, t) => {
	var n;
	e._zod ??= {}, e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), lt = {
	number: "number",
	bigint: "bigint",
	object: "date"
}, ut = /* @__PURE__ */ e("$ZodCheckLessThan", (e, t) => {
	A.init(e, t);
	let n = lt[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Infinity;
		t.value < r && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
			origin: n,
			code: "too_big",
			maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), dt = /* @__PURE__ */ e("$ZodCheckGreaterThan", (e, t) => {
	A.init(e, t);
	let n = lt[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? -Infinity;
		t.value > r && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
			origin: n,
			code: "too_small",
			minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), ft = /* @__PURE__ */ e("$ZodCheckMultipleOf", (e, t) => {
	A.init(e, t), e._zod.onattach.push((e) => {
		var n;
		(n = e._zod.bag).multipleOf ?? (n.multipleOf = t.value);
	}), e._zod.check = (n) => {
		if (typeof n.value != typeof t.value) throw Error("Cannot mix number and bigint in multiple_of check.");
		(typeof n.value == "bigint" ? n.value % t.value === BigInt(0) : u(n.value, t.value) === 0) || n.issues.push({
			origin: typeof n.value,
			code: "not_multiple_of",
			divisor: t.value,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), pt = /* @__PURE__ */ e("$ZodCheckNumberFormat", (e, t) => {
	A.init(e, t), t.format = t.format || "float64";
	let n = t.format?.includes("int"), r = n ? "int" : "number", [i, a] = se[t.format];
	e._zod.onattach.push((e) => {
		let r = e._zod.bag;
		r.format = t.format, r.minimum = i, r.maximum = a, n && (r.pattern = rt);
	}), e._zod.check = (o) => {
		let s = o.value;
		if (n) {
			if (!Number.isInteger(s)) {
				o.issues.push({
					expected: r,
					format: t.format,
					code: "invalid_type",
					continue: !1,
					input: s,
					inst: e
				});
				return;
			}
			if (!Number.isSafeInteger(s)) {
				s > 0 ? o.issues.push({
					input: s,
					code: "too_big",
					maximum: 2 ** 53 - 1,
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				}) : o.issues.push({
					input: s,
					code: "too_small",
					minimum: -(2 ** 53 - 1),
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				});
				return;
			}
		}
		s < i && o.issues.push({
			origin: "number",
			input: s,
			code: "too_small",
			minimum: i,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), s > a && o.issues.push({
			origin: "number",
			input: s,
			code: "too_big",
			maximum: a,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), mt = /* @__PURE__ */ e("$ZodCheckMaxLength", (e, t) => {
	var n;
	A.init(e, t), (n = e._zod.def).when ?? (n.when = (e) => {
		let t = e.value;
		return !c(t) && t.length !== void 0;
	}), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value;
		if (r.length <= t.maximum) return;
		let i = w(r);
		n.issues.push({
			origin: i,
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), ht = /* @__PURE__ */ e("$ZodCheckMinLength", (e, t) => {
	var n;
	A.init(e, t), (n = e._zod.def).when ?? (n.when = (e) => {
		let t = e.value;
		return !c(t) && t.length !== void 0;
	}), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value;
		if (r.length >= t.minimum) return;
		let i = w(r);
		n.issues.push({
			origin: i,
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), gt = /* @__PURE__ */ e("$ZodCheckLengthEquals", (e, t) => {
	var n;
	A.init(e, t), (n = e._zod.def).when ?? (n.when = (e) => {
		let t = e.value;
		return !c(t) && t.length !== void 0;
	}), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.length, n.maximum = t.length, n.length = t.length;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if (i === t.length) return;
		let a = w(r), o = i > t.length;
		n.issues.push({
			origin: a,
			...o ? {
				code: "too_big",
				maximum: t.length
			} : {
				code: "too_small",
				minimum: t.length
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), j = /* @__PURE__ */ e("$ZodCheckStringFormat", (e, t) => {
	var n, r;
	A.init(e, t), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.format = t.format, t.pattern && (n.patterns ??= /* @__PURE__ */ new Set(), n.patterns.add(t.pattern));
	}), t.pattern ? (n = e._zod).check ?? (n.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: t.format,
			input: n.value,
			...t.pattern ? { pattern: t.pattern.toString() } : {},
			inst: e,
			continue: !t.abort
		});
	}) : (r = e._zod).check ?? (r.check = () => {});
}), _t = /* @__PURE__ */ e("$ZodCheckRegex", (e, t) => {
	j.init(e, t), e._zod.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: n.value,
			pattern: t.pattern.toString(),
			inst: e,
			continue: !t.abort
		});
	};
}), vt = /* @__PURE__ */ e("$ZodCheckLowerCase", (e, t) => {
	t.pattern ??= st, j.init(e, t);
}), yt = /* @__PURE__ */ e("$ZodCheckUpperCase", (e, t) => {
	t.pattern ??= ct, j.init(e, t);
}), bt = /* @__PURE__ */ e("$ZodCheckIncludes", (e, t) => {
	A.init(e, t);
	let n = _(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${n}` : n);
	t.pattern = r, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(r);
	}), e._zod.check = (n) => {
		n.value.includes(t.includes, t.position) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: t.includes,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), xt = /* @__PURE__ */ e("$ZodCheckStartsWith", (e, t) => {
	A.init(e, t);
	let n = RegExp(`^${_(t.prefix)}.*`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.startsWith(t.prefix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: t.prefix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), St = /* @__PURE__ */ e("$ZodCheckEndsWith", (e, t) => {
	A.init(e, t);
	let n = RegExp(`.*${_(t.suffix)}$`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.endsWith(t.suffix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: t.suffix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Ct = /* @__PURE__ */ e("$ZodCheckOverwrite", (e, t) => {
	A.init(e, t), e._zod.check = (e) => {
		e.value = t.tx(e.value);
	};
}), wt = class {
	constructor(e = []) {
		this.content = [], this.indent = 0, this && (this.args = e);
	}
	indented(e) {
		this.indent += 1, e(this), --this.indent;
	}
	write(e) {
		if (typeof e == "function") {
			e(this, { execution: "sync" }), e(this, { execution: "async" });
			return;
		}
		let t = e.split("\n").filter((e) => e), n = Math.min(...t.map((e) => e.length - e.trimStart().length)), r = t.map((e) => e.slice(n)).map((e) => " ".repeat(this.indent * 2) + e);
		for (let e of r) this.content.push(e);
	}
	compile() {
		let e = Function, t = this?.args, n = [...(this?.content ?? [""]).map((e) => `  ${e}`)];
		return new e(...t, n.join("\n"));
	}
}, Tt = {
	major: 4,
	minor: 3,
	patch: 6
}, M = /* @__PURE__ */ e("$ZodType", (e, n) => {
	var r;
	e ??= {}, e._zod.def = n, e._zod.bag = e._zod.bag || {}, e._zod.version = Tt;
	let i = [...e._zod.def.checks ?? []];
	e._zod.traits.has("$ZodCheck") && i.unshift(e);
	for (let t of i) for (let n of t._zod.onattach) n(e);
	if (i.length === 0) (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
		e._zod.run = e._zod.parse;
	});
	else {
		let n = (e, n, r) => {
			let i = b(e), a;
			for (let o of n) {
				if (o._zod.def.when) {
					if (!o._zod.def.when(e)) continue;
				} else if (i) continue;
				let n = e.issues.length, s = o._zod.check(e);
				if (s instanceof Promise && r?.async === !1) throw new t();
				if (a || s instanceof Promise) a = (a ?? Promise.resolve()).then(async () => {
					await s, e.issues.length !== n && (i ||= b(e, n));
				});
				else {
					if (e.issues.length === n) continue;
					i ||= b(e, n);
				}
			}
			return a ? a.then(() => e) : e;
		}, r = (r, a, o) => {
			if (b(r)) return r.aborted = !0, r;
			let s = n(a, i, o);
			if (s instanceof Promise) {
				if (o.async === !1) throw new t();
				return s.then((t) => e._zod.parse(t, o));
			}
			return e._zod.parse(s, o);
		};
		e._zod.run = (a, o) => {
			if (o.skipChecks) return e._zod.parse(a, o);
			if (o.direction === "backward") {
				let t = e._zod.parse({
					value: a.value,
					issues: []
				}, {
					...o,
					skipChecks: !0
				});
				return t instanceof Promise ? t.then((e) => r(e, a, o)) : r(t, a, o);
			}
			let s = e._zod.parse(a, o);
			if (s instanceof Promise) {
				if (o.async === !1) throw new t();
				return s.then((e) => n(e, i, o));
			}
			return n(s, i, o);
		};
	}
	f(e, "~standard", () => ({
		validate: (t) => {
			try {
				let n = Se(e, t);
				return n.success ? { value: n.data } : { issues: n.error?.issues };
			} catch {
				return Ce(e, t).then((e) => e.success ? { value: e.data } : { issues: e.error?.issues });
			}
		},
		vendor: "zod",
		version: 1
	}));
}), N = /* @__PURE__ */ e("$ZodString", (e, t) => {
	M.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? nt(e._zod.bag), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = String(n.value);
		} catch {}
		return typeof n.value == "string" || n.issues.push({
			expected: "string",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), P = /* @__PURE__ */ e("$ZodStringFormat", (e, t) => {
	j.init(e, t), N.init(e, t);
}), Et = /* @__PURE__ */ e("$ZodGUID", (e, t) => {
	t.pattern ??= ze, P.init(e, t);
}), Dt = /* @__PURE__ */ e("$ZodUUID", (e, t) => {
	if (t.version) {
		let e = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[t.version];
		if (e === void 0) throw Error(`Invalid UUID version: "${t.version}"`);
		t.pattern ??= Be(e);
	} else t.pattern ??= Be();
	P.init(e, t);
}), Ot = /* @__PURE__ */ e("$ZodEmail", (e, t) => {
	t.pattern ??= Ve, P.init(e, t);
}), kt = /* @__PURE__ */ e("$ZodURL", (e, t) => {
	P.init(e, t), e._zod.check = (n) => {
		try {
			let r = n.value.trim(), i = new URL(r);
			t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(i.hostname) || n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: t.hostname.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			})), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(i.protocol.endsWith(":") ? i.protocol.slice(0, -1) : i.protocol) || n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: t.protocol.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			})), t.normalize ? n.value = i.href : n.value = r;
			return;
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "url",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), At = /* @__PURE__ */ e("$ZodEmoji", (e, t) => {
	t.pattern ??= Ue(), P.init(e, t);
}), jt = /* @__PURE__ */ e("$ZodNanoID", (e, t) => {
	t.pattern ??= Le, P.init(e, t);
}), Mt = /* @__PURE__ */ e("$ZodCUID", (e, t) => {
	t.pattern ??= Me, P.init(e, t);
}), Nt = /* @__PURE__ */ e("$ZodCUID2", (e, t) => {
	t.pattern ??= Ne, P.init(e, t);
}), Pt = /* @__PURE__ */ e("$ZodULID", (e, t) => {
	t.pattern ??= Pe, P.init(e, t);
}), Ft = /* @__PURE__ */ e("$ZodXID", (e, t) => {
	t.pattern ??= Fe, P.init(e, t);
}), It = /* @__PURE__ */ e("$ZodKSUID", (e, t) => {
	t.pattern ??= Ie, P.init(e, t);
}), Lt = /* @__PURE__ */ e("$ZodISODateTime", (e, t) => {
	t.pattern ??= tt(t), P.init(e, t);
}), Rt = /* @__PURE__ */ e("$ZodISODate", (e, t) => {
	t.pattern ??= Qe, P.init(e, t);
}), zt = /* @__PURE__ */ e("$ZodISOTime", (e, t) => {
	t.pattern ??= et(t), P.init(e, t);
}), Bt = /* @__PURE__ */ e("$ZodISODuration", (e, t) => {
	t.pattern ??= Re, P.init(e, t);
}), Vt = /* @__PURE__ */ e("$ZodIPv4", (e, t) => {
	t.pattern ??= We, P.init(e, t), e._zod.bag.format = "ipv4";
}), Ht = /* @__PURE__ */ e("$ZodIPv6", (e, t) => {
	t.pattern ??= Ge, P.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
		try {
			new URL(`http://[${n.value}]`);
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "ipv6",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), Ut = /* @__PURE__ */ e("$ZodCIDRv4", (e, t) => {
	t.pattern ??= Ke, P.init(e, t);
}), Wt = /* @__PURE__ */ e("$ZodCIDRv6", (e, t) => {
	t.pattern ??= qe, P.init(e, t), e._zod.check = (n) => {
		let r = n.value.split("/");
		try {
			if (r.length !== 2) throw Error();
			let [e, t] = r;
			if (!t) throw Error();
			let n = Number(t);
			if (`${n}` !== t || n < 0 || n > 128) throw Error();
			new URL(`http://[${e}]`);
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "cidrv6",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
});
function Gt(e) {
	if (e === "") return !0;
	if (e.length % 4 != 0) return !1;
	try {
		return atob(e), !0;
	} catch {
		return !1;
	}
}
var Kt = /* @__PURE__ */ e("$ZodBase64", (e, t) => {
	t.pattern ??= Je, P.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
		Gt(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function qt(e) {
	if (!Ye.test(e)) return !1;
	let t = e.replace(/[-_]/g, (e) => e === "-" ? "+" : "/");
	return Gt(t.padEnd(Math.ceil(t.length / 4) * 4, "="));
}
var Jt = /* @__PURE__ */ e("$ZodBase64URL", (e, t) => {
	t.pattern ??= Ye, P.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
		qt(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Yt = /* @__PURE__ */ e("$ZodE164", (e, t) => {
	t.pattern ??= Xe, P.init(e, t);
});
function Xt(e, t = null) {
	try {
		let n = e.split(".");
		if (n.length !== 3) return !1;
		let [r] = n;
		if (!r) return !1;
		let i = JSON.parse(atob(r));
		return !("typ" in i && i?.typ !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
	} catch {
		return !1;
	}
}
var Zt = /* @__PURE__ */ e("$ZodJWT", (e, t) => {
	P.init(e, t), e._zod.check = (n) => {
		Xt(n.value, t.alg) || n.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Qt = /* @__PURE__ */ e("$ZodNumber", (e, t) => {
	M.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? it, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = Number(n.value);
		} catch {}
		let i = n.value;
		if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i)) return n;
		let a = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : "Infinity" : void 0;
		return n.issues.push({
			expected: "number",
			code: "invalid_type",
			input: i,
			inst: e,
			...a ? { received: a } : {}
		}), n;
	};
}), $t = /* @__PURE__ */ e("$ZodNumberFormat", (e, t) => {
	pt.init(e, t), Qt.init(e, t);
}), en = /* @__PURE__ */ e("$ZodBoolean", (e, t) => {
	M.init(e, t), e._zod.pattern = at, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = !!n.value;
		} catch {}
		let i = n.value;
		return typeof i == "boolean" || n.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
	};
}), tn = /* @__PURE__ */ e("$ZodNull", (e, t) => {
	M.init(e, t), e._zod.pattern = ot, e._zod.values = new Set([null]), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === null || t.issues.push({
			expected: "null",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), nn = /* @__PURE__ */ e("$ZodUnknown", (e, t) => {
	M.init(e, t), e._zod.parse = (e) => e;
}), rn = /* @__PURE__ */ e("$ZodNever", (e, t) => {
	M.init(e, t), e._zod.parse = (t, n) => (t.issues.push({
		expected: "never",
		code: "invalid_type",
		input: t.value,
		inst: e
	}), t);
});
function an(e, t, n) {
	e.issues.length && t.issues.push(...x(n, e.issues)), t.value[n] = e.value;
}
var on = /* @__PURE__ */ e("$ZodArray", (e, t) => {
	M.init(e, t), e._zod.parse = (n, r) => {
		let i = n.value;
		if (!Array.isArray(i)) return n.issues.push({
			expected: "array",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
		n.value = Array(i.length);
		let a = [];
		for (let e = 0; e < i.length; e++) {
			let o = i[e], s = t.element._zod.run({
				value: o,
				issues: []
			}, r);
			s instanceof Promise ? a.push(s.then((t) => an(t, n, e))) : an(s, n, e);
		}
		return a.length ? Promise.all(a).then(() => n) : n;
	};
});
function F(e, t, n, r, i) {
	if (e.issues.length) {
		if (i && !(n in r)) return;
		t.issues.push(...x(n, e.issues));
	}
	e.value === void 0 ? n in r && (t.value[n] = void 0) : t.value[n] = e.value;
}
function sn(e) {
	let t = Object.keys(e.shape);
	for (let n of t) if (!e.shape?.[n]?._zod?.traits?.has("$ZodType")) throw Error(`Invalid element at key "${n}": expected a Zod schema`);
	let n = oe(e.shape);
	return {
		...e,
		keys: t,
		keySet: new Set(t),
		numKeys: t.length,
		optionalKeys: new Set(n)
	};
}
function cn(e, t, n, r, i, a) {
	let o = [], s = i.keySet, c = i.catchall._zod, l = c.def.type, u = c.optout === "optional";
	for (let i in t) {
		if (s.has(i)) continue;
		if (l === "never") {
			o.push(i);
			continue;
		}
		let a = c.run({
			value: t[i],
			issues: []
		}, r);
		a instanceof Promise ? e.push(a.then((e) => F(e, n, i, t, u))) : F(a, n, i, t, u);
	}
	return o.length && n.issues.push({
		code: "unrecognized_keys",
		keys: o,
		input: t,
		inst: a
	}), e.length ? Promise.all(e).then(() => n) : n;
}
var ln = /* @__PURE__ */ e("$ZodObject", (e, t) => {
	if (M.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
		let e = t.shape;
		Object.defineProperty(t, "shape", { get: () => {
			let n = { ...e };
			return Object.defineProperty(t, "shape", { value: n }), n;
		} });
	}
	let n = s(() => sn(t));
	f(e._zod, "propValues", () => {
		let e = t.shape, n = {};
		for (let t in e) {
			let r = e[t]._zod;
			if (r.values) {
				n[t] ?? (n[t] = /* @__PURE__ */ new Set());
				for (let e of r.values) n[t].add(e);
			}
		}
		return n;
	});
	let r = h, i = t.catchall, a;
	e._zod.parse = (t, o) => {
		a ??= n.value;
		let s = t.value;
		if (!r(s)) return t.issues.push({
			expected: "object",
			code: "invalid_type",
			input: s,
			inst: e
		}), t;
		t.value = {};
		let c = [], l = a.shape;
		for (let e of a.keys) {
			let n = l[e], r = n._zod.optout === "optional", i = n._zod.run({
				value: s[e],
				issues: []
			}, o);
			i instanceof Promise ? c.push(i.then((n) => F(n, t, e, s, r))) : F(i, t, e, s, r);
		}
		return i ? cn(c, s, t, o, n.value, e) : c.length ? Promise.all(c).then(() => t) : t;
	};
}), un = /* @__PURE__ */ e("$ZodObjectJIT", (e, t) => {
	ln.init(e, t);
	let n = e._zod.parse, i = s(() => sn(t)), a = (e) => {
		let t = new wt([
			"shape",
			"payload",
			"ctx"
		]), n = i.value, r = (e) => {
			let t = ee(e);
			return `shape[${t}]._zod.run({ value: input[${t}], issues: [] }, ctx)`;
		};
		t.write("const input = payload.value;");
		let a = Object.create(null), o = 0;
		for (let e of n.keys) a[e] = `key_${o++}`;
		t.write("const newResult = {};");
		for (let i of n.keys) {
			let n = a[i], o = ee(i), s = e[i]?._zod?.optout === "optional";
			t.write(`const ${n} = ${r(i)};`), s ? t.write(`
        if (${n}.issues.length) {
          if (${o} in input) {
            payload.issues = payload.issues.concat(${n}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${o}, ...iss.path] : [${o}]
            })));
          }
        }
        
        if (${n}.value === undefined) {
          if (${o} in input) {
            newResult[${o}] = undefined;
          }
        } else {
          newResult[${o}] = ${n}.value;
        }
        
      `) : t.write(`
        if (${n}.issues.length) {
          payload.issues = payload.issues.concat(${n}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${o}, ...iss.path] : [${o}]
          })));
        }
        
        if (${n}.value === undefined) {
          if (${o} in input) {
            newResult[${o}] = undefined;
          }
        } else {
          newResult[${o}] = ${n}.value;
        }
        
      `);
		}
		t.write("payload.value = newResult;"), t.write("return payload;");
		let s = t.compile();
		return (t, n) => s(e, t, n);
	}, o, c = h, l = !r.jitless, u = l && re.value, d = t.catchall, f;
	e._zod.parse = (r, s) => {
		f ??= i.value;
		let p = r.value;
		return c(p) ? l && u && s?.async === !1 && s.jitless !== !0 ? (o ||= a(t.shape), r = o(r, s), d ? cn([], p, r, s, f, e) : r) : n(r, s) : (r.issues.push({
			expected: "object",
			code: "invalid_type",
			input: p,
			inst: e
		}), r);
	};
});
function dn(e, t, n, r) {
	for (let n of e) if (n.issues.length === 0) return t.value = n.value, t;
	let a = e.filter((e) => !b(e));
	return a.length === 1 ? (t.value = a[0].value, a[0]) : (t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => C(e, r, i())))
	}), t);
}
var fn = /* @__PURE__ */ e("$ZodUnion", (e, t) => {
	M.init(e, t), f(e._zod, "optin", () => t.options.some((e) => e._zod.optin === "optional") ? "optional" : void 0), f(e._zod, "optout", () => t.options.some((e) => e._zod.optout === "optional") ? "optional" : void 0), f(e._zod, "values", () => {
		if (t.options.every((e) => e._zod.values)) return new Set(t.options.flatMap((e) => Array.from(e._zod.values)));
	}), f(e._zod, "pattern", () => {
		if (t.options.every((e) => e._zod.pattern)) {
			let e = t.options.map((e) => e._zod.pattern);
			return RegExp(`^(${e.map((e) => l(e.source)).join("|")})$`);
		}
	});
	let n = t.options.length === 1, r = t.options[0]._zod.run;
	e._zod.parse = (i, a) => {
		if (n) return r(i, a);
		let o = !1, s = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: i.value,
				issues: []
			}, a);
			if (t instanceof Promise) s.push(t), o = !0;
			else {
				if (t.issues.length === 0) return t;
				s.push(t);
			}
		}
		return o ? Promise.all(s).then((t) => dn(t, i, e, a)) : dn(s, i, e, a);
	};
}), pn = /* @__PURE__ */ e("$ZodDiscriminatedUnion", (e, t) => {
	t.inclusive = !1, fn.init(e, t);
	let n = e._zod.parse;
	f(e._zod, "propValues", () => {
		let e = {};
		for (let n of t.options) {
			let r = n._zod.propValues;
			if (!r || Object.keys(r).length === 0) throw Error(`Invalid discriminated union option at index "${t.options.indexOf(n)}"`);
			for (let [t, n] of Object.entries(r)) {
				e[t] || (e[t] = /* @__PURE__ */ new Set());
				for (let r of n) e[t].add(r);
			}
		}
		return e;
	});
	let r = s(() => {
		let e = t.options, n = /* @__PURE__ */ new Map();
		for (let r of e) {
			let e = r._zod.propValues?.[t.discriminator];
			if (!e || e.size === 0) throw Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);
			for (let t of e) {
				if (n.has(t)) throw Error(`Duplicate discriminator value "${String(t)}"`);
				n.set(t, r);
			}
		}
		return n;
	});
	e._zod.parse = (i, a) => {
		let o = i.value;
		if (!h(o)) return i.issues.push({
			code: "invalid_type",
			expected: "object",
			input: o,
			inst: e
		}), i;
		let s = r.value.get(o?.[t.discriminator]);
		return s ? s._zod.run(i, a) : t.unionFallback ? n(i, a) : (i.issues.push({
			code: "invalid_union",
			errors: [],
			note: "No matching discriminator",
			discriminator: t.discriminator,
			input: o,
			path: [t.discriminator],
			inst: e
		}), i);
	};
}), mn = /* @__PURE__ */ e("$ZodIntersection", (e, t) => {
	M.init(e, t), e._zod.parse = (e, n) => {
		let r = e.value, i = t.left._zod.run({
			value: r,
			issues: []
		}, n), a = t.right._zod.run({
			value: r,
			issues: []
		}, n);
		return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([t, n]) => hn(e, t, n)) : hn(e, i, a);
	};
});
function I(e, t) {
	if (e === t || e instanceof Date && t instanceof Date && +e == +t) return {
		valid: !0,
		data: e
	};
	if (g(e) && g(t)) {
		let n = Object.keys(t), r = Object.keys(e).filter((e) => n.indexOf(e) !== -1), i = {
			...e,
			...t
		};
		for (let n of r) {
			let r = I(e[n], t[n]);
			if (!r.valid) return {
				valid: !1,
				mergeErrorPath: [n, ...r.mergeErrorPath]
			};
			i[n] = r.data;
		}
		return {
			valid: !0,
			data: i
		};
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return {
			valid: !1,
			mergeErrorPath: []
		};
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r], o = I(i, a);
			if (!o.valid) return {
				valid: !1,
				mergeErrorPath: [r, ...o.mergeErrorPath]
			};
			n.push(o.data);
		}
		return {
			valid: !0,
			data: n
		};
	}
	return {
		valid: !1,
		mergeErrorPath: []
	};
}
function hn(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i;
	for (let n of t.issues) if (n.code === "unrecognized_keys") {
		i ??= n;
		for (let e of n.keys) r.has(e) || r.set(e, {}), r.get(e).l = !0;
	} else e.issues.push(n);
	for (let t of n.issues) if (t.code === "unrecognized_keys") for (let e of t.keys) r.has(e) || r.set(e, {}), r.get(e).r = !0;
	else e.issues.push(t);
	let a = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
	if (a.length && i && e.issues.push({
		...i,
		keys: a
	}), b(e)) return e;
	let o = I(t.value, n.value);
	if (!o.valid) throw Error(`Unmergable intersection. Error path: ${JSON.stringify(o.mergeErrorPath)}`);
	return e.value = o.data, e;
}
var gn = /* @__PURE__ */ e("$ZodRecord", (e, t) => {
	M.init(e, t), e._zod.parse = (n, r) => {
		let a = n.value;
		if (!g(a)) return n.issues.push({
			expected: "record",
			code: "invalid_type",
			input: a,
			inst: e
		}), n;
		let o = [], s = t.keyType._zod.values;
		if (s) {
			n.value = {};
			let i = /* @__PURE__ */ new Set();
			for (let e of s) if (typeof e == "string" || typeof e == "number" || typeof e == "symbol") {
				i.add(typeof e == "number" ? e.toString() : e);
				let s = t.valueType._zod.run({
					value: a[e],
					issues: []
				}, r);
				s instanceof Promise ? o.push(s.then((t) => {
					t.issues.length && n.issues.push(...x(e, t.issues)), n.value[e] = t.value;
				})) : (s.issues.length && n.issues.push(...x(e, s.issues)), n.value[e] = s.value);
			}
			let c;
			for (let e in a) i.has(e) || (c ??= [], c.push(e));
			c && c.length > 0 && n.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: c
			});
		} else {
			n.value = {};
			for (let s of Reflect.ownKeys(a)) {
				if (s === "__proto__") continue;
				let c = t.keyType._zod.run({
					value: s,
					issues: []
				}, r);
				if (c instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (typeof s == "string" && it.test(s) && c.issues.length) {
					let e = t.keyType._zod.run({
						value: Number(s),
						issues: []
					}, r);
					if (e instanceof Promise) throw Error("Async schemas not supported in object keys currently");
					e.issues.length === 0 && (c = e);
				}
				if (c.issues.length) {
					t.mode === "loose" ? n.value[s] = a[s] : n.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: c.issues.map((e) => C(e, r, i())),
						input: s,
						path: [s],
						inst: e
					});
					continue;
				}
				let l = t.valueType._zod.run({
					value: a[s],
					issues: []
				}, r);
				l instanceof Promise ? o.push(l.then((e) => {
					e.issues.length && n.issues.push(...x(s, e.issues)), n.value[c.value] = e.value;
				})) : (l.issues.length && n.issues.push(...x(s, l.issues)), n.value[c.value] = l.value);
			}
		}
		return o.length ? Promise.all(o).then(() => n) : n;
	};
}), _n = /* @__PURE__ */ e("$ZodEnum", (e, t) => {
	M.init(e, t);
	let n = a(t.entries), r = new Set(n);
	e._zod.values = r, e._zod.pattern = RegExp(`^(${n.filter((e) => ae.has(typeof e)).map((e) => typeof e == "string" ? _(e) : e.toString()).join("|")})$`), e._zod.parse = (t, i) => {
		let a = t.value;
		return r.has(a) || t.issues.push({
			code: "invalid_value",
			values: n,
			input: a,
			inst: e
		}), t;
	};
}), vn = /* @__PURE__ */ e("$ZodLiteral", (e, t) => {
	if (M.init(e, t), t.values.length === 0) throw Error("Cannot create literal schema with no valid values");
	let n = new Set(t.values);
	e._zod.values = n, e._zod.pattern = RegExp(`^(${t.values.map((e) => typeof e == "string" ? _(e) : e ? _(e.toString()) : String(e)).join("|")})$`), e._zod.parse = (r, i) => {
		let a = r.value;
		return n.has(a) || r.issues.push({
			code: "invalid_value",
			values: t.values,
			input: a,
			inst: e
		}), r;
	};
}), yn = /* @__PURE__ */ e("$ZodTransform", (e, r) => {
	M.init(e, r), e._zod.parse = (i, a) => {
		if (a.direction === "backward") throw new n(e.constructor.name);
		let o = r.transform(i.value, i);
		if (a.async) return (o instanceof Promise ? o : Promise.resolve(o)).then((e) => (i.value = e, i));
		if (o instanceof Promise) throw new t();
		return i.value = o, i;
	};
});
function bn(e, t) {
	return e.issues.length && t === void 0 ? {
		issues: [],
		value: void 0
	} : e;
}
var xn = /* @__PURE__ */ e("$ZodOptional", (e, t) => {
	M.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", f(e._zod, "values", () => t.innerType._zod.values ? new Set([...t.innerType._zod.values, void 0]) : void 0), f(e._zod, "pattern", () => {
		let e = t.innerType._zod.pattern;
		return e ? RegExp(`^(${l(e.source)})?$`) : void 0;
	}), e._zod.parse = (e, n) => {
		if (t.innerType._zod.optin === "optional") {
			let r = t.innerType._zod.run(e, n);
			return r instanceof Promise ? r.then((t) => bn(t, e.value)) : bn(r, e.value);
		}
		return e.value === void 0 ? e : t.innerType._zod.run(e, n);
	};
}), Sn = /* @__PURE__ */ e("$ZodExactOptional", (e, t) => {
	xn.init(e, t), f(e._zod, "values", () => t.innerType._zod.values), f(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (e, n) => t.innerType._zod.run(e, n);
}), Cn = /* @__PURE__ */ e("$ZodNullable", (e, t) => {
	M.init(e, t), f(e._zod, "optin", () => t.innerType._zod.optin), f(e._zod, "optout", () => t.innerType._zod.optout), f(e._zod, "pattern", () => {
		let e = t.innerType._zod.pattern;
		return e ? RegExp(`^(${l(e.source)}|null)$`) : void 0;
	}), f(e._zod, "values", () => t.innerType._zod.values ? new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (e, n) => e.value === null ? e : t.innerType._zod.run(e, n);
}), wn = /* @__PURE__ */ e("$ZodDefault", (e, t) => {
	M.init(e, t), e._zod.optin = "optional", f(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		if (e.value === void 0) return e.value = t.defaultValue, e;
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => Tn(e, t)) : Tn(r, t);
	};
});
function Tn(e, t) {
	return e.value === void 0 && (e.value = t.defaultValue), e;
}
var En = /* @__PURE__ */ e("$ZodPrefault", (e, t) => {
	M.init(e, t), e._zod.optin = "optional", f(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (e, n) => (n.direction === "backward" || e.value === void 0 && (e.value = t.defaultValue), t.innerType._zod.run(e, n));
}), Dn = /* @__PURE__ */ e("$ZodNonOptional", (e, t) => {
	M.init(e, t), f(e._zod, "values", () => {
		let e = t.innerType._zod.values;
		return e ? new Set([...e].filter((e) => e !== void 0)) : void 0;
	}), e._zod.parse = (n, r) => {
		let i = t.innerType._zod.run(n, r);
		return i instanceof Promise ? i.then((t) => On(t, e)) : On(i, e);
	};
});
function On(e, t) {
	return !e.issues.length && e.value === void 0 && e.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: e.value,
		inst: t
	}), e;
}
var kn = /* @__PURE__ */ e("$ZodCatch", (e, t) => {
	M.init(e, t), f(e._zod, "optin", () => t.innerType._zod.optin), f(e._zod, "optout", () => t.innerType._zod.optout), f(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((r) => (e.value = r.value, r.issues.length && (e.value = t.catchValue({
			...e,
			error: { issues: r.issues.map((e) => C(e, n, i())) },
			input: e.value
		}), e.issues = []), e)) : (e.value = r.value, r.issues.length && (e.value = t.catchValue({
			...e,
			error: { issues: r.issues.map((e) => C(e, n, i())) },
			input: e.value
		}), e.issues = []), e);
	};
}), An = /* @__PURE__ */ e("$ZodPipe", (e, t) => {
	M.init(e, t), f(e._zod, "values", () => t.in._zod.values), f(e._zod, "optin", () => t.in._zod.optin), f(e._zod, "optout", () => t.out._zod.optout), f(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (e, n) => {
		if (n.direction === "backward") {
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => L(e, t.in, n)) : L(r, t.in, n);
		}
		let r = t.in._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => L(e, t.out, n)) : L(r, t.out, n);
	};
});
function L(e, t, n) {
	return e.issues.length ? (e.aborted = !0, e) : t._zod.run({
		value: e.value,
		issues: e.issues
	}, n);
}
var jn = /* @__PURE__ */ e("$ZodReadonly", (e, t) => {
	M.init(e, t), f(e._zod, "propValues", () => t.innerType._zod.propValues), f(e._zod, "values", () => t.innerType._zod.values), f(e._zod, "optin", () => t.innerType?._zod?.optin), f(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then(Mn) : Mn(r);
	};
});
function Mn(e) {
	return e.value = Object.freeze(e.value), e;
}
var Nn = /* @__PURE__ */ e("$ZodCustom", (e, t) => {
	A.init(e, t), M.init(e, t), e._zod.parse = (e, t) => e, e._zod.check = (n) => {
		let r = n.value, i = t.fn(r);
		if (i instanceof Promise) return i.then((t) => Pn(t, n, r, e));
		Pn(i, n, r, e);
	};
});
function Pn(e, t, n, r) {
	if (!e) {
		let e = {
			code: "custom",
			input: n,
			inst: r,
			path: [...r._zod.def.path ?? []],
			continue: !r._zod.def.abort
		};
		r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(T(e));
	}
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/registries.js
var Fn, In = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
	}
	add(e, ...t) {
		let n = t[0];
		return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
	}
	clear() {
		return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
	}
	remove(e) {
		let t = this._map.get(e);
		return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this;
	}
	get(e) {
		let t = e._zod.parent;
		if (t) {
			let n = { ...this.get(t) ?? {} };
			delete n.id;
			let r = {
				...n,
				...this._map.get(e)
			};
			return Object.keys(r).length ? r : void 0;
		}
		return this._map.get(e);
	}
	has(e) {
		return this._map.has(e);
	}
};
function Ln() {
	return new In();
}
(Fn = globalThis).__zod_globalRegistry ?? (Fn.__zod_globalRegistry = Ln());
var R = globalThis.__zod_globalRegistry;
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/api.js
/* @__NO_SIDE_EFFECTS__ */
function Rn(e, t) {
	return new e({
		type: "string",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function zn(e, t) {
	return new e({
		type: "string",
		format: "email",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Bn(e, t) {
	return new e({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Vn(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Hn(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v4",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Un(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v6",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Wn(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v7",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Gn(e, t) {
	return new e({
		type: "string",
		format: "url",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Kn(e, t) {
	return new e({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function qn(e, t) {
	return new e({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Jn(e, t) {
	return new e({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Yn(e, t) {
	return new e({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Xn(e, t) {
	return new e({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Zn(e, t) {
	return new e({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Qn(e, t) {
	return new e({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function $n(e, t) {
	return new e({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function er(e, t) {
	return new e({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function tr(e, t) {
	return new e({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function nr(e, t) {
	return new e({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function rr(e, t) {
	return new e({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function ir(e, t) {
	return new e({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function ar(e, t) {
	return new e({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function or(e, t) {
	return new e({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: !1,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function sr(e, t) {
	return new e({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: !1,
		local: !1,
		precision: null,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function cr(e, t) {
	return new e({
		type: "string",
		format: "date",
		check: "string_format",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function lr(e, t) {
	return new e({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function ur(e, t) {
	return new e({
		type: "string",
		format: "duration",
		check: "string_format",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function dr(e, t) {
	return new e({
		type: "number",
		checks: [],
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function fr(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "safeint",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function pr(e, t) {
	return new e({
		type: "boolean",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function mr(e, t) {
	return new e({
		type: "null",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function hr(e) {
	return new e({ type: "unknown" });
}
/* @__NO_SIDE_EFFECTS__ */
function gr(e, t) {
	return new e({
		type: "never",
		...y(t)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function _r(e, t) {
	return new ut({
		check: "less_than",
		...y(t),
		value: e,
		inclusive: !1
	});
}
/* @__NO_SIDE_EFFECTS__ */
function z(e, t) {
	return new ut({
		check: "less_than",
		...y(t),
		value: e,
		inclusive: !0
	});
}
/* @__NO_SIDE_EFFECTS__ */
function vr(e, t) {
	return new dt({
		check: "greater_than",
		...y(t),
		value: e,
		inclusive: !1
	});
}
/* @__NO_SIDE_EFFECTS__ */
function B(e, t) {
	return new dt({
		check: "greater_than",
		...y(t),
		value: e,
		inclusive: !0
	});
}
/* @__NO_SIDE_EFFECTS__ */
function yr(e, t) {
	return new ft({
		check: "multiple_of",
		...y(t),
		value: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function br(e, t) {
	return new mt({
		check: "max_length",
		...y(t),
		maximum: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function V(e, t) {
	return new ht({
		check: "min_length",
		...y(t),
		minimum: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function xr(e, t) {
	return new gt({
		check: "length_equals",
		...y(t),
		length: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Sr(e, t) {
	return new _t({
		check: "string_format",
		format: "regex",
		...y(t),
		pattern: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Cr(e) {
	return new vt({
		check: "string_format",
		format: "lowercase",
		...y(e)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function wr(e) {
	return new yt({
		check: "string_format",
		format: "uppercase",
		...y(e)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Tr(e, t) {
	return new bt({
		check: "string_format",
		format: "includes",
		...y(t),
		includes: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Er(e, t) {
	return new xt({
		check: "string_format",
		format: "starts_with",
		...y(t),
		prefix: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Dr(e, t) {
	return new St({
		check: "string_format",
		format: "ends_with",
		...y(t),
		suffix: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function H(e) {
	return new Ct({
		check: "overwrite",
		tx: e
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Or(e) {
	return /* @__PURE__ */ H((t) => t.normalize(e));
}
/* @__NO_SIDE_EFFECTS__ */
function kr() {
	return /* @__PURE__ */ H((e) => e.trim());
}
/* @__NO_SIDE_EFFECTS__ */
function Ar() {
	return /* @__PURE__ */ H((e) => e.toLowerCase());
}
/* @__NO_SIDE_EFFECTS__ */
function jr() {
	return /* @__PURE__ */ H((e) => e.toUpperCase());
}
/* @__NO_SIDE_EFFECTS__ */
function Mr() {
	return /* @__PURE__ */ H((e) => te(e));
}
/* @__NO_SIDE_EFFECTS__ */
function Nr(e, t, n) {
	return new e({
		type: "array",
		element: t,
		...y(n)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Pr(e, t, n) {
	return new e({
		type: "custom",
		check: "custom",
		fn: t,
		...y(n)
	});
}
/* @__NO_SIDE_EFFECTS__ */
function Fr(e) {
	let t = /* @__PURE__ */ Ir((n) => (n.addIssue = (e) => {
		if (typeof e == "string") n.issues.push(T(e, n.value, t._zod.def));
		else {
			let r = e;
			r.fatal && (r.continue = !1), r.code ??= "custom", r.input ??= n.value, r.inst ??= t, r.continue ??= !t._zod.def.abort, n.issues.push(T(r));
		}
	}, e(n.value, n)));
	return t;
}
/* @__NO_SIDE_EFFECTS__ */
function Ir(e, t) {
	let n = new A({
		check: "custom",
		...y(t)
	});
	return n._zod.check = e, n;
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/to-json-schema.js
function Lr(e) {
	let t = e?.target ?? "draft-2020-12";
	return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
		processors: e.processors ?? {},
		metadataRegistry: e?.metadata ?? R,
		target: t,
		unrepresentable: e?.unrepresentable ?? "throw",
		override: e?.override ?? (() => {}),
		io: e?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		cycles: e?.cycles ?? "ref",
		reused: e?.reused ?? "inline",
		external: e?.external ?? void 0
	};
}
function U(e, t, n = {
	path: [],
	schemaPath: []
}) {
	var r;
	let i = e._zod.def, a = t.seen.get(e);
	if (a) return a.count++, n.schemaPath.includes(e) && (a.cycle = n.path), a.schema;
	let o = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: n.path
	};
	t.seen.set(e, o);
	let s = e._zod.toJSONSchema?.();
	if (s) o.schema = s;
	else {
		let r = {
			...n,
			schemaPath: [...n.schemaPath, e],
			path: n.path
		};
		if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, o.schema, r);
		else {
			let n = o.schema, a = t.processors[i.type];
			if (!a) throw Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
			a(e, t, n, r);
		}
		let a = e._zod.parent;
		a && (o.ref ||= a, U(a, t, r), t.seen.get(a).isParent = !0);
	}
	let c = t.metadataRegistry.get(e);
	return c && Object.assign(o.schema, c), t.io === "input" && W(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && o.schema._prefault && ((r = o.schema).default ?? (r.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function Rr(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = /* @__PURE__ */ new Map();
	for (let t of e.seen.entries()) {
		let n = e.metadataRegistry.get(t[0])?.id;
		if (n) {
			let e = r.get(n);
			if (e && e !== t[0]) throw Error(`Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			r.set(n, t[0]);
		}
	}
	let i = (t) => {
		let r = e.target === "draft-2020-12" ? "$defs" : "definitions";
		if (e.external) {
			let n = e.external.registry.get(t[0])?.id, i = e.external.uri ?? ((e) => e);
			if (n) return { ref: i(n) };
			let a = t[1].defId ?? t[1].schema.id ?? `schema${e.counter++}`;
			return t[1].defId = a, {
				defId: a,
				ref: `${i("__shared")}#/${r}/${a}`
			};
		}
		if (t[1] === n) return { ref: "#" };
		let i = `#/${r}/`, a = t[1].schema.id ?? `__schema${e.counter++}`;
		return {
			defId: a,
			ref: i + a
		};
	}, a = (e) => {
		if (e[1].schema.$ref) return;
		let t = e[1], { ref: n, defId: r } = i(e);
		t.def = { ...t.schema }, r && (t.defId = r);
		let a = t.schema;
		for (let e in a) delete a[e];
		a.$ref = n;
	};
	if (e.cycles === "throw") for (let t of e.seen.entries()) {
		let e = t[1];
		if (e.cycle) throw Error(`Cycle detected: #/${e.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (let n of e.seen.entries()) {
		let r = n[1];
		if (t === n[0]) {
			a(n);
			continue;
		}
		if (e.external) {
			let r = e.external.registry.get(n[0])?.id;
			if (t !== n[0] && r) {
				a(n);
				continue;
			}
		}
		if (e.metadataRegistry.get(n[0])?.id) {
			a(n);
			continue;
		}
		if (r.cycle) {
			a(n);
			continue;
		}
		if (r.count > 1 && e.reused === "ref") {
			a(n);
			continue;
		}
	}
}
function zr(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = (t) => {
		let n = e.seen.get(t);
		if (n.ref === null) return;
		let i = n.def ?? n.schema, a = { ...i }, o = n.ref;
		if (n.ref = null, o) {
			r(o);
			let n = e.seen.get(o), s = n.schema;
			if (s.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (i.allOf = i.allOf ?? [], i.allOf.push(s)) : Object.assign(i, s), Object.assign(i, a), t._zod.parent === o) for (let e in i) e === "$ref" || e === "allOf" || e in a || delete i[e];
			if (s.$ref && n.def) for (let e in i) e === "$ref" || e === "allOf" || e in n.def && JSON.stringify(i[e]) === JSON.stringify(n.def[e]) && delete i[e];
		}
		let s = t._zod.parent;
		if (s && s !== o) {
			r(s);
			let t = e.seen.get(s);
			if (t?.schema.$ref && (i.$ref = t.schema.$ref, t.def)) for (let e in i) e === "$ref" || e === "allOf" || e in t.def && JSON.stringify(i[e]) === JSON.stringify(t.def[e]) && delete i[e];
		}
		e.override({
			zodSchema: t,
			jsonSchema: i,
			path: n.path ?? []
		});
	};
	for (let t of [...e.seen.entries()].reverse()) r(t[0]);
	let i = {};
	if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
		let n = e.external.registry.get(t)?.id;
		if (!n) throw Error("Schema is missing an `id` property");
		i.$id = e.external.uri(n);
	}
	Object.assign(i, n.def ?? n.schema);
	let a = e.external?.defs ?? {};
	for (let t of e.seen.entries()) {
		let e = t[1];
		e.def && e.defId && (a[e.defId] = e.def);
	}
	e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? i.$defs = a : i.definitions = a);
	try {
		let n = JSON.parse(JSON.stringify(i));
		return Object.defineProperty(n, "~standard", {
			value: {
				...t["~standard"],
				jsonSchema: {
					input: G(t, "input", e.processors),
					output: G(t, "output", e.processors)
				}
			},
			enumerable: !1,
			writable: !1
		}), n;
	} catch {
		throw Error("Error converting schema to JSON.");
	}
}
function W(e, t) {
	let n = t ?? { seen: /* @__PURE__ */ new Set() };
	if (n.seen.has(e)) return !1;
	n.seen.add(e);
	let r = e._zod.def;
	if (r.type === "transform") return !0;
	if (r.type === "array") return W(r.element, n);
	if (r.type === "set") return W(r.valueType, n);
	if (r.type === "lazy") return W(r.getter(), n);
	if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault") return W(r.innerType, n);
	if (r.type === "intersection") return W(r.left, n) || W(r.right, n);
	if (r.type === "record" || r.type === "map") return W(r.keyType, n) || W(r.valueType, n);
	if (r.type === "pipe") return W(r.in, n) || W(r.out, n);
	if (r.type === "object") {
		for (let e in r.shape) if (W(r.shape[e], n)) return !0;
		return !1;
	}
	if (r.type === "union") {
		for (let e of r.options) if (W(e, n)) return !0;
		return !1;
	}
	if (r.type === "tuple") {
		for (let e of r.items) if (W(e, n)) return !0;
		return !!(r.rest && W(r.rest, n));
	}
	return !1;
}
var Br = (e, t = {}) => (n) => {
	let r = Lr({
		...n,
		processors: t
	});
	return U(e, r), Rr(r, e), zr(r, e);
}, G = (e, t, n = {}) => (r) => {
	let { libraryOptions: i, target: a } = r ?? {}, o = Lr({
		...i ?? {},
		target: a,
		io: t,
		processors: n
	});
	return U(e, o), Rr(o, e), zr(o, e);
}, Vr = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
}, Hr = (e, t, n, r) => {
	let i = n;
	i.type = "string";
	let { minimum: a, maximum: o, format: s, patterns: c, contentEncoding: l } = e._zod.bag;
	if (typeof a == "number" && (i.minLength = a), typeof o == "number" && (i.maxLength = o), s && (i.format = Vr[s] ?? s, i.format === "" && delete i.format, s === "time" && delete i.format), l && (i.contentEncoding = l), c && c.size > 0) {
		let e = [...c];
		e.length === 1 ? i.pattern = e[0].source : e.length > 1 && (i.allOf = [...e.map((e) => ({
			...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: e.source
		}))]);
	}
}, Ur = (e, t, n, r) => {
	let i = n, { minimum: a, maximum: o, format: s, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: u } = e._zod.bag;
	typeof s == "string" && s.includes("int") ? i.type = "integer" : i.type = "number", typeof u == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (i.minimum = u, i.exclusiveMinimum = !0) : i.exclusiveMinimum = u), typeof a == "number" && (i.minimum = a, typeof u == "number" && t.target !== "draft-04" && (u >= a ? delete i.minimum : delete i.exclusiveMinimum)), typeof l == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (i.maximum = l, i.exclusiveMaximum = !0) : i.exclusiveMaximum = l), typeof o == "number" && (i.maximum = o, typeof l == "number" && t.target !== "draft-04" && (l <= o ? delete i.maximum : delete i.exclusiveMaximum)), typeof c == "number" && (i.multipleOf = c);
}, Wr = (e, t, n, r) => {
	n.type = "boolean";
}, Gr = (e, t, n, r) => {
	t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, Kr = (e, t, n, r) => {
	n.not = {};
}, qr = (e, t, n, r) => {
	let i = e._zod.def, o = a(i.entries);
	o.every((e) => typeof e == "number") && (n.type = "number"), o.every((e) => typeof e == "string") && (n.type = "string"), n.enum = o;
}, Jr = (e, t, n, r) => {
	let i = e._zod.def, a = [];
	for (let e of i.values) if (e === void 0) {
		if (t.unrepresentable === "throw") throw Error("Literal `undefined` cannot be represented in JSON Schema");
	} else if (typeof e == "bigint") {
		if (t.unrepresentable === "throw") throw Error("BigInt literals cannot be represented in JSON Schema");
		a.push(Number(e));
	} else a.push(e);
	if (a.length !== 0) if (a.length === 1) {
		let e = a[0];
		n.type = e === null ? "null" : typeof e, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [e] : n.const = e;
	} else a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), a.every((e) => typeof e == "boolean") && (n.type = "boolean"), a.every((e) => e === null) && (n.type = "null"), n.enum = a;
}, Yr = (e, t, n, r) => {
	if (t.unrepresentable === "throw") throw Error("Custom types cannot be represented in JSON Schema");
}, Xr = (e, t, n, r) => {
	if (t.unrepresentable === "throw") throw Error("Transforms cannot be represented in JSON Schema");
}, Zr = (e, t, n, r) => {
	let i = n, a = e._zod.def, { minimum: o, maximum: s } = e._zod.bag;
	typeof o == "number" && (i.minItems = o), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = U(a.element, t, {
		...r,
		path: [...r.path, "items"]
	});
}, Qr = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "object", i.properties = {};
	let o = a.shape;
	for (let e in o) i.properties[e] = U(o[e], t, {
		...r,
		path: [
			...r.path,
			"properties",
			e
		]
	});
	let s = new Set(Object.keys(o)), c = new Set([...s].filter((e) => {
		let n = a.shape[e]._zod;
		return t.io === "input" ? n.optin === void 0 : n.optout === void 0;
	}));
	c.size > 0 && (i.required = Array.from(c)), a.catchall?._zod.def.type === "never" ? i.additionalProperties = !1 : a.catchall ? a.catchall && (i.additionalProperties = U(a.catchall, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	})) : t.io === "output" && (i.additionalProperties = !1);
}, $r = (e, t, n, r) => {
	let i = e._zod.def, a = i.inclusive === !1, o = i.options.map((e, n) => U(e, t, {
		...r,
		path: [
			...r.path,
			a ? "oneOf" : "anyOf",
			n
		]
	}));
	a ? n.oneOf = o : n.anyOf = o;
}, ei = (e, t, n, r) => {
	let i = e._zod.def, a = U(i.left, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			0
		]
	}), o = U(i.right, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			1
		]
	}), s = (e) => "allOf" in e && Object.keys(e).length === 1;
	n.allOf = [...s(a) ? a.allOf : [a], ...s(o) ? o.allOf : [o]];
}, ti = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "object";
	let o = a.keyType, s = o._zod.bag?.patterns;
	if (a.mode === "loose" && s && s.size > 0) {
		let e = U(a.valueType, t, {
			...r,
			path: [
				...r.path,
				"patternProperties",
				"*"
			]
		});
		i.patternProperties = {};
		for (let t of s) i.patternProperties[t.source] = e;
	} else (t.target === "draft-07" || t.target === "draft-2020-12") && (i.propertyNames = U(a.keyType, t, {
		...r,
		path: [...r.path, "propertyNames"]
	})), i.additionalProperties = U(a.valueType, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	});
	let c = o._zod.values;
	if (c) {
		let e = [...c].filter((e) => typeof e == "string" || typeof e == "number");
		e.length > 0 && (i.required = e);
	}
}, ni = (e, t, n, r) => {
	let i = e._zod.def, a = U(i.innerType, t, r), o = t.seen.get(e);
	t.target === "openapi-3.0" ? (o.ref = i.innerType, n.nullable = !0) : n.anyOf = [a, { type: "null" }];
}, ri = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, ii = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.default = JSON.parse(JSON.stringify(i.defaultValue));
}, ai = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, t.io === "input" && (n._prefault = JSON.parse(JSON.stringify(i.defaultValue)));
}, oi = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o;
	try {
		o = i.catchValue(void 0);
	} catch {
		throw Error("Dynamic catch values are not supported in JSON Schema");
	}
	n.default = o;
}, si = (e, t, n, r) => {
	let i = e._zod.def, a = t.io === "input" ? i.in._zod.def.type === "transform" ? i.out : i.in : i.out;
	U(a, t, r);
	let o = t.seen.get(e);
	o.ref = a;
}, ci = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.readOnly = !0;
}, li = (e, t, n, r) => {
	let i = e._zod.def;
	U(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, ui = /* @__PURE__ */ e("ZodISODateTime", (e, t) => {
	Lt.init(e, t), J.init(e, t);
});
function di(e) {
	return /* @__PURE__ */ sr(ui, e);
}
var fi = /* @__PURE__ */ e("ZodISODate", (e, t) => {
	Rt.init(e, t), J.init(e, t);
});
function pi(e) {
	return /* @__PURE__ */ cr(fi, e);
}
var mi = /* @__PURE__ */ e("ZodISOTime", (e, t) => {
	zt.init(e, t), J.init(e, t);
});
function hi(e) {
	return /* @__PURE__ */ lr(mi, e);
}
var gi = /* @__PURE__ */ e("ZodISODuration", (e, t) => {
	Bt.init(e, t), J.init(e, t);
});
function _i(e) {
	return /* @__PURE__ */ ur(gi, e);
}
//#endregion
//#region ../../node_modules/.bun/zod@4.3.6/node_modules/zod/v4/classic/errors.js
var vi = (e, t) => {
	ge.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
		format: { value: (t) => ye(e, t) },
		flatten: { value: (t) => ve(e, t) },
		addIssue: { value: (t) => {
			e.issues.push(t), e.message = JSON.stringify(e.issues, o, 2);
		} },
		addIssues: { value: (t) => {
			e.issues.push(...t), e.message = JSON.stringify(e.issues, o, 2);
		} },
		isEmpty: { get() {
			return e.issues.length === 0;
		} }
	});
};
e("ZodError", vi);
var K = e("ZodError", vi, { Parent: Error }), yi = /* @__PURE__ */ E(K), bi = /* @__PURE__ */ D(K), xi = /* @__PURE__ */ O(K), Si = /* @__PURE__ */ k(K), Ci = /* @__PURE__ */ we(K), wi = /* @__PURE__ */ Te(K), Ti = /* @__PURE__ */ Ee(K), Ei = /* @__PURE__ */ De(K), Di = /* @__PURE__ */ Oe(K), Oi = /* @__PURE__ */ ke(K), ki = /* @__PURE__ */ Ae(K), Ai = /* @__PURE__ */ je(K), q = /* @__PURE__ */ e("ZodType", (e, t) => (M.init(e, t), Object.assign(e["~standard"], { jsonSchema: {
	input: G(e, "input"),
	output: G(e, "output")
} }), e.toJSONSchema = Br(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.check = (...n) => e.clone(m(t, { checks: [...t.checks ?? [], ...n.map((e) => typeof e == "function" ? { _zod: {
	check: e,
	def: { check: "custom" },
	onattach: []
} } : e)] }), { parent: !0 }), e.with = e.check, e.clone = (t, n) => v(e, t, n), e.brand = () => e, e.register = ((t, n) => (t.add(e, n), e)), e.parse = (t, n) => yi(e, t, n, { callee: e.parse }), e.safeParse = (t, n) => xi(e, t, n), e.parseAsync = async (t, n) => bi(e, t, n, { callee: e.parseAsync }), e.safeParseAsync = async (t, n) => Si(e, t, n), e.spa = e.safeParseAsync, e.encode = (t, n) => Ci(e, t, n), e.decode = (t, n) => wi(e, t, n), e.encodeAsync = async (t, n) => Ti(e, t, n), e.decodeAsync = async (t, n) => Ei(e, t, n), e.safeEncode = (t, n) => Di(e, t, n), e.safeDecode = (t, n) => Oi(e, t, n), e.safeEncodeAsync = async (t, n) => ki(e, t, n), e.safeDecodeAsync = async (t, n) => Ai(e, t, n), e.refine = (t, n) => e.check(Ga(t, n)), e.superRefine = (t) => e.check(Ka(t)), e.overwrite = (t) => e.check(/* @__PURE__ */ H(t)), e.optional = () => Oa(e), e.exactOptional = () => Aa(e), e.nullable = () => Ma(e), e.nullish = () => Oa(Ma(e)), e.nonoptional = (t) => Ra(e, t), e.array = () => ua(e), e.or = (t) => ha([e, t]), e.and = (t) => ya(e, t), e.transform = (t) => $(e, Ea(t)), e.default = (t) => Pa(e, t), e.prefault = (t) => Ia(e, t), e.catch = (t) => Ba(e, t), e.pipe = (t) => $(e, t), e.readonly = () => Ua(e), e.describe = (t) => {
	let n = e.clone();
	return R.add(n, { description: t }), n;
}, Object.defineProperty(e, "description", {
	get() {
		return R.get(e)?.description;
	},
	configurable: !0
}), e.meta = (...t) => {
	if (t.length === 0) return R.get(e);
	let n = e.clone();
	return R.add(n, t[0]), n;
}, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e.apply = (t) => t(e), e)), ji = /* @__PURE__ */ e("_ZodString", (e, t) => {
	N.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Hr(e, t, n, r);
	let n = e._zod.bag;
	e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null, e.regex = (...t) => e.check(/* @__PURE__ */ Sr(...t)), e.includes = (...t) => e.check(/* @__PURE__ */ Tr(...t)), e.startsWith = (...t) => e.check(/* @__PURE__ */ Er(...t)), e.endsWith = (...t) => e.check(/* @__PURE__ */ Dr(...t)), e.min = (...t) => e.check(/* @__PURE__ */ V(...t)), e.max = (...t) => e.check(/* @__PURE__ */ br(...t)), e.length = (...t) => e.check(/* @__PURE__ */ xr(...t)), e.nonempty = (...t) => e.check(/* @__PURE__ */ V(1, ...t)), e.lowercase = (t) => e.check(/* @__PURE__ */ Cr(t)), e.uppercase = (t) => e.check(/* @__PURE__ */ wr(t)), e.trim = () => e.check(/* @__PURE__ */ kr()), e.normalize = (...t) => e.check(/* @__PURE__ */ Or(...t)), e.toLowerCase = () => e.check(/* @__PURE__ */ Ar()), e.toUpperCase = () => e.check(/* @__PURE__ */ jr()), e.slugify = () => e.check(/* @__PURE__ */ Mr());
}), Mi = /* @__PURE__ */ e("ZodString", (e, t) => {
	N.init(e, t), ji.init(e, t), e.email = (t) => e.check(/* @__PURE__ */ zn(Pi, t)), e.url = (t) => e.check(/* @__PURE__ */ Gn(Ii, t)), e.jwt = (t) => e.check(/* @__PURE__ */ or(Zi, t)), e.emoji = (t) => e.check(/* @__PURE__ */ Kn(Li, t)), e.guid = (t) => e.check(/* @__PURE__ */ Bn(Fi, t)), e.uuid = (t) => e.check(/* @__PURE__ */ Vn(Y, t)), e.uuidv4 = (t) => e.check(/* @__PURE__ */ Hn(Y, t)), e.uuidv6 = (t) => e.check(/* @__PURE__ */ Un(Y, t)), e.uuidv7 = (t) => e.check(/* @__PURE__ */ Wn(Y, t)), e.nanoid = (t) => e.check(/* @__PURE__ */ qn(Ri, t)), e.guid = (t) => e.check(/* @__PURE__ */ Bn(Fi, t)), e.cuid = (t) => e.check(/* @__PURE__ */ Jn(zi, t)), e.cuid2 = (t) => e.check(/* @__PURE__ */ Yn(Bi, t)), e.ulid = (t) => e.check(/* @__PURE__ */ Xn(Vi, t)), e.base64 = (t) => e.check(/* @__PURE__ */ rr(Ji, t)), e.base64url = (t) => e.check(/* @__PURE__ */ ir(Yi, t)), e.xid = (t) => e.check(/* @__PURE__ */ Zn(Hi, t)), e.ksuid = (t) => e.check(/* @__PURE__ */ Qn(Ui, t)), e.ipv4 = (t) => e.check(/* @__PURE__ */ $n(Wi, t)), e.ipv6 = (t) => e.check(/* @__PURE__ */ er(Gi, t)), e.cidrv4 = (t) => e.check(/* @__PURE__ */ tr(Ki, t)), e.cidrv6 = (t) => e.check(/* @__PURE__ */ nr(qi, t)), e.e164 = (t) => e.check(/* @__PURE__ */ ar(Xi, t)), e.datetime = (t) => e.check(di(t)), e.date = (t) => e.check(pi(t)), e.time = (t) => e.check(hi(t)), e.duration = (t) => e.check(_i(t));
});
function Ni(e) {
	return /* @__PURE__ */ Rn(Mi, e);
}
var J = /* @__PURE__ */ e("ZodStringFormat", (e, t) => {
	P.init(e, t), ji.init(e, t);
}), Pi = /* @__PURE__ */ e("ZodEmail", (e, t) => {
	Ot.init(e, t), J.init(e, t);
}), Fi = /* @__PURE__ */ e("ZodGUID", (e, t) => {
	Et.init(e, t), J.init(e, t);
}), Y = /* @__PURE__ */ e("ZodUUID", (e, t) => {
	Dt.init(e, t), J.init(e, t);
}), Ii = /* @__PURE__ */ e("ZodURL", (e, t) => {
	kt.init(e, t), J.init(e, t);
}), Li = /* @__PURE__ */ e("ZodEmoji", (e, t) => {
	At.init(e, t), J.init(e, t);
}), Ri = /* @__PURE__ */ e("ZodNanoID", (e, t) => {
	jt.init(e, t), J.init(e, t);
}), zi = /* @__PURE__ */ e("ZodCUID", (e, t) => {
	Mt.init(e, t), J.init(e, t);
}), Bi = /* @__PURE__ */ e("ZodCUID2", (e, t) => {
	Nt.init(e, t), J.init(e, t);
}), Vi = /* @__PURE__ */ e("ZodULID", (e, t) => {
	Pt.init(e, t), J.init(e, t);
}), Hi = /* @__PURE__ */ e("ZodXID", (e, t) => {
	Ft.init(e, t), J.init(e, t);
}), Ui = /* @__PURE__ */ e("ZodKSUID", (e, t) => {
	It.init(e, t), J.init(e, t);
}), Wi = /* @__PURE__ */ e("ZodIPv4", (e, t) => {
	Vt.init(e, t), J.init(e, t);
}), Gi = /* @__PURE__ */ e("ZodIPv6", (e, t) => {
	Ht.init(e, t), J.init(e, t);
}), Ki = /* @__PURE__ */ e("ZodCIDRv4", (e, t) => {
	Ut.init(e, t), J.init(e, t);
}), qi = /* @__PURE__ */ e("ZodCIDRv6", (e, t) => {
	Wt.init(e, t), J.init(e, t);
}), Ji = /* @__PURE__ */ e("ZodBase64", (e, t) => {
	Kt.init(e, t), J.init(e, t);
}), Yi = /* @__PURE__ */ e("ZodBase64URL", (e, t) => {
	Jt.init(e, t), J.init(e, t);
}), Xi = /* @__PURE__ */ e("ZodE164", (e, t) => {
	Yt.init(e, t), J.init(e, t);
}), Zi = /* @__PURE__ */ e("ZodJWT", (e, t) => {
	Zt.init(e, t), J.init(e, t);
}), Qi = /* @__PURE__ */ e("ZodNumber", (e, t) => {
	Qt.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Ur(e, t, n, r), e.gt = (t, n) => e.check(/* @__PURE__ */ vr(t, n)), e.gte = (t, n) => e.check(/* @__PURE__ */ B(t, n)), e.min = (t, n) => e.check(/* @__PURE__ */ B(t, n)), e.lt = (t, n) => e.check(/* @__PURE__ */ _r(t, n)), e.lte = (t, n) => e.check(/* @__PURE__ */ z(t, n)), e.max = (t, n) => e.check(/* @__PURE__ */ z(t, n)), e.int = (t) => e.check(ta(t)), e.safe = (t) => e.check(ta(t)), e.positive = (t) => e.check(/* @__PURE__ */ vr(0, t)), e.nonnegative = (t) => e.check(/* @__PURE__ */ B(0, t)), e.negative = (t) => e.check(/* @__PURE__ */ _r(0, t)), e.nonpositive = (t) => e.check(/* @__PURE__ */ z(0, t)), e.multipleOf = (t, n) => e.check(/* @__PURE__ */ yr(t, n)), e.step = (t, n) => e.check(/* @__PURE__ */ yr(t, n)), e.finite = () => e;
	let n = e._zod.bag;
	e.minValue = Math.max(n.minimum ?? -Infinity, n.exclusiveMinimum ?? -Infinity) ?? null, e.maxValue = Math.min(n.maximum ?? Infinity, n.exclusiveMaximum ?? Infinity) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? .5), e.isFinite = !0, e.format = n.format ?? null;
});
function $i(e) {
	return /* @__PURE__ */ dr(Qi, e);
}
var ea = /* @__PURE__ */ e("ZodNumberFormat", (e, t) => {
	$t.init(e, t), Qi.init(e, t);
});
function ta(e) {
	return /* @__PURE__ */ fr(ea, e);
}
var na = /* @__PURE__ */ e("ZodBoolean", (e, t) => {
	en.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Wr(e, t, n, r);
});
function ra(e) {
	return /* @__PURE__ */ pr(na, e);
}
var ia = /* @__PURE__ */ e("ZodNull", (e, t) => {
	tn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Gr(e, t, n, r);
});
function aa(e) {
	return /* @__PURE__ */ mr(ia, e);
}
var oa = /* @__PURE__ */ e("ZodUnknown", (e, t) => {
	nn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function X() {
	return /* @__PURE__ */ hr(oa);
}
var sa = /* @__PURE__ */ e("ZodNever", (e, t) => {
	rn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Kr(e, t, n, r);
});
function ca(e) {
	return /* @__PURE__ */ gr(sa, e);
}
var la = /* @__PURE__ */ e("ZodArray", (e, t) => {
	on.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Zr(e, t, n, r), e.element = t.element, e.min = (t, n) => e.check(/* @__PURE__ */ V(t, n)), e.nonempty = (t) => e.check(/* @__PURE__ */ V(1, t)), e.max = (t, n) => e.check(/* @__PURE__ */ br(t, n)), e.length = (t, n) => e.check(/* @__PURE__ */ xr(t, n)), e.unwrap = () => e.element;
});
function ua(e, t) {
	return /* @__PURE__ */ Nr(la, e, t);
}
var Z = /* @__PURE__ */ e("ZodObject", (e, t) => {
	un.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Qr(e, t, n, r), f(e, "shape", () => t.shape), e.keyof = () => Sa(Object.keys(e._zod.def.shape)), e.catchall = (t) => e.clone({
		...e._zod.def,
		catchall: t
	}), e.passthrough = () => e.clone({
		...e._zod.def,
		catchall: X()
	}), e.loose = () => e.clone({
		...e._zod.def,
		catchall: X()
	}), e.strict = () => e.clone({
		...e._zod.def,
		catchall: ca()
	}), e.strip = () => e.clone({
		...e._zod.def,
		catchall: void 0
	}), e.extend = (t) => ue(e, t), e.safeExtend = (t) => de(e, t), e.merge = (t) => fe(e, t), e.pick = (t) => ce(e, t), e.omit = (t) => le(e, t), e.partial = (...t) => pe(Da, e, t[0]), e.required = (...t) => me(La, e, t[0]);
});
function da(e, t) {
	return new Z({
		type: "object",
		shape: e ?? {},
		...y(t)
	});
}
function fa(e, t) {
	return new Z({
		type: "object",
		shape: e,
		catchall: ca(),
		...y(t)
	});
}
function pa(e, t) {
	return new Z({
		type: "object",
		shape: e,
		catchall: X(),
		...y(t)
	});
}
var ma = /* @__PURE__ */ e("ZodUnion", (e, t) => {
	fn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => $r(e, t, n, r), e.options = t.options;
});
function ha(e, t) {
	return new ma({
		type: "union",
		options: e,
		...y(t)
	});
}
var ga = /* @__PURE__ */ e("ZodDiscriminatedUnion", (e, t) => {
	ma.init(e, t), pn.init(e, t);
});
function _a(e, t, n) {
	return new ga({
		type: "union",
		options: t,
		discriminator: e,
		...y(n)
	});
}
var va = /* @__PURE__ */ e("ZodIntersection", (e, t) => {
	mn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ei(e, t, n, r);
});
function ya(e, t) {
	return new va({
		type: "intersection",
		left: e,
		right: t
	});
}
var ba = /* @__PURE__ */ e("ZodRecord", (e, t) => {
	gn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ti(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function xa(e, t, n) {
	return new ba({
		type: "record",
		keyType: e,
		valueType: t,
		...y(n)
	});
}
var Q = /* @__PURE__ */ e("ZodEnum", (e, t) => {
	_n.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => qr(e, t, n, r), e.enum = t.entries, e.options = Object.values(t.entries);
	let n = new Set(Object.keys(t.entries));
	e.extract = (e, r) => {
		let i = {};
		for (let r of e) if (n.has(r)) i[r] = t.entries[r];
		else throw Error(`Key ${r} not found in enum`);
		return new Q({
			...t,
			checks: [],
			...y(r),
			entries: i
		});
	}, e.exclude = (e, r) => {
		let i = { ...t.entries };
		for (let t of e) if (n.has(t)) delete i[t];
		else throw Error(`Key ${t} not found in enum`);
		return new Q({
			...t,
			checks: [],
			...y(r),
			entries: i
		});
	};
});
function Sa(e, t) {
	return new Q({
		type: "enum",
		entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
		...y(t)
	});
}
var Ca = /* @__PURE__ */ e("ZodLiteral", (e, t) => {
	vn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Jr(e, t, n, r), e.values = new Set(t.values), Object.defineProperty(e, "value", { get() {
		if (t.values.length > 1) throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return t.values[0];
	} });
});
function wa(e, t) {
	return new Ca({
		type: "literal",
		values: Array.isArray(e) ? e : [e],
		...y(t)
	});
}
var Ta = /* @__PURE__ */ e("ZodTransform", (e, t) => {
	yn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Xr(e, t, n, r), e._zod.parse = (r, i) => {
		if (i.direction === "backward") throw new n(e.constructor.name);
		r.addIssue = (n) => {
			if (typeof n == "string") r.issues.push(T(n, r.value, t));
			else {
				let t = n;
				t.fatal && (t.continue = !1), t.code ??= "custom", t.input ??= r.value, t.inst ??= e, r.issues.push(T(t));
			}
		};
		let a = t.transform(r.value, r);
		return a instanceof Promise ? a.then((e) => (r.value = e, r)) : (r.value = a, r);
	};
});
function Ea(e) {
	return new Ta({
		type: "transform",
		transform: e
	});
}
var Da = /* @__PURE__ */ e("ZodOptional", (e, t) => {
	xn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => li(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Oa(e) {
	return new Da({
		type: "optional",
		innerType: e
	});
}
var ka = /* @__PURE__ */ e("ZodExactOptional", (e, t) => {
	Sn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => li(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Aa(e) {
	return new ka({
		type: "optional",
		innerType: e
	});
}
var ja = /* @__PURE__ */ e("ZodNullable", (e, t) => {
	Cn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ni(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ma(e) {
	return new ja({
		type: "nullable",
		innerType: e
	});
}
var Na = /* @__PURE__ */ e("ZodDefault", (e, t) => {
	wn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ii(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Pa(e, t) {
	return new Na({
		type: "default",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : ie(t);
		}
	});
}
var Fa = /* @__PURE__ */ e("ZodPrefault", (e, t) => {
	En.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ai(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ia(e, t) {
	return new Fa({
		type: "prefault",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : ie(t);
		}
	});
}
var La = /* @__PURE__ */ e("ZodNonOptional", (e, t) => {
	Dn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ri(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ra(e, t) {
	return new La({
		type: "nonoptional",
		innerType: e,
		...y(t)
	});
}
var za = /* @__PURE__ */ e("ZodCatch", (e, t) => {
	kn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => oi(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Ba(e, t) {
	return new za({
		type: "catch",
		innerType: e,
		catchValue: typeof t == "function" ? t : () => t
	});
}
var Va = /* @__PURE__ */ e("ZodPipe", (e, t) => {
	An.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => si(e, t, n, r), e.in = t.in, e.out = t.out;
});
function $(e, t) {
	return new Va({
		type: "pipe",
		in: e,
		out: t
	});
}
var Ha = /* @__PURE__ */ e("ZodReadonly", (e, t) => {
	jn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => ci(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function Ua(e) {
	return new Ha({
		type: "readonly",
		innerType: e
	});
}
var Wa = /* @__PURE__ */ e("ZodCustom", (e, t) => {
	Nn.init(e, t), q.init(e, t), e._zod.processJSONSchema = (t, n, r) => Yr(e, t, n, r);
});
function Ga(e, t = {}) {
	return /* @__PURE__ */ Pr(Wa, e, t);
}
function Ka(e) {
	return /* @__PURE__ */ Fr(e);
}
function qa(e, t) {
	return $(Ea(e), t);
}
//#endregion
export { _a as a, $i as c, xa as d, fa as f, xe as g, X as h, ra as i, da as l, ha as m, aa as n, wa as o, Ni as p, ua as r, pa as s, Sa as t, qa as u };
