import { t as e } from "./chunk-C5e3QaDY.js";
import { a as t, c as n, f as r, g as i, i as a, l as o, m as s, n as c, o as l, p as u, r as d, s as f, t as p, u as m } from "./schemas-D8_brjAQ.js";
//#endregion
//#region ../../packages/shared/seeds.ts
var h = 7840;
function g(e) {
	return {
		daemon: e,
		gateway: e + 100,
		qdrant: e + 200,
		ces: e + 300,
		outboundProxy: e + 400,
		tcp: e + 500
	};
}
g(17e3), g(19e3), g(18e3), `${h}`, g(2e4), (/* @__PURE__ */ e(((e, t) => {
	t.exports = {};
})))();
//#endregion
//#region ../../packages/service-contracts/src/ingress.ts
var _ = [
	"cadet",
	"ngrok",
	"cloudflare",
	"tailscale"
], v = p([
	"local",
	"docker",
	"apple-container",
	"cloud",
	"custom",
	"baseten"
]), y = process.env.GATEWAY_PORT ? Number(process.env.GATEWAY_PORT) : 7830, b = o({
	assistantImage: u(),
	gatewayImage: u(),
	cesImage: u()
}), x = r({ memory: r({
	high: n().int().positive().optional(),
	max: n().int().positive().optional()
}).superRefine((e, t) => {
	e.high !== void 0 && e.max !== void 0 && e.high > e.max && t.addIssue({
		code: "custom",
		path: ["high"],
		message: `memory.high (${e.high}) must not exceed memory.max (${e.max})`
	});
}).optional() }), S = o({
	assistantId: u(),
	cloudAssistantId: u().optional(),
	cloudOrganizationId: u().optional(),
	name: u().optional(),
	hatchedAt: u().optional(),
	onboardedAt: u().optional(),
	watcherPid: n().optional(),
	machine: x.optional().catch(void 0)
}), C = {
	port: n(),
	daemonPort: n().optional(),
	cesPort: n().optional()
}, w = S.extend({
	...C,
	instanceDir: u().optional(),
	cloud: l("local")
}), T = S.extend({
	...C,
	cloud: l("docker"),
	containerInfo: b.optional()
}), E = S.extend({
	...C,
	cloud: l("apple-container"),
	mgmtSocket: u()
}), D = S.extend({ cloud: l("cloud") }), O = S.extend({
	cloud: l("custom"),
	ipAddress: u(),
	port: n()
}), k = S.extend({
	cloud: l("baseten"),
	sandboxUrl: u(),
	port: n(),
	previewUrl: u().optional()
});
function A(e) {
	if (typeof e != "object" || !e) return e;
	let t = e, n = t.cloud;
	if (typeof n == "string" && v.safeParse(n).success || (t = {
		...t,
		cloud: "local"
	}), t.port === void 0) {
		let e = t.resources, n = e && typeof e == "object" ? e.gatewayPort : void 0;
		t = {
			...t,
			port: typeof n == "number" ? n : y
		};
	}
	return t;
}
var j = m(A, t("cloud", [
	w,
	T,
	E,
	D,
	O,
	k
])), M = o({
	pid: n(),
	provider: p(_),
	startedAt: u(),
	publicUrl: u().optional()
}), N = o({
	pid: n().optional(),
	startedAt: u().optional(),
	port: n()
});
f({
	assistants: d(j.nullable().catch(null)).catch([]).transform((e) => e.filter((e) => e !== null)),
	activeAssistant: s([u(), c()]).catch(null),
	tunnel: M.optional().catch(void 0),
	app: N.optional().catch(void 0)
});
//#endregion
//#region src/assistant/resolution-contract.ts
function P(e) {
	if (/[\\\u0000-\u0020]/.test(e) || e.startsWith("//") || !e.startsWith("/") && !/^https?:\/\//i.test(e) && e.includes(":") || /(?:^|\/)(?:\.|%2e){1,2}(?:\/|$)/i.test(e)) return !1;
	try {
		let t = new URL(e, "https://app.example");
		return t.username || t.password || t.search || t.hash ? !1 : e.startsWith("/") || t.protocol === "https:" || t.protocol === "http:" && [
			"localhost",
			"127.0.0.1",
			"[::1]"
		].includes(t.hostname);
	} catch {
		return !1;
	}
}
var F = u().min(1).refine(P, "Expected a public host URL without credentials or query parameters."), I = o({
	id: u().min(1),
	version: u().min(1)
}), L = o({
	id: u().min(1),
	name: u().nullish().transform((e) => e?.trim() || "New Assistant"),
	avatar_url: u().nullish(),
	created: u().nullish(),
	remote: v.nullish().catch(() => void 0),
	allow_admin_access: a().nullish().catch(() => void 0)
}), R = t("status", [
	o({
		status: l("ready"),
		assistant: I
	}),
	o({ status: l("notReady") }),
	o({ status: l("unavailable") }),
	o({ status: l("selection") }),
	o({ status: l("empty") }),
	o({ status: l("unauthenticated") })
]), z = t("status", [
	o({
		status: l("selection"),
		assistants: d(L)
	}),
	o({ status: l("empty") }),
	o({ status: l("unauthenticated") })
]), B = o({
	source: l("mycadet-web-nav"),
	nav: p([
		"push",
		"replace",
		"pop"
	]),
	path: u()
}), V = o({
	source: l("mycadet-web-host-nav"),
	path: u()
});
//#endregion
//#region src/assistant/resolve-assistant.ts
function H(e, t) {
	let n = e.safeParse(t);
	if (!n.success) throw Error(`Invalid assistant API data.\n${i(n.error)}`);
	return n.data;
}
var U = Symbol("unauthenticated"), W = Symbol("not ready"), G = Symbol("unavailable");
function K({ apiBaseUrl: e = "/", signal: t }) {
	let n = window.location.origin, r = new URL(H(F, e), n);
	r.pathname = r.pathname.replace(/\/*$/, "/");
	let i = new Headers({ Accept: "application/json" });
	async function a(e) {
		t.throwIfAborted();
		let n = new URL(e, r), a = await fetch(n, {
			headers: i,
			signal: t,
			credentials: "include"
		});
		if (t.throwIfAborted(), a.status === 401) return U;
		if (a.status === 409) return W;
		if (a.status === 410) return G;
		if (!a.ok) throw console.error(`Assistant request failed: ${a.status} ${a.headers.get("content-type") ?? ""} from ${n.href}`), Error(`Assistant request failed: ${a.status} from ${n.href}`);
		let o = await a.json().catch((e) => {
			throw console.error(`Assistant response was not JSON from ${n.href}: ${e}`), e;
		});
		return t.throwIfAborted(), o;
	}
	return {
		base: r,
		get: a
	};
}
async function q(e) {
	let t = await K(e).get("v1/assistants/");
	return t === U ? { status: "unauthenticated" } : H(z, t);
}
async function J(e) {
	let t = await K(e).get(e.assistantId ? `v1/assistants/${encodeURIComponent(e.assistantId)}/` : "v1/assistant");
	return t === U ? { status: "unauthenticated" } : t === W ? { status: "notReady" } : t === G ? { status: "unavailable" } : H(R, t);
}
//#endregion
export { V as a, R as i, J as n, v as o, B as r, q as t };
