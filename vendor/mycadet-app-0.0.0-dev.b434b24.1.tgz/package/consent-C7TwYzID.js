//#region src/i18n/locales/zh/consent.json
var e = {
	whatsChanged: "更新内容",
	agreements: "协议",
	agreeTo: "我同意<0>{policy}</0>"
}, t = {
	continue: "继续",
	logOut: "注销"
}, n = {
	consentControls: e,
	actions: t
};
//#endregion
export { t as actions, e as consentControls, n as default };
