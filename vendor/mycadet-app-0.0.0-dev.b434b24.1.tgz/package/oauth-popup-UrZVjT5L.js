//#region src/lib/auth/oauth-popup.ts
function e(e) {
	return `cadet:oauth-complete:${e}`;
}
//#endregion
export { e as t };
