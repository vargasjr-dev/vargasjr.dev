import { t as e } from "./describe-error-DsSgTDeO.js";
import { t } from "./resolve-assistant-g0zYJ1Fn.js";
import { useEffect as n, useState as r } from "react";
//#region src/assistant/use-assistant-choices.ts
function i() {
	let [i, a] = r(0), o = JSON.stringify([i]), [s, c] = r();
	return n(() => {
		let n = new AbortController(), r = (e) => c({
			key: o,
			state: e
		});
		r({ status: "loading" });
		let i = setTimeout(() => {
			console.error("Assistant list request timed out after 10s"), n.abort(), r({ status: "error" });
		}, 1e4);
		return Promise.resolve().then(() => {
			if (!n.signal.aborted) return t({
				apiBaseUrl: "/",
				signal: n.signal
			});
		}).then((e) => {
			n.signal.aborted || e === void 0 || (clearTimeout(i), r(e));
		}, (t) => {
			n.signal.aborted || (console.error(`Assistant list request failed: ${e(t)}`), clearTimeout(i), r({ status: "error" }));
		}), () => {
			clearTimeout(i), n.abort();
		};
	}, [i, o]), {
		state: s?.key === o ? s.state : { status: "loading" },
		retry: () => a((e) => e + 1)
	};
}
//#endregion
export { i as t };
