import { n as e, o as t } from "./dist-CB0DYkRa.js";
import { jsx as n } from "react/jsx-runtime";
//#region ../../packages/design-library/src/components/typography.tsx
var r = {
	"title-large": "text-title-large",
	"title-medium": "text-title-medium",
	"title-small": "text-title-small",
	"body-large-lighter": "text-body-large-lighter",
	"body-large-default": "text-body-large-default",
	"body-medium-lighter": "text-body-medium-lighter",
	"body-medium-default": "text-body-medium-default",
	"body-small-lighter": "text-body-small-lighter",
	"body-small-default": "text-body-small-default",
	"body-small-emphasised": "text-body-small-emphasised",
	"label-medium-default": "text-label-medium-default",
	"label-small-default": "text-label-small-default",
	chat: "text-chat"
};
function i({ variant: i, as: a = "span", className: o, children: s, ref: c, asChild: l = !1, ...u }) {
	return /* @__PURE__ */ n(l ? e : a, {
		...u,
		ref: c,
		"data-slot": "typography",
		className: t(r[i], o),
		children: s
	});
}
//#endregion
export { i as t };
