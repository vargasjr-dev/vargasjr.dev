import { n as e } from "./dist-BTjb3IwJ.js";
//#region ../../node_modules/.bun/@capacitor+app@8.1.0+33da1c2fb16abc29/node_modules/@capacitor/app/dist/esm/web.js
var t = class extends e {
	constructor() {
		super(), this.handleVisibilityChange = () => {
			let e = { isActive: document.hidden !== !0 };
			this.notifyListeners("appStateChange", e), document.hidden ? this.notifyListeners("pause", null) : this.notifyListeners("resume", null);
		}, document.addEventListener("visibilitychange", this.handleVisibilityChange, !1);
	}
	exitApp() {
		throw this.unimplemented("Not implemented on web.");
	}
	async getInfo() {
		throw this.unimplemented("Not implemented on web.");
	}
	async getLaunchUrl() {
		return { url: "" };
	}
	async getState() {
		return { isActive: document.hidden !== !0 };
	}
	async minimizeApp() {
		throw this.unimplemented("Not implemented on web.");
	}
	async toggleBackButtonHandler() {
		throw this.unimplemented("Not implemented on web.");
	}
	async getAppLanguage() {
		return { value: navigator.language.split("-")[0].toLowerCase() };
	}
};
//#endregion
export { t as AppWeb };
