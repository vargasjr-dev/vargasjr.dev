import { t as e } from "./electron-bridge-VOSuV45z.js";
//#region src/lib/auth/auth-endpoint.ts
function t(t) {
	return e() ? new URL(`/_allauth/app/v1/${t}`, window.location.origin).href : `/_allauth/browser/v1/${t}`;
}
//#endregion
//#region src/lib/auth/csrf.ts
function n() {
	return document.cookie.split("; ").findLast((e) => e.startsWith("__Secure-csrftoken="))?.split("=").slice(1).join("=");
}
var r;
async function i() {
	n() || (r ??= (async () => {
		for (let e = 0; e < 2; e++) try {
			if (await fetch(t("auth/session"), { credentials: "same-origin" }), n()) return;
		} catch {
			e === 0 && await new Promise((e) => setTimeout(e, 500));
		}
	})().finally(() => {
		r = void 0;
	}), await r);
}
//#endregion
//#region src/runtime/session-token.ts
function a() {
	return e()?.auth?.getSessionToken?.() ?? null;
}
//#endregion
export { t as i, i as n, n as r, a as t };
