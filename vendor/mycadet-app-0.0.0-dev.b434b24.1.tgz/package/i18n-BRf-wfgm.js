import { createContext as e, useContext as t, useEffect as n, useMemo as r } from "react";
import { jsx as i } from "react/jsx-runtime";
import { Trans as a, useTranslation as o } from "react-i18next";
//#region ../../node_modules/.bun/i18next@26.3.6+1fb4c65d43e298b9/node_modules/i18next/dist/esm/i18next.js
var s = (e) => typeof e == "string", c = () => {
	let e, t, n = new Promise((n, r) => {
		e = n, t = r;
	});
	return n.resolve = e, n.reject = t, n;
}, l = (e) => e == null ? "" : String(e), u = (e, t, n) => {
	e.forEach((e) => {
		t[e] && (n[e] = t[e]);
	});
}, d = /###/g, f = (e) => e && e.includes("###") ? e.replace(d, ".") : e, p = (e) => !e || s(e), m = (e, t, n) => {
	let r = s(t) ? t.split(".") : t, i = 0;
	for (; i < r.length - 1;) {
		if (p(e)) return {};
		let t = f(r[i]);
		!e[t] && n && (e[t] = new n()), e = Object.prototype.hasOwnProperty.call(e, t) ? e[t] : {}, ++i;
	}
	return p(e) ? {} : {
		obj: e,
		k: f(r[i])
	};
}, h = (e, t, n) => {
	let { obj: r, k: i } = m(e, t, Object);
	if (r !== void 0 || t.length === 1) {
		r[i] = n;
		return;
	}
	let a = t[t.length - 1], o = t.slice(0, t.length - 1), s = m(e, o, Object);
	for (; s.obj === void 0 && o.length;) a = `${o[o.length - 1]}.${a}`, o = o.slice(0, o.length - 1), s = m(e, o, Object), s?.obj && s.obj[`${s.k}.${a}`] !== void 0 && (s.obj = void 0);
	s.obj[`${s.k}.${a}`] = n;
}, g = (e, t, n, r) => {
	let { obj: i, k: a } = m(e, t, Object);
	i[a] = i[a] || [], i[a].push(n);
}, _ = (e, t) => {
	let { obj: n, k: r } = m(e, t);
	if (n && Object.prototype.hasOwnProperty.call(n, r)) return n[r];
}, ee = (e, t, n) => {
	let r = _(e, n);
	return r === void 0 ? _(t, n) : r;
}, v = (e, t, n) => {
	for (let r in t) r !== "__proto__" && r !== "constructor" && (Object.prototype.hasOwnProperty.call(e, r) ? s(e[r]) || e[r] instanceof String || s(t[r]) || t[r] instanceof String ? n && (e[r] = t[r]) : v(e[r], t[r], n) : e[r] = t[r]);
	return e;
}, y = (e) => e.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"), b = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;"
}, x = (e) => s(e) ? e.replace(/[&<>"'\/]/g, (e) => b[e]) : e, te = class {
	constructor(e) {
		this.capacity = e, this.regExpMap = /* @__PURE__ */ new Map(), this.regExpQueue = [];
	}
	getRegExp(e) {
		let t = this.regExpMap.get(e);
		if (t !== void 0) return t;
		let n = new RegExp(e);
		return this.regExpQueue.length === this.capacity && this.regExpMap.delete(this.regExpQueue.shift()), this.regExpMap.set(e, n), this.regExpQueue.push(e), n;
	}
}, ne = [
	" ",
	",",
	"?",
	"!",
	";"
], S = new te(20), C = (e, t, n) => {
	t ||= "", n ||= "";
	let r = ne.filter((e) => !t.includes(e) && !n.includes(e));
	if (r.length === 0) return !0;
	let i = S.getRegExp(`(${r.map((e) => e === "?" ? "\\?" : e).join("|")})`), a = !i.test(e);
	if (!a) {
		let t = e.indexOf(n);
		t > 0 && !i.test(e.substring(0, t)) && (a = !0);
	}
	return a;
}, w = (e, t, n = ".") => {
	if (!e) return;
	if (e[t]) return Object.prototype.hasOwnProperty.call(e, t) ? e[t] : void 0;
	let r = t.split(n), i = e;
	for (let e = 0; e < r.length;) {
		if (!i || typeof i != "object") return;
		let t, a = "";
		for (let o = e; o < r.length; ++o) if (o !== e && (a += n), a += r[o], t = i[a], t !== void 0) {
			if ([
				"string",
				"number",
				"boolean"
			].includes(typeof t) && o < r.length - 1) continue;
			e += o - e + 1;
			break;
		}
		i = t;
	}
	return i;
}, T = (e) => e?.replace(/_/g, "-"), re = {
	type: "logger",
	log(e) {
		this.output("log", e);
	},
	warn(e) {
		this.output("warn", e);
	},
	error(e) {
		this.output("error", e);
	},
	output(e, t) {
		console?.[e]?.apply?.(console, t);
	}
}, E = new class e {
	constructor(e, t = {}) {
		this.init(e, t);
	}
	init(e, t = {}) {
		this.prefix = t.prefix || "i18next:", this.logger = e || re, this.options = t, this.debug = t.debug;
	}
	log(...e) {
		return this.forward(e, "log", "", !0);
	}
	warn(...e) {
		return this.forward(e, "warn", "", !0);
	}
	error(...e) {
		return this.forward(e, "error", "");
	}
	deprecate(...e) {
		return this.forward(e, "warn", "WARNING DEPRECATED: ", !0);
	}
	forward(e, t, n, r) {
		return r && !this.debug ? null : (e = e.map((e) => s(e) ? e.replace(/[\r\n\x00-\x1F\x7F]/g, " ") : e), s(e[0]) && (e[0] = `${n}${this.prefix} ${e[0]}`), this.logger[t](e));
	}
	create(t) {
		return new e(this.logger, {
			prefix: `${this.prefix}:${t}:`,
			...this.options
		});
	}
	clone(t) {
		return t ||= this.options, t.prefix = t.prefix || this.prefix, new e(this.logger, t);
	}
}(), D = class {
	constructor() {
		this.observers = {};
	}
	on(e, t) {
		return e.split(" ").forEach((e) => {
			this.observers[e] || (this.observers[e] = /* @__PURE__ */ new Map());
			let n = this.observers[e].get(t) || 0;
			this.observers[e].set(t, n + 1);
		}), this;
	}
	off(e, t) {
		if (this.observers[e]) {
			if (!t) {
				delete this.observers[e];
				return;
			}
			this.observers[e].delete(t);
		}
	}
	once(e, t) {
		let n = (...r) => {
			t(...r), this.off(e, n);
		};
		return this.on(e, n), this;
	}
	emit(e, ...t) {
		this.observers[e] && Array.from(this.observers[e].entries()).forEach(([e, n]) => {
			for (let r = 0; r < n; r++) e(...t);
		}), this.observers["*"] && Array.from(this.observers["*"].entries()).forEach(([n, r]) => {
			for (let i = 0; i < r; i++) n(e, ...t);
		});
	}
}, ie = class extends D {
	constructor(e, t = {
		ns: ["translation"],
		defaultNS: "translation"
	}) {
		super(), this.data = e || {}, this.options = t, this.options.keySeparator === void 0 && (this.options.keySeparator = "."), this.options.ignoreJSONStructure === void 0 && (this.options.ignoreJSONStructure = !0);
	}
	addNamespaces(e) {
		this.options.ns.includes(e) || this.options.ns.push(e);
	}
	removeNamespaces(e) {
		let t = this.options.ns.indexOf(e);
		t > -1 && this.options.ns.splice(t, 1);
	}
	getResource(e, t, n, r = {}) {
		let i = r.keySeparator === void 0 ? this.options.keySeparator : r.keySeparator, a = r.ignoreJSONStructure === void 0 ? this.options.ignoreJSONStructure : r.ignoreJSONStructure, o;
		e.includes(".") ? o = e.split(".") : (o = [e, t], n && (Array.isArray(n) ? o.push(...n) : s(n) && i ? o.push(...n.split(i)) : o.push(n)));
		let c = _(this.data, o);
		return !c && !t && !n && e.includes(".") && (e = o[0], t = o[1], n = o.slice(2).join(".")), c || !a || !s(n) ? c : w(this.data?.[e]?.[t], n, i);
	}
	addResource(e, t, n, r, i = { silent: !1 }) {
		let a = i.keySeparator === void 0 ? this.options.keySeparator : i.keySeparator, o = [e, t];
		n && (o = o.concat(a ? n.split(a) : n)), e.includes(".") && (o = e.split("."), r = t, t = o[1]), this.addNamespaces(t), h(this.data, o, r), i.silent || this.emit("added", e, t, n, r);
	}
	addResources(e, t, n, r = { silent: !1 }) {
		for (let r in n) (s(n[r]) || Array.isArray(n[r])) && this.addResource(e, t, r, n[r], { silent: !0 });
		r.silent || this.emit("added", e, t, n);
	}
	addResourceBundle(e, t, n, r, i, a = {
		silent: !1,
		skipCopy: !1
	}) {
		let o = [e, t];
		e.includes(".") && (o = e.split("."), r = n, n = t, t = o[1]), this.addNamespaces(t);
		let s = _(this.data, o) || {};
		a.skipCopy || (n = JSON.parse(JSON.stringify(n))), r ? v(s, n, i) : s = {
			...s,
			...n
		}, h(this.data, o, s), a.silent || this.emit("added", e, t, n);
	}
	removeResourceBundle(e, t) {
		this.hasResourceBundle(e, t) && delete this.data[e][t], this.removeNamespaces(t), this.emit("removed", e, t);
	}
	hasResourceBundle(e, t) {
		return this.getResource(e, t) !== void 0;
	}
	getResourceBundle(e, t) {
		return t ||= this.options.defaultNS, this.getResource(e, t);
	}
	getDataByLanguage(e) {
		return this.data[e];
	}
	hasLanguageSomeTranslations(e) {
		let t = this.getDataByLanguage(e);
		return !!(t && Object.keys(t) || []).find((e) => t[e] && Object.keys(t[e]).length > 0);
	}
	toJSON() {
		return this.data;
	}
}, ae = {
	processors: {},
	addPostProcessor(e) {
		this.processors[e.name] = e;
	},
	handle(e, t, n, r, i) {
		return e.forEach((e) => {
			t = this.processors[e]?.process(t, n, r, i) ?? t;
		}), t;
	}
}, oe = Symbol("i18next/PATH_KEY");
function se() {
	let e = [], t = Object.create(null), n;
	return t.get = (r, i) => (n?.revoke?.(), i === oe ? e : (e.push(i), n = Proxy.revocable(r, t), n.proxy)), Proxy.revocable(Object.create(null), t).proxy;
}
function O(e, t) {
	let { [oe]: n } = e(se()), r = t?.keySeparator ?? ".", i = t?.nsSeparator ?? ":", a = t?.enableSelector === "strict";
	if (n.length > 1 && i) {
		let e = t?.ns, o = a ? Array.isArray(e) ? e : e ? [e] : null : Array.isArray(e) ? e : null;
		if (o && (a ? o : o.length > 1 ? o.slice(1) : []).includes(n[0])) return `${n[0]}${i}${n.slice(1).join(r)}`;
	}
	return n.join(r);
}
var ce = (e) => !s(e) && typeof e != "boolean" && typeof e != "number", le = class e extends D {
	constructor(e, t = {}) {
		super(), u([
			"resourceStore",
			"languageUtils",
			"pluralResolver",
			"interpolator",
			"backendConnector",
			"i18nFormat",
			"utils"
		], e, this), this.options = t, this.options.keySeparator === void 0 && (this.options.keySeparator = "."), this.logger = E.create("translator"), this.checkedLoadedFor = {};
	}
	changeLanguage(e) {
		e && (this.language = e);
	}
	exists(e, t = { interpolation: {} }) {
		let n = { ...t };
		if (e == null) return !1;
		let r = this.resolve(e, n);
		if (r?.res === void 0) return !1;
		let i = ce(r.res);
		return !(n.returnObjects === !1 && i);
	}
	extractFromKey(e, t) {
		let n = t.nsSeparator === void 0 ? this.options.nsSeparator : t.nsSeparator;
		n === void 0 && (n = ":");
		let r = t.keySeparator === void 0 ? this.options.keySeparator : t.keySeparator, i = t.ns || this.options.defaultNS || [], a = n && e.includes(n), o = !this.options.userDefinedKeySeparator && !t.keySeparator && !this.options.userDefinedNsSeparator && !t.nsSeparator && !C(e, n, r);
		if (a && !o) {
			let t = e.match(this.interpolator.nestingRegexp);
			if (t && t.length > 0) return {
				key: e,
				namespaces: s(i) ? [i] : i
			};
			let a = e.split(n);
			(n !== r || n === r && this.options.ns.includes(a[0])) && (i = a.shift()), e = a.join(r);
		}
		return {
			key: e,
			namespaces: s(i) ? [i] : i
		};
	}
	translate(t, n, r) {
		let i = typeof n == "object" ? { ...n } : n;
		if (typeof i != "object" && this.options.overloadTranslationOptionHandler && (i = this.options.overloadTranslationOptionHandler(arguments)), typeof i == "object" && (i = { ...i }), i ||= {}, t == null) return "";
		typeof t == "function" && (t = O(t, {
			...this.options,
			...i
		})), Array.isArray(t) || (t = [String(t)]), t = t.map((e) => typeof e == "function" ? O(e, {
			...this.options,
			...i
		}) : String(e));
		let a = i.returnDetails === void 0 ? this.options.returnDetails : i.returnDetails, o = i.keySeparator === void 0 ? this.options.keySeparator : i.keySeparator, { key: c, namespaces: l } = this.extractFromKey(t[t.length - 1], i), u = l[l.length - 1], d = i.nsSeparator === void 0 ? this.options.nsSeparator : i.nsSeparator;
		d === void 0 && (d = ":");
		let f = i.lng || this.language, p = i.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
		if (f?.toLowerCase() === "cimode") return p ? a ? {
			res: `${u}${d}${c}`,
			usedKey: c,
			exactUsedKey: c,
			usedLng: f,
			usedNS: u,
			usedParams: this.getUsedParamsDetails(i)
		} : `${u}${d}${c}` : a ? {
			res: c,
			usedKey: c,
			exactUsedKey: c,
			usedLng: f,
			usedNS: u,
			usedParams: this.getUsedParamsDetails(i)
		} : c;
		let m = this.resolve(t, i), h = m?.res, g = m?.usedKey || c, _ = m?.exactUsedKey || c, ee = [
			"[object Number]",
			"[object Function]",
			"[object RegExp]"
		], v = i.joinArrays === void 0 ? this.options.joinArrays : i.joinArrays, y = !this.i18nFormat || this.i18nFormat.handleAsObject, b = i.count !== void 0 && !s(i.count), x = e.hasDefaultValue(i), te = b ? this.pluralResolver.getSuffix(f, i.count, i) : "", ne = i.ordinal && b ? this.pluralResolver.getSuffix(f, i.count, { ordinal: !1 }) : "", S = b && !i.ordinal && i.count === 0, C = S && i[`defaultValue${this.options.pluralSeparator}zero`] || i[`defaultValue${te}`] || i[`defaultValue${ne}`] || i.defaultValue, w = h;
		y && !h && x && (w = C);
		let T = ce(w), re = Object.prototype.toString.apply(w);
		if (y && w && T && !ee.includes(re) && !(s(v) && Array.isArray(w))) {
			if (!i.returnObjects && !this.options.returnObjects) {
				this.options.returnedObjectHandler || this.logger.warn("accessing an object - but returnObjects options is not enabled!");
				let e = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(g, w, {
					...i,
					ns: l
				}) : `key '${c} (${this.language})' returned an object instead of string.`;
				return a ? (m.res = e, m.usedParams = this.getUsedParamsDetails(i), m) : e;
			}
			if (o) {
				let e = Array.isArray(w), t = e ? [] : {}, n = e ? _ : g;
				for (let e in w) if (Object.prototype.hasOwnProperty.call(w, e)) {
					let r = `${n}${o}${e}`;
					x && !h ? t[e] = this.translate(r, {
						...i,
						defaultValue: ce(C) ? C[e] : void 0,
						joinArrays: !1,
						ns: l
					}) : t[e] = this.translate(r, {
						...i,
						joinArrays: !1,
						ns: l
					}), t[e] === r && (t[e] = w[e]);
				}
				h = t;
			}
		} else if (y && s(v) && Array.isArray(h)) h = h.join(v), h &&= this.extendTranslation(h, t, i, r);
		else {
			let e = !1, n = !1;
			!this.isValidLookup(h) && x && (e = !0, h = C), this.isValidLookup(h) || (n = !0, h = c);
			let a = (i.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey) && n ? void 0 : h, s = x && C !== h && this.options.updateMissing;
			if (n || e || s) {
				if (this.logger.log(s ? "updateKey" : "missingKey", f, u, b && !s ? `${c}${this.pluralResolver.getSuffix(f, i.count, i)}` : c, s ? C : h), o) {
					let e = this.resolve(c, {
						...i,
						keySeparator: !1
					});
					e && e.res && this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
				}
				let e = [], t = this.languageUtils.getFallbackCodes(this.options.fallbackLng, i.lng || this.language);
				if (this.options.saveMissingTo === "fallback" && t && t[0]) for (let n = 0; n < t.length; n++) e.push(t[n]);
				else this.options.saveMissingTo === "all" ? e = this.languageUtils.toResolveHierarchy(i.lng || this.language) : e.push(i.lng || this.language);
				let n = (e, t, n) => {
					let r = x && n !== h ? n : a;
					this.options.missingKeyHandler ? this.options.missingKeyHandler(e, u, t, r, s, i) : this.backendConnector?.saveMissing && this.backendConnector.saveMissing(e, u, t, r, s, i), this.emit("missingKey", e, u, t, h);
				};
				this.options.saveMissing && (this.options.saveMissingPlurals && b ? e.forEach((e) => {
					let t = this.pluralResolver.getSuffixes(e, i);
					S && i[`defaultValue${this.options.pluralSeparator}zero`] && !t.includes(`${this.options.pluralSeparator}zero`) && t.push(`${this.options.pluralSeparator}zero`), t.forEach((t) => {
						n([e], c + t, i[`defaultValue${t}`] || C);
					});
				}) : n(e, c, C));
			}
			h = this.extendTranslation(h, t, i, m, r), n && h === c && this.options.appendNamespaceToMissingKey && (h = `${u}${d}${c}`), (n || e) && this.options.parseMissingKeyHandler && (h = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${u}${d}${c}` : c, e ? h : void 0, i));
		}
		return a ? (m.res = h, m.usedParams = this.getUsedParamsDetails(i), m) : h;
	}
	extendTranslation(e, t, n, r, i) {
		if (this.i18nFormat?.parse) e = this.i18nFormat.parse(e, {
			...this.options.interpolation.defaultVariables,
			...n
		}, n.lng || this.language || r.usedLng, r.usedNS, r.usedKey, { resolved: r });
		else if (!n.skipInterpolation) {
			n.interpolation && this.interpolator.init({
				...n,
				interpolation: {
					...this.options.interpolation,
					...n.interpolation
				}
			});
			let a = s(e) && (n?.interpolation?.skipOnVariables === void 0 ? this.options.interpolation.skipOnVariables : n.interpolation.skipOnVariables), o;
			if (a) {
				let t = e.match(this.interpolator.nestingRegexp);
				o = t && t.length;
			}
			let c = n.replace && !s(n.replace) ? n.replace : n;
			if (this.options.interpolation.defaultVariables && (c = {
				...this.options.interpolation.defaultVariables,
				...c
			}), e = this.interpolator.interpolate(e, c, n.lng || this.language || r.usedLng, n), a) {
				let t = e.match(this.interpolator.nestingRegexp), r = t && t.length;
				o < r && (n.nest = !1);
			}
			!n.lng && r && r.res && (n.lng = this.language || r.usedLng), n.nest !== !1 && (e = this.interpolator.nest(e, (...e) => i?.[0] === e[0] && !n.context ? (this.logger.warn(`It seems you are nesting recursively key: ${e[0]} in key: ${t[0]}`), null) : this.translate(...e, t), n)), n.interpolation && this.interpolator.reset();
		}
		let a = n.postProcess || this.options.postProcess, o = s(a) ? [a] : a;
		return e != null && o?.length && n.applyPostProcessor !== !1 && (e = ae.handle(o, e, t, this.options && this.options.postProcessPassResolved ? {
			i18nResolved: {
				...r,
				usedParams: this.getUsedParamsDetails(n)
			},
			...n
		} : n, this)), e;
	}
	resolve(e, t = {}) {
		let n, r, i, a, o;
		return s(e) && (e = [e]), Array.isArray(e) && (e = e.map((e) => typeof e == "function" ? O(e, {
			...this.options,
			...t
		}) : e)), e.forEach((e) => {
			if (this.isValidLookup(n)) return;
			let c = this.extractFromKey(e, t), l = c.key;
			r = l;
			let u = c.namespaces;
			this.options.fallbackNS && (u = u.concat(this.options.fallbackNS));
			let d = t.count !== void 0 && !s(t.count), f = d && !t.ordinal && t.count === 0, p = t.context !== void 0 && (s(t.context) || typeof t.context == "number") && t.context !== "", m = t.lngs ? t.lngs : this.languageUtils.toResolveHierarchy(t.lng || this.language, t.fallbackLng);
			u.forEach((e) => {
				this.isValidLookup(n) || (o = e, !this.checkedLoadedFor[`${m[0]}-${e}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(o) && (this.checkedLoadedFor[`${m[0]}-${e}`] = !0, this.logger.warn(`key "${r}" for languages "${m.join(", ")}" won't get resolved as namespace "${o}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!")), m.forEach((r) => {
					if (this.isValidLookup(n)) return;
					a = r;
					let o = [l];
					if (this.i18nFormat?.addLookupKeys) this.i18nFormat.addLookupKeys(o, l, r, e, t);
					else {
						let e;
						d && (e = this.pluralResolver.getSuffix(r, t.count, t));
						let n = `${this.options.pluralSeparator}zero`, i = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
						if (d && (t.ordinal && e.startsWith(i) && o.push(l + e.replace(i, this.options.pluralSeparator)), o.push(l + e), f && o.push(l + n)), p) {
							let r = `${l}${this.options.contextSeparator || "_"}${t.context}`;
							o.push(r), d && (t.ordinal && e.startsWith(i) && o.push(r + e.replace(i, this.options.pluralSeparator)), o.push(r + e), f && o.push(r + n));
						}
					}
					let s;
					for (; s = o.pop();) this.isValidLookup(n) || (i = s, n = this.getResource(r, e, s, t));
				}));
			});
		}), {
			res: n,
			usedKey: r,
			exactUsedKey: i,
			usedLng: a,
			usedNS: o
		};
	}
	isValidLookup(e) {
		return e !== void 0 && !(!this.options.returnNull && e === null) && !(!this.options.returnEmptyString && e === "");
	}
	getResource(e, t, n, r = {}) {
		return this.i18nFormat?.getResource ? this.i18nFormat.getResource(e, t, n, r) : this.resourceStore.getResource(e, t, n, r);
	}
	getUsedParamsDetails(e = {}) {
		let t = [
			"defaultValue",
			"ordinal",
			"context",
			"replace",
			"lng",
			"lngs",
			"fallbackLng",
			"ns",
			"keySeparator",
			"nsSeparator",
			"returnObjects",
			"returnDetails",
			"joinArrays",
			"postProcess",
			"interpolation"
		], n = e.replace && !s(e.replace), r = n ? e.replace : e;
		if (n && e.count !== void 0 && (r = {
			...r,
			count: e.count
		}), this.options.interpolation.defaultVariables && (r = {
			...this.options.interpolation.defaultVariables,
			...r
		}), !n) {
			r = { ...r };
			for (let e of t) delete r[e];
		}
		return r;
	}
	static hasDefaultValue(e) {
		for (let t in e) if (Object.prototype.hasOwnProperty.call(e, t) && t.startsWith("defaultValue") && e[t] !== void 0) return !0;
		return !1;
	}
}, ue = class {
	constructor(e) {
		this.options = e, this.supportedLngs = this.options.supportedLngs || !1, this.logger = E.create("languageUtils");
	}
	getScriptPartFromCode(e) {
		if (e = T(e), !e || !e.includes("-")) return null;
		let t = e.split("-");
		return t.length === 2 || (t.pop(), t[t.length - 1].toLowerCase() === "x") ? null : this.formatLanguageCode(t.join("-"));
	}
	getLanguagePartFromCode(e) {
		if (e = T(e), !e || !e.includes("-")) return e;
		let t = e.split("-");
		return this.formatLanguageCode(t[0]);
	}
	formatLanguageCode(e) {
		if (s(e) && e.includes("-")) {
			let t;
			try {
				t = Intl.getCanonicalLocales(e)[0];
			} catch {}
			return t && this.options.lowerCaseLng && (t = t.toLowerCase()), t || (this.options.lowerCaseLng ? e.toLowerCase() : e);
		}
		return this.options.cleanCode || this.options.lowerCaseLng ? e.toLowerCase() : e;
	}
	isSupportedCode(e) {
		return (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) && (e = this.getLanguagePartFromCode(e)), !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.includes(e);
	}
	getBestMatchFromCodes(e) {
		if (!e) return null;
		let t;
		return e.forEach((e) => {
			if (t) return;
			let n = this.formatLanguageCode(e);
			(!this.options.supportedLngs || this.isSupportedCode(n)) && (t = n);
		}), !t && this.options.supportedLngs && e.forEach((e) => {
			if (t) return;
			let n = this.getScriptPartFromCode(e);
			if (this.isSupportedCode(n)) return t = n;
			let r = this.getLanguagePartFromCode(e);
			if (this.isSupportedCode(r)) return t = r;
			t = this.options.supportedLngs.find((e) => e === r ? !0 : !e.includes("-") && !r.includes("-") ? !1 : !!(e.includes("-") && !r.includes("-") && e.slice(0, e.indexOf("-")) === r || e.startsWith(r) && r.length > 1));
		}), t ||= this.getFallbackCodes(this.options.fallbackLng)[0], t;
	}
	getFallbackCodes(e, t) {
		if (!e) return [];
		if (typeof e == "function" && (e = e(t)), s(e) && (e = [e]), Array.isArray(e)) return e;
		if (!t) return e.default || [];
		let n = e[t];
		return n ||= e[this.getScriptPartFromCode(t)], n ||= e[this.formatLanguageCode(t)], n ||= e[this.getLanguagePartFromCode(t)], n ||= e.default, n || [];
	}
	toResolveHierarchy(e, t) {
		let n = this.getFallbackCodes((t === !1 ? [] : t) || this.options.fallbackLng || [], e), r = [], i = (e) => {
			e && (this.isSupportedCode(e) ? r.push(e) : this.logger.warn(`rejecting language code not found in supportedLngs: ${e}`));
		};
		return s(e) && (e.includes("-") || e.includes("_")) ? (this.options.load !== "languageOnly" && i(this.formatLanguageCode(e)), this.options.load !== "languageOnly" && this.options.load !== "currentOnly" && i(this.getScriptPartFromCode(e)), this.options.load !== "currentOnly" && i(this.getLanguagePartFromCode(e))) : s(e) && i(this.formatLanguageCode(e)), n.forEach((e) => {
			r.includes(e) || i(this.formatLanguageCode(e));
		}), r;
	}
}, de = {
	zero: 0,
	one: 1,
	two: 2,
	few: 3,
	many: 4,
	other: 5
}, fe = {
	select: (e) => e === 1 ? "one" : "other",
	resolvedOptions: () => ({ pluralCategories: ["one", "other"] })
}, pe = class {
	constructor(e, t = {}) {
		this.languageUtils = e, this.options = t, this.logger = E.create("pluralResolver"), this.pluralRulesCache = {};
	}
	clearCache() {
		this.pluralRulesCache = {};
	}
	getRule(e, t = {}) {
		let n = T(e === "dev" ? "en" : e), r = t.ordinal ? "ordinal" : "cardinal", i = JSON.stringify({
			cleanedCode: n,
			type: r
		});
		if (i in this.pluralRulesCache) return this.pluralRulesCache[i];
		let a;
		try {
			a = new Intl.PluralRules(n, { type: r });
		} catch {
			if (typeof Intl > "u") return this.logger.error("No Intl support, please use an Intl polyfill!"), fe;
			if (!e.match(/-|_/)) return fe;
			let n = this.languageUtils.getLanguagePartFromCode(e);
			a = this.getRule(n, t);
		}
		return this.pluralRulesCache[i] = a, a;
	}
	needsPlural(e, t = {}) {
		let n = this.getRule(e, t);
		return n ||= this.getRule("dev", t), n?.resolvedOptions().pluralCategories.length > 1;
	}
	getPluralFormsOfKey(e, t, n = {}) {
		return this.getSuffixes(e, n).map((e) => `${t}${e}`);
	}
	getSuffixes(e, t = {}) {
		let n = this.getRule(e, t);
		return n ||= this.getRule("dev", t), n ? n.resolvedOptions().pluralCategories.sort((e, t) => de[e] - de[t]).map((e) => `${this.options.prepend}${t.ordinal ? `ordinal${this.options.prepend}` : ""}${e}`) : [];
	}
	getSuffix(e, t, n = {}) {
		let r = this.getRule(e, n);
		return r ? `${this.options.prepend}${n.ordinal ? `ordinal${this.options.prepend}` : ""}${r.select(t)}` : (this.logger.warn(`no plural rule found for: ${e}`), this.getSuffix("dev", t, n));
	}
}, me = (e, t, n, r = ".", i = !0) => {
	let a = ee(e, t, n);
	return !a && i && s(n) && (a = w(e, n, r), a === void 0 && (a = w(t, n, r))), a;
}, he = (e) => e.replace(/\$/g, "$$$$"), ge = class {
	constructor(e = {}) {
		this.logger = E.create("interpolator"), this.options = e, this.format = e?.interpolation?.format || ((e) => e), this.init(e);
	}
	init(e = {}) {
		e.interpolation ||= { escapeValue: !0 };
		let { escape: t, escapeValue: n, useRawValueToEscape: r, prefix: i, prefixEscaped: a, suffix: o, suffixEscaped: s, formatSeparator: c, unescapeSuffix: l, unescapePrefix: u, nestingPrefix: d, nestingPrefixEscaped: f, nestingSuffix: p, nestingSuffixEscaped: m, nestingOptionsSeparator: h, maxReplaces: g, alwaysFormat: _ } = e.interpolation;
		this.escape = t === void 0 ? x : t, this.escapeValue = n === void 0 ? !0 : n, this.useRawValueToEscape = r === void 0 ? !1 : r, this.prefix = i ? y(i) : a || "{{", this.suffix = o ? y(o) : s || "}}", this.formatSeparator = c || ",", this.unescapePrefix = l ? "" : u ? y(u) : "-", this.unescapeSuffix = this.unescapePrefix ? "" : l ? y(l) : "", this.nestingPrefix = d ? y(d) : f || y("$t("), this.nestingSuffix = p ? y(p) : m || y(")"), this.nestingOptionsSeparator = h || ",", this.maxReplaces = g || 1e3, this.alwaysFormat = _ === void 0 ? !1 : _, this.resetRegExp();
	}
	reset() {
		this.options && this.init(this.options);
	}
	resetRegExp() {
		let e = (e, t) => e?.source === t ? (e.lastIndex = 0, e) : new RegExp(t, "g");
		this.regexp = e(this.regexp, `${this.prefix}(.+?)${this.suffix}`), this.regexpUnescape = e(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`), this.nestingRegexp = e(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
	}
	interpolate(e, t, n, r) {
		let i, a, o, c = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {}, u = (e) => {
			if (!e.includes(this.formatSeparator)) {
				let i = me(t, c, e, this.options.keySeparator, this.options.ignoreJSONStructure);
				return this.alwaysFormat ? this.format(i, void 0, n, {
					...r,
					...t,
					interpolationkey: e
				}) : i;
			}
			let i = e.split(this.formatSeparator), a = i.shift().trim(), o = i.join(this.formatSeparator).trim();
			return this.format(me(t, c, a, this.options.keySeparator, this.options.ignoreJSONStructure), o, n, {
				...r,
				...t,
				interpolationkey: a
			});
		};
		this.resetRegExp(), !this.escapeValue && typeof e == "string" && /\$t\([^)]*\{[^}]*\{\{/.test(e) && this.logger.warn("nesting options string contains interpolated variables with escapeValue: false — if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.");
		let d = r?.missingInterpolationHandler || this.options.missingInterpolationHandler, f = r?.interpolation?.skipOnVariables === void 0 ? this.options.interpolation.skipOnVariables : r.interpolation.skipOnVariables;
		return [{
			regex: this.regexpUnescape,
			safeValue: (e) => e
		}, {
			regex: this.regexp,
			safeValue: (e) => this.escapeValue ? this.escape(e) : e
		}].forEach((t) => {
			for (o = 0; i = t.regex.exec(e);) {
				let n = i[1].trim();
				if (a = u(n), a === void 0) if (typeof d == "function") {
					let t = d(e, i, r);
					a = s(t) ? t : "";
				} else if (r && Object.prototype.hasOwnProperty.call(r, n)) a = "";
				else if (f) {
					a = i[0];
					continue;
				} else this.logger.warn(`missed to pass in variable ${n} for interpolating ${e}`), a = "";
				else !s(a) && !this.useRawValueToEscape && (a = l(a));
				let c = t.safeValue(a);
				if (e = e.replace(i[0], he(c)), f ? (t.regex.lastIndex += c.length, t.regex.lastIndex -= i[0].length) : t.regex.lastIndex = 0, o++, o >= this.maxReplaces) break;
			}
		}), e;
	}
	nest(e, t, n = {}) {
		let r, i, a, o = (e, t) => {
			let n = this.nestingOptionsSeparator;
			if (!e.includes(n)) return e;
			let r = e.split(RegExp(`${y(n)}[ ]*{`)), i = `{${r[1]}`;
			e = r[0], i = this.interpolate(i, a);
			let o = i.match(/'/g), s = i.match(/"/g);
			((o?.length ?? 0) % 2 == 0 && !s || (s?.length ?? 0) % 2 != 0) && (i = i.replace(/'/g, "\""));
			try {
				a = JSON.parse(i), t && (a = {
					...t,
					...a
				});
			} catch (t) {
				return this.logger.warn(`failed parsing options string in nesting for key ${e}`, t), `${e}${n}${i}`;
			}
			return a.defaultValue && a.defaultValue.includes(this.prefix) && delete a.defaultValue, e;
		};
		for (; r = this.nestingRegexp.exec(e);) {
			let c = [];
			a = { ...n }, a = a.replace && !s(a.replace) ? a.replace : a, a.applyPostProcessor = !1, delete a.defaultValue;
			let u = /{.*}/s.test(r[1]) ? r[1].lastIndexOf("}") + 1 : r[1].indexOf(this.formatSeparator);
			if (u !== -1 && (c = r[1].slice(u).split(this.formatSeparator).map((e) => e.trim()).filter(Boolean), r[1] = r[1].slice(0, u)), i = t(o.call(this, r[1].trim(), a), a), i && r[0] === e && !s(i)) return i;
			s(i) || (i = l(i)), i ||= (this.logger.warn(`missed to resolve ${r[1]} for nesting ${e}`), ""), c.length && (i = c.reduce((e, t) => this.format(e, t, n.lng, {
				...n,
				interpolationkey: r[1].trim()
			}), i.trim())), e = e.replace(r[0], i), this.regexp.lastIndex = 0;
		}
		return e;
	}
}, _e = (e) => {
	let t = e.toLowerCase().trim(), n = {};
	if (e.includes("(")) {
		let r = e.split("(");
		t = r[0].toLowerCase().trim();
		let i = r[1].slice(0, -1);
		t === "currency" && !i.includes(":") ? n.currency ||= i.trim() : t === "relativetime" && !i.includes(":") ? n.range ||= i.trim() : i.split(";").forEach((e) => {
			if (e) {
				let [t, ...r] = e.split(":"), i = r.join(":").trim().replace(/^'+|'+$/g, ""), a = t.trim();
				n[a] || (n[a] = i), i === "false" && (n[a] = !1), i === "true" && (n[a] = !0), isNaN(i) || (n[a] = parseInt(i, 10));
			}
		});
	}
	return {
		formatName: t,
		formatOptions: n
	};
}, ve = (e) => {
	let t = {};
	return (n, r, i) => {
		let a = i;
		i && i.interpolationkey && i.formatParams && i.formatParams[i.interpolationkey] && i[i.interpolationkey] && (a = {
			...a,
			[i.interpolationkey]: void 0
		});
		let o = r + JSON.stringify(a), s = t[o];
		return s || (s = e(T(r), i), t[o] = s), s(n);
	};
}, ye = (e) => (t, n, r) => e(T(n), r)(t), be = class {
	constructor(e = {}) {
		this.logger = E.create("formatter"), this.options = e, this.init(e);
	}
	init(e, t = { interpolation: {} }) {
		this.formatSeparator = t.interpolation.formatSeparator || ",";
		let n = t.cacheInBuiltFormats ? ve : ye;
		this.formats = {
			number: n((e, t) => {
				let n = new Intl.NumberFormat(e, { ...t });
				return (e) => n.format(e);
			}),
			currency: n((e, t) => {
				let n = new Intl.NumberFormat(e, {
					...t,
					style: "currency"
				});
				return (e) => n.format(e);
			}),
			datetime: n((e, t) => {
				let n = new Intl.DateTimeFormat(e, { ...t });
				return (e) => n.format(e);
			}),
			relativetime: n((e, t) => {
				let n = new Intl.RelativeTimeFormat(e, { ...t });
				return (e) => n.format(e, t.range || "day");
			}),
			list: n((e, t) => {
				let n = new Intl.ListFormat(e, { ...t });
				return (e) => n.format(e);
			})
		};
	}
	add(e, t) {
		this.formats[e.toLowerCase().trim()] = t;
	}
	addCached(e, t) {
		this.formats[e.toLowerCase().trim()] = ve(t);
	}
	format(e, t, n, r = {}) {
		if (!t || e == null) return e;
		let i = t.split(this.formatSeparator), a = [];
		for (let e = 0; e < i.length; e++) {
			let t = i[e];
			for (; t.indexOf("(") > -1 && !t.includes(")") && e + 1 < i.length;) t = `${t}${this.formatSeparator}${i[++e]}`;
			a.push(t);
		}
		return a.reduce((e, t) => {
			let { formatName: i, formatOptions: a } = _e(t);
			if (this.formats[i]) {
				let t = e;
				try {
					let o = r?.formatParams?.[r.interpolationkey] || {}, s = o.locale || o.lng || r.locale || r.lng || n;
					t = this.formats[i](e, s, {
						...a,
						...r,
						...o
					});
				} catch (e) {
					this.logger.warn(e);
				}
				return t;
			} else this.logger.warn(`there was no format function for ${i}`);
			return e;
		}, e);
	}
}, xe = (e, t) => {
	e.pending[t] !== void 0 && (delete e.pending[t], e.pendingCount--);
}, Se = class extends D {
	constructor(e, t, n, r = {}) {
		super(), this.backend = e, this.store = t, this.services = n, this.languageUtils = n.languageUtils, this.options = r, this.logger = E.create("backendConnector"), this.waitingReads = [], this.maxParallelReads = r.maxParallelReads || 10, this.readingCalls = 0, this.maxRetries = r.maxRetries >= 0 ? r.maxRetries : 5, this.retryTimeout = r.retryTimeout >= 1 ? r.retryTimeout : 350, this.state = {}, this.queue = [], this.backend?.init?.(n, r.backend, r);
	}
	queueLoad(e, t, n, r) {
		let i = {}, a = {}, o = {}, s = {};
		return e.forEach((e) => {
			let r = !0;
			t.forEach((t) => {
				let o = `${e}|${t}`;
				!n.reload && this.store.hasResourceBundle(e, t) ? this.state[o] = 2 : this.state[o] < 0 || (this.state[o] === 1 ? a[o] === void 0 && (a[o] = !0) : (this.state[o] = 1, r = !1, a[o] === void 0 && (a[o] = !0), i[o] === void 0 && (i[o] = !0), s[t] === void 0 && (s[t] = !0)));
			}), r || (o[e] = !0);
		}), (Object.keys(i).length || Object.keys(a).length) && this.queue.push({
			pending: a,
			pendingCount: Object.keys(a).length,
			loaded: {},
			errors: [],
			callback: r
		}), {
			toLoad: Object.keys(i),
			pending: Object.keys(a),
			toLoadLanguages: Object.keys(o),
			toLoadNamespaces: Object.keys(s)
		};
	}
	loaded(e, t, n) {
		let r = e.split("|"), i = r[0], a = r[1];
		t && this.emit("failedLoading", i, a, t), !t && n && this.store.addResourceBundle(i, a, n, void 0, void 0, { skipCopy: !0 }), this.state[e] = t ? -1 : 2, t && n && (this.state[e] = 0);
		let o = {};
		this.queue.forEach((n) => {
			g(n.loaded, [i], a), xe(n, e), t && n.errors.push(t), n.pendingCount === 0 && !n.done && (Object.keys(n.loaded).forEach((e) => {
				o[e] || (o[e] = {});
				let t = n.loaded[e];
				t.length && t.forEach((t) => {
					o[e][t] === void 0 && (o[e][t] = !0);
				});
			}), n.done = !0, n.errors.length ? n.callback(n.errors) : n.callback());
		}), this.emit("loaded", o), this.queue = this.queue.filter((e) => !e.done);
	}
	read(e, t, n, r = 0, i = this.retryTimeout, a) {
		if (!e.length) return a(null, {});
		if (this.readingCalls >= this.maxParallelReads) {
			this.waitingReads.push({
				lng: e,
				ns: t,
				fcName: n,
				tried: r,
				wait: i,
				callback: a
			});
			return;
		}
		this.readingCalls++;
		let o = (o, s) => {
			if (this.readingCalls--, this.waitingReads.length > 0) {
				let e = this.waitingReads.shift();
				this.read(e.lng, e.ns, e.fcName, e.tried, e.wait, e.callback);
			}
			if (o && s && r < this.maxRetries) {
				setTimeout(() => {
					this.read(e, t, n, r + 1, i * 2, a);
				}, i);
				return;
			}
			a(o, s);
		}, s = this.backend[n].bind(this.backend);
		if (s.length === 2) {
			try {
				let n = s(e, t);
				n && typeof n.then == "function" ? n.then((e) => o(null, e)).catch(o) : o(null, n);
			} catch (e) {
				o(e);
			}
			return;
		}
		return s(e, t, o);
	}
	prepareLoading(e, t, n = {}, r) {
		if (!this.backend) return this.logger.warn("No backend was added via i18next.use. Will not load resources."), r && r();
		s(e) && (e = this.languageUtils.toResolveHierarchy(e)), s(t) && (t = [t]);
		let i = this.queueLoad(e, t, n, r);
		if (!i.toLoad.length) return i.pending.length || r(), null;
		i.toLoad.forEach((e) => {
			this.loadOne(e);
		});
	}
	load(e, t, n) {
		this.prepareLoading(e, t, {}, n);
	}
	reload(e, t, n) {
		this.prepareLoading(e, t, { reload: !0 }, n);
	}
	loadOne(e, t = "") {
		let n = e.split("|"), r = n[0], i = n[1];
		this.read(r, i, "read", void 0, void 0, (n, a) => {
			n && this.logger.warn(`${t}loading namespace ${i} for language ${r} failed`, n), !n && a && this.logger.log(`${t}loaded namespace ${i} for language ${r}`, a), this.loaded(e, n, a);
		});
	}
	saveMissing(e, t, n, r, i, a = {}, o = () => {}) {
		if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(t)) {
			this.logger.warn(`did not save key "${n}" as the namespace "${t}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
			return;
		}
		if (!(n == null || n === "")) {
			if (this.backend?.create) {
				let s = {
					...a,
					isUpdate: i
				}, c = this.backend.create.bind(this.backend);
				if (c.length < 6) try {
					let i;
					i = c.length === 5 ? c(e, t, n, r, s) : c(e, t, n, r), i && typeof i.then == "function" ? i.then((e) => o(null, e)).catch(o) : o(null, i);
				} catch (e) {
					o(e);
				}
				else c(e, t, n, r, o, s);
			}
			!e || !e[0] || this.store.addResource(e[0], t, n, r);
		}
	}
}, k = () => ({
	debug: !1,
	initAsync: !0,
	ns: ["translation"],
	defaultNS: ["translation"],
	fallbackLng: ["dev"],
	fallbackNS: !1,
	supportedLngs: !1,
	nonExplicitSupportedLngs: !1,
	load: "all",
	preload: !1,
	keySeparator: ".",
	nsSeparator: ":",
	pluralSeparator: "_",
	contextSeparator: "_",
	enableSelector: !1,
	partialBundledLanguages: !1,
	saveMissing: !1,
	updateMissing: !1,
	saveMissingTo: "fallback",
	saveMissingPlurals: !0,
	missingKeyHandler: !1,
	missingInterpolationHandler: !1,
	postProcess: !1,
	postProcessPassResolved: !1,
	returnNull: !1,
	returnEmptyString: !0,
	returnObjects: !1,
	joinArrays: !1,
	returnedObjectHandler: !1,
	parseMissingKeyHandler: !1,
	appendNamespaceToMissingKey: !1,
	appendNamespaceToCIMode: !1,
	overloadTranslationOptionHandler: (e) => {
		let t = {};
		if (typeof e[1] == "object" && (t = e[1]), s(e[1]) && (t.defaultValue = e[1]), s(e[2]) && (t.tDescription = e[2]), typeof e[2] == "object" || typeof e[3] == "object") {
			let n = e[3] || e[2];
			Object.keys(n).forEach((e) => {
				t[e] = n[e];
			});
		}
		return t;
	},
	interpolation: {
		escapeValue: !0,
		prefix: "{{",
		suffix: "}}",
		formatSeparator: ",",
		unescapePrefix: "-",
		nestingPrefix: "$t(",
		nestingSuffix: ")",
		nestingOptionsSeparator: ",",
		maxReplaces: 1e3,
		skipOnVariables: !0
	},
	cacheInBuiltFormats: !0
}), Ce = (e) => (s(e.ns) && (e.ns = [e.ns]), s(e.fallbackLng) && (e.fallbackLng = [e.fallbackLng]), s(e.fallbackNS) && (e.fallbackNS = [e.fallbackNS]), e.supportedLngs && !e.supportedLngs.includes("cimode") && (e.supportedLngs = e.supportedLngs.concat(["cimode"])), e), A = () => {}, we = (e) => {
	Object.getOwnPropertyNames(Object.getPrototypeOf(e)).forEach((t) => {
		typeof e[t] == "function" && (e[t] = e[t].bind(e));
	});
}, j = class e extends D {
	constructor(e = {}, t) {
		if (super(), this.options = Ce(e), this.services = {}, this.logger = E, this.modules = { external: [] }, we(this), t && !this.isInitialized && !e.isClone) {
			if (!this.options.initAsync) return this.init(e, t), this;
			setTimeout(() => {
				this.init(e, t);
			}, 0);
		}
	}
	init(e = {}, t) {
		this.isInitializing = !0, typeof e == "function" && (t = e, e = {}), e.defaultNS == null && e.ns && (s(e.ns) ? e.defaultNS = e.ns : e.ns.includes("translation") || (e.defaultNS = e.ns[0]));
		let n = k();
		this.options = {
			...n,
			...this.options,
			...Ce(e)
		}, this.options.interpolation = {
			...n.interpolation,
			...this.options.interpolation
		}, e.keySeparator !== void 0 && (this.options.userDefinedKeySeparator = e.keySeparator), e.nsSeparator !== void 0 && (this.options.userDefinedNsSeparator = e.nsSeparator), typeof this.options.overloadTranslationOptionHandler != "function" && (this.options.overloadTranslationOptionHandler = n.overloadTranslationOptionHandler);
		let r = (e) => e ? typeof e == "function" ? new e() : e : null;
		if (!this.options.isClone) {
			this.modules.logger ? E.init(r(this.modules.logger), this.options) : E.init(null, this.options);
			let e;
			e = this.modules.formatter ? this.modules.formatter : be;
			let t = new ue(this.options);
			this.store = new ie(this.options.resources, this.options);
			let n = this.services;
			n.logger = E, n.resourceStore = this.store, n.languageUtils = t, n.pluralResolver = new pe(t, { prepend: this.options.pluralSeparator }), e && (n.formatter = r(e), n.formatter.init && n.formatter.init(n, this.options), this.options.interpolation.format = n.formatter.format.bind(n.formatter)), n.interpolator = new ge(this.options), n.utils = { hasLoadedNamespace: this.hasLoadedNamespace.bind(this) }, n.backendConnector = new Se(r(this.modules.backend), n.resourceStore, n, this.options), n.backendConnector.on("*", (e, ...t) => {
				this.emit(e, ...t);
			}), this.modules.languageDetector && (n.languageDetector = r(this.modules.languageDetector), n.languageDetector.init && n.languageDetector.init(n, this.options.detection, this.options)), this.modules.i18nFormat && (n.i18nFormat = r(this.modules.i18nFormat), n.i18nFormat.init && n.i18nFormat.init(this)), this.translator = new le(this.services, this.options), this.translator.on("*", (e, ...t) => {
				this.emit(e, ...t);
			}), this.modules.external.forEach((e) => {
				e.init && e.init(this);
			});
		}
		if (this.format = this.options.interpolation.format, t ||= A, this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
			let e = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
			e.length > 0 && e[0] !== "dev" && (this.options.lng = e[0]);
		}
		!this.services.languageDetector && !this.options.lng && this.logger.warn("init: no languageDetector is used and no lng is defined"), [
			"getResource",
			"hasResourceBundle",
			"getResourceBundle",
			"getDataByLanguage"
		].forEach((e) => {
			this[e] = (...t) => this.store[e](...t);
		}), [
			"addResource",
			"addResources",
			"addResourceBundle",
			"removeResourceBundle"
		].forEach((e) => {
			this[e] = (...t) => (this.store[e](...t), this);
		});
		let i = c(), a = () => {
			let e = (e, n) => {
				this.isInitializing = !1, this.isInitialized && !this.initializedStoreOnce && this.logger.warn("init: i18next is already initialized. You should call init just once!"), this.isInitialized = !0, this.options.isClone || this.logger.log("initialized", this.options), this.emit("initialized", this.options), i.resolve(n), t(e, n);
			};
			if ((this.languages || this.isLanguageChangingTo) && !this.isInitialized) return e(null, this.t.bind(this));
			this.changeLanguage(this.options.lng, e);
		};
		return this.options.resources || !this.options.initAsync ? a() : setTimeout(a, 0), i;
	}
	loadResources(e, t = A) {
		let n = t, r = s(e) ? e : this.language;
		if (typeof e == "function" && (n = e), !this.options.resources || this.options.partialBundledLanguages) {
			if (r?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return n();
			let e = [], t = (t) => {
				t && t !== "cimode" && this.services.languageUtils.toResolveHierarchy(t).forEach((t) => {
					t !== "cimode" && (e.includes(t) || e.push(t));
				});
			};
			r ? t(r) : this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach((e) => t(e)), this.options.preload?.forEach?.((e) => t(e)), this.services.backendConnector.load(e, this.options.ns, (e) => {
				!e && !this.resolvedLanguage && this.language && this.setResolvedLanguage(this.language), n(e);
			});
		} else n(null);
	}
	reloadResources(e, t, n) {
		let r = c();
		return typeof e == "function" && (n = e, e = void 0), typeof t == "function" && (n = t, t = void 0), e ||= this.languages, t ||= this.options.ns, n ||= A, this.services.backendConnector.reload(e, t, (e) => {
			r.resolve(), n(e);
		}), r;
	}
	use(e) {
		if (!e) throw Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
		if (!e.type) throw Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
		return e.type === "backend" && (this.modules.backend = e), (e.type === "logger" || e.log && e.warn && e.error) && (this.modules.logger = e), e.type === "languageDetector" && (this.modules.languageDetector = e), e.type === "i18nFormat" && (this.modules.i18nFormat = e), e.type === "postProcessor" && ae.addPostProcessor(e), e.type === "formatter" && (this.modules.formatter = e), e.type === "3rdParty" && this.modules.external.push(e), this;
	}
	setResolvedLanguage(e) {
		if (!(!e || !this.languages) && !["cimode", "dev"].includes(e)) {
			for (let e = 0; e < this.languages.length; e++) {
				let t = this.languages[e];
				if (!["cimode", "dev"].includes(t) && this.store.hasLanguageSomeTranslations(t)) {
					this.resolvedLanguage = t;
					break;
				}
			}
			!this.resolvedLanguage && !this.languages.includes(e) && this.store.hasLanguageSomeTranslations(e) && (this.resolvedLanguage = e, this.languages.unshift(e));
		}
	}
	changeLanguage(e, t) {
		this.isLanguageChangingTo = e;
		let n = c();
		this.emit("languageChanging", e);
		let r = (e) => {
			this.language = e, this.languages = this.services.languageUtils.toResolveHierarchy(e), this.resolvedLanguage = void 0, this.setResolvedLanguage(e);
		}, i = (i, a) => {
			a ? this.isLanguageChangingTo === e && (r(a), this.translator.changeLanguage(a), this.isLanguageChangingTo = void 0, this.emit("languageChanged", a), this.logger.log("languageChanged", a)) : this.isLanguageChangingTo = void 0, n.resolve((...e) => this.t(...e)), t && t(i, (...e) => this.t(...e));
		}, a = (t) => {
			!e && !t && this.services.languageDetector && (t = []);
			let n = s(t) ? t : t && t[0], a = this.store.hasLanguageSomeTranslations(n) ? n : this.services.languageUtils.getBestMatchFromCodes(s(t) ? [t] : t);
			a && (this.language || r(a), this.translator.language || this.translator.changeLanguage(a), this.services.languageDetector?.cacheUserLanguage?.(a)), this.loadResources(a, (e) => {
				i(e, a);
			});
		};
		return !e && this.services.languageDetector && !this.services.languageDetector.async ? a(this.services.languageDetector.detect()) : !e && this.services.languageDetector && this.services.languageDetector.async ? this.services.languageDetector.detect.length === 0 ? this.services.languageDetector.detect().then(a) : this.services.languageDetector.detect(a) : a(e), n;
	}
	getFixedT(e, t, n, r) {
		let i = r?.scopeNs, a = (e, t, ...r) => {
			let o;
			o = typeof t == "object" ? { ...t } : this.options.overloadTranslationOptionHandler([e, t].concat(r)), o.lng = o.lng || a.lng, o.lngs = o.lngs || a.lngs;
			let s = o.ns !== void 0 && o.ns !== null;
			o.ns = o.ns || a.ns, o.keyPrefix !== "" && (o.keyPrefix = o.keyPrefix || n || a.keyPrefix);
			let c = {
				...this.options,
				...o
			};
			Array.isArray(i) && !s && (c.ns = i), typeof o.keyPrefix == "function" && (o.keyPrefix = O(o.keyPrefix, c));
			let l = this.options.keySeparator || ".", u;
			return o.keyPrefix && Array.isArray(e) ? u = e.map((e) => (typeof e == "function" && (e = O(e, c)), `${o.keyPrefix}${l}${e}`)) : (typeof e == "function" && (e = O(e, c)), u = o.keyPrefix ? `${o.keyPrefix}${l}${e}` : e), this.t(u, o);
		};
		return s(e) ? a.lng = e : a.lngs = e, a.ns = t, a.keyPrefix = n, a;
	}
	t(...e) {
		return this.translator?.translate(...e);
	}
	exists(...e) {
		return this.translator?.exists(...e);
	}
	setDefaultNamespace(e) {
		this.options.defaultNS = e;
	}
	hasLoadedNamespace(e, t = {}) {
		if (!this.isInitialized) return this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages), !1;
		if (!this.languages || !this.languages.length) return this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages), !1;
		let n = t.lng || this.resolvedLanguage || this.languages[0], r = this.options ? this.options.fallbackLng : !1, i = this.languages[this.languages.length - 1];
		if (n.toLowerCase() === "cimode") return !0;
		let a = (e, t) => {
			let n = this.services.backendConnector.state[`${e}|${t}`];
			return n === -1 || n === 0 || n === 2;
		};
		if (t.precheck) {
			let e = t.precheck(this, a);
			if (e !== void 0) return e;
		}
		return !!(this.hasResourceBundle(n, e) || !this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages || a(n, e) && (!r || a(i, e)));
	}
	loadNamespaces(e, t) {
		let n = c();
		return this.options.ns ? (s(e) && (e = [e]), e.forEach((e) => {
			this.options.ns.includes(e) || this.options.ns.push(e);
		}), this.loadResources((e) => {
			n.resolve(), t && t(e);
		}), n) : (t && t(), Promise.resolve());
	}
	loadLanguages(e, t) {
		let n = c();
		s(e) && (e = [e]);
		let r = this.options.preload || [], i = e.filter((e) => !r.includes(e) && this.services.languageUtils.isSupportedCode(e));
		return i.length ? (this.options.preload = r.concat(i), this.loadResources((e) => {
			n.resolve(), t && t(e);
		}), n) : (t && t(), Promise.resolve());
	}
	dir(e) {
		if (e ||= this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language), !e) return "rtl";
		try {
			let t = new Intl.Locale(e);
			if (t && t.getTextInfo) {
				let e = t.getTextInfo();
				if (e && e.direction) return e.direction;
			}
		} catch {}
		let t = /* @__PURE__ */ "ar.shu.sqr.ssh.xaa.yhd.yud.aao.abh.abv.acm.acq.acw.acx.acy.adf.ads.aeb.aec.afb.ajp.apc.apd.arb.arq.ars.ary.arz.auz.avl.ayh.ayl.ayn.ayp.bbz.pga.he.iw.ps.pbt.pbu.pst.prp.prd.ug.ur.ydd.yds.yih.ji.yi.hbo.men.xmn.fa.jpr.peo.pes.prs.dv.sam.ckb".split("."), n = this.services?.languageUtils || new ue(k());
		return e.toLowerCase().indexOf("-latn") > 1 ? "ltr" : t.includes(n.getLanguagePartFromCode(e)) || e.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
	}
	static createInstance(t = {}, n) {
		let r = new e(t, n);
		return r.createInstance = e.createInstance, r;
	}
	cloneInstance(t = {}, n = A) {
		let r = t.forkResourceStore;
		r && delete t.forkResourceStore;
		let i = {
			...this.options,
			...t,
			isClone: !0
		}, a = new e(i);
		if ((t.debug !== void 0 || t.prefix !== void 0) && (a.logger = a.logger.clone(t)), [
			"store",
			"services",
			"language"
		].forEach((e) => {
			a[e] = this[e];
		}), a.services = { ...this.services }, a.services.utils = { hasLoadedNamespace: a.hasLoadedNamespace.bind(a) }, r && (a.store = new ie(Object.keys(this.store.data).reduce((e, t) => (e[t] = { ...this.store.data[t] }, e[t] = Object.keys(e[t]).reduce((n, r) => (n[r] = { ...e[t][r] }, n), e[t]), e), {}), i), a.services.resourceStore = a.store), t.interpolation) {
			let e = {
				...k().interpolation,
				...this.options.interpolation,
				...t.interpolation
			}, n = {
				...i,
				interpolation: e
			};
			a.services.interpolator = new ge(n);
		}
		return a.translator = new le(a.services, i), a.translator.on("*", (e, ...t) => {
			a.emit(e, ...t);
		}), a.init(i, n), a.translator.options = i, a.translator.backendConnector.services.utils = { hasLoadedNamespace: a.hasLoadedNamespace.bind(a) }, a;
	}
	toJSON() {
		return {
			options: this.options,
			store: this.store,
			language: this.language,
			languages: this.languages,
			resolvedLanguage: this.resolvedLanguage
		};
	}
}.createInstance(), Te = j.createInstance;
j.dir, j.init, j.loadResources, j.reloadResources, j.use, j.changeLanguage, j.getFixedT, j.t, j.exists, j.setDefaultNamespace, j.hasLoadedNamespace, j.loadNamespaces, j.loadLanguages;
//#endregion
//#region src/i18n/instance.ts
var M = Te(), N = [
	"__proto__",
	"constructor",
	"prototype"
];
function Ee(e, t, n) {
	function r(e) {
		return e && e.indexOf("###") > -1 ? e.replace(/###/g, ".") : e;
	}
	function i() {
		return !e || typeof e == "string";
	}
	for (var a = typeof t == "string" ? t.split(".") : [].concat(t); a.length > 1;) {
		if (i()) return {};
		var o = r(a.shift());
		if (N.indexOf(o) > -1) return {};
		!e[o] && n && (e[o] = new n()), e = e[o];
	}
	if (i()) return {};
	var s = r(a.shift());
	return N.indexOf(s) > -1 ? {} : {
		obj: e,
		k: s
	};
}
function De(e, t, n) {
	var r = Ee(e, t, Object), i = r.obj, a = r.k;
	i !== void 0 && (i[a] = n);
}
function Oe(e, t) {
	var n = Ee(e, t), r = n.obj, i = n.k;
	if (r) return r[i];
}
var ke = [], Ae = ke.forEach, je = ke.slice;
function Me(e) {
	return Ae.call(je.call(arguments, 1), function(t) {
		if (t) for (var n = 0, r = Object.keys(t); n < r.length; n++) {
			var i = r[n];
			N.indexOf(i) > -1 || e[i] === void 0 && (e[i] = t[i]);
		}
	}), e;
}
//#endregion
//#region ../../node_modules/.bun/@formatjs+fast-memoize@3.1.7/node_modules/@formatjs/fast-memoize/index.js
function P(e, t) {
	let n = t && t.cache ? t.cache : Ve, r = t && t.serializer ? t.serializer : ze;
	return (t && t.strategy ? t.strategy : Ie)(e, {
		cache: n,
		serializer: r
	});
}
function Ne(e) {
	return e == null || typeof e == "number" || typeof e == "boolean";
}
function Pe(e, t, n, r) {
	let i = Ne(r) ? r : n(r), a = t.get(i);
	return a === void 0 && (a = e.call(this, r), t.set(i, a)), a;
}
function Fe(e, t, n) {
	let r = Array.prototype.slice.call(arguments, 3), i = n(r), a = t.get(i);
	return a === void 0 && (a = e.apply(this, r), t.set(i, a)), a;
}
function F(e, t, n, r, i) {
	return n.bind(t, e, r, i);
}
function Ie(e, t) {
	let n = e.length === 1 ? Pe : Fe;
	return F(e, this, n, t.cache.create(), t.serializer);
}
function Le(e, t) {
	return F(e, this, Fe, t.cache.create(), t.serializer);
}
function Re(e, t) {
	return F(e, this, Pe, t.cache.create(), t.serializer);
}
var ze = function() {
	return JSON.stringify(arguments);
}, Be = class {
	constructor() {
		this.cache = Object.create(null);
	}
	get(e) {
		return this.cache[e];
	}
	set(e, t) {
		this.cache[e] = t;
	}
}, Ve = { create: function() {
	return new Be();
} }, I = {
	variadic: Le,
	monadic: Re
}, He = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Ue(e) {
	let t = {};
	return e.replace(He, (e) => {
		let n = e.length;
		switch (e[0]) {
			case "G":
				t.era = n === 4 ? "long" : n === 5 ? "narrow" : "short";
				break;
			case "y":
				t.year = n === 2 ? "2-digit" : "numeric";
				break;
			case "Y":
			case "u":
			case "U":
			case "r": throw RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
			case "q":
			case "Q": throw RangeError("`q/Q` (quarter) patterns are not supported");
			case "M":
			case "L":
				t.month = [
					"numeric",
					"2-digit",
					"short",
					"long",
					"narrow"
				][n - 1];
				break;
			case "w":
			case "W": throw RangeError("`w/W` (week) patterns are not supported");
			case "d":
				t.day = ["numeric", "2-digit"][n - 1];
				break;
			case "D":
			case "F":
			case "g": throw RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
			case "E":
				t.weekday = n === 4 ? "long" : n === 5 ? "narrow" : "short";
				break;
			case "e":
				if (n < 4) throw RangeError("`e..eee` (weekday) patterns are not supported");
				t.weekday = [
					"short",
					"long",
					"narrow",
					"short"
				][n - 3];
				break;
			case "c":
				if (n < 4) throw RangeError("`c..ccc` (weekday) patterns are not supported");
				t.weekday = [
					"short",
					"long",
					"narrow",
					"short"
				][n - 3];
				break;
			case "a":
				t.hour12 = !0;
				break;
			case "b":
			case "B": throw RangeError("`b/B` (period) patterns are not supported, use `a` instead");
			case "h":
				t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][n - 1];
				break;
			case "H":
				t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][n - 1];
				break;
			case "K":
				t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][n - 1];
				break;
			case "k":
				t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][n - 1];
				break;
			case "j":
			case "J":
			case "C": throw RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
			case "m":
				t.minute = ["numeric", "2-digit"][n - 1];
				break;
			case "s":
				t.second = ["numeric", "2-digit"][n - 1];
				break;
			case "S":
			case "A": throw RangeError("`S/A` (second) patterns are not supported, use `s` instead");
			case "z":
				t.timeZoneName = n < 4 ? "short" : "long";
				break;
			case "Z":
			case "O":
			case "v":
			case "V":
			case "X":
			case "x": throw RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
		}
		return "";
	}), t;
}
var We = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function Ge(e) {
	if (e.length === 0) throw Error("Number skeleton cannot be empty");
	let t = e.split(We).filter((e) => e.length > 0), n = [];
	for (let e of t) {
		let t = e.split("/");
		if (t.length === 0) throw Error("Invalid number skeleton");
		let [r, ...i] = t;
		for (let e of i) if (e.length === 0) throw Error("Invalid number skeleton");
		n.push({
			stem: r,
			options: i
		});
	}
	return n;
}
function Ke(e) {
	return e.replace(/^(.*?)-/, "");
}
var qe = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Je = /^(@+)?(\+|#+)?[rs]?$/g, Ye = /(\*)(0+)|(#+)(0+)|(0+)/g, Xe = /^(0+)$/;
function Ze(e) {
	let t = {};
	return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(Je, function(e, n, r) {
		return typeof r == "string" ? r === "+" ? t.minimumSignificantDigits = n.length : n[0] === "#" ? t.maximumSignificantDigits = n.length : (t.minimumSignificantDigits = n.length, t.maximumSignificantDigits = n.length + (typeof r == "string" ? r.length : 0)) : (t.minimumSignificantDigits = n.length, t.maximumSignificantDigits = n.length), "";
	}), t;
}
function Qe(e) {
	switch (e) {
		case "sign-auto": return { signDisplay: "auto" };
		case "sign-accounting":
		case "()": return { currencySign: "accounting" };
		case "sign-always":
		case "+!": return { signDisplay: "always" };
		case "sign-accounting-always":
		case "()!": return {
			signDisplay: "always",
			currencySign: "accounting"
		};
		case "sign-except-zero":
		case "+?": return { signDisplay: "exceptZero" };
		case "sign-accounting-except-zero":
		case "()?": return {
			signDisplay: "exceptZero",
			currencySign: "accounting"
		};
		case "sign-never":
		case "+_": return { signDisplay: "never" };
	}
}
function $e(e) {
	let t;
	if (e[0] === "E" && e[1] === "E" ? (t = { notation: "engineering" }, e = e.slice(2)) : e[0] === "E" && (t = { notation: "scientific" }, e = e.slice(1)), t) {
		let n = e.slice(0, 2);
		if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !Xe.test(e)) throw Error("Malformed concise eng/scientific notation");
		t.minimumIntegerDigits = e.length;
	}
	return t;
}
function et(e) {
	return Qe(e) || {};
}
function tt(e) {
	let t = {};
	for (let n of e) {
		switch (n.stem) {
			case "percent":
			case "%":
				t.style = "percent";
				continue;
			case "%x100":
				t.style = "percent", t.scale = 100;
				continue;
			case "currency":
				t.style = "currency", t.currency = n.options[0];
				continue;
			case "group-off":
			case ",_":
				t.useGrouping = !1;
				continue;
			case "precision-integer":
			case ".":
				t.maximumFractionDigits = 0;
				continue;
			case "measure-unit":
			case "unit":
				t.style = "unit", t.unit = Ke(n.options[0]);
				continue;
			case "compact-short":
			case "K":
				t.notation = "compact", t.compactDisplay = "short";
				continue;
			case "compact-long":
			case "KK":
				t.notation = "compact", t.compactDisplay = "long";
				continue;
			case "scientific":
				t = {
					...t,
					notation: "scientific",
					...n.options.reduce((e, t) => ({
						...e,
						...et(t)
					}), {})
				};
				continue;
			case "engineering":
				t = {
					...t,
					notation: "engineering",
					...n.options.reduce((e, t) => ({
						...e,
						...et(t)
					}), {})
				};
				continue;
			case "notation-simple":
				t.notation = "standard";
				continue;
			case "unit-width-narrow":
				t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
				continue;
			case "unit-width-short":
				t.currencyDisplay = "code", t.unitDisplay = "short";
				continue;
			case "unit-width-full-name":
				t.currencyDisplay = "name", t.unitDisplay = "long";
				continue;
			case "unit-width-iso-code":
				t.currencyDisplay = "symbol";
				continue;
			case "scale":
				t.scale = parseFloat(n.options[0]);
				continue;
			case "rounding-mode-floor":
				t.roundingMode = "floor";
				continue;
			case "rounding-mode-ceiling":
				t.roundingMode = "ceil";
				continue;
			case "rounding-mode-down":
				t.roundingMode = "trunc";
				continue;
			case "rounding-mode-up":
				t.roundingMode = "expand";
				continue;
			case "rounding-mode-half-even":
				t.roundingMode = "halfEven";
				continue;
			case "rounding-mode-half-down":
				t.roundingMode = "halfTrunc";
				continue;
			case "rounding-mode-half-up":
				t.roundingMode = "halfExpand";
				continue;
			case "integer-width":
				if (n.options.length > 1) throw RangeError("integer-width stems only accept a single optional option");
				n.options[0].replace(Ye, function(e, n, r, i, a, o) {
					if (n) t.minimumIntegerDigits = r.length;
					else if (i && a) throw Error("We currently do not support maximum integer digits");
					else if (o) throw Error("We currently do not support exact integer digits");
					return "";
				});
				continue;
		}
		if (Xe.test(n.stem)) {
			t.minimumIntegerDigits = n.stem.length;
			continue;
		}
		if (qe.test(n.stem)) {
			if (n.options.length > 1) throw RangeError("Fraction-precision stems only accept a single optional option");
			n.stem.replace(qe, function(e, n, r, i, a, o) {
				return r === "*" ? t.minimumFractionDigits = n.length : i && i[0] === "#" ? t.maximumFractionDigits = i.length : a && o ? (t.minimumFractionDigits = a.length, t.maximumFractionDigits = a.length + o.length) : (t.minimumFractionDigits = n.length, t.maximumFractionDigits = n.length), "";
			});
			let e = n.options[0];
			e === "w" ? t = {
				...t,
				trailingZeroDisplay: "stripIfInteger"
			} : e && (t = {
				...t,
				...Ze(e)
			});
			continue;
		}
		if (Je.test(n.stem)) {
			t = {
				...t,
				...Ze(n.stem)
			};
			continue;
		}
		let e = Qe(n.stem);
		e && (t = {
			...t,
			...e
		});
		let r = $e(n.stem);
		r && (t = {
			...t,
			...r
		});
	}
	return t;
}
//#endregion
//#region ../../node_modules/.bun/@formatjs+icu-messageformat-parser@3.5.16/node_modules/@formatjs/icu-messageformat-parser/index.js
var nt = /* @__PURE__ */ function(e) {
	return e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG", e;
}({});
function rt(e) {
	return e.type === 0;
}
function it(e) {
	return e.type === 1;
}
function at(e) {
	return e.type === 2;
}
function ot(e) {
	return e.type === 3;
}
function st(e) {
	return e.type === 4;
}
function ct(e) {
	return e.type === 5;
}
function lt(e) {
	return e.type === 6;
}
function ut(e) {
	return e.type === 7;
}
function dt(e) {
	return e.type === 8;
}
function ft(e) {
	return !!(e && typeof e == "object" && e.type === 0);
}
function L(e) {
	return !!(e && typeof e == "object" && e.type === 1);
}
var pt = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, R = {
	"001": ["H", "h"],
	419: [
		"h",
		"H",
		"hB",
		"hb"
	],
	AC: [
		"H",
		"h",
		"hb",
		"hB"
	],
	AD: ["H", "hB"],
	AE: [
		"h",
		"hB",
		"hb",
		"H"
	],
	AF: [
		"H",
		"hb",
		"hB",
		"h"
	],
	AG: [
		"h",
		"hb",
		"H",
		"hB"
	],
	AI: [
		"H",
		"h",
		"hb",
		"hB"
	],
	AL: [
		"h",
		"H",
		"hB"
	],
	AM: ["H", "hB"],
	AO: ["H", "hB"],
	AR: [
		"h",
		"H",
		"hB",
		"hb"
	],
	AS: ["h", "H"],
	AT: ["H", "hB"],
	AU: [
		"h",
		"hb",
		"H",
		"hB"
	],
	AW: ["H", "hB"],
	AX: ["H"],
	AZ: [
		"H",
		"hB",
		"h"
	],
	BA: [
		"H",
		"hB",
		"h"
	],
	BB: [
		"h",
		"hb",
		"H",
		"hB"
	],
	BD: [
		"h",
		"hB",
		"H"
	],
	BE: ["H", "hB"],
	BF: ["H", "hB"],
	BG: [
		"H",
		"hB",
		"h"
	],
	BH: [
		"h",
		"hB",
		"hb",
		"H"
	],
	BI: ["H", "h"],
	BJ: ["H", "hB"],
	BL: ["H", "hB"],
	BM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	BN: [
		"hb",
		"hB",
		"h",
		"H"
	],
	BO: [
		"h",
		"H",
		"hB",
		"hb"
	],
	BQ: ["H"],
	BR: ["H", "hB"],
	BS: [
		"h",
		"hb",
		"H",
		"hB"
	],
	BT: ["h", "H"],
	BW: [
		"H",
		"h",
		"hb",
		"hB"
	],
	BY: ["H", "h"],
	BZ: [
		"H",
		"h",
		"hb",
		"hB"
	],
	CA: [
		"h",
		"hb",
		"H",
		"hB"
	],
	CC: [
		"H",
		"h",
		"hb",
		"hB"
	],
	CD: ["hB", "H"],
	CF: [
		"H",
		"h",
		"hB"
	],
	CG: ["H", "hB"],
	CH: [
		"H",
		"hB",
		"h"
	],
	CI: ["H", "hB"],
	CK: [
		"H",
		"h",
		"hb",
		"hB"
	],
	CL: [
		"h",
		"H",
		"hB",
		"hb"
	],
	CM: [
		"H",
		"h",
		"hB"
	],
	CN: [
		"H",
		"hB",
		"hb",
		"h"
	],
	CO: [
		"h",
		"H",
		"hB",
		"hb"
	],
	CP: ["H"],
	CR: [
		"h",
		"H",
		"hB",
		"hb"
	],
	CU: [
		"h",
		"H",
		"hB",
		"hb"
	],
	CV: ["H", "hB"],
	CW: ["H", "hB"],
	CX: [
		"H",
		"h",
		"hb",
		"hB"
	],
	CY: [
		"h",
		"H",
		"hb",
		"hB"
	],
	CZ: ["H"],
	DE: ["H", "hB"],
	DG: [
		"H",
		"h",
		"hb",
		"hB"
	],
	DJ: ["h", "H"],
	DK: ["H"],
	DM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	DO: [
		"h",
		"H",
		"hB",
		"hb"
	],
	DZ: [
		"h",
		"hB",
		"hb",
		"H"
	],
	EA: [
		"H",
		"h",
		"hB",
		"hb"
	],
	EC: [
		"h",
		"H",
		"hB",
		"hb"
	],
	EE: ["H", "hB"],
	EG: [
		"h",
		"hB",
		"hb",
		"H"
	],
	EH: [
		"h",
		"hB",
		"hb",
		"H"
	],
	ER: ["h", "H"],
	ES: [
		"H",
		"hB",
		"h",
		"hb"
	],
	ET: [
		"hB",
		"hb",
		"h",
		"H"
	],
	FI: ["H"],
	FJ: [
		"h",
		"hb",
		"H",
		"hB"
	],
	FK: [
		"H",
		"h",
		"hb",
		"hB"
	],
	FM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	FO: ["H", "h"],
	FR: ["H", "hB"],
	GA: ["H", "hB"],
	GB: [
		"H",
		"h",
		"hb",
		"hB"
	],
	GD: [
		"h",
		"hb",
		"H",
		"hB"
	],
	GE: [
		"H",
		"hB",
		"h"
	],
	GF: ["H", "hB"],
	GG: [
		"H",
		"h",
		"hb",
		"hB"
	],
	GH: ["h", "H"],
	GI: [
		"H",
		"h",
		"hb",
		"hB"
	],
	GL: ["H", "h"],
	GM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	GN: ["H", "hB"],
	GP: ["H", "hB"],
	GQ: [
		"H",
		"hB",
		"h",
		"hb"
	],
	GR: [
		"h",
		"H",
		"hb",
		"hB"
	],
	GS: [
		"H",
		"h",
		"hb",
		"hB"
	],
	GT: [
		"h",
		"H",
		"hB",
		"hb"
	],
	GU: [
		"h",
		"hb",
		"H",
		"hB"
	],
	GW: ["H", "hB"],
	GY: [
		"h",
		"hb",
		"H",
		"hB"
	],
	HK: [
		"h",
		"hB",
		"hb",
		"H"
	],
	HN: [
		"h",
		"H",
		"hB",
		"hb"
	],
	HR: ["H", "hB"],
	HU: ["H", "h"],
	IC: [
		"H",
		"h",
		"hB",
		"hb"
	],
	ID: ["H"],
	IE: [
		"H",
		"h",
		"hb",
		"hB"
	],
	IL: ["H", "hB"],
	IM: [
		"H",
		"h",
		"hb",
		"hB"
	],
	IN: ["h", "H"],
	IO: [
		"H",
		"h",
		"hb",
		"hB"
	],
	IQ: [
		"h",
		"hB",
		"hb",
		"H"
	],
	IR: ["hB", "H"],
	IS: ["H"],
	IT: ["H", "hB"],
	JE: [
		"H",
		"h",
		"hb",
		"hB"
	],
	JM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	JO: [
		"h",
		"hB",
		"hb",
		"H"
	],
	JP: [
		"H",
		"K",
		"h"
	],
	KE: [
		"hB",
		"hb",
		"H",
		"h"
	],
	KG: [
		"H",
		"h",
		"hB",
		"hb"
	],
	KH: [
		"hB",
		"h",
		"H",
		"hb"
	],
	KI: [
		"h",
		"hb",
		"H",
		"hB"
	],
	KM: [
		"H",
		"h",
		"hB",
		"hb"
	],
	KN: [
		"h",
		"hb",
		"H",
		"hB"
	],
	KP: [
		"h",
		"H",
		"hB",
		"hb"
	],
	KR: [
		"h",
		"H",
		"hB",
		"hb"
	],
	KW: [
		"h",
		"hB",
		"hb",
		"H"
	],
	KY: [
		"h",
		"hb",
		"H",
		"hB"
	],
	KZ: ["H", "hB"],
	LA: [
		"H",
		"hb",
		"hB",
		"h"
	],
	LB: [
		"h",
		"hB",
		"hb",
		"H"
	],
	LC: [
		"h",
		"hb",
		"H",
		"hB"
	],
	LI: [
		"H",
		"hB",
		"h"
	],
	LK: [
		"H",
		"h",
		"hB",
		"hb"
	],
	LR: [
		"h",
		"hb",
		"H",
		"hB"
	],
	LS: ["h", "H"],
	LT: [
		"H",
		"h",
		"hb",
		"hB"
	],
	LU: [
		"H",
		"h",
		"hB"
	],
	LV: [
		"H",
		"hB",
		"hb",
		"h"
	],
	LY: [
		"h",
		"hB",
		"hb",
		"H"
	],
	MA: [
		"H",
		"h",
		"hB",
		"hb"
	],
	MC: ["H", "hB"],
	MD: ["H", "hB"],
	ME: [
		"H",
		"hB",
		"h"
	],
	MF: ["H", "hB"],
	MG: ["H", "h"],
	MH: [
		"h",
		"hb",
		"H",
		"hB"
	],
	MK: [
		"H",
		"h",
		"hb",
		"hB"
	],
	ML: ["H"],
	MM: [
		"hB",
		"hb",
		"H",
		"h"
	],
	MN: [
		"H",
		"h",
		"hb",
		"hB"
	],
	MO: [
		"h",
		"hB",
		"hb",
		"H"
	],
	MP: [
		"h",
		"hb",
		"H",
		"hB"
	],
	MQ: ["H", "hB"],
	MR: [
		"h",
		"hB",
		"hb",
		"H"
	],
	MS: [
		"H",
		"h",
		"hb",
		"hB"
	],
	MT: ["H", "h"],
	MU: ["H", "h"],
	MV: ["H", "h"],
	MW: [
		"h",
		"hb",
		"H",
		"hB"
	],
	MX: [
		"h",
		"H",
		"hB",
		"hb"
	],
	MY: [
		"hb",
		"hB",
		"h",
		"H"
	],
	MZ: ["H", "hB"],
	NA: [
		"h",
		"H",
		"hB",
		"hb"
	],
	NC: ["H", "hB"],
	NE: ["H"],
	NF: [
		"H",
		"h",
		"hb",
		"hB"
	],
	NG: [
		"H",
		"h",
		"hb",
		"hB"
	],
	NI: [
		"h",
		"H",
		"hB",
		"hb"
	],
	NL: ["H", "hB"],
	NO: ["H", "h"],
	NP: [
		"H",
		"h",
		"hB"
	],
	NR: [
		"H",
		"h",
		"hb",
		"hB"
	],
	NU: [
		"H",
		"h",
		"hb",
		"hB"
	],
	NZ: [
		"h",
		"hb",
		"H",
		"hB"
	],
	OM: [
		"h",
		"hB",
		"hb",
		"H"
	],
	PA: [
		"h",
		"H",
		"hB",
		"hb"
	],
	PE: [
		"h",
		"H",
		"hB",
		"hb"
	],
	PF: [
		"H",
		"h",
		"hB"
	],
	PG: ["h", "H"],
	PH: [
		"h",
		"hB",
		"hb",
		"H"
	],
	PK: [
		"h",
		"hB",
		"H"
	],
	PL: ["H", "h"],
	PM: ["H", "hB"],
	PN: [
		"H",
		"h",
		"hb",
		"hB"
	],
	PR: [
		"h",
		"H",
		"hB",
		"hb"
	],
	PS: [
		"h",
		"hB",
		"hb",
		"H"
	],
	PT: ["H", "hB"],
	PW: ["h", "H"],
	PY: [
		"h",
		"H",
		"hB",
		"hb"
	],
	QA: [
		"h",
		"hB",
		"hb",
		"H"
	],
	RE: ["H", "hB"],
	RO: ["H", "hB"],
	RS: [
		"H",
		"hB",
		"h"
	],
	RU: ["H"],
	RW: ["H", "h"],
	SA: [
		"h",
		"hB",
		"hb",
		"H"
	],
	SB: [
		"h",
		"hb",
		"H",
		"hB"
	],
	SC: [
		"H",
		"h",
		"hB"
	],
	SD: [
		"h",
		"hB",
		"hb",
		"H"
	],
	SE: ["H"],
	SG: [
		"h",
		"hb",
		"H",
		"hB"
	],
	SH: [
		"H",
		"h",
		"hb",
		"hB"
	],
	SI: ["H", "hB"],
	SJ: ["H"],
	SK: ["H"],
	SL: [
		"h",
		"hb",
		"H",
		"hB"
	],
	SM: [
		"H",
		"h",
		"hB"
	],
	SN: [
		"H",
		"h",
		"hB"
	],
	SO: ["h", "H"],
	SR: ["H", "hB"],
	SS: [
		"h",
		"hb",
		"H",
		"hB"
	],
	ST: ["H", "hB"],
	SV: [
		"h",
		"H",
		"hB",
		"hb"
	],
	SX: [
		"H",
		"h",
		"hb",
		"hB"
	],
	SY: [
		"h",
		"hB",
		"hb",
		"H"
	],
	SZ: [
		"h",
		"hb",
		"H",
		"hB"
	],
	TA: [
		"H",
		"h",
		"hb",
		"hB"
	],
	TC: [
		"h",
		"hb",
		"H",
		"hB"
	],
	TD: [
		"h",
		"H",
		"hB"
	],
	TF: [
		"H",
		"h",
		"hB"
	],
	TG: ["H", "hB"],
	TH: ["H", "h"],
	TJ: ["H", "h"],
	TL: [
		"H",
		"hB",
		"hb",
		"h"
	],
	TM: ["H", "h"],
	TN: [
		"h",
		"hB",
		"hb",
		"H"
	],
	TO: ["h", "H"],
	TR: ["H", "hB"],
	TT: [
		"h",
		"hb",
		"H",
		"hB"
	],
	TW: [
		"hB",
		"hb",
		"h",
		"H"
	],
	TZ: [
		"hB",
		"hb",
		"H",
		"h"
	],
	UA: [
		"H",
		"hB",
		"h"
	],
	UG: [
		"hB",
		"hb",
		"H",
		"h"
	],
	UM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	US: [
		"h",
		"hb",
		"H",
		"hB"
	],
	UY: [
		"h",
		"H",
		"hB",
		"hb"
	],
	UZ: [
		"H",
		"hB",
		"h"
	],
	VA: [
		"H",
		"h",
		"hB"
	],
	VC: [
		"h",
		"hb",
		"H",
		"hB"
	],
	VE: [
		"h",
		"H",
		"hB",
		"hb"
	],
	VG: [
		"h",
		"hb",
		"H",
		"hB"
	],
	VI: [
		"h",
		"hb",
		"H",
		"hB"
	],
	VN: ["H", "h"],
	VU: ["h", "H"],
	WF: ["H", "hB"],
	WS: ["h", "H"],
	XK: [
		"H",
		"hB",
		"h"
	],
	YE: [
		"h",
		"hB",
		"hb",
		"H"
	],
	YT: ["H", "hB"],
	ZA: [
		"H",
		"h",
		"hb",
		"hB"
	],
	ZM: [
		"h",
		"hb",
		"H",
		"hB"
	],
	ZW: ["H", "h"],
	"af-ZA": [
		"H",
		"h",
		"hB",
		"hb"
	],
	"ar-001": [
		"h",
		"hB",
		"hb",
		"H"
	],
	"ca-ES": [
		"H",
		"h",
		"hB"
	],
	"en-001": [
		"h",
		"hb",
		"H",
		"hB"
	],
	"en-HK": [
		"h",
		"hb",
		"H",
		"hB"
	],
	"en-IL": [
		"H",
		"h",
		"hb",
		"hB"
	],
	"en-MY": [
		"h",
		"hb",
		"H",
		"hB"
	],
	"es-BR": [
		"H",
		"h",
		"hB",
		"hb"
	],
	"es-ES": [
		"H",
		"h",
		"hB",
		"hb"
	],
	"es-GQ": [
		"H",
		"h",
		"hB",
		"hb"
	],
	"fr-CA": [
		"H",
		"h",
		"hB"
	],
	"gl-ES": [
		"H",
		"h",
		"hB"
	],
	"gu-IN": [
		"hB",
		"hb",
		"h",
		"H"
	],
	"hi-IN": [
		"hB",
		"h",
		"H"
	],
	"it-CH": [
		"H",
		"h",
		"hB"
	],
	"it-IT": [
		"H",
		"h",
		"hB"
	],
	"kn-IN": [
		"hB",
		"h",
		"H"
	],
	"ku-SY": ["H", "hB"],
	"ml-IN": [
		"hB",
		"h",
		"H"
	],
	"mr-IN": [
		"hB",
		"hb",
		"h",
		"H"
	],
	"pa-IN": [
		"hB",
		"hb",
		"h",
		"H"
	],
	"ta-IN": [
		"hB",
		"h",
		"hb",
		"H"
	],
	"te-IN": [
		"hB",
		"h",
		"H"
	],
	"zu-ZA": [
		"H",
		"hB",
		"hb",
		"h"
	]
};
function mt(e, t) {
	let n = "";
	for (let r = 0; r < e.length; r++) {
		let i = e.charAt(r);
		if (i === "j") {
			let a = 0;
			for (; r + 1 < e.length && e.charAt(r + 1) === i;) a++, r++;
			let o = 1 + (a & 1), s = a < 2 ? 1 : 3 + (a >> 1), c = ht(t);
			for ((c == "H" || c == "k") && (s = 0); s-- > 0;) n += "a";
			for (; o-- > 0;) n = c + n;
		} else i === "J" ? n += "H" : n += i;
	}
	return n;
}
function ht(e) {
	let t = e.hourCycle;
	if (t === void 0 && e.hourCycles && e.hourCycles.length && (t = e.hourCycles[0]), t) switch (t) {
		case "h24": return "k";
		case "h23": return "H";
		case "h12": return "h";
		case "h11": return "K";
		default: throw Error("Invalid hourCycle");
	}
	let n = e.language, r;
	return n !== "root" && (r = e.maximize().region), (R[r || ""] || R[n || ""] || R[`${n}-001`] || R["001"])[0];
}
var gt = RegExp(`^${pt.source}*`), _t = RegExp(`${pt.source}*$`);
function z(e, t) {
	return {
		start: e,
		end: t
	};
}
var vt = !!Object.fromEntries, yt = !!String.prototype.trimStart, bt = !!String.prototype.trimEnd, xt = vt ? Object.fromEntries : function(e) {
	let t = {};
	for (let [n, r] of e) t[n] = r;
	return t;
}, St = yt ? function(e) {
	return e.trimStart();
} : function(e) {
	return e.replace(gt, "");
}, Ct = bt ? function(e) {
	return e.trimEnd();
} : function(e) {
	return e.replace(_t, "");
}, wt = /* @__PURE__ */ RegExp("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
function Tt(e, t) {
	return wt.lastIndex = t, wt.exec(e)[1] ?? "";
}
function Et(e) {
	if (e.length === 0) return null;
	let t = 1, n = 1;
	for (let r = 0; r < e.length;) {
		let i = e.charCodeAt(r);
		switch (i) {
			case 35:
			case 39:
			case 60:
			case 123:
			case 125: return null;
		}
		if (i === 10) t++, n = 1, r++;
		else if (n++, i >= 55296 && i <= 56319 && r + 1 < e.length) {
			let t = e.charCodeAt(r + 1);
			r += t >= 56320 && t <= 57343 ? 2 : 1;
		} else r++;
	}
	return {
		offset: e.length,
		line: t,
		column: n
	};
}
var Dt = class {
	constructor(e, t = {}) {
		this.message = e, this.position = {
			offset: 0,
			line: 1,
			column: 1
		}, this.ignoreTag = !!t.ignoreTag, this.locale = t.locale, this.requiresOtherClause = !!t.requiresOtherClause, this.shouldParseSkeletons = !!t.shouldParseSkeletons;
	}
	parse() {
		if (this.offset() !== 0) throw Error("parser can only be used once");
		if (this.message.length > 0) {
			let e = this.message.charCodeAt(0);
			if (e !== 35 && e !== 39 && e !== 60 && e !== 123 && e !== 125) {
				let e = Et(this.message);
				if (e) {
					let t = this.clonePosition();
					return this.position = e, {
						val: [{
							type: 0,
							value: this.message,
							location: z(t, this.clonePosition())
						}],
						err: null
					};
				}
			}
		}
		return this.parseMessage(0, "", !1);
	}
	parseMessage(e, t, n) {
		let r = [];
		for (; !this.isEOF();) {
			let i = this.char();
			if (i === 123) {
				let t = this.parseArgument(e, n);
				if (t.err) return t;
				r.push(t.val);
			} else if (i === 125 && e > 0) break;
			else if (i === 35 && (t === "plural" || t === "selectordinal")) {
				let e = this.clonePosition();
				this.bump(), r.push({
					type: 7,
					location: z(e, this.clonePosition())
				});
			} else if (i === 60 && !this.ignoreTag && this.peek() === 47) {
				if (n) break;
				return this.error(26, z(this.clonePosition(), this.clonePosition()));
			} else if (i === 60 && !this.ignoreTag && B(this.peek() || 0)) {
				let n = this.parseTag(e, t);
				if (n.err) return n;
				r.push(n.val);
			} else {
				let n = this.parseLiteral(e, t);
				if (n.err) return n;
				r.push(n.val);
			}
		}
		return {
			val: r,
			err: null
		};
	}
	parseTag(e, t) {
		let n = this.clonePosition();
		this.bump();
		let r = this.parseTagName();
		if (this.bumpSpace(), this.bumpIf("/>")) return {
			val: {
				type: 0,
				value: `<${r}/>`,
				location: z(n, this.clonePosition())
			},
			err: null
		};
		if (this.bumpIf(">")) {
			let i = this.parseMessage(e + 1, t, !0);
			if (i.err) return i;
			let a = i.val, o = this.clonePosition();
			if (this.bumpIf("</")) {
				if (this.isEOF() || !B(this.char())) return this.error(23, z(o, this.clonePosition()));
				let e = this.clonePosition();
				return r === this.parseTagName() ? (this.bumpSpace(), this.bumpIf(">") ? {
					val: {
						type: 8,
						value: r,
						children: a,
						location: z(n, this.clonePosition())
					},
					err: null
				} : this.error(23, z(o, this.clonePosition()))) : this.error(26, z(e, this.clonePosition()));
			} else return this.error(27, z(n, this.clonePosition()));
		} else return this.error(23, z(n, this.clonePosition()));
	}
	parseTagName() {
		let e = this.offset();
		for (this.bump(); !this.isEOF() && kt(this.char());) this.bump();
		return this.message.slice(e, this.offset());
	}
	parseLiteral(e, t) {
		let n = this.clonePosition(), r = "";
		for (;;) {
			let n = this.tryParseQuote(t);
			if (n) {
				r += n;
				continue;
			}
			let i = this.tryParseUnquoted(e, t);
			if (i) {
				r += i;
				continue;
			}
			let a = this.tryParseLeftAngleBracket();
			if (a) {
				r += a;
				continue;
			}
			break;
		}
		let i = z(n, this.clonePosition());
		return {
			val: {
				type: 0,
				value: r,
				location: i
			},
			err: null
		};
	}
	tryParseLeftAngleBracket() {
		return !this.isEOF() && this.char() === 60 && (this.ignoreTag || !Ot(this.peek() || 0)) ? (this.bump(), "<") : null;
	}
	tryParseQuote(e) {
		if (this.isEOF() || this.char() !== 39) return null;
		switch (this.peek()) {
			case 39: return this.bump(), this.bump(), "'";
			case 123:
			case 60:
			case 62:
			case 125: break;
			case 35:
				if (e === "plural" || e === "selectordinal") break;
				return null;
			default: return null;
		}
		this.bump();
		let t = [this.char()];
		for (this.bump(); !this.isEOF();) {
			let e = this.char();
			if (e === 39) if (this.peek() === 39) t.push(39), this.bump();
			else {
				this.bump();
				break;
			}
			else t.push(e);
			this.bump();
		}
		return String.fromCodePoint(...t);
	}
	tryParseUnquoted(e, t) {
		if (this.isEOF()) return null;
		let n = this.char();
		return n === 60 || n === 123 || n === 35 && (t === "plural" || t === "selectordinal") || n === 125 && e > 0 ? null : (this.bump(), String.fromCodePoint(n));
	}
	parseArgument(e, t) {
		let n = this.clonePosition();
		if (this.bump(), this.bumpSpace(), this.isEOF()) return this.error(1, z(n, this.clonePosition()));
		if (this.char() === 125) return this.bump(), this.error(2, z(n, this.clonePosition()));
		let r = this.parseIdentifierIfPossible().value;
		if (!r) return this.error(3, z(n, this.clonePosition()));
		if (this.bumpSpace(), this.isEOF()) return this.error(1, z(n, this.clonePosition()));
		switch (this.char()) {
			case 125: return this.bump(), {
				val: {
					type: 1,
					value: r,
					location: z(n, this.clonePosition())
				},
				err: null
			};
			case 44: return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(1, z(n, this.clonePosition())) : this.parseArgumentOptions(e, t, r, n);
			default: return this.error(3, z(n, this.clonePosition()));
		}
	}
	parseIdentifierIfPossible() {
		let e = this.clonePosition(), t = this.offset(), n = Tt(this.message, t), r = t + n.length;
		return this.bumpTo(r), {
			value: n,
			location: z(e, this.clonePosition())
		};
	}
	parseArgumentOptions(e, t, n, r) {
		let i = this.clonePosition(), a = this.parseIdentifierIfPossible().value, o = this.clonePosition();
		switch (a) {
			case "": return this.error(4, z(i, o));
			case "number":
			case "date":
			case "time": {
				this.bumpSpace();
				let e = null;
				if (this.bumpIf(",")) {
					this.bumpSpace();
					let t = this.clonePosition(), n = this.parseSimpleArgStyleIfPossible();
					if (n.err) return n;
					let r = Ct(n.val);
					if (r.length === 0) return this.error(6, z(this.clonePosition(), this.clonePosition()));
					e = {
						style: r,
						styleLocation: z(t, this.clonePosition())
					};
				}
				let t = this.tryParseArgumentClose(r);
				if (t.err) return t;
				let i = z(r, this.clonePosition());
				if (e && e.style.startsWith("::")) {
					let t = St(e.style.slice(2));
					if (a === "number") {
						let r = this.parseNumberSkeletonFromString(t, e.styleLocation);
						return r.err ? r : {
							val: {
								type: 2,
								value: n,
								location: i,
								style: r.val
							},
							err: null
						};
					} else {
						if (t.length === 0) return this.error(10, i);
						let r = t;
						this.locale && (r = mt(t, this.locale));
						let o = {
							type: 1,
							pattern: r,
							location: e.styleLocation,
							parsedOptions: this.shouldParseSkeletons ? Ue(r) : {}
						};
						return {
							val: {
								type: a === "date" ? 3 : 4,
								value: n,
								location: i,
								style: o
							},
							err: null
						};
					}
				}
				return {
					val: {
						type: a === "number" ? 2 : a === "date" ? 3 : 4,
						value: n,
						location: i,
						style: e?.style ?? null
					},
					err: null
				};
			}
			case "plural":
			case "selectordinal":
			case "select": {
				let i = this.clonePosition();
				if (this.bumpSpace(), !this.bumpIf(",")) return this.error(12, z(i, { ...i }));
				this.bumpSpace();
				let o = this.parseIdentifierIfPossible(), s = 0;
				if (a !== "select" && o.value === "offset") {
					if (!this.bumpIf(":")) return this.error(13, z(this.clonePosition(), this.clonePosition()));
					this.bumpSpace();
					let e = this.tryParseDecimalInteger(13, 14);
					if (e.err) return e;
					this.bumpSpace(), o = this.parseIdentifierIfPossible(), s = e.val;
				}
				let c = this.tryParsePluralOrSelectOptions(e, a, t, o);
				if (c.err) return c;
				let l = this.tryParseArgumentClose(r);
				if (l.err) return l;
				let u = z(r, this.clonePosition());
				return a === "select" ? {
					val: {
						type: 5,
						value: n,
						options: xt(c.val),
						location: u
					},
					err: null
				} : {
					val: {
						type: 6,
						value: n,
						options: xt(c.val),
						offset: s,
						pluralType: a === "plural" ? "cardinal" : "ordinal",
						location: u
					},
					err: null
				};
			}
			default: return this.error(5, z(i, o));
		}
	}
	tryParseArgumentClose(e) {
		return this.isEOF() || this.char() !== 125 ? this.error(1, z(e, this.clonePosition())) : (this.bump(), {
			val: !0,
			err: null
		});
	}
	parseSimpleArgStyleIfPossible() {
		let e = 0, t = this.clonePosition();
		for (; !this.isEOF();) switch (this.char()) {
			case 39: {
				this.bump();
				let e = this.clonePosition();
				if (!this.bumpUntil("'")) return this.error(11, z(e, this.clonePosition()));
				this.bump();
				break;
			}
			case 123:
				e += 1, this.bump();
				break;
			case 125:
				if (e > 0) --e;
				else return {
					val: this.message.slice(t.offset, this.offset()),
					err: null
				};
				break;
			default:
				this.bump();
				break;
		}
		return {
			val: this.message.slice(t.offset, this.offset()),
			err: null
		};
	}
	parseNumberSkeletonFromString(e, t) {
		let n = [];
		try {
			n = Ge(e);
		} catch {
			return this.error(7, t);
		}
		return {
			val: {
				type: 0,
				tokens: n,
				location: t,
				parsedOptions: this.shouldParseSkeletons ? tt(n) : {}
			},
			err: null
		};
	}
	tryParsePluralOrSelectOptions(e, t, n, r) {
		let i = !1, a = [], o = /* @__PURE__ */ new Set(), { value: s, location: c } = r;
		for (;;) {
			if (s.length === 0) {
				let e = this.clonePosition();
				if (t !== "select" && this.bumpIf("=")) {
					let t = this.tryParseDecimalInteger(16, 19);
					if (t.err) return t;
					c = z(e, this.clonePosition()), s = this.message.slice(e.offset, this.offset());
				} else break;
			}
			if (o.has(s)) return this.error(t === "select" ? 21 : 20, c);
			s === "other" && (i = !0), this.bumpSpace();
			let r = this.clonePosition();
			if (!this.bumpIf("{")) return this.error(t === "select" ? 17 : 18, z(this.clonePosition(), this.clonePosition()));
			let l = this.parseMessage(e + 1, t, n);
			if (l.err) return l;
			let u = this.tryParseArgumentClose(r);
			if (u.err) return u;
			a.push([s, {
				value: l.val,
				location: z(r, this.clonePosition())
			}]), o.add(s), this.bumpSpace(), {value: s, location: c} = this.parseIdentifierIfPossible();
		}
		return a.length === 0 ? this.error(t === "select" ? 15 : 16, z(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !i ? this.error(22, z(this.clonePosition(), this.clonePosition())) : {
			val: a,
			err: null
		};
	}
	tryParseDecimalInteger(e, t) {
		let n = 1, r = this.clonePosition();
		this.bumpIf("+") || this.bumpIf("-") && (n = -1);
		let i = !1, a = 0;
		for (; !this.isEOF();) {
			let e = this.char();
			if (e >= 48 && e <= 57) i = !0, a = a * 10 + (e - 48), this.bump();
			else break;
		}
		let o = z(r, this.clonePosition());
		return i ? (a *= n, Number.isSafeInteger(a) ? {
			val: a,
			err: null
		} : this.error(t, o)) : this.error(e, o);
	}
	offset() {
		return this.position.offset;
	}
	isEOF() {
		return this.offset() === this.message.length;
	}
	clonePosition() {
		return {
			offset: this.position.offset,
			line: this.position.line,
			column: this.position.column
		};
	}
	char() {
		let e = this.position.offset;
		if (e >= this.message.length) throw Error("out of bound");
		let t = this.message.codePointAt(e);
		if (t === void 0) throw Error(`Offset ${e} is at invalid UTF-16 code unit boundary`);
		return t;
	}
	error(e, t) {
		return {
			val: null,
			err: {
				kind: e,
				message: this.message,
				location: t
			}
		};
	}
	bump() {
		if (this.isEOF()) return;
		let e = this.char();
		e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
	}
	bumpIf(e) {
		if (this.message.startsWith(e, this.offset())) {
			for (let t = 0; t < e.length; t++) this.bump();
			return !0;
		}
		return !1;
	}
	bumpUntil(e) {
		let t = this.offset(), n = this.message.indexOf(e, t);
		return n >= 0 ? (this.bumpTo(n), !0) : (this.bumpTo(this.message.length), !1);
	}
	bumpTo(e) {
		if (this.offset() > e) throw Error(`targetOffset ${e} must be greater than or equal to the current offset ${this.offset()}`);
		for (e = Math.min(e, this.message.length);;) {
			let t = this.offset();
			if (t === e) break;
			if (t > e) throw Error(`targetOffset ${e} is at invalid UTF-16 code unit boundary`);
			if (this.bump(), this.isEOF()) break;
		}
	}
	bumpSpace() {
		for (; !this.isEOF() && At(this.char());) this.bump();
	}
	peek() {
		if (this.isEOF()) return null;
		let e = this.char(), t = this.offset();
		return this.message.charCodeAt(t + (e >= 65536 ? 2 : 1)) ?? null;
	}
};
function B(e) {
	return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function Ot(e) {
	return B(e) || e === 47;
}
function kt(e) {
	return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function At(e) {
	return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function V(e) {
	e.forEach((e) => {
		if (delete e.location, ct(e) || lt(e)) for (let t in e.options) delete e.options[t].location, V(e.options[t].value);
		else at(e) && ft(e.style) || (ot(e) || st(e)) && L(e.style) ? delete e.style.location : dt(e) && V(e.children);
	});
}
function jt(e, t = {}) {
	t = {
		shouldParseSkeletons: !0,
		requiresOtherClause: !0,
		...t
	};
	let n = new Dt(e, t).parse();
	if (n.err) {
		let e = SyntaxError(nt[n.err.kind]);
		throw e.location = n.err.location, e.originalMessage = n.err.message, e;
	}
	return t?.captureLocation || V(n.val), n.val;
}
//#endregion
//#region ../../node_modules/.bun/intl-messageformat@11.2.13/node_modules/intl-messageformat/index.js
var H = class extends Error {
	constructor(e, t, n) {
		super(e), this.code = t, this.originalMessage = n;
	}
	toString() {
		return `[formatjs Error: ${this.code}] ${this.message}`;
	}
}, Mt = class extends H {
	constructor(e, t, n, r) {
		super(`Invalid values for "${e}": "${t}". Options are "${Object.keys(n).join("\", \"")}"`, "INVALID_VALUE", r);
	}
}, Nt = class extends H {
	constructor(e, t, n) {
		super(`Value for "${e}" must be of type ${t}`, "INVALID_VALUE", n);
	}
}, Pt = class extends H {
	constructor(e, t) {
		super(`The intl string context variable "${e}" was not provided to the string "${t}"`, "MISSING_VALUE", t);
	}
};
function Ft(e) {
	return e.length < 2 ? e : e.reduce((e, t) => {
		let n = e[e.length - 1];
		return !n || n.type !== 0 || t.type !== 0 ? e.push(t) : n.value += t.value, e;
	}, []);
}
function It(e) {
	return typeof e == "function";
}
function U(e, t, n, r, i, a, o) {
	if (e.length === 1 && rt(e[0])) return [{
		type: 0,
		value: e[0].value
	}];
	let s = [];
	for (let c of e) {
		if (rt(c)) {
			s.push({
				type: 0,
				value: c.value
			});
			continue;
		}
		if (ut(c)) {
			typeof a == "number" && s.push({
				type: 0,
				value: n.getNumberFormat(t).format(a)
			});
			continue;
		}
		let { value: e } = c;
		if (!(i && e in i)) throw new Pt(e, o);
		let l = i[e];
		if (it(c)) {
			(!l || typeof l == "string" || typeof l == "number" || typeof l == "bigint") && (l = typeof l == "string" || typeof l == "number" || typeof l == "bigint" ? String(l) : ""), s.push({
				type: typeof l == "string" ? 0 : 1,
				value: l
			});
			continue;
		}
		if (ot(c)) {
			let e = typeof c.style == "string" ? r.date[c.style] : L(c.style) ? c.style.parsedOptions : void 0;
			s.push({
				type: 0,
				value: n.getDateTimeFormat(t, e).format(l)
			});
			continue;
		}
		if (st(c)) {
			let e = typeof c.style == "string" ? r.time[c.style] : L(c.style) ? c.style.parsedOptions : r.time.medium;
			s.push({
				type: 0,
				value: n.getDateTimeFormat(t, e).format(l)
			});
			continue;
		}
		if (at(c)) {
			let e = typeof c.style == "string" ? r.number[c.style] : ft(c.style) ? c.style.parsedOptions : void 0;
			if (e && e.scale) {
				let t = e.scale || 1;
				if (typeof l == "bigint") {
					if (!Number.isInteger(t)) throw TypeError(`Cannot apply fractional scale ${t} to bigint value. Scale must be an integer when formatting bigint.`);
					l *= BigInt(t);
				} else l *= t;
			}
			s.push({
				type: 0,
				value: n.getNumberFormat(t, e).format(l)
			});
			continue;
		}
		if (dt(c)) {
			let { children: e, value: l } = c, u = i[l];
			if (!It(u)) throw new Nt(l, "function", o);
			let d = u(U(e, t, n, r, i, a).map((e) => e.value));
			Array.isArray(d) || (d = [d]), s.push(...d.map((e) => ({
				type: typeof e == "string" ? 0 : 1,
				value: e
			})));
		}
		if (ct(c)) {
			let e = l, a = (Object.prototype.hasOwnProperty.call(c.options, e) ? c.options[e] : void 0) || c.options.other;
			if (!a) throw new Mt(c.value, l, Object.keys(c.options), o);
			s.push(...U(a.value, t, n, r, i));
			continue;
		}
		if (lt(c)) {
			let e = `=${l}`, a = Object.prototype.hasOwnProperty.call(c.options, e) ? c.options[e] : void 0;
			if (!a) {
				if (!Intl.PluralRules) throw new H("Intl.PluralRules is not available in this environment.\nTry polyfilling it using \"@formatjs/intl-pluralrules\"\n", "MISSING_INTL_API", o);
				let e = typeof l == "bigint" ? Number(l) : l, r = n.getPluralRules(t, { type: c.pluralType }).select(e - (c.offset || 0));
				a = (Object.prototype.hasOwnProperty.call(c.options, r) ? c.options[r] : void 0) || c.options.other;
			}
			if (!a) throw new Mt(c.value, l, Object.keys(c.options), o);
			let u = typeof l == "bigint" ? Number(l) : l;
			s.push(...U(a.value, t, n, r, i, u - (c.offset || 0)));
			continue;
		}
	}
	return Ft(s);
}
function Lt(e, t) {
	return t ? {
		...e,
		...t,
		...Object.keys(e).reduce((n, r) => (n[r] = {
			...e[r],
			...t[r]
		}, n), {})
	} : e;
}
function Rt(e, t) {
	return t ? Object.keys(e).reduce((n, r) => (n[r] = Lt(e[r], t[r]), n), { ...e }) : e;
}
function W(e) {
	return { create() {
		return {
			get(t) {
				return e[t];
			},
			set(t, n) {
				e[t] = n;
			}
		};
	} };
}
function zt(e = {
	number: {},
	dateTime: {},
	pluralRules: {}
}) {
	return {
		getNumberFormat: P((...e) => new Intl.NumberFormat(...e), {
			cache: W(e.number),
			strategy: I.variadic
		}),
		getDateTimeFormat: P((...e) => new Intl.DateTimeFormat(...e), {
			cache: W(e.dateTime),
			strategy: I.variadic
		}),
		getPluralRules: P((...e) => new Intl.PluralRules(...e), {
			cache: W(e.pluralRules),
			strategy: I.variadic
		})
	};
}
var Bt = class e {
	constructor(t, n = e.defaultLocale, r, i) {
		if (this.formatterCache = {
			number: {},
			dateTime: {},
			pluralRules: {}
		}, this.format = (e) => {
			let t = this.formatToParts(e);
			if (t.length === 1) return t[0].value;
			let n = t.reduce((e, t) => (!e.length || t.type !== 0 || typeof e[e.length - 1] != "string" ? e.push(t.value) : e[e.length - 1] += t.value, e), []);
			return n.length <= 1 ? n[0] || "" : n;
		}, this.formatToParts = (e) => U(this.ast, this.locales, this.formatters, this.formats, e, void 0, this.message), this.resolvedOptions = () => ({ locale: this.resolvedLocale?.toString() || Intl.NumberFormat.supportedLocalesOf(this.locales)[0] }), this.getAst = () => this.ast, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
			if (this.message = t, !e.__parse) throw TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
			let { ...n } = i || {};
			this.ast = e.__parse(t, {
				...n,
				locale: this.resolvedLocale
			});
		} else this.ast = t;
		if (!Array.isArray(this.ast)) throw TypeError("A message must be provided as a String or AST.");
		this.formats = Rt(e.formats, r), this.formatters = i && i.formatters || zt(this.formatterCache);
	}
	static {
		this.memoizedDefaultLocale = null;
	}
	static get defaultLocale() {
		return e.memoizedDefaultLocale ||= new Intl.NumberFormat().resolvedOptions().locale, e.memoizedDefaultLocale;
	}
	static {
		this.resolveLocale = (e) => {
			if (Intl.Locale === void 0) return;
			let t = Intl.NumberFormat.supportedLocalesOf(e);
			return t.length > 0 ? new Intl.Locale(t[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
		};
	}
	static {
		this.__parse = jt;
	}
	static {
		this.formats = {
			number: {
				integer: { maximumFractionDigits: 0 },
				currency: { style: "currency" },
				percent: { style: "percent" }
			},
			date: {
				short: {
					month: "numeric",
					day: "numeric",
					year: "2-digit"
				},
				medium: {
					month: "short",
					day: "numeric",
					year: "numeric"
				},
				long: {
					month: "long",
					day: "numeric",
					year: "numeric"
				},
				full: {
					weekday: "long",
					month: "long",
					day: "numeric",
					year: "numeric"
				}
			},
			time: {
				short: {
					hour: "numeric",
					minute: "numeric"
				},
				medium: {
					hour: "numeric",
					minute: "numeric",
					second: "numeric"
				},
				long: {
					hour: "numeric",
					minute: "numeric",
					second: "numeric",
					timeZoneName: "short"
				},
				full: {
					hour: "numeric",
					minute: "numeric",
					second: "numeric",
					timeZoneName: "short"
				}
			}
		};
	}
};
//#endregion
//#region ../../node_modules/.bun/i18next-icu@2.4.4+85079ac2b5c58174/node_modules/i18next-icu/dist/es/index.js
function Vt(e, t) {
	return Kt(e) || Gt(e, t) || Ut(e, t) || Ht();
}
function Ht() {
	throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function Ut(e, t) {
	if (e) {
		if (typeof e == "string") return Wt(e, t);
		var n = Object.prototype.toString.call(e).slice(8, -1);
		if (n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set") return Array.from(e);
		if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Wt(e, t);
	}
}
function Wt(e, t) {
	(t == null || t > e.length) && (t = e.length);
	for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
	return r;
}
function Gt(e, t) {
	if (!(typeof Symbol > "u" || !(Symbol.iterator in Object(e)))) {
		var n = [], r = !0, i = !1, a = void 0;
		try {
			for (var o = e[Symbol.iterator](), s; !(r = (s = o.next()).done) && (n.push(s.value), !(t && n.length === t)); r = !0);
		} catch (e) {
			i = !0, a = e;
		} finally {
			try {
				!r && o.return != null && o.return();
			} finally {
				if (i) throw a;
			}
		}
		return n;
	}
}
function Kt(e) {
	if (Array.isArray(e)) return e;
}
function G(e) {
	"@babel/helpers - typeof";
	return G = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
		return typeof e;
	} : function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, G(e);
}
function qt(e, t) {
	var n = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var r = Object.getOwnPropertySymbols(e);
		t && (r = r.filter(function(t) {
			return Object.getOwnPropertyDescriptor(e, t).enumerable;
		})), n.push.apply(n, r);
	}
	return n;
}
function Jt(e) {
	for (var t = 1; t < arguments.length; t++) {
		var n = arguments[t] == null ? {} : arguments[t];
		t % 2 ? qt(Object(n), !0).forEach(function(t) {
			Yt(e, t, n[t]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : qt(Object(n)).forEach(function(t) {
			Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
		});
	}
	return e;
}
function Yt(e, t, n) {
	return t in e ? Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[t] = n, e;
}
function Xt(e, t) {
	if (!(e instanceof t)) throw TypeError("Cannot call a class as a function");
}
function Zt(e, t) {
	for (var n = 0; n < t.length; n++) {
		var r = t[n];
		r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r);
	}
}
function Qt(e, t, n) {
	return t && Zt(e.prototype, t), n && Zt(e, n), e;
}
function $t() {
	return {
		memoize: !0,
		memoizeFallback: !1,
		bindI18n: "",
		bindI18nStore: "",
		parseErrorHandler: function(e, t, n, r) {
			return n;
		},
		parseLngForICU: function(e) {
			return e;
		},
		escapeVariables: !1
	};
}
var K = /* @__PURE__ */ function() {
	function e(t) {
		Xt(this, e), this.type = "i18nFormat", this.mem = {}, this.init(null, t);
	}
	return Qt(e, [
		{
			key: "init",
			value: function(e, t) {
				var n = this, r = e && e.options && e.options.i18nFormat || {};
				if (this.options = Me(r, t, this.options || {}, $t()), this.formats = this.options.formats, e) {
					var i = this.options, a = i.bindI18n, o = i.bindI18nStore, s = i.memoize;
					e.IntlMessageFormat = Bt, e.ICU = this, s && (a && e.on(a, function() {
						return n.clearCache();
					}), o && e.store.on(o, function() {
						return n.clearCache();
					}));
				}
			}
		},
		{
			key: "addUserDefinedFormats",
			value: function(e) {
				this.formats = this.formats ? Jt(Jt({}, this.formats), e) : e;
			}
		},
		{
			key: "parse",
			value: function(e, t, n, r, i, a) {
				var o = a && a.resolved && a.resolved.res, s = this.options.memoize && `${n}.${r}.${i.replace(/\./g, "###")}`, c;
				this.options.memoize && (c = Oe(this.mem, s));
				try {
					return c || (c = new Bt(e, this.options.parseLngForICU(n), this.formats, { ignoreTag: !0 }), this.options.memoize && (this.options.memoizeFallback || !a || o) && De(this.mem, s, c)), c.format(this.escapeVariableValues(t));
				} catch (n) {
					return this.options.parseErrorHandler(n, i, e, t);
				}
			}
		},
		{
			key: "addLookupKeys",
			value: function(e, t, n, r, i) {
				return e;
			}
		},
		{
			key: "clearCache",
			value: function() {
				this.mem = {};
			}
		},
		{
			key: "escapeVariableValues",
			value: function(e) {
				if (!this.options.escapeVariables || !e || G(e) !== "object") return e;
				for (var t = {}, n = 0, r = Object.entries(e); n < r.length; n++) {
					var i = Vt(r[n], 2), a = i[0], o = i[1];
					typeof o == "string" ? t[a] = o.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;") : t[a] = o;
				}
				return t;
			}
		}
	]), e;
}();
K.type = "i18nFormat";
var en = {
	authWaitSpinner: { loading: "Loading" },
	signupScreen: {
		headlineLead: "Meet your new",
		headlineRoles: {
			personalIntelligence: "Personal Intelligence",
			softwareEngineer: "Software Engineer",
			financeOps: "Finance Ops",
			householdManager: "Household Manager",
			gtmEngineer: "GTM Engineer",
			productLead: "Product Lead"
		},
		subtitle: "The most powerful assistant that can handle your work and life admin tasks.",
		continue: "Continue",
		downloadMac: "Download for macOS",
		haveAccountPrompt: "Already have an account? <signIn>Sign in</signIn>"
	},
	signupClosedScreen: {
		title: "Signups are currently closed",
		message: "Sorry, Cadet is not accepting new signups at this time. Feel free to try again later. Alternatively, you can self-host Cadet. Learn more about self-hosting <selfHostingLink>here</selfHostingLink>.",
		haveAccountPrompt: "Already have an account? <signIn>Sign in</signIn>"
	},
	accountPage: {
		loading: "Loading...",
		welcomeTitle: "Welcome to Cadet",
		welcomeSubtitle: "Sign in to get started.",
		signIn: "Sign in",
		signedInTitle: "Welcome!",
		signedInTitleNamed: "Welcome, {name}!",
		signedInSubtitle: "You are signed in.",
		goToAssistant: "Go to your assistant",
		signOut: "Sign out",
		manageAssistants: "Manage assistants"
	},
	loginPage: {
		signUp: "Sign up",
		signIn: "Sign in"
	},
	logoutPage: { title: "Signing out..." },
	platformLoopbackPage: {
		backToWelcome: "Back to Welcome",
		completing: "Completing login..."
	},
	oauthComplete: { errorCode: "Error: {code}" },
	providerCallbackPage: {
		signupClosedTitle: "Signups are currently closed",
		signupClosedSubtitle: "Sorry, Cadet is not accepting new signups at this time. Feel free to try again later.",
		backToSignIn: "Back to sign in",
		failedTitle: "Authentication failed",
		failedSubtitle: "Something went wrong during social sign-in. Please try again or use a different method.",
		completingTitle: "Completing sign-in...",
		completingSubtitle: "Please wait while we finish authenticating you."
	},
	providerSignupPage: {
		completingTitle: "Completing signup...",
		completingSubtitle: "Please wait while we load your information.",
		headingLine1: "Almost there,",
		headingLine2: "one more detail",
		firstNameQuestion: "What should I call you?",
		firstNamePlaceholder: "First name",
		lastNameQuestion: "And your last name?",
		lastNamePlaceholder: "Last name",
		roleQuestion: "Your role",
		rolePlaceholder: "e.g. Software Engineer",
		submitting: "Setting up…",
		submit: "Continue →",
		completeAccountTitle: "Complete your account",
		completeAccountSubtitle: "We need a few more details to finish setting up your account.",
		backToSignIn: "← Back to sign in",
		emailPlaceholder: "Email",
		usernamePlaceholder: "Username",
		completeSignup: "Complete signup",
		completingSignup: "Completing..."
	},
	authErrors: {
		genericFailure: "Something went wrong. Please try again.",
		signupClosed: "Sorry, Cadet is not accepting new signups at this time. Feel free to try again later.",
		providerSignup: "No Cadet account is linked to that login yet. Sign up first, then sign in.",
		loginIncomplete: "Your account needs another step to finish signing in. Please sign in on the web, then try again.",
		desktopUpdateRequired: "This version of the Cadet desktop app can't sign in. Update the app, then try again.",
		loopbackStateMismatch: "Login failed: state mismatch. Please try again.",
		loopbackNoToken: "Login failed: no session token received. Please try again.",
		loopbackInvalidToken: "Login failed: invalid session token."
	},
	welcome: {
		title: "Welcome to Cadet",
		body: "Your own personal intelligence is just a step away.",
		cancel: "Cancel",
		logIn: "Log In",
		continueWithoutAccount: "Continue without account",
		comingSoon: "Coming Soon!"
	},
	selectAssistantScreen: {
		listAriaLabel: "Assistants",
		create: "Create an assistant",
		rowActionsAriaLabel: "Actions for {name}",
		retire: "Retire Assistant",
		addRemote: "Add a remote assistant",
		currentWithHost: "Current · {host}",
		remoteWithHost: "Remote · {host}",
		removeFromDevice: "Remove from this device…",
		unnamedAssistant: "the assistant",
		hatchAssistant: "Hatch a new assistant",
		localAssistant: "On this computer",
		cloudHosted: "Cloud-hosted",
		cloudHostedWithHost: "Cloud-hosted · {host}",
		selfHosted: "Self-hosted"
	},
	appShell: {
		loading: "Loading assistant…",
		error: "Unable to load assistant.",
		errorTitle: "We couldn't reach your assistant",
		errorBody: "It didn't respond just now. If your assistant was just started, give it a moment, then retry.",
		notReady: "Your assistant isn't ready.",
		notReadyTitle: "Your assistant isn't ready.",
		notReadyBody: "It isn't up right now. Try again in a bit, or start it from your Cadet account.",
		wake: "Wake it up",
		waking: "Waking…",
		wakeFailed: "The wake didn't go through just now. Try again in a bit.",
		empty: "No assistant is available.",
		unauthenticated: "Please sign in to continue.",
		retry: "Retry",
		switchAssistant: "Switch assistant",
		title: "Assistant",
		selection: "Choose an assistant.",
		unavailable: "This assistant is unavailable.",
		assistantSwitchFailed: "Couldn't switch to that assistant."
	},
	actions: {
		cancel: "Cancel",
		add: "Add",
		adding: "Adding…",
		connect: "Connect",
		connecting: "Connecting…",
		continue: "Continue",
		back: "Back",
		loginToUse: "Log in to use",
		tryAgain: "Try again"
	},
	connectAssistantDialog: {
		title: "Connect a Remote Assistant",
		instruction: "Paste the pairing link from the assistant's Pair a device settings, or just its address, and approve the request there.",
		linkGuidance: "This link came from a pairing QR code. To connect this device, paste the pairing link from the assistant's machine here.",
		legacyLinkGuidance: "This link came from an older version of the app and can no longer be used. Generate a new pairing link on the assistant's machine and paste it here.",
		addressLabel: "Address or pairing link",
		addressPlaceholder: "https://your-assistant.ts.net",
		nameLabel: "Name (optional)",
		approveOnHost: "Approve this code on the assistant's machine to finish connecting.",
		waitingForApproval: "Waiting for approval…",
		retrying: "The assistant isn't ready to pair yet. Still trying until the code expires.",
		expiresIn: "Expires in {time}",
		retryExpired: "The pairing code expired before the assistant was ready to pair. Start over to get a new one.",
		submitError: "Failed to connect to that assistant. Please try again.",
		importedTitle: "Pairing Imported",
		importedBody: "This pairing is access-only: it works now, but its access expires and cannot renew itself. When it does, generate a fresh pairing link on the assistant's machine and paste it here to pair again."
	},
	startScreen: { createAssistant: "Create your assistant" },
	hostingScreen: {
		title: "Hosting",
		body: "Choose where you want your assistant to live.",
		needHelp: "Need help deciding?",
		optionsAriaLabel: "Hosting options"
	},
	apiKeyScreen: {
		title: "Connect a Model Provider",
		body: "Choose the model provider your assistant should use.",
		providerLabel: "Provider",
		modelLabel: "Model",
		baseUrlLabel: "Base URL",
		modelsLabel: "Models",
		modelsPlaceholder: "model-1, model-2",
		modelsHelp: "Comma-separated model identifiers exposed by your endpoint.",
		apiKeyLabel: "{provider} API Key",
		apiKeyPlaceholder: "Enter your API key",
		noKeyPrompt: "Don't have it?",
		getKeyLink: "Get an API key here"
	},
	hatchingScreen: {
		apiKeyFailed: "Your API key didn't work",
		genericFailure: "Something went wrong",
		ready: "Your assistant is ready!",
		updateApiKey: "Update API key",
		waking: "Waking up…",
		wakingBody: "Hang tight, your assistant will have a few questions for you once it's up.",
		progressAriaLabel: "Assistant startup progress",
		phase: {
			initializing: "Getting things ready…",
			provisioning: "Setting up your assistant…",
			connecting: "Connecting to your assistant…",
			ready: "Ready"
		}
	},
	pairingPage: {
		pairingCode: "Pairing code",
		pair: "Pair",
		expiresAt: "Expires {time}.",
		cancel: "Cancel",
		enterNewCode: "Enter a new code"
	},
	assistantBackups: {
		columnCreated: "Created",
		columnReady: "Ready",
		columnSnapshotName: "Snapshot Name",
		columnType: "Type",
		copyFailed: "Couldn't copy the snapshot name.",
		copySnapshotName: "Copy snapshot name",
		createBackup: "Create Backup",
		createFailedToast: "Failed to create backup.",
		createSuccessToast: "Backup started. It will appear in the list shortly.",
		creating: "Creating…",
		empty: "No backups found for this assistant.",
		export: "Export",
		exportDownloading: "Downloading…",
		exportExporting: "Exporting…",
		exportFailedToast: "Failed to export the assistant.",
		exportMessage: "Download a .tar.gz archive of the whole installation, including encrypted credentials and the keys needed to read them. Keep this archive private.",
		exportPreparing: "Preparing…",
		exportTitle: "Export Assistant",
		loadFailed: "Failed to load backups.",
		loading: "Loading backups...",
		notReady: "Backup is not ready to use",
		oldestRemovedNotice: "Creating a new backup will remove the oldest one.",
		pending: "Pending",
		ready: "Ready",
		restore: "Restore",
		restoreFailedToast: "Failed to restore backup.",
		restoreMessage: "Restore from backup \"{name}\"?\n\nThe assistant will be temporarily unavailable during the restore.",
		restoreSuccessToast: "Backup restored successfully.",
		restoreTitle: "Restore Backup",
		typeDoctor: "Doctor",
		typePointInTime: "Point-in-time",
		typePreview: "Preview",
		typeScheduled: "Scheduled"
	},
	assistantUpgrades: {
		alreadyOnVersion: "You are already on this version.",
		confirmUpdateMessage: "Update to version {version}? The assistant will be briefly unavailable during the update.",
		confirmUpdateTitle: "Update assistant",
		current: "Current",
		currentSuffix: "(current)",
		latest: "latest",
		latestSuffix: "(latest)",
		loading: "Loading...",
		noReleases: "No releases available",
		selected: "Selected",
		successUpdated: "Successfully updated to version {version}.",
		toastUpdateComplete: "Update complete. Your assistant is healthy.",
		toastUpdateFailed: "Failed to trigger update. Please try again.",
		toastUpdateInitiated: "Update to {version} initiated.",
		update: "Update",
		updateTo: "Update to",
		updating: "Updating..."
	},
	assistantsPage: {
		title: "Manage assistants",
		subtitle: "Backups, upgrades, and exports for each assistant on this account.",
		loading: "Loading your assistants...",
		loadFailed: "The assistant list failed to load.",
		retry: "Try again",
		signInRequired: "Sign in to manage your assistants.",
		empty: "No assistants on this account yet.",
		upgradesSection: "Version",
		backupsSection: "Backups",
		adminAccessSection: "Admin access",
		adminAccess: {
			stateOn: "Enabled — the assistant's data may be fetched through the cloud's admin seam (log downloads).",
			stateOff: "Disabled — the cloud's admin tooling cannot fetch this assistant's data.",
			enable: "Enable admin access",
			disable: "Disable admin access",
			working: "Working…",
			updated: "Admin access updated.",
			updateFailed: "The admin access update failed.",
			notAvailable: "Admin access applies to cloud-hosted assistants only."
		}
	}
}, tn = {
	doctorChatBlocks: {
		allowOnce: "Allow once",
		alwaysAllow: "Always Allow",
		backUp: "Back up",
		backupPromptBody: "The doctor is about to run <toolCode>{toolName}</toolCode>. Would you like to back up your workspace first?",
		backupPromptTitle: "Create a backup before modifying?",
		completedStep: "Completed 1 step",
		confirmationRequired: "Confirmation required",
		copyAria: "Copy to clipboard",
		copyAriaCopied: "Copied",
		copyError: "Couldn't copy the message.",
		copyTitle: "Copy",
		copyTitleCopied: "Copied!",
		deny: "Deny",
		failedStep: "Failed 1 step",
		feedbackBody: "You can send it with logs while the Doctor keeps looking for a fix or workaround here.",
		feedbackTitle: "This sounds like feedback for the Cadet team.",
		gladSolved: "Glad it's solved!",
		hideDetails: "Hide details",
		notSolved: "Not solved",
		notSolvedAria: "No, my problem is not solved",
		output: "Output",
		runningStep: "Running 1 step",
		shareFeedback: "Share Feedback",
		showDetails: "Show details",
		skip: "Skip",
		solvedAria: "Yes, my problem is solved",
		technicalDetails: "Technical Details",
		toolLabel: "Tool:"
	},
	doctorPanel: {
		connecting: "Connecting...",
		copiedToast: "Session copied to clipboard.",
		copyFailed: "Couldn't copy the session.",
		copySession: "Copy Session",
		endSession: "End Session",
		goToNewest: "Go to Newest",
		goToNewestAria: "Go to newest message",
		idleDescription: "Start a diagnostic session to have the Doctor analyze your assistant, identify issues, and suggest or apply fixes. The Doctor is free to use. Doctor logs may be temporarily stored.",
		idleTitle: "Assistant Doctor",
		loading: "Loading...",
		newSession: "New Session",
		noAssistant: "No assistant found. Hatch an assistant to use the Doctor.",
		placeholderApproval: "Type \"approve\" or \"deny\", or send a message...",
		placeholderMessage: "Type a message...",
		sendMessageAria: "Send message",
		sessionMenu: "Session options",
		shareFeedback: "Share Feedback",
		startSession: "Start Doctor Session",
		thinking: "Thinking…",
		title: "Doctor",
		openBackups: "Open backups in assistant settings"
	},
	shareFeedbackModal: {
		aboutDiagnosticsAria: "About diagnostics",
		addFiles: "Add files",
		attachments: "Attachments",
		bugTip: "Tip: Get faster support by posting in our <discordLink>Discord community</discordLink>",
		cancel: "Cancel",
		category: "Category",
		closeAria: "Close",
		diagnosticsTooltip: "Diagnostics include browser context, assistant logs, and timestamps - never passwords or credentials.",
		downloadDiagnostics: "Download diagnostics directly",
		downloadDiagnosticsAria: "Download diagnostics directly",
		downloadDiagnosticsButton: "Download diagnostics",
		dropFiles: "Drop files to attach…",
		featureTip: "Tip: Vote on features on our <roadmapLink>public roadmap</roadmapLink>",
		includeConversation: "Include the most recent conversation",
		includeConversationAria: "Include the most recent conversation",
		includeDiagnostics: "Include diagnostics",
		includeDiagnosticsAria: "Include browser diagnostics",
		messageLabelBug: "What went wrong?",
		messageLabelFeature: "Describe your idea",
		messageLabelOther: "What's on your mind?",
		messagePlaceholderBug: "What did you expect to happen, and what happened instead?",
		messagePlaceholderFeature: "What problem would this solve for you?",
		messagePlaceholderOther: "Share your thoughts...",
		preparingDiagnostics: "Preparing diagnostics…",
		reasonBugReport: "Bug Report",
		reasonFeatureRequest: "Feature Request",
		reasonOther: "Other",
		removeAttachmentAria: "Remove {name}",
		sendingFeedback: "Sending feedback…",
		submit: "Submit",
		timeRange: "Time range",
		timeRangeAllTime: "All time",
		timeRangeAria: "Diagnostics time range",
		timeRangePast24Hours: "Past 24 hours",
		timeRangePastHour: "Past hour",
		title: "Share Feedback",
		doctorSessionAttached: "The doctor session transcript will be attached to your report."
	},
	detailPanelStopButton: { tooltip: "Stop" },
	doctorPage: { empty: "There's no assistant on this machine yet. Hatch one first, then come back to the Doctor." }
}, nn = {
	aboutPage: {
		build: "Build",
		taglineMacOS: "AI assistant for your Mac",
		taglineWindows: "AI assistant for your PC",
		version: "Version"
	},
	activeAssistantGate: {
		connecting: "Connecting to your assistant…",
		logIn: "Log In",
		logOut: "Log Out",
		errorTitle: "We couldn't reach your assistant",
		retry: "Try again"
	},
	addCredentialModal: {
		cancel: "Cancel",
		credentialSaved: "Credential saved.",
		description: "Add an API key or token to let tools and integrations use it.",
		fieldLabel: "Field",
		fieldPlaceholder: "e.g. api_token",
		labelOptional: "Label (optional)",
		labelPlaceholder: "e.g. GitHub personal access token",
		save: "Save",
		saveFailed: "Failed to save credential",
		serviceLabel: "Service",
		servicePlaceholder: "e.g. github",
		title: "Add credential",
		valueLabel: "Value",
		valuePlaceholder: "Enter the secret value"
	},
	addCreditsModal: {
		amount: "Amount",
		cancel: "Cancel",
		configureAutoReload: "Configure Auto-Reload",
		continue: "Continue",
		description: "You'll be redirected to Stripe to complete the payment.",
		title: "Add Credits"
	},
	appCard: {
		openApp: "Open App",
		pin: "Pin",
		previewTitle: "{name} preview",
		unpin: "Unpin"
	},
	appNavBar: {
		close: "Close",
		copyLink: "Copy link",
		deploy: "Deploy",
		deployToVercel: "Deploy to Vercel",
		deployToVercelSubtitle: "Publish as a static page",
		deployedCopyLinkAria: "Deployed to Vercel, copy link",
		deployedCopyLinkTooltip: "Deployed: copy link",
		deployedToVercel: "Deployed to Vercel",
		deploying: "Deploying…",
		edit: "Edit",
		expandApp: "Expand app",
		fullscreen: "Fullscreen",
		openApp: "Open app",
		redeploy: "Redeploy",
		redeploySubtitle: "Publish the current version",
		share: "Share",
		shareAndDeploy: "Share & deploy",
		shareExportSubtitle: "Export as .cadet file",
		sharing: "Sharing…"
	},
	appViewerContainer: { exitFullscreen: "Exit fullscreen" },
	assistantConnect: { failed: "Failed to connect to the assistant." },
	assistantEmailIntroModal: { setUp: "Set up email" },
	assistantFeatureFlagStore: { updateFailed: "Couldn't update \"{label}\". Your change was reverted." },
	avatarManagementModal: {
		accent: "Accent",
		accentAutomatic: "Automatic",
		accentPickerLabel: "Accent color",
		accentReset: "Reset",
		body: "Body",
		color: "Color",
		eyes: "Eyes",
		keepUploadedDescription: "Saving the character replaces it",
		keepUploadedLabel: "Keep your uploaded image",
		loadError: "Unable to load avatar components. Make sure your assistant is running.",
		name: "Name",
		next: "Next {label}",
		previous: "Previous {label}",
		randomize: "Randomize",
		save: "Save",
		saving: "Saving…",
		title: "Update Avatar",
		uploadImage: "Upload image",
		uploadedAlt: "Uploaded avatar",
		useCharacterDescription: "Pick from our built-in avatars",
		useCharacterLabel: "Use a character instead"
	},
	bundleConfirmPage: {
		bySigner: "by {name}",
		cancel: "Cancel",
		capabilities: "Capabilities",
		createdBy: "Created by",
		hideWarnings: "Hide Warnings ({count})",
		install: "Install",
		installAnyway: "Install Anyway",
		loading: "Loading...",
		showWarnings: "Show Warnings ({count})",
		size: "Size"
	},
	byoVoiceNote: { body: "Your assistant speaks through a provider you configured yourself. Set its voice on <settingsLink>Models & Services</settingsLink>." },
	channelSetupCompleteNotice: {
		verifyTitle: "One last step: verify it's you",
		verifyAction: "Verify me",
		verifyBody: "Your assistant doesn't know which {channel} account is yours yet, so it won't answer you. Say \"verify me on {channel}\" in chat to finish.",
		verifyActionBody: "Your assistant doesn't know which {channel} account is yours yet, so it won't answer you. It finishes this with you in chat.",
		verifiedTitle: "You're verified",
		verifiedBody: "Your assistant knows your {channel} account, so it will answer you. You're all set."
	},
	chatAvatar: {
		alt: "Assistant avatar",
		fallbackLetter: "V"
	},
	chooserAvatarChip: { alt: "Assistant avatar" },
	collapsibleNavSection: { actionsTitle: "{title} actions" },
	commandPalette: {
		ariaLabel: "Command palette",
		clear: "Clear",
		clearSearch: "Clear search",
		closeSearch: "Close search",
		noResults: "No results",
		placeholder: "Search conversations, memories…",
		searchAriaLabel: "Search",
		searching: "Searching…"
	},
	companionIntro: {
		announcement: {
			body: "I can now join you anywhere on your desktop.",
			cards: {
				context: {
					body: "Let me see what you see and help in context.",
					title: "Show and explain"
				},
				flow: {
					body: "Reach me without leaving the app you’re in.",
					title: "Stay in your flow"
				},
				together: {
					body: "Talk, point, and make progress together.",
					title: "Work side by side"
				}
			},
			close: "Close",
			previewLabel: "Your desktop companion",
			previewAssistantName: "Quill",
			start: "Let’s go",
			title: "Meet me where you work"
		},
		ariaLabel: "Introducing your companion",
		back: "Back",
		call: {
			click: "Click",
			line: "Listening",
			shortcut: "Shortcut"
		},
		close: "Close",
		done: "Got it",
		draw: {
			body: "Point out anything on your screen",
			title: "Draw"
		},
		idle: {
			body: "Hover me and I’ll come out.",
			title: "Hey, it’s me",
			titleNamed: "Hey, it’s {name}"
		},
		key: {
			scolded: "No, the button on your keyboard",
			title: "Make it easy to talk to me"
		},
		meet: { body: "I stay on your desktop, even when Cadet isn’t visible." },
		mute: {
			body: "Click the mic to mute yourself or the speaker to mute me",
			title: "Mute"
		},
		next: "Next",
		share: {
			body: "Show me a tab, window, or entire screen",
			title: "Share your screen"
		},
		talk: {
			body: "Click me to start a conversation.",
			gesture: "Or double tap this key:",
			greeted: "You did it! That’s all there is to it.",
			title: "Talk to me"
		},
		try: {
			body: "Say hello and I’ll answer out loud.",
			how: "Click me, or double tap the key",
			title: "Give it a go"
		},
		permission: {
			microphoneAction: "Enable microphone",
			microphoneSettingsHint: "Turn on Cadet’s microphone switch in System Settings, then return here.",
			microphonePromptHint: "macOS will ask you to allow microphone access.",
			microphoneBody: "Let me use your microphone for voice conversations.",
			shortcutBody: "Let me hear the shortcut while you use other apps.",
			screenAction: "Enable screen sharing",
			screenBody: "Prepare screen sharing. You choose what to share when you use it.",
			openSettings: "Open Settings",
			settingsHint: "Allow access in System Settings, then return here.",
			restricted: "This permission is restricted on your Mac. You can skip this step.",
			error: "Could not check access. Try again.",
			waiting: "Checking access…",
			skip: "Skip for now"
		}
	},
	companionPopover: {
		allow: "Allow",
		confirm: "Confirm",
		credentialLabel: "Credential",
		defaultSuffix: "(default)",
		deny: "Deny",
		dismiss: "Dismiss",
		enter: "Enter",
		microphoneFallback: "Microphone {index}",
		microphonePermissionHint: "Allow microphone access to see each microphone by name.",
		microphoneTitle: "Microphone",
		needsCredentials: "Need a credential",
		needsCredentialsFor: "Need credentials for {service}",
		needsOkCount: "{count, plural, one {Need your OK on # thing} other {Need your OK on # things}}",
		notNow: "Not Now",
		openApp: "Open Cadet",
		pendingBadge: "{count, plural, one {# thing needs your OK} other {# things need your OK}}",
		previewVoice: "Preview {voice}",
		review: "Review",
		savedMicrophone: "Saved microphone",
		savedMicrophoneNotConnected: "Saved microphone (not connected)",
		stopPreview: "Stop preview",
		surfaceFallback: "Something to look at",
		systemDefault: "System Default",
		voiceTitle: "Voice"
	},
	companionSurface: {
		calling: "Calling…",
		callingNamed: "Calling {name}…",
		captureKind: "Source kind",
		captureNothing: "Nothing to show",
		capturePicker: "What to teach from",
		captureScreen: "Screen {n}",
		captureScreenRecordingOff: "Screen Recording is off",
		captureScreens: "Screens",
		captureTabs: "Chrome tabs",
		captureTurnOnScreenRecording: "Turn on",
		captureWindows: "Windows",
		dictating: "Listening",
		draw: "Draw",
		clearMarks: "Clear marks",
		drawTools: "Drawing tool",
		drawFreehand: "Freehand",
		drawLine: "Line",
		drawBox: "Box",
		drawCircle: "Circle",
		dictatingTranscribing: "Thinking",
		endSession: "End session",
		muteAssistant: "Mute assistant",
		muteAssistantNamed: "Mute {name}",
		muteMicrophone: "Mute microphone",
		notNow: "Not now",
		offerCopy: "Copy",
		offerDiscard: "Discard",
		offerHeard: "{app} pasted that",
		offerNowhere: "Nowhere to put these",
		offerPasteFailed: "Couldn't paste these",
		offerQuit: "Quit {app}",
		offerUse: "Use Cadet's",
		offerVersion: "Cadet heard",
		openCadet: "Open Cadet",
		share: "Share",
		sharePicker: "What to share",
		showSummary: "Show summary",
		stopTeaching: "Stop teaching",
		summarizing: "Summarizing",
		talk: "Talk",
		teach: "Teach",
		unmuteAssistant: "Unmute assistant",
		unmuteAssistantNamed: "Unmute {name}",
		unmuteMicrophone: "Unmute microphone",
		chooseMicrophone: "Choose microphone",
		workCount: "{count, plural, =0 {Nothing running} one {# thing running} other {# things running}}",
		workDone: "Done",
		workStopped: "Stopped",
		workMore: "{count} more",
		workWaiting: "{count, plural, one {# waiting on you} other {# waiting on you}}",
		workWaitingStep: "Waiting on you"
	},
	companionWatchFramePage: {
		sharingScreen: "Sharing your screen",
		sharingScreenNamed: "Sharing your screen with {name}",
		sharingWindow: "Sharing a window",
		sharingWindowNamed: "Sharing a window with {name}",
		teaching: "Teaching",
		teachingNamed: "Teaching {name}"
	},
	contentActionBar: {
		copiedAria: "Copied",
		copyFailed: "Couldn't copy the file contents.",
		copyFileContentsAria: "Copy file contents",
		downloadFileAria: "Download file",
		editFileAria: "Edit file"
	},
	conversationTitle: { untitled: "Untitled" },
	copyButton: {
		copied: "Copied",
		copyFailed: "Could not copy to the clipboard."
	},
	createAssistantDialog: {
		cancel: "Cancel",
		create: "Create",
		description: "Provision a new assistant. It will start up in the background.",
		namePlaceholder: "Assistant name (optional)",
		title: "New Assistant",
		toastSuccess: "New assistant created."
	},
	dateRangeSelect: {
		ariaLabel: "Date range",
		lastDays: "{days, plural, one {Last # day} other {Last # days}}"
	},
	deleteAppDialog: {
		delete: "Delete",
		deleting: "Deleting…",
		message: "\"{name}\" will be permanently removed.",
		title: "Delete app"
	},
	deployDialogs: {
		confirmLabel: "Let your assistant handle it",
		confirmLabelNamed: "Let {assistantName} handle it",
		message: "\"{appName}\" uses backend services that won't work on a static Vercel page. Your assistant can deploy it properly with serverless functions.",
		messageNamed: "\"{appName}\" uses backend services that won't work on a static Vercel page. {assistantName} can deploy it properly with serverless functions.",
		title: "This app needs a full deploy"
	},
	deployStore: {
		appExported: "App exported",
		deployFailed: "Failed to deploy",
		deployedToVercel: "Deployed to Vercel",
		open: "Open",
		shareFailed: "Failed to share app"
	},
	detailPanelStopButton: { tooltip: "Stop" },
	detailPrimitives: {
		copy: "Copy",
		expandedValue: "Expanded value",
		showLess: "Show less",
		showMore: "Show more"
	},
	dictationOverlayPage: { stopRecording: "Stop recording" },
	discordNudgeBanner: {
		ariaLabel: "Join the Cadet Discord community",
		ctaLong: "Join Discord",
		ctaShort: "Join",
		subtitleLong: "Talk to the team - share feedback, request features, get answers faster",
		subtitleShort: "Share feedback, request features, get answers faster",
		title: "Join our community!"
	},
	discordSetupConnectStep: {
		instructions: "Paste the bot token you copied from the Bot page.",
		verificationNoticeTitle: "Ignore the \"Verify your App\" page",
		verificationNoticeBody: "Discord shows it for every new app. It only matters past 100 servers.",
		botTokenLabel: "Bot token",
		save: "Connect",
		saving: "Connecting...",
		saved: "Connected. Next, add the bot to a server.",
		botTokenPlaceholder: "MTk4NjIyNDgzNzAyNDU0..."
	},
	discordSetupCreateStep: {
		inPortal: "In the Discord developer portal:",
		stepCreateApp: "Click <strong>New Application</strong> and give the app your assistant's name:",
		copyName: "Copy name",
		copied: "Copied!",
		stepAppIcon: "Optional: download the avatar, then upload it on <strong>General Information</strong> as the app icon.",
		stepResetToken: "Go to the <strong>Bot</strong> page in the app's menu, then click <strong>Reset Token</strong> and copy the token right away. Discord only shows it once.",
		stepIntentsOff: "On the same page, leave all three <strong>Privileged Gateway Intents</strong> switches off. Your assistant doesn't need them: it only reads direct messages and messages that mention it.",
		openPortal: "Open Discord portal",
		continue: "I have my token"
	},
	discordSetupFinishStep: {
		connectedTitle: "Bot added",
		connectedBody: "The token is saved and the bot is in your server. The Discord side is done."
	},
	discordSetupInviteStep: {
		instructions: "Your bot can't see or answer anything until it joins a server. Open the link, pick your server, and approve.",
		openInvite: "Add to a server",
		confirmJoined: "I've added the bot",
		noAppId: "Connect a bot token first, then come back to add it to a server."
	},
	discordSetupWizard: {
		channelLabel: "Discord",
		stepCreate: "Create app",
		stepConnect: "Connect",
		stepInvite: "Add to server",
		stepFinish: "Finish",
		copyError: "Could not copy the name. Type it into Discord instead."
	},
	diskPressureBanner: {
		acknowledge: "Acknowledge",
		acknowledging: "Acknowledging...",
		cleanupBody: "Prompt your assistant to free up space before it runs out and enters a locked state.",
		cleanupTitle: "Cleanup mode is active",
		criticalBody: "Your assistant will enter a locked state if it runs out of storage.",
		criticalModalDescription: "Your assistant will enter a locked state if it runs out of storage. You should either prompt your assistant to free up space or increase your storage.",
		criticalTitle: "Storage is critically low",
		dontShowAgain: "Don't show again",
		manageStorage: "Manage Storage",
		review: "Review",
		upgrade: "Upgrade",
		warningBody: "Free up space to avoid interruptions.",
		warningBodyWithUpgrade: "Free up space or add more storage to avoid interruptions.",
		warningTitle: "Your storage is almost full"
	},
	downloadFeedback: {
		failed: "Download failed",
		revealMac: "Show in Finder",
		revealWindows: "Show in File Explorer",
		saved: "Saved to Downloads",
		started: "Download started",
		startedDescription: "Look for {filename} in your browser's downloads."
	},
	editFooter: {
		discard: "Discard",
		save: "Save",
		saving: "Saving…"
	},
	featureIntroModal: { close: "Close" },
	fileViewMode: {
		formatted: "Formatted",
		modeAria: "How to show this file",
		source: "Source"
	},
	generateInviteLinkDialog: {
		copyAriaLabel: "Copy invite link",
		createFailed: "Failed to create invite link. Make sure A2A is enabled for your assistant.",
		creating: "Creating invite link…",
		done: "Done",
		shareHint: "Share this link with another assistant owner to establish a connection.",
		title: "Share Connection Link",
		tryAgain: "Try Again"
	},
	githubNudgeBanner: {
		ariaLabel: "Cadet is open source on GitHub",
		ctaAriaLabel: "Star Cadet on GitHub",
		ctaLabel: "Star us",
		subtitle: "Star us on GitHub or contribute",
		title: "Cadet is open source"
	},
	lazyBoundary: { loadError: "This section couldn't load. Reload the page to try again." },
	localNotification: { goToConversation: "Go to Conversation" },
	desktopAppBanner: {
		ariaLabelMacOS: "Download the macOS app",
		ariaLabelWindows: "Download the Windows app",
		ctaAriaLabelMacOS: "Download macOS app",
		ctaAriaLabelWindows: "Download Windows app",
		ctaLabel: "Download",
		subtitle: "Computer use · terminal access · native automation",
		titleMacOS: "Get the macOS app",
		titleWindows: "Get the Windows app"
	},
	nativeAppBanner: {
		bannerAria: "Download the {appName} app",
		bannerAriaGeneric: "Download the Cadet mobile app",
		download: "Download",
		downloadAppAria: "Download {appName} app",
		downloadAppAriaGeneric: "Download Cadet mobile app",
		subtitle: "Push notifications · biometric login · haptics",
		title: "Get the {appName} app",
		titleGeneric: "Get the Cadet app"
	},
	nudgeChatBanner: { dismissAria: "Dismiss" },
	onboardingBackButton: { back: "Back" },
	platformLoginNotice: {
		cancel: "Cancel",
		logIn: "Log In"
	},
	profileCard: {
		assistantHandleIdleEmpty: "Your assistant doesn't have a handle yet - claim one to make it mentionable.",
		assistantHandleLabel: "Assistant handle",
		assistantHandleUpdated: "Assistant handle updated.",
		available: "Available",
		availableHelper: "Available.",
		checkAvailabilityFailed: "Couldn't check availability.",
		checkingAvailability: "Checking availability…",
		chooseDifferentHandle: "Please choose a different handle.",
		emailLabel: "Email",
		handleHelper: "Lowercase letters, digits, hyphens, and underscores. 3–30 characters.",
		handleLocked: "Your assistant's handle is locked because it's used as its email subdomain. To change it, <releaseLink>release the subdomain</releaseLink> first.",
		loading: "Loading your profile…",
		notAvailable: "Not available",
		profileUpdated: "Profile updated.",
		save: "Save",
		saved: "Saved",
		saving: "Saving…",
		subtitle: "Manage your account details and preferences.",
		title: "Profile",
		userHandleIdleAutoGenerated: "Your handle was auto-generated at signup - pick one you like.",
		userHandleLabel: "User handle"
	},
	profileQuickAddProvider: { created: "Profile \"{name}\" created" },
	quickInputPage: {
		logoAlt: "Cadet",
		placeholder: "Ask Cadet anything...",
		send: "Send message"
	},
	removeFromDeviceDialog: {
		confirm: "Remove",
		messageOrigin: "This won't affect {assistantName} or sign you out there. It only forgets the entry on this device. Add it again anytime.",
		messagePaired: "This won't affect {assistantName} on its host machine. It only forgets the pairing on this device. Pair again anytime with cadet connect import.",
		messagePlatform: "This won't delete {assistantName}. It only removes it from this device. Logging in will make it available again.",
		title: "Remove from this device?",
		removeFailed: "Failed to remove device from assistant"
	},
	resourcePressureBanner: {
		body: "Your assistant is working hard and reaching its current resource limits. Upgrade to keep it running smoothly.",
		bodyNoUpgrade: "Your assistant is working hard and reaching its current resource limits.",
		dontShowAgain: "Don't show again",
		title: "Your assistant needs more power",
		titleNamed: "{assistantName} needs more power",
		upgrade: "Upgrade"
	},
	retireConfirmDialog: {
		confirmLabel: "Retire",
		message: "This will permanently retire this assistant and all of its data. You will need to go through the onboarding flow again to create a new one. This action cannot be undone.",
		title: "Retire Assistant"
	},
	rootHydrateFallback: { loadingAria: "Loading" },
	routePendingIndicator: { loadingAria: "Loading" },
	rootLayout: { unnamedAssistant: "the assistant" },
	routeErrorBoundary: {
		chunkFailBody: "This section couldn't load. Likely a network blip or a stale version. Reload the page to try again.",
		reload: "Reload"
	},
	runtimeUpgradeBanner: {
		confirmMessage: "Update to version {version}? The assistant will be briefly unavailable during the update.",
		confirmTitle: "Update assistant runtime",
		later: "Later",
		title: "New assistant version available: {version}",
		toastComplete: "Update complete. Your assistant is healthy.",
		toastFailed: "Failed to trigger update. Please try again.",
		update: "Update"
	},
	sectionActionsButton: { ariaLabel: "{name} actions" },
	serviceFormControls: {
		reset: "Reset",
		save: "Save"
	},
	shareConnectionLinkButton: { label: "Share Connection Link" },
	shareFeedbackModal: {
		aboutDiagnosticsAria: "About diagnostics",
		addFiles: "Add files",
		adminOnlyHint: "Admin only - builds the diagnostics archive locally and downloads it instead of submitting feedback or notifying Slack.",
		attachments: "Attachments",
		bugTip: "Tip: Get faster support by posting in our <discordLink>Discord community</discordLink>",
		cancel: "Cancel",
		category: "Category",
		closeAria: "Close",
		diagnosticsTooltip: "Diagnostics include browser context, assistant logs, and timestamps - never passwords or credentials.",
		downloadDiagnostics: "Download diagnostics directly",
		downloadDiagnosticsAria: "Download diagnostics directly",
		downloadDiagnosticsButton: "Download diagnostics",
		dropFiles: "Drop files to attach…",
		email: "Email",
		featureTip: "Tip: Vote on features on our <roadmapLink>public roadmap</roadmapLink>",
		includeConversation: "Include the most recent conversation",
		includeConversationAria: "Include the most recent conversation",
		includeDiagnostics: "Include diagnostics",
		includeDiagnosticsAria: "Include browser diagnostics",
		messageLabelBug: "What went wrong?",
		messageLabelFeature: "Describe your idea",
		messageLabelOther: "What's on your mind?",
		messagePlaceholderBug: "What did you expect to happen, and what happened instead?",
		messagePlaceholderFeature: "What problem would this solve for you?",
		messagePlaceholderOther: "Share your thoughts...",
		preparingDiagnostics: "Preparing diagnostics…",
		reasonBugReport: "Bug Report",
		reasonFeatureRequest: "Feature Request",
		reasonOther: "Other",
		removeAttachmentAria: "Remove {name}",
		sendingFeedback: "Sending feedback…",
		submit: "Submit",
		timeRange: "Time range",
		timeRangeAllTime: "All time",
		timeRangeAria: "Diagnostics time range",
		timeRangePast24Hours: "Past 24 hours",
		timeRangePastHour: "Past hour",
		title: "Share Feedback"
	},
	shareFeedbackModalFallback: { loadingAria: "Loading the feedback form" },
	shareFeedbackModalLoadError: {
		close: "Close",
		message: "Couldn't load the feedback form.",
		retry: "Try again"
	},
	sideListDrawer: {
		closeAria: "Close",
		closeSidebarAria: "Close sidebar",
		openSidebarAria: "Open sidebar"
	},
	sidebarShell: {
		backFrom: "Back from {title}",
		backToMenu: "Back to {title} menu",
		navigationAria: "{title} navigation"
	},
	sidebarTree: { ariaLabel: "Sidebar navigation" },
	skillLineageLink: { label: "Learned from this conversation" },
	skillRemovalDialog: {
		message: "Remove \"{name}\" from this assistant?",
		remove: "Remove",
		title: "Remove skill"
	},
	slackSetupCreateStep: {
		approvalNotice: "If Slack shows “Request approval” instead of <strong>Install</strong>, a workspace admin needs to approve the app first.",
		createdApp: "I created the app",
		inSlack: "In Slack:",
		stepManifest: "Under <strong>Or start your own way</strong>, pick <strong>From a manifest</strong>, then <strong>Continue</strong>",
		stepPaste: "Choose your workspace and paste the manifest",
		stepReview: "Review the permissions, then click <strong>Create and Install</strong>"
	},
	slackSetupNameStep: {
		appName: "App Name",
		appNamePlaceholder: "My Assistant",
		copied: "Copied!",
		copyManifest: "Copy manifest",
		description: "Description (optional)",
		descriptionHelper: "Shown on the app's Slack profile.",
		descriptionPlaceholder: "What this assistant helps with",
		intro: "Name your Slack app and copy its manifest. Every permission and setting comes pre-configured.",
		next: "Next"
	},
	slackSetupOpenStep: {
		body: "Open Slack in a new tab to create the app, then come back here for the steps to follow.",
		copied: "Copied!",
		copyManifest: "Copy manifest",
		manifestCopiedNotice: "You copied this app's manifest here. If you have copied anything since, copy it again before you paste.",
		manifestNotCopiedNotice: "You have not copied this app's manifest yet. Slack's create-app modal has no other way to get it, so copy it before you paste.",
		next: "Next",
		openSlack: "Open Slack"
	},
	slackSetupTokensStep: {
		appTokenLabel: "App Token",
		botTokenLabel: "Bot Token",
		connectSlack: "Connect Slack",
		connecting: "Connecting…",
		credentialsSaved: "Credentials saved",
		instructions: "On Slack's confirmation screen, expand <credentials>Your app credentials</credentials> and copy both tokens.",
		skipNotice: "That screen also offers a command-line walkthrough and a <download>Download app files</download> button. Skip both. They set up a separate local app, and this assistant needs only the two tokens.",
		savedBody: "Both tokens are stored. The Slack side is done."
	},
	slackSetupWizard: {
		channelLabel: "Slack",
		copyError: "Could not copy the manifest. Copy it again before continuing.",
		stepConnect: "Connect",
		stepCreate: "Create",
		stepName: "Name",
		stepOpen: "Open"
	},
	stackedBarTooltip: { total: "Total: {value}" },
	startupFailure: { reloadApp: "Reload app" },
	statusBanner: {
		reconnecting: "Reconnecting to your assistant…",
		dismiss: "Dismiss",
		goToDoctor: "Go to Doctor",
		resumeAssistant: "Resume Assistant",
		retryNow: "Retry now",
		wakeUp: "Wake up"
	},
	sttLanguagePicker: {
		allLanguages: "All languages",
		featured: "Featured",
		languagesAriaLabel: "Languages",
		noMatch: "No languages match.",
		searchAriaLabel: "Search languages",
		searchPlaceholder: "Search languages",
		suggested: "Suggested"
	},
	sttLanguagePickerModal: { description: "Applies from your next spoken turn." },
	sttProviderForm: {
		apiKeyLabel: "API Key",
		apiKeyPlaceholderReplace: "••••••••  (Enter a new key to replace)",
		providerAriaLabel: "STT provider",
		providerLabel: "Provider",
		saveFailed: "Failed to save speech-to-text settings",
		saveSuccess: "Speech-to-text settings saved",
		spokenLanguage: "Spoken language",
		spokenLanguageApplies: "Applies from your next spoken turn.",
		cadetTranscription: "Transcription runs through your Cadet account.",
		windowsNativeDisplayName: "Windows Native Dictation",
		windowsNativeSetupWarning: "Requires Basic speech recognition for your Windows display language: open Settings > Time & language > Language & region, select the three dots next to the display language, choose Language options, then under Language features download Basic speech recognition.",
		windowsNativeSubtitle: "Windows on-device speech recognition, running locally through the Windows helper. Works offline and needs no API key."
	},
	subagentAvatarChip: { ariaLabel: "Subagent {subagentId}" },
	systemPermissionsCard: {
		accessibilityDescription: "Allows your assistant to click, type, and control apps on your behalf.",
		accessibilityLabel: "Accessibility",
		checking: "Checking permissions...",
		dockIcon: "Dock icon",
		microphoneDescription: "Allows your assistant to capture audio for voice input and recordings.",
		microphoneLabel: "Microphone",
		notificationBadgesDescription: "Allows your assistant to show unseen conversation counts on the {surface}.",
		notificationBadgesLabel: "Notification Badges",
		notificationsDescription: "Allows your assistant to send macOS alerts for approvals, messages, and task updates.",
		notificationsLabel: "Notifications",
		notificationsWindowsDescription: "Allows your assistant to show Windows notifications for approvals, messages, and task updates.",
		screenDescription: "Allows your assistant to capture screen context during computer-use tasks.",
		screenLabel: "Screen Recording",
		speechRecognitionDescription: "Allows your assistant to transcribe your speech into text on-device.",
		speechRecognitionLabel: "Speech Recognition",
		speechRecognitionWindowsDescription: "Allows your assistant to transcribe your speech into text with Windows speech recognition.",
		taskbarIcon: "taskbar icon",
		title: "System Permissions"
	},
	telegramSetupConnectStep: {
		botTokenLabel: "Bot Token",
		connectTelegram: "Connect Telegram",
		instructions: "Paste the token from BotFather's reply. It is the whole line after <tokenLine>Use this token to access the HTTP API</tokenLine>.",
		saving: "Saving…",
		savedTitle: "Token saved",
		savedBody: "Your bot token is stored. The Telegram side is done."
	},
	telegramSetupCreateStep: {
		copied: "Copied!",
		copyName: "Copy name",
		displayNameHint: "For the display name, <strong>{suggestedName}</strong> keeps this bot matching your assistant. The username is separate and does not have to match.",
		chatScopeNotice: "Private chats and groups are supported. In a group, the assistant replies when it is mentioned or when someone replies to it. Broadcast channels are not supported.",
		inBotFather: "In BotFather:",
		intro: "Telegram bots are created by messaging <strong>@BotFather</strong>. Open it, run through the prompts, then come back with the token it gives you.",
		next: "Next",
		openBotFather: "Open BotFather",
		stepDisplayName: "Give it a display name, which is what people see in chat",
		stepSendNewBot: "Send <strong>/newbot</strong>",
		stepTokenReply: "BotFather replies with a token after <strong>Use this token to access the HTTP API</strong>",
		stepUsername: "Give it a username, which must be unique and end in <strong>bot</strong>"
	},
	telegramSetupWizard: {
		channelLabel: "Telegram",
		copyError: "Could not copy the name. Type it into BotFather instead.",
		stepConnect: "Connect",
		stepCreate: "Create bot"
	},
	tenantHost: {
		shopifyLabel: "Shop domain",
		shopifyPlaceholder: "your-store.myshopify.com"
	},
	terminalPanel: { recoveryModeBanner: "Recovery Mode active: this session is connected to the debug terminal." },
	themeStagePage: {
		accentFill: "Accent fill",
		activeBorder: "Active border",
		activeSurface: "Active surface",
		assistantBubble: "A reply from the assistant, rendered full-width on the page surface.",
		buttonDisabled: "Disabled",
		buttonPrimary: "Primary",
		buttonSecondary: "Secondary",
		chatAssistant1: "Done. The summary is ready. Revenue grew steadily, the two flagged risks from last quarter are resolved, and I pulled the three charts worth showing into a separate page.",
		chatAssistant2: "Scheduled for 9am. I'll include the charts and a one-paragraph version for anyone skimming on their phone.",
		chatUser1: "Can you summarize the quarterly report before tomorrow's meeting?",
		chatUser2: "Perfect. Send it to the team in the morning.",
		composerPlaceholder: "Message your assistant",
		faintText: "Faint text - the last legible step of the ramp.",
		inputFilled: "Text someone has already typed into a field.",
		inputPlaceholder: "A placeholder in an empty field",
		newConversation: "New conversation",
		overlaySurface: "Overlay surface",
		primaryText: "Primary text - the main reading surface of the app.",
		quietText: "Quiet text - metadata and timestamps.",
		raisedCard: "Raised card",
		raisedCardBody: "Elevated surfaces sit above panels and the page background.",
		samplerTitle: "Theme sampler",
		secondaryText: "Secondary text - supporting copy and descriptions.",
		sectionAccent: "Accent",
		sectionButtons: "Buttons",
		sectionInputs: "Inputs",
		sectionMessages: "Messages",
		sectionSurfaces: "Surfaces and borders",
		sectionText: "Text",
		send: "Send",
		subtleDivider: "Subtle divider above this line.",
		tertiaryText: "Tertiary text - captions, labels, and placeholders.",
		userBubble: "A message from the user, in its bubble."
	},
	themeToggle: {
		dark: "Dark",
		label: "Theme",
		light: "Light",
		system: "System"
	},
	ttsProviderForm: {
		apiKey: "API Key",
		apiKeyRequired: "Save an API key for this provider before testing.",
		chooseFromCatalog: "Choose from catalog",
		customVoiceIdAriaLabel: "Custom voice ID",
		noCloudVoices: "No cloud voices are currently available.",
		provider: "Provider",
		providerAriaLabel: "TTS provider",
		saveFailed: "Failed to save text-to-speech settings",
		saved: "Text-to-speech settings saved",
		test: "Test",
		testing: "Testing…",
		voice: "Voice",
		voiceId: "Voice ID",
		voiceIdPlaceholder: "Enter a voice ID"
	},
	updateToast: {
		available: "Update available. Starting download…",
		closeAriaLabel: "Close",
		downloading: "Downloading update…",
		ready: "Cadet {version} is ready.",
		restartToInstall: "Restart to install",
		versionFallback: "update"
	},
	useAppDelete: { deleteFailed: "Failed to delete app" },
	useAppDeployment: {
		copyFailed: "Couldn't copy the link. Open it at {url}",
		linkCopied: "Link copied",
		open: "Open"
	},
	useAssistantChannels: {
		setupPrompt: {
			slack: "I want to reach you on Slack. Let's set it up.",
			telegram: "I want to reach you on Telegram. Let's set it up.",
			discord: "I want to reach you on Discord. Let's set it up.",
			email: "I want to email you. Let's set up your email address.",
			phone: "I want to be able to call you. Let's set you up with a phone number."
		},
		finishPrompt: {
			slack: "Slack is set up but not working. Can you finish it off?",
			telegram: "Telegram is set up but not working. Can you finish it off?",
			discord: "Discord is set up but not working. Can you finish it off?",
			email: "My email address is set up but not working. Can you finish it off?",
			phone: "My phone number is set up but not working. Can you finish it off?"
		}
	},
	useBookmarks: {
		addFailed: "Failed to bookmark message.",
		removeFailed: "Failed to remove bookmark."
	},
	useConnectClaude: {
		exchangeFailed: "Check the pasted key and try again.",
		failed: "Connecting Claude failed. Please try again.",
		notStarted: "Start the Connect Claude flow first.",
		pasteEmpty: "Paste the code shown on the Claude page.",
		popupBlocked: "Your browser blocked the sign-in tab. Allow pop-ups for this site, then click Connect again.",
		startFailed: "Couldn't start Connect Claude. Please try again.",
		timedOut: "Timed out waiting for Claude to connect. Please try again."
	},
	useOauthConnect: {
		accountConnected: "{name} account connected.",
		authorizationError: "{name} error: {code}",
		authorizationFailed: "{name} authorization failed",
		popupBlocked: "Popup blocked. Please enable popups and try again.",
		startFailed: "Failed to start {name} authorization.",
		startFailedWithReason: "Couldn't start {name} authorization: {reason}"
	},
	useOpenUrlDirectives: {
		blocked: "Your browser blocked a page the assistant tried to open.",
		openPage: "Open page"
	},
	useVoiceSamplePreview: { playFailed: "Could not play the voice sample." },
	useWorkspaceTheme: { updated: "Theme updated" },
	vercelTokenDialog: {
		body: "Enter your Vercel API token to deploy apps as static pages.",
		cancel: "Cancel",
		createToken: "Create a token on Vercel →",
		save: "Save",
		saveFailed: "Failed to save Vercel token.",
		saving: "Saving…",
		title: "Connect Vercel",
		tokenLabel: "API Token",
		tokenPlaceholder: "Vercel API token"
	},
	voiceList: {
		assistantVoiceAriaLabel: "Assistant voice",
		defaultSuffix: "(default)",
		previewVoice: "Preview {description}",
		providerAriaLabel: "Voice provider",
		stopPreview: "Stop preview"
	},
	voicePickerField: {
		ariaLabel: "Voice",
		selectVoice: "Select a voice"
	},
	voicePickerModal: {
		done: "Done",
		title: "Voices"
	},
	voiceProvidersNote: { body: "Speech providers, transcription, and API keys live in <modelsLink>Models & Services</modelsLink>." },
	voiceTranscriptToggles: {
		recommendedOff: "Recommended off",
		userTranscriptLabel: "Show the words you say",
		userTranscriptDescription: "Live transcription while you speak.",
		assistantTranscriptLabel: "Show the words the assistant says",
		assistantTranscriptDescription: "Text alongside the spoken response."
	},
	windowsMenuBar: {
		developer: "Developer",
		file: "File",
		help: "Help",
		view: "View"
	},
	domainVerificationChip: {
		checkingDomain: "Checking domain…",
		domainVerified: "Domain verified",
		failedTitle: "Domain verification failed. DNS records may not have propagated correctly. You could try releasing and re-registering the domain.",
		unknownStatus: "Unknown status",
		unknownStatusTitle: "Unable to retrieve domain verification status.",
		verificationFailed: "Verification failed",
		verifiedTitle: "DNS records have been verified. Your domain is ready to send and receive email.",
		verifyingDomain: "Verifying domain…",
		verifyingTitle: "DNS records have been provisioned. Waiting for the email provider to verify them - this usually takes a few minutes.",
		setupRequired: "Domain setup required",
		setupRequiredTitle: "This domain has not been provisioned with the email provider. It cannot send or receive email until setup is complete."
	},
	managedServicesBanner: { body: "Managed services are metered and deducted from your Cadet account balance. <link>View pricing</link>" },
	serviceCard: {
		managedLabel: "Managed",
		modeToggleAriaLabel: "Service mode",
		yourOwnLabel: "Your Own"
	},
	channelAvatarDownload: {
		previewAlt: "Your assistant's avatar",
		download: "Download avatar",
		prompt: {
			slack: "Download your assistant's avatar to upload as the app icon.",
			discord: "Download your assistant's avatar to upload as the bot icon.",
			telegram: "Download your assistant's avatar, then send it to BotFather with /setuserpic."
		}
	},
	thresholdPresets: {
		strict: {
			label: "Strict",
			description: "Always ask before acting. No actions are auto-approved."
		},
		conservative: {
			label: "Conservative",
			description: "Auto-approve low-risk actions, like web searches and reading and writing files in its own workspace."
		},
		relaxed: {
			label: "Relaxed",
			description: "Auto-approve low and medium-risk actions, like changing files outside its own workspace."
		},
		fullAccess: {
			label: "Full access",
			description: "Auto-approve all actions, including high-risk and unrecognized commands. Your assistant will never ask for permission."
		}
	},
	scheduleFormatters: {
		everyHours: "Every {count, plural, one {# hr} other {# hrs}}",
		everyMinutes: "Every {count, plural, one {# min} other {# mins}}",
		retrospectiveSubtitle: "After conversation activity"
	},
	assistantHandleModal: {
		title: "Assistant handle",
		description: "Your assistant's public name. It is also the name its email address is built on.",
		helper: "Lowercase letters, numbers, hyphens, underscores."
	},
	detailShell: {
		close: "Close",
		closePanel: "Close panel",
		loading: "Loading…"
	},
	permissionGuide: {
		back: "Back to the tour",
		dragInstruction: "Drag {app} into the list to allow {permission}.",
		dragApp: "Drag {app} to System Settings, or press to show in Finder",
		dragError: "Drag unavailable. Try dragging from Finder.",
		showInFinder: "Show in Finder",
		inputLabel: "Input Monitoring"
	},
	pairDeviceUrl: {
		loopback: "This is a loopback address other devices can't reach. Enter the assistant's public https URL.",
		nonHttps: "The URL must use https so your devices can connect securely.",
		privateAddress: "This address points at a private network address. Enter the assistant's public https URL so your devices can reach it.",
		serviceFallbackName: "the tunnel provider",
		serviceWebsite: "This is {service}'s website, not your assistant's address. Start a tunnel on the host to get one; `cadet tunnel --help` lists the providers.",
		unparseable: "Enter a valid URL, e.g. https://your-assistant.ts.net."
	}
}, rn = {
	consentControls: {
		whatsChanged: "What's changed",
		agreements: "Agreements",
		agreeTo: "I agree to the <0>{policy}</0>"
	},
	actions: {
		continue: "Continue",
		logOut: "Log out"
	}
}, an = {
	actions: {
		continue: "Continue",
		back: "Back",
		forward: "Forward",
		cancel: "Cancel",
		add: "Add",
		adding: "Adding…",
		tryAgain: "Try again",
		remove: "Remove {value}",
		downloadMacOSApp: "Download the macOS app",
		downloadWindowsApp: "Download the Windows app",
		claim: "Claim"
	},
	onboardingAutocomplete: {
		addOption: "Add “{value}”",
		enterHint: "↵ Enter",
		freeTextHint: "Type anything and press ↵ to add your own"
	},
	stepIndicator: { ariaLabel: "Step {current} of {total}" },
	introductionScreen: {
		greetingNamed: "Hey, {name}!",
		greeting: "Hey!",
		introNamed: "I’m {name}, your new AI assistant.",
		intro: "I’m your new AI assistant."
	},
	pitchStep: {
		setupLine: "You’ve used AI that just answers questions.",
		helpLine: "The more I help,",
		punchLine: "I’m different.",
		betterLine: "the better I get,",
		lessLine: "and the less you have to do."
	},
	createPersonalityStep: {
		title: "Create my personality",
		lockedBody: "Personality locked, chat with your assistant to make any more updates",
		axisAriaLabel: "{left} to {right}",
		axes: {
			companionCoworker: {
				left: "Companion",
				right: "Coworker"
			},
			genzBoomer: {
				left: "Gen Z",
				right: "Baby Boomer"
			},
			executeCollaborate: {
				left: "Independent",
				right: "Collaborative"
			},
			playfulSerious: {
				left: "Playful",
				right: "Serious"
			},
			politeUnfiltered: {
				left: "Polite",
				right: "Unfiltered"
			}
		}
	},
	giveMeAFaceScreen: {
		title: "Give me a face and a name",
		previousCharacter: "Previous character",
		nextCharacter: "Next character",
		namePlaceholder: "Name your assistant",
		nameAriaLabel: "Assistant name",
		editName: "Edit name",
		shuffle: "Shuffle name and appearance",
		hearVoice: "Hear my voice",
		stopVoice: "Stop the voice sample"
	},
	integrationStep: { title: "Here's some initial usage<br></br> to get started." },
	researchOnboardingScreen: {
		title: "Let's start with you.",
		firstNameLabel: "What should I call you?",
		firstNamePlaceholder: "Your name",
		skip: "Skip onboarding"
	},
	existingAssistantStep: {
		titleNamed: "{name} is already up and running",
		title: "Your assistant is already up and running",
		bodyNamed: "You two have history: a personality, memories, and past conversations. Running setup again would overwrite who {name} is now.",
		body: "You two have history: a personality, memories, and past conversations. Running setup again would overwrite who your assistant is now.",
		keepNamed: "Keep {name} and start chatting",
		keep: "Keep your assistant and start chatting",
		redoNamed: "Start over and rebuild {name}'s personality",
		redo: "Start over and rebuild its personality"
	},
	lookingYouUpStep: {
		searching: "Searching the web to get to know you…",
		readingProfiles: "Reading public profiles…",
		skimming: "Skimming the highlights…",
		connectingDots: "Connecting the dots…",
		piecing: "Piecing it together…",
		almostThere: "Almost there…"
	},
	finishingUpStep: {
		updatingPersonality: "Updating my personality…",
		findingVoice: "Finding my voice…",
		gettingIntoCharacter: "Getting into character…",
		almostThere: "Almost there…"
	},
	researchResultsStep: {
		title: "This is what I found about you",
		bodyLoadingWithClaims: "Still checking the rest. You can review these as they come in.",
		bodyReadyWithClaims: "I searched the web. Feel free to remove anything that isn’t true.",
		bodyLoadingEmpty: "Still putting this together…",
		removeClaim: "Remove \"{claim}\"",
		notMe: "This is not me",
		stillSearching: "Still searching…"
	},
	suggestionsStep: {
		title: "Here’s what we could do first",
		pickOne: "Pick one to jump in, or start your own thing. <skip>Skip to Chat</skip>",
		loading: "Putting together a few ideas…",
		alreadySetUp: "Already set up the <plugins></plugins> {count, plural, one {plugin} other {plugins}} to help with your work",
		listAnd: " and ",
		listCommaAnd: ", and ",
		listComma: ", ",
		fallbacks: {
			brief: {
				suggestion: "I'll pull together a quick brief on what's new in your field",
				prompt: "Give me a quick brief on what's new in my field right now."
			},
			weekly: {
				suggestion: "I'll send a weekly briefing on news in your space",
				prompt: "Set up a weekly briefing on news in my space."
			},
			week: {
				suggestion: "I'll help you get on top of your week",
				prompt: "Help me get on top of my week."
			},
			draft: {
				suggestion: "I'll draft something from a few rough notes",
				prompt: "Draft something from a few rough notes I'll give you."
			}
		}
	},
	authErrors: {
		genericFailure: "Something went wrong. Please try again.",
		signupClosed: "Sorry, Cadet is not accepting new signups at this time. Feel free to try again later.",
		providerSignup: "No Cadet account is linked to that login yet. Sign up first, then sign in.",
		loginIncomplete: "Your account needs another step to finish signing in. Please sign in on the web, then try again.",
		desktopUpdateRequired: "This version of the Cadet desktop app can't sign in. Update the app, then try again."
	},
	hatchingScreen: {
		genericFailure: "Something went wrong",
		localFallbackPitch: "Get started today with a local assistant"
	}
}, q = [
	"common",
	"account",
	"consent",
	"onboarding",
	"doctor"
], on = "common", J = [
	"en",
	"es",
	"ru",
	"zh",
	"zh-TW"
];
function Y(e) {
	return typeof e == "string" && J.includes(e);
}
function sn(e) {
	for (let t of e) {
		let e = t.trim();
		if (e === "") continue;
		let n = J.find((t) => t.toLowerCase() === e.toLowerCase());
		if (n) return n;
		let r = e.toLowerCase();
		if ((r === "zh-hant" || r.startsWith("zh-hant-") || r === "zh-hk" || r === "zh-mo") && Y("zh-TW")) return "zh-TW";
		let i = e.split("-")[0].toLowerCase(), a = J.find((e) => e.toLowerCase() === i);
		if (a) return a;
	}
	return "en";
}
//#endregion
//#region src/i18n/catalogs.ts
var X = {
	common: nn,
	account: en,
	consent: rn,
	onboarding: an,
	doctor: tn
}, cn = {
	es: {
		common: () => import("./common-DzOa0ubF.js"),
		account: () => import("./account-s7hLpp5H.js"),
		consent: () => import("./consent--wQBezkl.js"),
		onboarding: () => import("./onboarding-BHMj79Jf.js"),
		doctor: () => import("./doctor-bsv-5cau.js")
	},
	ru: {
		common: () => import("./common-DWoWV3Uy.js"),
		account: () => import("./account-Y_FawXrP.js"),
		consent: () => import("./consent-L9ifjAHE.js"),
		onboarding: () => import("./onboarding-BG79w2o-.js"),
		doctor: () => import("./doctor-BxoGmfie.js")
	},
	zh: {
		common: () => import("./common-BV3Bampe.js"),
		account: () => import("./account-DS6Ruf31.js"),
		consent: () => import("./consent-C7TwYzID.js"),
		onboarding: () => import("./onboarding-CXcMFkpQ.js"),
		doctor: () => import("./doctor-V8BELIsb.js")
	},
	"zh-TW": {
		common: () => import("./common-CbGRtTGD.js"),
		account: () => import("./account-CPGFaPKZ.js"),
		consent: () => import("./consent-BhTKL--_.js"),
		onboarding: () => import("./onboarding-DjdsIf7Q.js"),
		doctor: () => import("./doctor-Bw5hacb8.js")
	}
};
async function ln(e) {
	if (e === "en") return X;
	let t = cn[e], n = await Promise.all(q.map(async (e) => [e, (await t[e]()).default]));
	return Object.fromEntries(n);
}
//#endregion
//#region src/i18n/config.ts
function un(e, t) {
	return {
		lng: e,
		fallbackLng: "en",
		ns: [...q],
		defaultNS: on,
		resources: t,
		interpolation: { escapeValue: !1 },
		returnNull: !1
	};
}
//#endregion
//#region src/i18n/system-locale.ts
function dn() {
	if (typeof navigator > "u") return [];
	let e = navigator.languages;
	return Array.isArray(e) && e.length > 0 ? [...e] : navigator.language ? [navigator.language] : [];
}
//#endregion
//#region src/utils/local-settings.ts
function fn(e, t) {
	if (typeof window > "u") return t;
	try {
		return localStorage.getItem(e) ?? t;
	} catch {
		return t;
	}
}
function pn(e, t) {
	if (typeof window > "u") return !1;
	try {
		localStorage.setItem(e, t);
	} catch {
		return !1;
	}
	return bn(e, t), !0;
}
function mn(e, t) {
	typeof window > "u" || bn(e, t);
}
function hn(e) {
	if (!(typeof window > "u")) {
		try {
			localStorage.removeItem(e);
		} catch {
			return;
		}
		bn(e, null);
	}
}
function gn(e, t) {
	if (typeof window > "u") return t;
	try {
		let n = localStorage.getItem(e);
		return n === "true" ? !0 : n === "false" ? !1 : t;
	} catch {
		return t;
	}
}
function _n(e, t) {
	pn(e, t ? "true" : "false");
}
function vn(e, t) {
	if (typeof window > "u") return () => {};
	let n = (n) => {
		n.key === e && t();
	}, r = (n) => {
		n.detail?.key === e && t();
	};
	return window.addEventListener("storage", n), window.addEventListener(yn, r), () => {
		window.removeEventListener("storage", n), window.removeEventListener(yn, r);
	};
}
var yn = "cadet:pref-changed";
function bn(e, t) {
	try {
		window.dispatchEvent(new CustomEvent(yn, { detail: {
			key: e,
			value: t
		} }));
	} catch {}
}
//#endregion
//#region src/utils/device-settings.ts
var Z = {
	locale: { key: "device:locale" },
	installReferrer: { key: "device:install_referrer" },
	biometricEnabled: { key: "device:biometric_enabled" }
};
function xn(e, t) {
	if (typeof window > "u") return t;
	try {
		return localStorage.getItem(Z[e].key) ?? t;
	} catch {
		return t;
	}
}
function Sn(e, t) {
	pn(Z[e].key, t);
}
function Cn(e) {
	if (typeof window > "u") return !1;
	try {
		return localStorage.getItem(Z[e].key) !== null;
	} catch {
		return !1;
	}
}
function wn(e, t) {
	if (typeof window > "u") return t;
	try {
		let t = localStorage.getItem(Z[e].key);
		if (t === "true") return !0;
		if (t === "false") return !1;
	} catch {}
	return t;
}
function Tn(e, t) {
	_n(Z[e].key, t);
}
//#endregion
//#region src/i18n/locale-preference.ts
function En() {
	return xn("locale", "");
}
function Dn(e) {
	Sn("locale", e);
}
//#endregion
//#region src/i18n/i18n.ts
function On() {
	let e = En();
	return Y(e) ? e : sn(dn());
}
function kn(e) {
	if (typeof document > "u") return;
	document.documentElement.lang = e;
	let t;
	try {
		let n = new Intl.Locale(e);
		t = n.getTextInfo?.().direction ?? n.textInfo?.direction;
	} catch {
		t = void 0;
	}
	document.documentElement.dir = t === "rtl" ? "rtl" : "ltr";
}
async function An(e) {
	let t = q.filter((t) => !M.hasResourceBundle(e, t));
	if (t.length === 0) return;
	let n = await ln(e);
	for (let r of t) M.addResourceBundle(e, r, n[r], !0, !0);
}
function jn(e, t) {
	console.warn("App translation catalog could not be loaded", t, e);
}
async function Mn() {
	let e = On();
	if (M.isInitialized) try {
		return await Nn(e), e;
	} catch (t) {
		return jn(t, e), Q();
	}
	let t = { en: X }, n = "en";
	if (e !== "en") try {
		t[e] = await ln(e), n = e;
	} catch (t) {
		jn(t, e);
	}
	return await M.use(new K()).init(un(n, t)), kn(n), n;
}
async function Nn(e) {
	await An(e), await M.changeLanguage(e), Dn(e), kn(e);
}
function Q() {
	let e = M.resolvedLanguage ?? M.language;
	return Y(e) ? e : "en";
}
function Pn(e) {
	return e.split("-")[0].toLowerCase();
}
function Fn() {
	let e = Q();
	return dn().find((t) => Pn(t) === Pn(e) && In(t)) ?? e;
}
function In(e) {
	try {
		return Intl.getCanonicalLocales(e), !0;
	} catch {
		return !1;
	}
}
//#endregion
//#region src/i18n/provider.tsx
var $ = e(void 0);
function Ln({ children: e }) {
	let t = r(() => {
		let e = Te();
		return e.use(new K()).init({
			...un("en", { en: X }),
			initAsync: !1
		}), e;
	}, []);
	return n(() => {
		let e = !0, n = Q();
		return ln(n).then((r) => {
			if (e) {
				for (let [e, i] of Object.entries(r)) t.addResourceBundle(n, e, i, !0, !0);
				t.changeLanguage(n);
			}
		}).catch(() => {
			e && t.changeLanguage("en");
		}), () => {
			e = !1;
		};
	}, [t]), /* @__PURE__ */ i($.Provider, {
		value: t,
		children: e
	});
}
//#endregion
//#region src/i18n/react.tsx
function Rn(e, n) {
	let r = t($) ?? M;
	return o(e, {
		...n,
		i18n: r
	});
}
var zn = (e) => {
	let n = t($) ?? M;
	return /* @__PURE__ */ i(a, {
		...e,
		i18n: n
	});
}, Bn = M.t.bind(M);
//#endregion
export { pn as _, Q as a, wn as c, Tn as d, Sn as f, hn as g, mn as h, Ln as i, xn as l, fn as m, zn as n, Fn as o, gn as p, Rn as r, Mn as s, Bn as t, Cn as u, vn as v };
