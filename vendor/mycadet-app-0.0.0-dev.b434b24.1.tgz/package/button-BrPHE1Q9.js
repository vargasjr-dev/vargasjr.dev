import { t as e } from "./loader-circle-Ch7lYSrj.js";
import { n as t, o as n, r, t as i } from "./dist-CB0DYkRa.js";
import * as a from "react";
import { cloneElement as o, createContext as s, isValidElement as c, useCallback as l, useContext as u, useLayoutEffect as d, useSyncExternalStore as f } from "react";
import * as p from "react-dom";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
typeof window < "u" && window.document && window.document.createElement;
function g(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return function(r) {
		if (e?.(r), n === !1 || !r.defaultPrevented) return t?.(r);
	};
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-compose-refs@1.1.3+bf264c7668a20073/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
function _(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function v(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = _(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : _(e[t], null);
			}
		};
	};
}
function y(...e) {
	return a.useCallback(v(...e), e);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-context@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-context/dist/index.mjs
function b(e, t = []) {
	let n = [];
	function r(t, r) {
		let i = a.createContext(r);
		i.displayName = t + "Context";
		let o = n.length;
		n = [...n, r];
		let s = (t) => {
			let { scope: n, children: r, ...s } = t, c = n?.[e]?.[o] || i, l = a.useMemo(() => s, Object.values(s));
			return /* @__PURE__ */ m(c.Provider, {
				value: l,
				children: r
			});
		};
		s.displayName = t + "Provider";
		function c(n, s) {
			let c = s?.[e]?.[o] || i, l = a.useContext(c);
			if (l) return l;
			if (r !== void 0) return r;
			throw Error(`\`${n}\` must be used within \`${t}\``);
		}
		return [s, c];
	}
	let i = () => {
		let t = n.map((e) => a.createContext(e));
		return function(n) {
			let r = n?.[e] || t;
			return a.useMemo(() => ({ [`__scope${e}`]: {
				...n,
				[e]: r
			} }), [n, r]);
		};
	};
	return i.scopeName = e, [r, x(i, ...t)];
}
function x(...e) {
	let t = e[0];
	if (e.length === 1) return t;
	let n = () => {
		let n = e.map((e) => ({
			useScope: e(),
			scopeName: e.scopeName
		}));
		return function(e) {
			let r = n.reduce((t, { useScope: n, scopeName: r }) => {
				let i = n(e)[`__scope${r}`];
				return {
					...t,
					...i
				};
			}, {});
			return a.useMemo(() => ({ [`__scope${t.scopeName}`]: r }), [r]);
		};
	};
	return n.scopeName = t.scopeName, n;
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-slot@1.3.0+bf264c7668a20073/node_modules/@radix-ui/react-slot/dist/index.mjs
/* @__NO_SIDE_EFFECTS__ */
function S(e) {
	let t = a.forwardRef((t, n) => {
		let { children: r, ...i } = t, o = null, s = !1, c = [];
		A(r) && typeof P == "function" && (r = P(r._payload)), a.Children.forEach(r, (e) => {
			if (O(e)) {
				s = !0;
				let t = e, n = "child" in t.props ? t.props.child : t.props.children;
				A(n) && typeof P == "function" && (n = P(n._payload)), o = T(t, n), c.push(o?.props?.children);
			} else c.push(e);
		}), o ? o = a.cloneElement(o, void 0, c) : !s && a.Children.count(r) === 1 && a.isValidElement(r) && (o = r);
		let l = o ? D(o) : void 0, u = y(n, l);
		if (!o) {
			if (r || r === 0) throw Error(s ? N(e) : M(e));
			return r;
		}
		let d = E(i, o.props ?? {});
		return o.type !== a.Fragment && (d.ref = n ? u : l), a.cloneElement(o, d);
	});
	return t.displayName = `${e}.Slot`, t;
}
var C = Symbol.for("radix.slottable");
/* @__NO_SIDE_EFFECTS__ */
function w(e) {
	let t = (e) => "child" in e ? e.children(e.child) : e.children;
	return t.displayName = `${e}.Slottable`, t.__radixId = C, t;
}
var T = (e, t) => {
	if ("child" in e.props) {
		let t = e.props.child;
		return a.isValidElement(t) ? a.cloneElement(t, void 0, e.props.children(t.props.children)) : null;
	}
	return a.isValidElement(t) ? t : null;
};
function E(e, t) {
	let n = { ...t };
	for (let r in t) {
		let i = e[r], a = t[r];
		/^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
			let t = a(...e);
			return i(...e), t;
		} : i && (n[r] = i) : r === "style" ? n[r] = {
			...i,
			...a
		} : r === "className" && (n[r] = [i, a].filter(Boolean).join(" "));
	}
	return {
		...e,
		...n
	};
}
function D(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
function O(e) {
	return a.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === C;
}
var k = Symbol.for("react.lazy");
function A(e) {
	return typeof e == "object" && !!e && "$$typeof" in e && e.$$typeof === k && "_payload" in e && j(e._payload);
}
function j(e) {
	return typeof e == "object" && !!e && "then" in e;
}
var M = (e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, N = (e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, P = a.use, F = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((e, t) => {
	let n = /* @__PURE__ */ S(`Primitive.${t}`), r = a.forwardRef((e, r) => {
		let { asChild: i, ...a } = e, o = i ? n : t;
		return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ m(o, {
			...a,
			ref: r
		});
	});
	return r.displayName = `Primitive.${t}`, {
		...e,
		[t]: r
	};
}, {});
function I(e, t) {
	e && p.flushSync(() => e.dispatchEvent(t));
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-callback-ref@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
function ee(e) {
	let t = a.useRef(e);
	return a.useEffect(() => {
		t.current = e;
	}), a.useMemo(() => ((...e) => t.current?.(...e)), []);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-layout-effect@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var L = globalThis?.document ? a.useLayoutEffect : () => {}, R = a.useEffectEvent, z = a.useInsertionEffect;
function te(e) {
	if (typeof R == "function") return R(e);
	let t = a.useRef(() => {
		throw Error("Cannot call an event handler while rendering.");
	});
	return typeof z == "function" ? z(() => {
		t.current = e;
	}) : L(() => {
		t.current = e;
	}), a.useMemo(() => ((...e) => t.current?.(...e)), []);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-dismissable-layer@1.1.14+07ecf1aa3bcbed22/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var ne = "DismissableLayer", re = "dismissableLayer.update", ie = "dismissableLayer.pointerDownOutside", ae = "dismissableLayer.focusOutside", oe, se = a.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
}), ce = a.forwardRef((e, t) => {
	let { disableOutsidePointerEvents: n = !1, deferPointerDownOutside: r = !1, onEscapeKeyDown: i, onPointerDownOutside: o, onFocusOutside: s, onInteractOutside: c, onDismiss: l, ...u } = e, d = a.useContext(se), [f, p] = a.useState(null), h = f?.ownerDocument ?? globalThis?.document, [, _] = a.useState({}), v = y(t, p), b = Array.from(d.layers), [x] = [...d.layersWithOutsidePointerEventsDisabled].slice(-1), S = b.indexOf(x), C = f ? b.indexOf(f) : -1, w = d.layersWithOutsidePointerEventsDisabled.size > 0, T = C >= S, E = a.useRef(!1), D = fe((e) => {
		let t = e.target;
		if (!(t instanceof Node)) return;
		let n = [...d.branches].some((e) => e.contains(t));
		!T || n || (o?.(e), c?.(e), e.defaultPrevented || l?.());
	}, {
		ownerDocument: h,
		deferPointerDownOutside: r,
		isDeferredPointerDownOutsideRef: E,
		dismissableSurfaces: d.dismissableSurfaces
	}), O = pe((e) => {
		if (r && E.current) return;
		let t = e.target;
		[...d.branches].some((e) => e.contains(t)) || (s?.(e), c?.(e), e.defaultPrevented || l?.());
	}, h), k = f ? C === b.length - 1 : !1, A = te((e) => {
		e.key === "Escape" && (i?.(e), !e.defaultPrevented && l && (e.preventDefault(), l()));
	});
	return a.useEffect(() => {
		if (k) return h.addEventListener("keydown", A, { capture: !0 }), () => h.removeEventListener("keydown", A, { capture: !0 });
	}, [h, k]), a.useEffect(() => {
		if (f) return n && (d.layersWithOutsidePointerEventsDisabled.size === 0 && (oe = h.body.style.pointerEvents, h.body.style.pointerEvents = "none"), d.layersWithOutsidePointerEventsDisabled.add(f)), d.layers.add(f), me(), () => {
			n && (d.layersWithOutsidePointerEventsDisabled.delete(f), d.layersWithOutsidePointerEventsDisabled.size === 0 && (h.body.style.pointerEvents = oe));
		};
	}, [
		f,
		h,
		n,
		d
	]), a.useEffect(() => () => {
		f && (d.layers.delete(f), d.layersWithOutsidePointerEventsDisabled.delete(f), me());
	}, [f, d]), a.useEffect(() => {
		let e = () => _({});
		return document.addEventListener(re, e), () => document.removeEventListener(re, e);
	}, []), /* @__PURE__ */ m(F.div, {
		...u,
		ref: v,
		style: {
			pointerEvents: w ? T ? "auto" : "none" : void 0,
			...e.style
		},
		onFocusCapture: g(e.onFocusCapture, O.onFocusCapture),
		onBlurCapture: g(e.onBlurCapture, O.onBlurCapture),
		onPointerDownCapture: g(e.onPointerDownCapture, D.onPointerDownCapture)
	});
});
ce.displayName = ne;
var le = "DismissableLayerBranch", ue = a.forwardRef((e, t) => {
	let n = a.useContext(se), r = a.useRef(null), i = y(t, r);
	return a.useEffect(() => {
		let e = r.current;
		if (e) return n.branches.add(e), () => {
			n.branches.delete(e);
		};
	}, [n.branches]), /* @__PURE__ */ m(F.div, {
		...e,
		ref: i
	});
});
ue.displayName = le;
function de() {
	let e = a.useContext(se), [t, n] = a.useState(null);
	return a.useEffect(() => {
		if (t) return e.dismissableSurfaces.add(t), () => {
			e.dismissableSurfaces.delete(t);
		};
	}, [t, e.dismissableSurfaces]), n;
}
function fe(e, t) {
	let { ownerDocument: n = globalThis?.document, deferPointerDownOutside: r = !1, isDeferredPointerDownOutsideRef: i, dismissableSurfaces: o } = t, s = ee(e), c = a.useRef(!1), l = a.useRef(!1), u = a.useRef(/* @__PURE__ */ new Map()), d = a.useRef(() => {});
	return a.useEffect(() => {
		function e() {
			l.current = !1, i.current = !1, u.current.clear();
		}
		function t() {
			return Array.from(u.current.values()).some(Boolean);
		}
		function a(e) {
			if (!l.current) return;
			let t = e.target;
			t instanceof Node && [...o].some((e) => e.contains(t)) || u.current.set(e.type, !0), e.type === "click" && window.setTimeout(() => {
				l.current && d.current();
			}, 0);
		}
		function f(e) {
			l.current && u.current.set(e.type, !1);
		}
		let p = (a) => {
			if (a.target && !c.current) {
				let o = function() {
					n.removeEventListener("click", d.current);
					let r = t();
					e(), r || he(ie, s, c, { discrete: !0 });
				}, c = { originalEvent: a };
				l.current = !0, i.current = r && a.button === 0, u.current.clear(), !r || a.button !== 0 ? o() : (n.removeEventListener("click", d.current), d.current = o, n.addEventListener("click", d.current, { once: !0 }));
			} else n.removeEventListener("click", d.current), e();
			c.current = !1;
		}, m = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (let e of m) n.addEventListener(e, a, !0), n.addEventListener(e, f);
		let h = window.setTimeout(() => {
			n.addEventListener("pointerdown", p);
		}, 0);
		return () => {
			window.clearTimeout(h), n.removeEventListener("pointerdown", p), n.removeEventListener("click", d.current);
			for (let e of m) n.removeEventListener(e, a, !0), n.removeEventListener(e, f);
		};
	}, [
		n,
		s,
		r,
		i,
		o
	]), { onPointerDownCapture: () => c.current = !0 };
}
function pe(e, t = globalThis?.document) {
	let n = ee(e), r = a.useRef(!1);
	return a.useEffect(() => {
		let e = (e) => {
			e.target && !r.current && he(ae, n, { originalEvent: e }, { discrete: !1 });
		};
		return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e);
	}, [t, n]), {
		onFocusCapture: () => r.current = !0,
		onBlurCapture: () => r.current = !1
	};
}
function me() {
	let e = new CustomEvent(re);
	document.dispatchEvent(e);
}
function he(e, t, n, { discrete: r }) {
	let i = n.originalEvent.target, a = new CustomEvent(e, {
		bubbles: !1,
		cancelable: !0,
		detail: n
	});
	t && i.addEventListener(e, t, { once: !0 }), r ? I(i, a) : i.dispatchEvent(a);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-id@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-id/dist/index.mjs
var ge = a.useId || (() => void 0), _e = 0;
function ve(e) {
	let [t, n] = a.useState(ge());
	return L(() => {
		e || n((e) => e ?? String(_e++));
	}, [e]), e || (t ? `radix-${t}` : "");
}
//#endregion
//#region ../../node_modules/.bun/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var ye = [
	"top",
	"right",
	"bottom",
	"left"
], B = Math.min, V = Math.max, be = Math.round, xe = Math.floor, H = (e) => ({
	x: e,
	y: e
}), Se = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function Ce(e, t, n) {
	return V(e, B(t, n));
}
function U(e, t) {
	return typeof e == "function" ? e(t) : e;
}
function W(e) {
	return e.split("-")[0];
}
function we(e) {
	return e.split("-")[1];
}
function Te(e) {
	return e === "x" ? "y" : "x";
}
function Ee(e) {
	return e === "y" ? "height" : "width";
}
function G(e) {
	let t = e[0];
	return t === "t" || t === "b" ? "y" : "x";
}
function De(e) {
	return Te(G(e));
}
function Oe(e, t, n) {
	n === void 0 && (n = !1);
	let r = we(e), i = De(e), a = Ee(i), o = i === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
	return t.reference[a] > t.floating[a] && (o = Le(o)), [o, Le(o)];
}
function ke(e) {
	let t = Le(e);
	return [
		Ae(e),
		t,
		Ae(t)
	];
}
function Ae(e) {
	return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start");
}
var je = ["left", "right"], Me = ["right", "left"], Ne = ["top", "bottom"], Pe = ["bottom", "top"];
function Fe(e, t, n) {
	switch (e) {
		case "top":
		case "bottom": return n ? t ? Me : je : t ? je : Me;
		case "left":
		case "right": return t ? Ne : Pe;
		default: return [];
	}
}
function Ie(e, t, n, r) {
	let i = we(e), a = Fe(W(e), n === "start", r);
	return i && (a = a.map((e) => e + "-" + i), t && (a = a.concat(a.map(Ae)))), a;
}
function Le(e) {
	let t = W(e);
	return Se[t] + e.slice(t.length);
}
function Re(e) {
	return {
		top: e.top ?? 0,
		right: e.right ?? 0,
		bottom: e.bottom ?? 0,
		left: e.left ?? 0
	};
}
function ze(e) {
	return typeof e == "number" ? {
		top: e,
		right: e,
		bottom: e,
		left: e
	} : Re(e);
}
function Be(e) {
	let { x: t, y: n, width: r, height: i } = e;
	return {
		width: r,
		height: i,
		top: n,
		left: t,
		right: t + r,
		bottom: n + i,
		x: t,
		y: n
	};
}
//#endregion
//#region ../../node_modules/.bun/@floating-ui+core@1.8.0/node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function Ve(e, t, n) {
	let { reference: r, floating: i } = e, a = G(t), o = De(t), s = Ee(o), c = W(t), l = a === "y", u = r.x + r.width / 2 - i.width / 2, d = r.y + r.height / 2 - i.height / 2, f = r[s] / 2 - i[s] / 2, p;
	switch (c) {
		case "top":
			p = {
				x: u,
				y: r.y - i.height
			};
			break;
		case "bottom":
			p = {
				x: u,
				y: r.y + r.height
			};
			break;
		case "right":
			p = {
				x: r.x + r.width,
				y: d
			};
			break;
		case "left":
			p = {
				x: r.x - i.width,
				y: d
			};
			break;
		default: p = {
			x: r.x,
			y: r.y
		};
	}
	let m = we(t);
	return m && (p[o] += f * (m === "end" ? 1 : -1) * (n && l ? -1 : 1)), p;
}
async function He(e, t) {
	t === void 0 && (t = {});
	let { x: n, y: r, platform: i, rects: a, elements: o, strategy: s } = e, { boundary: c = "clippingAncestors", rootBoundary: l = "viewport", elementContext: u = "floating", altBoundary: d = !1, padding: f = 0 } = U(t, e), p = ze(f), m = o[d ? u === "floating" ? "reference" : "floating" : u], h = Be(await i.getClippingRect({
		element: await (i.isElement == null ? void 0 : i.isElement(m)) ?? !0 ? m : m.contextElement || await (i.getDocumentElement == null ? void 0 : i.getDocumentElement(o.floating)),
		boundary: c,
		rootBoundary: l,
		strategy: s
	})), g = u === "floating" ? {
		x: n,
		y: r,
		width: a.floating.width,
		height: a.floating.height
	} : a.reference, _ = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(o.floating)), v = await (i.isElement == null ? void 0 : i.isElement(_)) && await (i.getScale == null ? void 0 : i.getScale(_)) || {
		x: 1,
		y: 1
	}, y = Be(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements: o,
		rect: g,
		offsetParent: _,
		strategy: s
	}) : g);
	return {
		top: (h.top - y.top + p.top) / v.y,
		bottom: (y.bottom - h.bottom + p.bottom) / v.y,
		left: (h.left - y.left + p.left) / v.x,
		right: (y.right - h.right + p.right) / v.x
	};
}
var Ue = 50, We = async (e, t, n) => {
	let { placement: r = "bottom", strategy: i = "absolute", middleware: a = [], platform: o } = n, s = o.detectOverflow ? o : {
		...o,
		detectOverflow: He
	}, c = await (o.isRTL == null ? void 0 : o.isRTL(t)), l = await o.getElementRects({
		reference: e,
		floating: t,
		strategy: i
	}), { x: u, y: d } = Ve(l, r, c), f = r, p = 0, m = {};
	for (let n = 0; n < a.length; n++) {
		let h = a[n];
		if (!h) continue;
		let { name: g, fn: _ } = h, { x: v, y, data: b, reset: x } = await _({
			x: u,
			y: d,
			initialPlacement: r,
			placement: f,
			strategy: i,
			middlewareData: m,
			rects: l,
			platform: s,
			elements: {
				reference: e,
				floating: t
			}
		});
		u = v ?? u, d = y ?? d, m[g] = {
			...m[g],
			...b
		}, x && p < Ue && (p++, typeof x == "object" && (x.placement && (f = x.placement), x.rects && (l = x.rects === !0 ? await o.getElementRects({
			reference: e,
			floating: t,
			strategy: i
		}) : x.rects), {x: u, y: d} = Ve(l, f, c)), n = -1);
	}
	return {
		x: u,
		y: d,
		placement: f,
		strategy: i,
		middlewareData: m
	};
}, Ge = (e) => ({
	name: "arrow",
	options: e,
	async fn(t) {
		let { x: n, y: r, placement: i, rects: a, platform: o, elements: s, middlewareData: c } = t, { element: l, padding: u = 0 } = U(e, t) || {};
		if (l == null) return {};
		let d = ze(u), f = {
			x: n,
			y: r
		}, p = De(i), m = Ee(p), h = await o.getDimensions(l), g = p === "y", _ = g ? "top" : "left", v = g ? "bottom" : "right", y = g ? "clientHeight" : "clientWidth", b = a.reference[m] + a.reference[p] - f[p] - a.floating[m], x = f[p] - a.reference[p], S = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(l)), C = S ? S[y] : 0;
		(!C || !await (o.isElement == null ? void 0 : o.isElement(S))) && (C = s.floating[y] || a.floating[m]);
		let w = b / 2 - x / 2, T = C / 2 - h[m] / 2 - 1, E = B(d[_], T), D = B(d[v], T), O = C - h[m] - D, k = C / 2 - h[m] / 2 + w, A = Ce(E, k, O), j = !c.arrow && we(i) != null && k !== A && a.reference[m] / 2 - (k < E ? E : D) - h[m] / 2 < 0, M = j ? k < E ? k - E : k - O : 0;
		return {
			[p]: f[p] + M,
			data: {
				[p]: A,
				centerOffset: k - A - M,
				...j && { alignmentOffset: M }
			},
			reset: j
		};
	}
}), Ke = function(e) {
	return e === void 0 && (e = {}), {
		name: "flip",
		options: e,
		async fn(t) {
			var n;
			let { placement: r, middlewareData: i, rects: a, initialPlacement: o, platform: s, elements: c } = t, { mainAxis: l = !0, crossAxis: u = !0, fallbackPlacements: d, fallbackStrategy: f = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: m = !0, ...h } = U(e, t);
			if ((n = i.arrow) != null && n.alignmentOffset) return {};
			let g = W(r), _ = G(o), v = W(o) === o, y = await (s.isRTL == null ? void 0 : s.isRTL(c.floating)), b = d || (v || !m ? [Le(o)] : ke(o)), x = p !== "none";
			!d && x && b.push(...Ie(o, m, p, y));
			let S = [o, ...b], C = await s.detectOverflow(t, h), w = [], T = i.flip?.overflows || [];
			if (l && w.push(C[g]), u) {
				let e = Oe(r, a, y);
				w.push(C[e[0]], C[e[1]]);
			}
			if (T = [...T, {
				placement: r,
				overflows: w
			}], !w.every((e) => e <= 0)) {
				let e = (i.flip?.index || 0) + 1, t = S[e];
				if (t && (!(u === "alignment" && _ !== G(t)) || T.every((e) => G(e.placement) === _ ? e.overflows[0] > 0 : !0))) return {
					data: {
						index: e,
						overflows: T
					},
					reset: { placement: t }
				};
				let n = T.filter((e) => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]?.placement;
				if (!n) switch (f) {
					case "bestFit": {
						let e = T.filter((e) => {
							if (x) {
								let t = G(e.placement);
								return t === _ || t === "y";
							}
							return !0;
						}).map((e) => [e.placement, e.overflows.filter((e) => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]?.[0];
						e && (n = e);
						break;
					}
					case "initialPlacement":
						n = o;
						break;
				}
				if (r !== n) return { reset: { placement: n } };
			}
			return {};
		}
	};
};
function qe(e, t) {
	return {
		top: e.top - t.height,
		right: e.right - t.width,
		bottom: e.bottom - t.height,
		left: e.left - t.width
	};
}
function Je(e) {
	return ye.some((t) => e[t] >= 0);
}
var Ye = function(e) {
	return e === void 0 && (e = {}), {
		name: "hide",
		options: e,
		async fn(t) {
			let { rects: n, platform: r } = t, { strategy: i = "referenceHidden", ...a } = U(e, t);
			switch (i) {
				case "referenceHidden": {
					let e = qe(await r.detectOverflow(t, {
						...a,
						elementContext: "reference"
					}), n.reference);
					return { data: {
						referenceHiddenOffsets: e,
						referenceHidden: Je(e)
					} };
				}
				case "escaped": {
					let e = qe(await r.detectOverflow(t, {
						...a,
						altBoundary: !0
					}), n.floating);
					return { data: {
						escapedOffsets: e,
						escaped: Je(e)
					} };
				}
				default: return {};
			}
		}
	};
}, Xe = /* @__PURE__ */ new Set(["left", "top"]);
async function Ze(e, t) {
	let { placement: n, platform: r, elements: i } = e, a = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), o = W(n), s = we(n), c = G(n) === "y", l = Xe.has(o) ? -1 : 1, u = a && c ? -1 : 1, d = U(t, e), { mainAxis: f, crossAxis: p, alignmentAxis: m } = typeof d == "number" ? {
		mainAxis: d,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: d.mainAxis || 0,
		crossAxis: d.crossAxis || 0,
		alignmentAxis: d.alignmentAxis
	};
	return s && typeof m == "number" && (p = s === "end" ? m * -1 : m), c ? {
		x: p * u,
		y: f * l
	} : {
		x: f * l,
		y: p * u
	};
}
var Qe = function(e) {
	return e === void 0 && (e = 0), {
		name: "offset",
		options: e,
		async fn(t) {
			var n;
			let { x: r, y: i, placement: a, middlewareData: o } = t, s = await Ze(t, e);
			return a === o.offset?.placement && (n = o.arrow) != null && n.alignmentOffset ? {} : {
				x: r + s.x,
				y: i + s.y,
				data: {
					...s,
					placement: a
				}
			};
		}
	};
}, $e = function(e) {
	return e === void 0 && (e = {}), {
		name: "shift",
		options: e,
		async fn(t) {
			let { x: n, y: r, placement: i, platform: a } = t, { mainAxis: o = !0, crossAxis: s = !1, limiter: c = { fn: (e) => {
				let { x: t, y: n } = e;
				return {
					x: t,
					y: n
				};
			} }, ...l } = U(e, t), u = {
				x: n,
				y: r
			}, d = await a.detectOverflow(t, l), f = G(i), p = Te(f), m = u[p], h = u[f], g = (e, t) => Ce(t + d[e === "y" ? "top" : "left"], t, t - d[e === "y" ? "bottom" : "right"]);
			o && (m = g(p, m)), s && (h = g(f, h));
			let _ = c.fn({
				...t,
				[p]: m,
				[f]: h
			});
			return {
				..._,
				data: {
					x: _.x - n,
					y: _.y - r,
					enabled: {
						[p]: o,
						[f]: s
					}
				}
			};
		}
	};
}, et = function(e) {
	return e === void 0 && (e = {}), {
		options: e,
		fn(t) {
			let { x: n, y: r, placement: i, rects: a, middlewareData: o } = t, { offset: s = 0, mainAxis: c = !0, crossAxis: l = !0 } = U(e, t), u = {
				x: n,
				y: r
			}, d = G(i), f = Te(d), p = u[f], m = u[d], h = U(s, t), g = typeof h == "number" ? {
				mainAxis: h,
				crossAxis: 0
			} : {
				mainAxis: h.mainAxis ?? 0,
				crossAxis: h.crossAxis ?? 0
			};
			if (c) {
				let e = f === "y" ? "height" : "width", t = a.reference[f] - a.floating[e] + g.mainAxis, n = a.reference[f] + a.reference[e] - g.mainAxis;
				p < t ? p = t : p > n && (p = n);
			}
			if (l) {
				let e = f === "y" ? "width" : "height", t = Xe.has(W(i)), n = a.reference[d] - a.floating[e] + (t && o.offset?.[d] || 0) + (t ? 0 : g.crossAxis), r = a.reference[d] + a.reference[e] + (t ? 0 : o.offset?.[d] || 0) - (t ? g.crossAxis : 0);
				m < n ? m = n : m > r && (m = r);
			}
			return {
				[f]: p,
				[d]: m
			};
		}
	};
}, tt = function(e) {
	return e === void 0 && (e = {}), {
		name: "size",
		options: e,
		async fn(t) {
			let { placement: n, rects: r, platform: i, elements: a } = t, { apply: o = () => {}, ...s } = U(e, t), c = await i.detectOverflow(t, s), l = W(n), u = we(n), d = G(n) === "y", { width: f, height: p } = r.floating, m, h;
			l === "top" || l === "bottom" ? (m = l, h = u === (await (i.isRTL == null ? void 0 : i.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (h = l, m = u === "end" ? "top" : "bottom");
			let g = p - c.top - c.bottom, _ = f - c.left - c.right, v = B(p - c[m], g), y = B(f - c[h], _), b = t.middlewareData.shift, x = !b, S = v, C = y;
			b != null && b.enabled.x && (C = _), b != null && b.enabled.y && (S = g), x && !u && (d ? C = f - 2 * V(c.left, c.right) : S = p - 2 * V(c.top, c.bottom)), await o({
				...t,
				availableWidth: C,
				availableHeight: S
			});
			let w = await i.getDimensions(a.floating);
			return f !== w.width || p !== w.height ? { reset: { rects: !0 } } : {};
		}
	};
};
//#endregion
//#region ../../node_modules/.bun/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function nt() {
	return typeof window < "u";
}
function rt(e) {
	return it(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function K(e) {
	var t;
	return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function q(e) {
	return ((it(e) ? e.ownerDocument : e.document) || window.document)?.documentElement;
}
function it(e) {
	return nt() ? e instanceof Node || e instanceof K(e).Node : !1;
}
function J(e) {
	return nt() ? e instanceof Element || e instanceof K(e).Element : !1;
}
function Y(e) {
	return nt() ? e instanceof HTMLElement || e instanceof K(e).HTMLElement : !1;
}
function at(e) {
	return !nt() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof K(e).ShadowRoot;
}
function ot(e) {
	let { overflow: t, overflowX: n, overflowY: r, display: i } = Z(e);
	return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && i !== "inline" && i !== "contents";
}
function st(e) {
	return /^(table|td|th)$/.test(rt(e));
}
function ct(e) {
	try {
		if (e.matches(":popover-open")) return !0;
	} catch {}
	try {
		return e.matches(":modal");
	} catch {
		return !1;
	}
}
var lt = /transform|translate|scale|rotate|perspective|filter/, ut = /paint|layout|strict|content/, X = (e) => !!e && e !== "none", dt;
function ft(e) {
	let t = J(e) ? Z(e) : e;
	return X(t.transform) || X(t.translate) || X(t.scale) || X(t.rotate) || X(t.perspective) || !mt() && (X(t.backdropFilter) || X(t.filter)) || lt.test(t.willChange || "") || ut.test(t.contain || "");
}
function pt(e) {
	let t = Q(e);
	for (; Y(t) && !ht(t);) {
		if (ft(t)) return t;
		if (ct(t)) return null;
		t = Q(t);
	}
	return null;
}
function mt() {
	return dt ??= typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none"), dt;
}
function ht(e) {
	return /^(html|body|#document)$/.test(rt(e));
}
function Z(e) {
	return K(e).getComputedStyle(e);
}
function gt(e) {
	return J(e) ? {
		scrollLeft: e.scrollLeft,
		scrollTop: e.scrollTop
	} : {
		scrollLeft: e.scrollX,
		scrollTop: e.scrollY
	};
}
function Q(e) {
	if (rt(e) === "html") return e;
	let t = e.assignedSlot || e.parentNode || at(e) && e.host || q(e);
	return at(t) ? t.host : t;
}
function _t(e) {
	let t = Q(e);
	return ht(t) ? (e.ownerDocument || e).body : Y(t) && ot(t) ? t : _t(t);
}
function vt(e, t, n) {
	t === void 0 && (t = []), n === void 0 && (n = !0);
	let r = _t(e), i = r === e.ownerDocument?.body, a = K(r);
	if (i) {
		let e = yt(a);
		return t.concat(a, a.visualViewport || [], ot(r) ? r : [], e && n ? vt(e) : []);
	} else return t.concat(r, vt(r, [], n));
}
function yt(e) {
	return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
//#endregion
//#region ../../node_modules/.bun/@floating-ui+dom@1.8.0/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function bt(e) {
	let t = Z(e), n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0, i = Y(e), a = i ? e.offsetWidth : n, o = i ? e.offsetHeight : r, s = be(n) !== a || be(r) !== o;
	return s && (n = a, r = o), {
		width: n,
		height: r,
		$: s
	};
}
function xt(e) {
	return J(e) ? e : e.contextElement;
}
function St(e) {
	let t = xt(e);
	if (!Y(t)) return H(1);
	let n = t.getBoundingClientRect(), { width: r, height: i, $: a } = bt(t), o = (a ? be(n.width) : n.width) / r, s = (a ? be(n.height) : n.height) / i;
	return (!o || !Number.isFinite(o)) && (o = 1), (!s || !Number.isFinite(s)) && (s = 1), {
		x: o,
		y: s
	};
}
var Ct = /* @__PURE__ */ H(0);
function wt(e) {
	let t = K(e);
	return !mt() || !t.visualViewport ? Ct : {
		x: t.visualViewport.offsetLeft,
		y: t.visualViewport.offsetTop
	};
}
function Tt(e, t, n) {
	return t === void 0 && (t = !1), !!n && t && n === K(e);
}
function $(e, t, n, r) {
	t === void 0 && (t = !1), n === void 0 && (n = !1);
	let i = e.getBoundingClientRect(), a = xt(e), o = H(1);
	t && (r ? J(r) && (o = St(r)) : o = St(e));
	let s = Tt(a, n, r) ? wt(a) : H(0), c = (i.left + s.x) / o.x, l = (i.top + s.y) / o.y, u = i.width / o.x, d = i.height / o.y;
	if (a && r) {
		let e = K(a), t = J(r) ? K(r) : r, n = e, i = yt(n);
		for (; i && t !== n;) {
			let e = St(i), t = i.getBoundingClientRect(), r = Z(i), a = t.left + (i.clientLeft + parseFloat(r.paddingLeft)) * e.x, o = t.top + (i.clientTop + parseFloat(r.paddingTop)) * e.y;
			c *= e.x, l *= e.y, u *= e.x, d *= e.y, c += a, l += o, n = K(i), i = yt(n);
		}
	}
	return Be({
		width: u,
		height: d,
		x: c,
		y: l
	});
}
function Et(e, t) {
	let n = gt(e).scrollLeft;
	return t ? t.left + n : $(q(e)).left + n;
}
function Dt(e, t) {
	let n = e.getBoundingClientRect();
	return {
		x: n.left + t.scrollLeft - Et(e, n),
		y: n.top + t.scrollTop
	};
}
function Ot(e) {
	let { elements: t, rect: n, offsetParent: r, strategy: i } = e, a = i === "fixed", o = q(r), s = t ? ct(t.floating) : !1;
	if (r === o || s && a) return n;
	let c = {
		scrollLeft: 0,
		scrollTop: 0
	}, l = H(1), u = H(0), d = Y(r);
	if ((d || !a) && ((rt(r) !== "body" || ot(o)) && (c = gt(r)), d)) {
		let e = $(r);
		l = St(r), u.x = e.x + r.clientLeft, u.y = e.y + r.clientTop;
	}
	let f = o && !d && !a ? Dt(o, c) : H(0);
	return {
		width: n.width * l.x,
		height: n.height * l.y,
		x: n.x * l.x - c.scrollLeft * l.x + u.x + f.x,
		y: n.y * l.y - c.scrollTop * l.y + u.y + f.y
	};
}
function kt(e) {
	return e.getClientRects ? Array.from(e.getClientRects()) : [];
}
function At(e) {
	let t = gt(e), n = e.ownerDocument.body, r = V(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth), i = V(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight), a = -t.scrollLeft + Et(e), o = -t.scrollTop;
	return Z(n).direction === "rtl" && (a += V(e.clientWidth, n.clientWidth) - r), {
		width: r,
		height: i,
		x: a,
		y: o
	};
}
var jt = 25;
function Mt(e, t, n) {
	n === void 0 && (n = "viewport");
	let r = n === "layoutViewport", i = K(e), a = q(e), o = i.visualViewport, s = a.clientWidth, c = a.clientHeight, l = 0, u = 0;
	if (o) {
		let e = !mt() || t === "fixed";
		r ? e || (l = -o.offsetLeft, u = -o.offsetTop) : (s = o.width, c = o.height, e && (l = o.offsetLeft, u = o.offsetTop));
	}
	if (Et(a) <= 0) {
		let e = a.ownerDocument, t = e.body, n = getComputedStyle(t), r = e.compatMode === "CSS1Compat" && parseFloat(n.marginLeft) + parseFloat(n.marginRight) || 0, i = Math.abs(a.clientWidth - t.clientWidth - r), o = getComputedStyle(a).scrollbarGutter === "stable both-edges" ? i / 2 : i;
		o <= jt && (s -= o);
	}
	return {
		width: s,
		height: c,
		x: l,
		y: u
	};
}
function Nt(e, t) {
	let n = $(e, !0, t === "fixed"), r = n.top + e.clientTop, i = n.left + e.clientLeft, a = St(e);
	return {
		width: e.clientWidth * a.x,
		height: e.clientHeight * a.y,
		x: i * a.x,
		y: r * a.y
	};
}
function Pt(e, t, n) {
	let r;
	if (t === "viewport" || t === "layoutViewport") r = Mt(e, n, t);
	else if (t === "document") r = At(q(e));
	else if (J(t)) r = Nt(t, n);
	else {
		let n = wt(e);
		r = {
			x: t.x - n.x,
			y: t.y - n.y,
			width: t.width,
			height: t.height
		};
	}
	return Be(r);
}
function Ft(e, t) {
	let n = t.get(e);
	if (n) return n;
	let r = vt(e, [], !1).filter((e) => J(e) && rt(e) !== "body"), i = null, a = Z(e).position === "fixed", o = a ? Q(e) : e;
	for (; J(o) && !ht(o);) {
		let e = Z(o), t = ft(o), n = i ? i.position : a ? "fixed" : "";
		!t && (n === "fixed" || n === "absolute" && e.position === "static") ? r = r.filter((e) => e !== o) : i = e, o = Q(o);
	}
	return t.set(e, r), r;
}
function It(e) {
	let { element: t, boundary: n, rootBoundary: r, strategy: i } = e, a = [...n === "clippingAncestors" ? ct(t) ? [] : Ft(t, this._c) : [].concat(n), r], o = Pt(t, a[0], i), s = o.top, c = o.right, l = o.bottom, u = o.left;
	for (let e = 1; e < a.length; e++) {
		let n = Pt(t, a[e], i);
		s = V(n.top, s), c = B(n.right, c), l = B(n.bottom, l), u = V(n.left, u);
	}
	return {
		width: c - u,
		height: l - s,
		x: u,
		y: s
	};
}
function Lt(e) {
	let { width: t, height: n } = bt(e);
	return {
		width: t,
		height: n
	};
}
function Rt(e, t, n) {
	let r = Y(t), i = q(t), a = n === "fixed", o = $(e, !0, a, t), s = {
		scrollLeft: 0,
		scrollTop: 0
	}, c = H(0);
	if ((r || !a) && ((rt(t) !== "body" || ot(i)) && (s = gt(t)), r)) {
		let e = $(t, !0, a, t);
		c.x = e.x + t.clientLeft, c.y = e.y + t.clientTop;
	}
	!r && i && (c.x = Et(i));
	let l = i && !r && !a ? Dt(i, s) : H(0);
	return {
		x: o.left + s.scrollLeft - c.x - l.x,
		y: o.top + s.scrollTop - c.y - l.y,
		width: o.width,
		height: o.height
	};
}
function zt(e) {
	return Z(e).position === "static";
}
function Bt(e, t) {
	if (!Y(e) || Z(e).position === "fixed") return null;
	if (t) return t(e);
	let n = e.offsetParent;
	return q(e) === n && (n = n.ownerDocument.body), n;
}
function Vt(e, t) {
	let n = K(e);
	if (ct(e)) return n;
	if (!Y(e)) {
		let t = Q(e);
		for (; t && !ht(t);) {
			if (J(t) && !zt(t)) return t;
			t = Q(t);
		}
		return n;
	}
	let r = Bt(e, t);
	for (; r && st(r) && zt(r);) r = Bt(r, t);
	return r && ht(r) && zt(r) && !ft(r) ? n : r || pt(e) || n;
}
var Ht = async function(e) {
	let t = this.getOffsetParent || Vt, n = this.getDimensions, r = await n(e.floating);
	return {
		reference: Rt(e.reference, await t(e.floating), e.strategy),
		floating: {
			x: 0,
			y: 0,
			width: r.width,
			height: r.height
		}
	};
};
function Ut(e) {
	return Z(e).direction === "rtl";
}
var Wt = {
	convertOffsetParentRelativeRectToViewportRelativeRect: Ot,
	getDocumentElement: q,
	getClippingRect: It,
	getOffsetParent: Vt,
	getElementRects: Ht,
	getClientRects: kt,
	getDimensions: Lt,
	getScale: St,
	isElement: J,
	isRTL: Ut
};
function Gt(e, t) {
	return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function Kt(e, t, n) {
	let r = null, i, a = q(e);
	function o() {
		var e;
		clearTimeout(i), (e = r) == null || e.disconnect(), r = null;
	}
	function s(n, c) {
		n === void 0 && (n = !1), c === void 0 && (c = 1), o();
		let l = e.getBoundingClientRect(), { left: u, top: d, width: f, height: p } = l;
		if (n || t(), !f || !p) return;
		let m = xe(d), h = xe(a.clientWidth - (u + f)), g = xe(a.clientHeight - (d + p)), _ = xe(u), v = {
			rootMargin: -m + "px " + -h + "px " + -g + "px " + -_ + "px",
			threshold: V(0, B(1, c)) || 1
		}, y = !0;
		function b(t) {
			let n = t[0].intersectionRatio;
			if (!Gt(l, e.getBoundingClientRect())) return s();
			if (n !== c) {
				if (!y) return s();
				n ? s(!1, n) : i = setTimeout(() => {
					s(!1, 1e-7);
				}, 1e3);
			}
			y = !1;
		}
		try {
			r = new IntersectionObserver(b, {
				...v,
				root: a.ownerDocument
			});
		} catch {
			r = new IntersectionObserver(b, v);
		}
		r.observe(e);
	}
	let c = K(e), l = () => s(n);
	return c.addEventListener("resize", l), s(!0), () => {
		c.removeEventListener("resize", l), o();
	};
}
function qt(e, t, n, r) {
	r === void 0 && (r = {});
	let { ancestorScroll: i = !0, ancestorResize: a = !0, elementResize: o = typeof ResizeObserver == "function", layoutShift: s = typeof IntersectionObserver == "function", animationFrame: c = !1 } = r, l = xt(e), u = i || a ? [...l ? vt(l) : [], ...t ? vt(t) : []] : [];
	u.forEach((e) => {
		i && e.addEventListener("scroll", n), a && e.addEventListener("resize", n);
	});
	let d = l && s ? Kt(l, n, a) : null, f = -1, p = null;
	o && (p = new ResizeObserver((e) => {
		let [r] = e;
		r && r.target === l && p && t && (p.unobserve(t), cancelAnimationFrame(f), f = requestAnimationFrame(() => {
			var e;
			(e = p) == null || e.observe(t);
		})), n();
	}), l && !c && p.observe(l), t && p.observe(t));
	let m, h = c ? $(e) : null;
	c && g();
	function g() {
		let t = $(e);
		h && !Gt(h, t) && n(), h = t, m = requestAnimationFrame(g);
	}
	return n(), () => {
		var e;
		u.forEach((e) => {
			i && e.removeEventListener("scroll", n), a && e.removeEventListener("resize", n);
		}), d?.(), (e = p) == null || e.disconnect(), p = null, c && cancelAnimationFrame(m);
	};
}
var Jt = Qe, Yt = $e, Xt = Ke, Zt = tt, Qt = Ye, $t = Ge, en = et, tn = (e, t, n) => {
	let r = /* @__PURE__ */ new Map(), i = n ?? {}, a = {
		...Wt,
		...i.platform,
		_c: r
	};
	return We(e, t, {
		...i,
		platform: a
	});
}, nn = typeof document < "u" ? d : function() {};
function rn(e, t) {
	if (e === t) return !0;
	if (typeof e != typeof t) return !1;
	if (typeof e == "function" && e.toString() === t.toString()) return !0;
	let n, r, i;
	if (e && t && typeof e == "object") {
		if (Array.isArray(e)) {
			if (n = e.length, n !== t.length) return !1;
			for (r = n; r-- !== 0;) if (!rn(e[r], t[r])) return !1;
			return !0;
		}
		if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
		for (r = n; r-- !== 0;) if (!{}.hasOwnProperty.call(t, i[r])) return !1;
		for (r = n; r-- !== 0;) {
			let n = i[r];
			if (!(n === "_owner" && e.$$typeof) && !rn(e[n], t[n])) return !1;
		}
		return !0;
	}
	return e !== e && t !== t;
}
function an(e) {
	return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function on(e, t) {
	let n = an(e);
	return Math.round(t * n) / n;
}
function sn(e) {
	let t = a.useRef(e);
	return nn(() => {
		t.current = e;
	}), t;
}
function cn(e) {
	e === void 0 && (e = {});
	let { placement: t = "bottom", strategy: n = "absolute", middleware: r = [], platform: i, elements: { reference: o, floating: s } = {}, transform: c = !0, whileElementsMounted: l, open: u } = e, [d, f] = a.useState({
		x: 0,
		y: 0,
		strategy: n,
		placement: t,
		middlewareData: {},
		isPositioned: !1
	}), [m, h] = a.useState(r);
	rn(m, r) || h(r);
	let [g, _] = a.useState(null), [v, y] = a.useState(null), b = a.useCallback((e) => {
		e !== w.current && (w.current = e, _(e));
	}, []), x = a.useCallback((e) => {
		e !== T.current && (T.current = e, y(e));
	}, []), S = o || g, C = s || v, w = a.useRef(null), T = a.useRef(null), E = a.useRef(d), D = l != null, O = sn(l), k = sn(i), A = sn(u), j = a.useCallback(() => {
		if (!w.current || !T.current) return;
		let e = {
			placement: t,
			strategy: n,
			middleware: m
		};
		k.current && (e.platform = k.current), tn(w.current, T.current, e).then((e) => {
			let t = {
				...e,
				isPositioned: A.current !== !1
			};
			M.current && !rn(E.current, t) && (E.current = t, p.flushSync(() => {
				f(t);
			}));
		});
	}, [
		m,
		t,
		n,
		k,
		A
	]);
	nn(() => {
		u === !1 && E.current.isPositioned && (E.current.isPositioned = !1, f((e) => ({
			...e,
			isPositioned: !1
		})));
	}, [u]);
	let M = a.useRef(!1);
	nn(() => (M.current = !0, () => {
		M.current = !1;
	}), []), nn(() => {
		if (S && (w.current = S), C && (T.current = C), S && C) {
			if (O.current) return O.current(S, C, j);
			j();
		}
	}, [
		S,
		C,
		j,
		O,
		D
	]);
	let N = a.useMemo(() => ({
		reference: w,
		floating: T,
		setReference: b,
		setFloating: x
	}), [b, x]), P = a.useMemo(() => ({
		reference: S,
		floating: C
	}), [S, C]), F = a.useMemo(() => {
		let e = {
			position: n,
			left: 0,
			top: 0
		};
		if (!P.floating) return e;
		let t = on(P.floating, d.x), r = on(P.floating, d.y);
		return c ? {
			...e,
			transform: "translate(" + t + "px, " + r + "px)",
			...an(P.floating) >= 1.5 && { willChange: "transform" }
		} : {
			position: n,
			left: t,
			top: r
		};
	}, [
		n,
		c,
		P.floating,
		d.x,
		d.y
	]);
	return a.useMemo(() => ({
		...d,
		update: j,
		refs: N,
		elements: P,
		floatingStyles: F
	}), [
		d,
		j,
		N,
		P,
		F
	]);
}
var ln = (e) => {
	function t(e) {
		return {}.hasOwnProperty.call(e, "current");
	}
	return {
		name: "arrow",
		options: e,
		fn(n) {
			let { element: r, padding: i } = typeof e == "function" ? e(n) : e;
			return r && t(r) ? r.current == null ? {} : $t({
				element: r.current,
				padding: i
			}).fn(n) : r ? $t({
				element: r,
				padding: i
			}).fn(n) : {};
		}
	};
}, un = (e, t) => {
	let n = Jt(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, dn = (e, t) => {
	let n = Yt(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, fn = (e, t) => ({
	fn: en(e).fn,
	options: [e, t]
}), pn = (e, t) => {
	let n = Xt(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, mn = (e, t) => {
	let n = Zt(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, hn = (e, t) => {
	let n = Qt(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, gn = (e, t) => {
	let n = ln(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, _n = "Arrow", vn = a.forwardRef((e, t) => {
	let { children: n, width: r = 10, height: i = 5, ...a } = e;
	return /* @__PURE__ */ m(F.svg, {
		...a,
		ref: t,
		width: r,
		height: i,
		viewBox: "0 0 30 10",
		preserveAspectRatio: "none",
		children: e.asChild ? n : /* @__PURE__ */ m("polygon", { points: "0,0 30,0 15,10" })
	});
});
vn.displayName = _n;
var yn = vn;
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-size@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-use-size/dist/index.mjs
function bn(e) {
	let [t, n] = a.useState(void 0);
	return L(() => {
		if (e) {
			n({
				width: e.offsetWidth,
				height: e.offsetHeight
			});
			let t = new ResizeObserver((t) => {
				if (!Array.isArray(t) || !t.length) return;
				let r = t[0], i, a;
				if ("borderBoxSize" in r) {
					let e = r.borderBoxSize, t = Array.isArray(e) ? e[0] : e;
					i = t.inlineSize, a = t.blockSize;
				} else i = e.offsetWidth, a = e.offsetHeight;
				n({
					width: i,
					height: a
				});
			});
			return t.observe(e, { box: "border-box" }), () => t.unobserve(e);
		} else n(void 0);
	}, [e]), t;
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-popper@1.3.2+07ecf1aa3bcbed22/node_modules/@radix-ui/react-popper/dist/index.mjs
var xn = "Popper", [Sn, Cn] = b(xn), [wn, Tn] = Sn(xn), En = (e) => {
	let { __scopePopper: t, children: n } = e, [r, i] = a.useState(null), [o, s] = a.useState(void 0);
	return /* @__PURE__ */ m(wn, {
		scope: t,
		anchor: r,
		onAnchorChange: i,
		placementState: o,
		setPlacementState: s,
		children: n
	});
};
En.displayName = xn;
var Dn = "PopperAnchor", On = a.forwardRef((e, t) => {
	let { __scopePopper: n, virtualRef: r, ...i } = e, o = Tn(Dn, n), s = a.useRef(null), c = o.onAnchorChange, l = y(t, a.useCallback((e) => {
		s.current = e, e && c(e);
	}, [c])), u = a.useRef(null);
	a.useEffect(() => {
		if (!r) return;
		let e = u.current;
		u.current = r.current, e !== u.current && c(u.current);
	});
	let d = o.placementState && Rn(o.placementState), f = d?.[0], p = d?.[1];
	return r ? null : /* @__PURE__ */ m(F.div, {
		"data-radix-popper-side": f,
		"data-radix-popper-align": p,
		...i,
		ref: l
	});
});
On.displayName = Dn;
var kn = "PopperContent", [An, jn] = Sn(kn), Mn = a.forwardRef((e, t) => {
	let { __scopePopper: n, side: r = "bottom", sideOffset: i = 0, align: o = "center", alignOffset: s = 0, arrowPadding: c = 0, avoidCollisions: l = !0, collisionBoundary: u = [], collisionPadding: d = 0, sticky: f = "partial", hideWhenDetached: p = !1, updatePositionStrategy: h = "optimized", onPlaced: g, ..._ } = e, v = Tn(kn, n), [b, x] = a.useState(null), S = y(t, x), [C, w] = a.useState(null), T = bn(C), E = T?.width ?? 0, D = T?.height ?? 0, O = r + (o === "center" ? "" : "-" + o), k = typeof d == "number" ? d : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...d
	}, A = Array.isArray(u) ? u : [u], j = A.length > 0, M = {
		padding: k,
		boundary: A.filter(In),
		altBoundary: j
	}, { refs: N, floatingStyles: P, placement: I, isPositioned: R, middlewareData: z } = cn({
		strategy: "fixed",
		placement: O,
		whileElementsMounted: (...e) => qt(...e, { animationFrame: h === "always" }),
		elements: { reference: v.anchor },
		middleware: [
			un({
				mainAxis: i + D,
				alignmentAxis: s
			}),
			l && dn({
				mainAxis: !0,
				crossAxis: !1,
				limiter: f === "partial" ? fn() : void 0,
				...M
			}),
			l && pn({ ...M }),
			mn({
				...M,
				apply: ({ elements: e, rects: t, availableWidth: n, availableHeight: r }) => {
					let { width: i, height: a } = t.reference, o = e.floating.style;
					o.setProperty("--radix-popper-available-width", `${n}px`), o.setProperty("--radix-popper-available-height", `${r}px`), o.setProperty("--radix-popper-anchor-width", `${i}px`), o.setProperty("--radix-popper-anchor-height", `${a}px`);
				}
			}),
			C && gn({
				element: C,
				padding: c
			}),
			Ln({
				arrowWidth: E,
				arrowHeight: D
			}),
			p && hn({
				strategy: "referenceHidden",
				...M,
				boundary: j ? M.boundary : void 0
			})
		]
	}), te = v.setPlacementState;
	L(() => (te(I), () => {
		te(void 0);
	}), [I, te]);
	let [ne, re] = Rn(I), ie = ee(g);
	L(() => {
		R && ie?.();
	}, [R, ie]);
	let ae = z.arrow?.x, oe = z.arrow?.y, se = z.arrow?.centerOffset !== 0, [ce, le] = a.useState();
	return L(() => {
		b && le(window.getComputedStyle(b).zIndex);
	}, [b]), /* @__PURE__ */ m("div", {
		ref: N.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...P,
			transform: R ? P.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: ce,
			"--radix-popper-transform-origin": [z.transformOrigin?.x, z.transformOrigin?.y].join(" "),
			...z.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: e.dir,
		children: /* @__PURE__ */ m(An, {
			scope: n,
			placedSide: ne,
			placedAlign: re,
			onArrowChange: w,
			arrowX: ae,
			arrowY: oe,
			shouldHideArrow: se,
			children: /* @__PURE__ */ m(F.div, {
				"data-side": ne,
				"data-align": re,
				..._,
				ref: S,
				style: {
					..._.style,
					animation: R ? void 0 : "none"
				}
			})
		})
	});
});
Mn.displayName = kn;
var Nn = "PopperArrow", Pn = {
	top: "bottom",
	right: "left",
	bottom: "top",
	left: "right"
}, Fn = a.forwardRef(function(e, t) {
	let { __scopePopper: n, ...r } = e, i = jn(Nn, n), a = Pn[i.placedSide];
	return /* @__PURE__ */ m("span", {
		ref: i.onArrowChange,
		style: {
			position: "absolute",
			left: i.arrowX,
			top: i.arrowY,
			[a]: 0,
			transformOrigin: {
				top: "",
				right: "0 0",
				bottom: "center 0",
				left: "100% 0"
			}[i.placedSide],
			transform: {
				top: "translateY(100%)",
				right: "translateY(50%) rotate(90deg) translateX(-50%)",
				bottom: "rotate(180deg)",
				left: "translateY(50%) rotate(-90deg) translateX(50%)"
			}[i.placedSide],
			visibility: i.shouldHideArrow ? "hidden" : void 0
		},
		children: /* @__PURE__ */ m(yn, {
			...r,
			ref: t,
			style: {
				...r.style,
				display: "block"
			}
		})
	});
});
Fn.displayName = Nn;
function In(e) {
	return e !== null;
}
var Ln = (e) => ({
	name: "transformOrigin",
	options: e,
	fn(t) {
		let { placement: n, rects: r, middlewareData: i } = t, a = i.arrow?.centerOffset !== 0, o = a ? 0 : e.arrowWidth, s = a ? 0 : e.arrowHeight, [c, l] = Rn(n), u = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[l], d = (i.arrow?.x ?? 0) + o / 2, f = (i.arrow?.y ?? 0) + s / 2, p = "", m = "";
		return c === "bottom" ? (p = a ? u : `${d}px`, m = `${-s}px`) : c === "top" ? (p = a ? u : `${d}px`, m = `${r.floating.height + s}px`) : c === "right" ? (p = `${-s}px`, m = a ? u : `${f}px`) : c === "left" && (p = `${r.floating.width + s}px`, m = a ? u : `${f}px`), { data: {
			x: p,
			y: m
		} };
	}
});
function Rn(e) {
	let [t, n = "center"] = e.split("-");
	return [t, n];
}
var zn = En, Bn = On, Vn = Mn, Hn = Fn, Un = "Portal", Wn = a.forwardRef((e, t) => {
	let { container: n, ...r } = e, [i, o] = a.useState(!1);
	L(() => o(!0), []);
	let s = n || i && globalThis?.document?.body;
	return s ? p.createPortal(/* @__PURE__ */ m(F.div, {
		...r,
		ref: t
	}), s) : null;
});
Wn.displayName = Un;
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-presence@1.1.6+07ecf1aa3bcbed22/node_modules/@radix-ui/react-presence/dist/index.mjs
function Gn(e, t) {
	return a.useReducer((e, n) => t[e][n] ?? e, e);
}
var Kn = (e) => {
	let { present: t, children: n } = e, r = qn(t), i = typeof n == "function" ? n({ present: r.isPresent }) : a.Children.only(n), o = Yn(r.ref, Zn(i));
	return typeof n == "function" || r.isPresent ? a.cloneElement(i, { ref: o }) : null;
};
Kn.displayName = "Presence";
function qn(e) {
	let [t, n] = a.useState(), r = a.useRef(null), i = a.useRef(e), o = a.useRef("none"), [s, c] = Gn(e ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	return a.useEffect(() => {
		let e = Xn(r.current);
		o.current = s === "mounted" ? e : "none";
	}, [s]), L(() => {
		let t = r.current, n = i.current;
		if (n !== e) {
			let r = o.current, a = Xn(t);
			e ? c("MOUNT") : a === "none" || t?.display === "none" ? c("UNMOUNT") : c(n && r !== a ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
		}
	}, [e, c]), L(() => {
		if (t) {
			let e, n = t.ownerDocument.defaultView ?? window, a = (a) => {
				let o = Xn(r.current).includes(CSS.escape(a.animationName));
				if (a.target === t && o && (c("ANIMATION_END"), !i.current)) {
					let r = t.style.animationFillMode;
					t.style.animationFillMode = "forwards", e = n.setTimeout(() => {
						t.style.animationFillMode === "forwards" && (t.style.animationFillMode = r);
					});
				}
			}, s = (e) => {
				e.target === t && (o.current = Xn(r.current));
			};
			return t.addEventListener("animationstart", s), t.addEventListener("animationcancel", a), t.addEventListener("animationend", a), () => {
				n.clearTimeout(e), t.removeEventListener("animationstart", s), t.removeEventListener("animationcancel", a), t.removeEventListener("animationend", a);
			};
		} else c("ANIMATION_END");
	}, [t, c]), {
		isPresent: ["mounted", "unmountSuspended"].includes(s),
		ref: a.useCallback((e) => {
			r.current = e ? getComputedStyle(e) : null, n(e);
		}, [])
	};
}
function Jn(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function Yn(...e) {
	let t = a.useRef(e);
	return t.current = e, a.useCallback((e) => {
		let n = t.current, r = !1, i = n.map((t) => {
			let n = Jn(t, e);
			return !r && typeof n == "function" && (r = !0), n;
		});
		if (r) return () => {
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				typeof t == "function" ? t() : Jn(n[e], null);
			}
		};
	}, []);
}
function Xn(e) {
	return e?.animationName || "none";
}
function Zn(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-controllable-state@1.2.3+bf264c7668a20073/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var Qn = a.useInsertionEffect || L;
function $n({ prop: e, defaultProp: t, onChange: n = () => {}, caller: r }) {
	let [i, o, s] = er({
		defaultProp: t,
		onChange: n
	}), c = e !== void 0, l = c ? e : i;
	{
		let t = a.useRef(e !== void 0);
		a.useEffect(() => {
			let e = t.current;
			e !== c && console.warn(`${r} is changing from ${e ? "controlled" : "uncontrolled"} to ${c ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`), t.current = c;
		}, [c, r]);
	}
	return [l, a.useCallback((t) => {
		if (c) {
			let n = tr(t) ? t(e) : t;
			n !== e && s.current?.(n);
		} else o(t);
	}, [
		c,
		e,
		o,
		s
	])];
}
function er({ defaultProp: e, onChange: t }) {
	let [n, r] = a.useState(e), i = a.useRef(n), o = a.useRef(t);
	return Qn(() => {
		o.current = t;
	}, [t]), a.useEffect(() => {
		i.current !== n && (o.current?.(n), i.current = n);
	}, [n, i]), [
		n,
		r,
		o
	];
}
function tr(e) {
	return typeof e == "function";
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-visually-hidden@1.2.7+07ecf1aa3bcbed22/node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var nr = Object.freeze({
	position: "absolute",
	border: 0,
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	wordWrap: "normal"
}), rr = "VisuallyHidden", ir = a.forwardRef((e, t) => /* @__PURE__ */ m(F.span, {
	...e,
	ref: t,
	style: {
		...nr,
		...e.style
	}
}));
ir.displayName = rr;
var ar = ir, [or, sr] = b("Tooltip", [Cn]), cr = Cn(), lr = "TooltipProvider", ur = 700, dr = "tooltip.open", [fr, pr] = or(lr), mr = (e) => {
	let { __scopeTooltip: t, delayDuration: n = ur, skipDelayDuration: r = 300, disableHoverableContent: i = !1, children: o } = e, s = a.useRef(!0), c = a.useRef(!1), l = a.useRef(0);
	return a.useEffect(() => {
		let e = l.current;
		return () => window.clearTimeout(e);
	}, []), /* @__PURE__ */ m(fr, {
		scope: t,
		isOpenDelayedRef: s,
		delayDuration: n,
		onOpen: a.useCallback(() => {
			r <= 0 || (window.clearTimeout(l.current), s.current = !1);
		}, [r]),
		onClose: a.useCallback(() => {
			r <= 0 || (window.clearTimeout(l.current), l.current = window.setTimeout(() => s.current = !0, r));
		}, [r]),
		isPointerInTransitRef: c,
		onPointerInTransitChange: a.useCallback((e) => {
			c.current = e;
		}, []),
		disableHoverableContent: i,
		children: o
	});
};
mr.displayName = lr;
var hr = "Tooltip", [gr, _r] = or(hr), vr = (e) => {
	let { __scopeTooltip: t, children: n, open: r, defaultOpen: i, onOpenChange: o, disableHoverableContent: s, delayDuration: c } = e, l = pr(hr, e.__scopeTooltip), u = cr(t), [d, f] = a.useState(null), p = ve(), h = a.useRef(0), g = s ?? l.disableHoverableContent, _ = c ?? l.delayDuration, v = a.useRef(!1), [y, b] = $n({
		prop: r,
		defaultProp: i ?? !1,
		onChange: (e) => {
			e ? (l.onOpen(), document.dispatchEvent(new CustomEvent(dr))) : l.onClose(), o?.(e);
		},
		caller: hr
	}), x = a.useMemo(() => y ? v.current ? "delayed-open" : "instant-open" : "closed", [y]), S = a.useCallback(() => {
		window.clearTimeout(h.current), h.current = 0, v.current = !1, b(!0);
	}, [b]), C = a.useCallback(() => {
		window.clearTimeout(h.current), h.current = 0, b(!1);
	}, [b]), w = a.useCallback(() => {
		window.clearTimeout(h.current), h.current = window.setTimeout(() => {
			v.current = !0, b(!0), h.current = 0;
		}, _);
	}, [_, b]);
	return a.useEffect(() => () => {
		h.current &&= (window.clearTimeout(h.current), 0);
	}, []), /* @__PURE__ */ m(zn, {
		...u,
		children: /* @__PURE__ */ m(gr, {
			scope: t,
			contentId: p,
			open: y,
			stateAttribute: x,
			trigger: d,
			onTriggerChange: f,
			onTriggerEnter: a.useCallback(() => {
				l.isOpenDelayedRef.current ? w() : S();
			}, [
				l.isOpenDelayedRef,
				w,
				S
			]),
			onTriggerLeave: a.useCallback(() => {
				g ? C() : (window.clearTimeout(h.current), h.current = 0);
			}, [C, g]),
			onOpen: S,
			onClose: C,
			disableHoverableContent: g,
			children: n
		})
	});
};
vr.displayName = hr;
var yr = "TooltipTrigger", br = a.forwardRef((e, t) => {
	let { __scopeTooltip: n, ...r } = e, i = _r(yr, n), o = pr(yr, n), s = cr(n), c = y(t, a.useRef(null), i.onTriggerChange), l = a.useRef(!1), u = a.useRef(!1), d = a.useCallback(() => l.current = !1, []);
	return a.useEffect(() => () => document.removeEventListener("pointerup", d), [d]), /* @__PURE__ */ m(Bn, {
		asChild: !0,
		...s,
		children: /* @__PURE__ */ m(F.button, {
			"aria-describedby": i.open ? i.contentId : void 0,
			"data-state": i.stateAttribute,
			...r,
			ref: c,
			onPointerMove: g(e.onPointerMove, (e) => {
				e.pointerType !== "touch" && !u.current && !o.isPointerInTransitRef.current && (i.onTriggerEnter(), u.current = !0);
			}),
			onPointerLeave: g(e.onPointerLeave, () => {
				i.onTriggerLeave(), u.current = !1;
			}),
			onPointerDown: g(e.onPointerDown, () => {
				i.open && i.onClose(), l.current = !0, document.addEventListener("pointerup", d, { once: !0 });
			}),
			onFocus: g(e.onFocus, () => {
				l.current || i.onOpen();
			}),
			onBlur: g(e.onBlur, i.onClose),
			onClick: g(e.onClick, i.onClose)
		})
	});
});
br.displayName = yr;
var xr = "TooltipPortal", [Sr, Cr] = or(xr, { forceMount: void 0 }), wr = (e) => {
	let { __scopeTooltip: t, forceMount: n, children: r, container: i } = e, a = _r(xr, t);
	return /* @__PURE__ */ m(Sr, {
		scope: t,
		forceMount: n,
		children: /* @__PURE__ */ m(Kn, {
			present: n || a.open,
			children: /* @__PURE__ */ m(Wn, {
				asChild: !0,
				container: i,
				children: r
			})
		})
	});
};
wr.displayName = xr;
var Tr = "TooltipContent", Er = a.forwardRef((e, t) => {
	let n = Cr(Tr, e.__scopeTooltip), { forceMount: r = n.forceMount, side: i = "top", ...a } = e, o = _r(Tr, e.__scopeTooltip);
	return /* @__PURE__ */ m(Kn, {
		present: r || o.open,
		children: o.disableHoverableContent ? /* @__PURE__ */ m(jr, {
			side: i,
			...a,
			ref: t
		}) : /* @__PURE__ */ m(Dr, {
			side: i,
			...a,
			ref: t
		})
	});
}), Dr = a.forwardRef((e, t) => {
	let n = _r(Tr, e.__scopeTooltip), r = pr(Tr, e.__scopeTooltip), i = a.useRef(null), o = y(t, i), [s, c] = a.useState(null), { trigger: l, onClose: u } = n, d = i.current, { onPointerInTransitChange: f } = r, p = a.useCallback(() => {
		c(null), f(!1);
	}, [f]), h = a.useCallback((e, t) => {
		let n = e.currentTarget, r = {
			x: e.clientX,
			y: e.clientY
		}, i = Fr(r, Pr(r, n.getBoundingClientRect())), a = Ir(t.getBoundingClientRect());
		c(Rr([...i, ...a])), f(!0);
	}, [f]);
	return a.useEffect(() => () => p(), [p]), a.useEffect(() => {
		if (l && d) {
			let e = (e) => h(e, d), t = (e) => h(e, l);
			return l.addEventListener("pointerleave", e), d.addEventListener("pointerleave", t), () => {
				l.removeEventListener("pointerleave", e), d.removeEventListener("pointerleave", t);
			};
		}
	}, [
		l,
		d,
		h,
		p
	]), a.useEffect(() => {
		if (s) {
			let e = (e) => {
				let t = e.target, n = {
					x: e.clientX,
					y: e.clientY
				}, r = l?.contains(t) || d?.contains(t), i = !Lr(n, s);
				r ? p() : i && (p(), u());
			};
			return document.addEventListener("pointermove", e), () => document.removeEventListener("pointermove", e);
		}
	}, [
		l,
		d,
		s,
		u,
		p
	]), /* @__PURE__ */ m(jr, {
		...e,
		ref: o
	});
}), [Or, kr] = or(hr, { isInside: !1 }), Ar = /* @__PURE__ */ w("TooltipContent"), jr = a.forwardRef((e, t) => {
	let { __scopeTooltip: n, children: r, "aria-label": i, onEscapeKeyDown: o, onPointerDownOutside: s, ...c } = e, l = _r(Tr, n), u = cr(n), { onClose: d } = l;
	return a.useEffect(() => (document.addEventListener(dr, d), () => document.removeEventListener(dr, d)), [d]), a.useEffect(() => {
		if (l.trigger) {
			let e = (e) => {
				e.target instanceof Node && e.target.contains(l.trigger) && d();
			};
			return window.addEventListener("scroll", e, { capture: !0 }), () => window.removeEventListener("scroll", e, { capture: !0 });
		}
	}, [l.trigger, d]), /* @__PURE__ */ m(ce, {
		asChild: !0,
		disableOutsidePointerEvents: !1,
		onEscapeKeyDown: o,
		onPointerDownOutside: s,
		onFocusOutside: (e) => e.preventDefault(),
		onDismiss: d,
		children: /* @__PURE__ */ h(Vn, {
			"data-state": l.stateAttribute,
			...u,
			...c,
			ref: t,
			style: {
				...c.style,
				"--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
				"--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
				"--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
				"--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
				"--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
			},
			children: [/* @__PURE__ */ m(Ar, { children: r }), /* @__PURE__ */ m(Or, {
				scope: n,
				isInside: !0,
				children: /* @__PURE__ */ m(ar, {
					id: l.contentId,
					role: "tooltip",
					children: i || r
				})
			})]
		})
	});
});
Er.displayName = Tr;
var Mr = "TooltipArrow", Nr = a.forwardRef((e, t) => {
	let { __scopeTooltip: n, ...r } = e, i = cr(n);
	return kr(Mr, n).isInside ? null : /* @__PURE__ */ m(Hn, {
		...i,
		...r,
		ref: t
	});
});
Nr.displayName = Mr;
function Pr(e, t) {
	let n = Math.abs(t.top - e.y), r = Math.abs(t.bottom - e.y), i = Math.abs(t.right - e.x), a = Math.abs(t.left - e.x);
	switch (Math.min(n, r, i, a)) {
		case a: return "left";
		case i: return "right";
		case n: return "top";
		case r: return "bottom";
		default: throw Error("unreachable");
	}
}
function Fr(e, t, n = 5) {
	let r = [];
	switch (t) {
		case "top":
			r.push({
				x: e.x - n,
				y: e.y + n
			}, {
				x: e.x + n,
				y: e.y + n
			});
			break;
		case "bottom":
			r.push({
				x: e.x - n,
				y: e.y - n
			}, {
				x: e.x + n,
				y: e.y - n
			});
			break;
		case "left":
			r.push({
				x: e.x + n,
				y: e.y - n
			}, {
				x: e.x + n,
				y: e.y + n
			});
			break;
		case "right":
			r.push({
				x: e.x - n,
				y: e.y - n
			}, {
				x: e.x - n,
				y: e.y + n
			});
			break;
	}
	return r;
}
function Ir(e) {
	let { top: t, right: n, bottom: r, left: i } = e;
	return [
		{
			x: i,
			y: t
		},
		{
			x: n,
			y: t
		},
		{
			x: n,
			y: r
		},
		{
			x: i,
			y: r
		}
	];
}
function Lr(e, t) {
	let { x: n, y: r } = e, i = !1;
	for (let e = 0, a = t.length - 1; e < t.length; a = e++) {
		let o = t[e], s = t[a], c = o.x, l = o.y, u = s.x, d = s.y;
		l > r != d > r && n < (u - c) * (r - l) / (d - l) + c && (i = !i);
	}
	return i;
}
function Rr(e) {
	let t = e.slice();
	return t.sort((e, t) => e.x < t.x ? -1 : e.x > t.x ? 1 : e.y < t.y ? -1 : +(e.y > t.y)), zr(t);
}
function zr(e) {
	if (e.length <= 1) return e.slice();
	let t = [];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (; t.length >= 2;) {
			let e = t[t.length - 1], n = t[t.length - 2];
			if ((e.x - n.x) * (r.y - n.y) >= (e.y - n.y) * (r.x - n.x)) t.pop();
			else break;
		}
		t.push(r);
	}
	t.pop();
	let n = [];
	for (let t = e.length - 1; t >= 0; t--) {
		let r = e[t];
		for (; n.length >= 2;) {
			let e = n[n.length - 1], t = n[n.length - 2];
			if ((e.x - t.x) * (r.y - t.y) >= (e.y - t.y) * (r.x - t.x)) n.pop();
			else break;
		}
		n.push(r);
	}
	return n.pop(), t.length === 1 && n.length === 1 && t[0].x === n[0].x && t[0].y === n[0].y ? t : t.concat(n);
}
var Br = mr, Vr = vr, Hr = br, Ur = wr, Wr = Er, Gr = "(hover: none)", Kr = s(null);
function qr() {
	let e = u(Kr), t = f(l((e) => {
		let t = window.matchMedia(Gr);
		return t.addEventListener("change", e), () => t.removeEventListener("change", e);
	}, []), l(() => !window.matchMedia(Gr).matches, []), () => !0);
	return e ?? t;
}
//#endregion
//#region ../../packages/design-library/src/utils/portal-container.tsx
var Jr = s(null);
function Yr({ container: e, children: t }) {
	return /* @__PURE__ */ m(Jr, {
		value: e,
		children: t
	});
}
function Xr() {
	return u(Jr);
}
//#endregion
//#region ../../packages/design-library/src/components/tooltip.tsx
var Zr = Vr;
function Qr(e) {
	return /* @__PURE__ */ m(Hr, {
		"data-slot": "tooltip-trigger",
		...e
	});
}
function $r({ className: e, children: t, sideOffset: r = 6, ref: i, ...a }) {
	let o = Xr();
	return qr() ? /* @__PURE__ */ m(Ur, {
		container: o ?? void 0,
		children: /* @__PURE__ */ m(Wr, {
			ref: i,
			"data-slot": "tooltip-content",
			sideOffset: r,
			className: n("z-50 rounded-[5px] bg-[var(--primary-base)] px-2 py-1.5 shadow-[var(--shadow-popover)]", "text-body-small-default text-[color:var(--content-inset)]", "max-w-[min(20rem,var(--radix-tooltip-content-available-width,20rem))]", "text-pretty break-words", "data-[state=delayed-open]:animate-[popoverIn_120ms_ease-out]", "data-[state=instant-open]:animate-[popoverIn_60ms_ease-out]", e),
			...a,
			children: t
		})
	}) : null;
}
function ei({ content: e, children: n, side: r, align: i, delayDuration: a, ...o }) {
	return qr() ? /* @__PURE__ */ m(Br, {
		delayDuration: 200,
		skipDelayDuration: 300,
		children: /* @__PURE__ */ h(Zr, {
			delayDuration: a,
			children: [/* @__PURE__ */ m(Qr, {
				asChild: !0,
				...o,
				children: n
			}), /* @__PURE__ */ m($r, {
				side: r,
				align: i,
				children: e
			})]
		})
	}) : /* @__PURE__ */ m(t, {
		...o,
		children: n
	});
}
ei.Root = Zr, ei.Trigger = Qr, ei.Content = $r;
//#endregion
//#region ../../packages/design-library/src/components/button.tsx
var ti = i([
	"relative inline-flex items-center justify-center gap-1.5 cursor-pointer",
	"select-none whitespace-nowrap transition-[background-color,color,border-color,transform,box-shadow]",
	"duration-150 ease-out outline-none border",
	"keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0",
	"active:scale-[0.97]",
	"disabled:cursor-not-allowed disabled:active:scale-100",
	"aria-disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-60 aria-disabled:active:scale-100",
	"text-[color:var(--vbtn-fg)]"
].join(" "), {
	variants: {
		variant: {
			primary: [
				"[--vbtn-fg:var(--content-inset)]",
				"bg-[var(--primary-base)]",
				"hover:bg-[var(--primary-hover)]",
				"active:bg-[var(--primary-active)]",
				"border-transparent",
				"disabled:bg-[var(--primary-disabled)]",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			accent: [
				"[--vbtn-fg:var(--vbtn-accent-fg,var(--content-inset))]",
				"bg-[var(--vbtn-accent,var(--primary-base))]",
				"hover:bg-[color-mix(in_srgb,#000_10%,var(--vbtn-accent,var(--primary-hover)))]",
				"active:bg-[color-mix(in_srgb,#000_16%,var(--vbtn-accent,var(--primary-active)))]",
				"border-transparent",
				"disabled:bg-[var(--primary-disabled)]",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			danger: [
				"[--vbtn-fg:var(--aux-white)]",
				"bg-[var(--system-negative-strong)]",
				"hover:bg-[var(--system-negative-hover)]",
				"active:bg-[var(--system-negative-hover)]",
				"border-transparent",
				"disabled:bg-[var(--primary-disabled)]",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			dangerOutline: [
				"[--vbtn-fg:var(--system-negative-strong)]",
				"bg-transparent",
				"border-[var(--system-negative-strong)]",
				"hover:[--vbtn-fg:var(--system-negative-hover)]",
				"hover:border-[var(--system-negative-hover)]",
				"active:border-[var(--system-negative-hover)]",
				"disabled:border-[var(--primary-disabled)]",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			dangerGhost: [
				"[--vbtn-fg:var(--system-negative-strong)]",
				"bg-transparent border-transparent",
				"hover:[--vbtn-fg:var(--system-negative-hover)]",
				"hover:bg-[var(--system-negative-weak)]",
				"active:bg-[var(--system-negative-weak)] active:scale-100",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			outlined: [
				"[--vbtn-fg:var(--primary-base)]",
				"bg-transparent",
				"border-[var(--border-element)]",
				"hover:[--vbtn-fg:var(--primary-active)]",
				"hover:bg-[color-mix(in_srgb,var(--primary-second-hover)_15%,transparent)]",
				"active:bg-[color-mix(in_srgb,var(--primary-second-hover)_20%,transparent)]",
				"disabled:border-[var(--primary-disabled)]",
				"disabled:[--vbtn-fg:var(--content-disabled)]",
				"disabled:bg-transparent"
			].join(" "),
			ghost: [
				"[--vbtn-fg:var(--content-default)]",
				"bg-transparent border-transparent",
				"hover:[--vbtn-fg:var(--primary-active)]",
				"hover:bg-[color-mix(in_srgb,var(--primary-second-hover)_15%,transparent)]",
				"active:bg-[color-mix(in_srgb,var(--primary-second-hover)_20%,transparent)] active:scale-100",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" "),
			link: [
				"[--vbtn-fg:var(--content-link)]",
				"inline bg-transparent border-transparent",
				"underline hover:[--vbtn-fg:var(--content-link-hover)]",
				"active:scale-100",
				"disabled:[--vbtn-fg:var(--content-disabled)]"
			].join(" ")
		},
		size: {
			regular: "h-8 px-2.5 text-body-medium-default rounded-md",
			compact: "h-6 px-2 text-body-small-default rounded-[6px]",
			large: "h-11 px-4 text-body-large-default rounded-md"
		},
		shape: {
			default: "",
			pill: "rounded-full"
		},
		iconOnly: {
			true: "p-0",
			false: ""
		},
		fullWidth: {
			true: "w-full",
			false: ""
		},
		active: {
			true: "",
			false: ""
		},
		expandOnMobile: {
			true: "",
			false: ""
		}
	},
	compoundVariants: [
		{
			iconOnly: !0,
			size: "regular",
			class: "h-8 w-8"
		},
		{
			iconOnly: !0,
			size: "compact",
			class: "h-6 w-6"
		},
		{
			iconOnly: !0,
			size: "large",
			class: "h-11 w-11"
		},
		{
			iconOnly: !0,
			size: "regular",
			expandOnMobile: !0,
			class: "touch-mobile:h-10 touch-mobile:w-10"
		},
		{
			iconOnly: !0,
			size: "compact",
			expandOnMobile: !0,
			class: "touch-mobile:h-10 touch-mobile:w-10"
		},
		{
			variant: "primary",
			active: !0,
			class: [
				"bg-[var(--primary-active)]",
				"hover:bg-[var(--primary-active)]",
				"active:bg-[var(--primary-active)]"
			].join(" ")
		},
		{
			variant: "ghost",
			active: !0,
			class: [
				"bg-[var(--surface-lift)]",
				"hover:bg-[var(--surface-active)]",
				"active:bg-[var(--surface-active)]",
				"[--vbtn-fg:var(--primary-active)]",
				"disabled:bg-[var(--border-disabled)]"
			].join(" ")
		},
		{
			variant: "outlined",
			active: !0,
			class: [
				"border-[var(--primary-base)]",
				"bg-[var(--surface-lift)]",
				"hover:bg-[var(--surface-active)]",
				"active:bg-[var(--surface-active)]",
				"[--vbtn-fg:var(--primary-active)]"
			].join(" ")
		},
		{
			variant: "outlined",
			iconOnly: !0,
			class: ["hover:bg-[var(--surface-base)]", "active:bg-[var(--surface-active)]"].join(" ")
		},
		{
			variant: "ghost",
			iconOnly: !0,
			active: !1,
			class: "[--vbtn-fg:var(--content-tertiary)] hover:[--vbtn-fg:var(--primary-active)]"
		},
		{
			variant: "outlined",
			iconOnly: !0,
			active: !1,
			class: "[--vbtn-fg:var(--content-tertiary)] hover:[--vbtn-fg:var(--primary-active)]"
		},
		{
			variant: "ghost",
			iconOnly: !0,
			expandOnMobile: !0,
			class: [
				"touch-mobile:bg-[var(--surface-lift)]",
				"touch-mobile:rounded-full",
				"touch-mobile:[--vbtn-fg:var(--content-default)]",
				"touch-mobile:hover:bg-[var(--surface-active)]",
				"touch-mobile:active:bg-[var(--surface-active)]"
			].join(" ")
		},
		{
			variant: "accent",
			iconOnly: !0,
			class: "[--vbtn-fg:var(--vbtn-accent-glyph,var(--vbtn-accent-fg,var(--content-inset)))]"
		},
		{
			variant: "link",
			class: "h-auto p-0 rounded-none text-[length:inherit] leading-[inherit]"
		}
	],
	defaultVariants: {
		variant: "primary",
		size: "regular",
		shape: "default",
		iconOnly: !1,
		fullWidth: !1,
		active: !1,
		expandOnMobile: !0
	}
});
function ni(e) {
	return e === "compact" ? 10 : e === "large" ? 16 : 14;
}
function ri({ ref: i, variant: a = "primary", size: s = "regular", shape: l = "default", loading: u = !1, leftIcon: d, rightIcon: f, iconOnly: p, fullWidth: h = !1, active: g = !1, expandOnMobile: _ = !0, iconOnlyGlyphClassName: v, tintColor: y, tooltip: b, tooltipSide: x, asChild: S = !1, className: C, style: w, type: T, children: E, title: D, disabled: O, onClick: k, ...A }) {
	let j = p != null && p !== !1, M = O === !0, N = S && M, P = N || u && !M, F = u ? /* @__PURE__ */ m(e, { className: "animate-spin" }) : null, I = F ?? d, ee = F ?? p, L = ni(s), R = {
		width: L,
		height: L,
		flexShrink: 0,
		display: "inline-flex",
		alignItems: "center",
		justifyContent: "center"
	}, z = n("inline-flex items-center justify-center shrink-0", s === "large" ? "size-4 [&_svg]:size-4" : "size-3.5 [&_svg]:size-3.5", _ && "touch-mobile:size-4 touch-mobile:[&_svg]:size-4", v), te = S ? t : "button", ne = {
		...y && !M ? { "--vbtn-fg": y } : null,
		...w
	}, re = (e) => {
		e.preventDefault(), e.stopPropagation();
	}, ie = /* @__PURE__ */ m(te, {
		...A,
		ref: i,
		type: S ? void 0 : T ?? "button",
		disabled: S ? void 0 : O,
		"aria-disabled": P ? !0 : A["aria-disabled"],
		"aria-busy": u ? !0 : A["aria-busy"],
		"data-disabled": N ? "" : void 0,
		"data-loading": u ? "" : void 0,
		"data-slot": "button",
		"data-variant": a,
		tabIndex: N ? -1 : A.tabIndex,
		onClick: P ? re : k,
		title: D,
		className: n(ti({
			variant: a,
			size: s,
			shape: l,
			iconOnly: j,
			fullWidth: h,
			active: g,
			expandOnMobile: _
		}), C),
		style: ne,
		children: j ? S && c(E) ? o(E, void 0, /* @__PURE__ */ m("span", {
			"aria-hidden": "true",
			className: z,
			children: ee
		})) : /* @__PURE__ */ m("span", {
			"aria-hidden": "true",
			className: z,
			children: ee
		}) : I == null && f == null ? E : [
			I == null ? null : /* @__PURE__ */ m("span", {
				"aria-hidden": "true",
				style: R,
				children: I
			}, "left-icon"),
			/* @__PURE__ */ m(r, { children: E }, "children"),
			f == null ? null : /* @__PURE__ */ m("span", {
				"aria-hidden": "true",
				style: R,
				children: f
			}, "right-icon")
		]
	});
	return b ? /* @__PURE__ */ m(ei, {
		content: b,
		side: x,
		children: ie
	}) : ie;
}
//#endregion
export { y as A, ce as C, I as D, F as E, S as O, ve as S, ee as T, un as _, $n as a, cn as b, Bn as c, zn as d, Cn as f, fn as g, hn as h, Xr as i, g as j, b as k, Hn as l, pn as m, ei as n, Kn as o, gn as p, Yr as r, Wn as s, ri as t, Vn as u, dn as v, de as w, qt as x, mn as y };
