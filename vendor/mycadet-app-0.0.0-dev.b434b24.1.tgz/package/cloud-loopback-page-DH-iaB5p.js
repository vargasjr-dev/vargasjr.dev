import { c as e, d as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { i as n, l as r } from "./schemas-D8_brjAQ.js";
import { r as i } from "./i18n-BRf-wfgm.js";
import { n as a } from "./api-DnMWUBLS.js";
import { n as o } from "./routes-DW44XTQk.js";
import { t as s } from "./auth-store-Bx-RKZJ9.js";
import { useEffect as c, useState as l } from "react";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
//#region src/runtime/local-host-transport.ts
var f = r({ ok: n() });
async function p(e, t) {
	try {
		let n = await fetch(e, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(t)
		}), r = f.safeParse(await n.json());
		return r.success ? r.data : { ok: !1 };
	} catch {
		return { ok: !1 };
	}
}
//#endregion
//#region src/runtime/cloud-session-host.ts
async function m(e) {
	return (await p("/v1/session", { token: e })).ok;
}
//#endregion
//#region src/domains/account/pages/cloud-loopback-page.tsx
var h = "cadet:loopback:state", g = "cadet:loopback:returnTo";
function _() {
	let { t: n } = i("account"), [r] = t(), f = e(), [p, _] = l(null);
	return c(() => {
		let e = r.get("state"), t = r.get("session_token"), i = sessionStorage.getItem(h), c = sessionStorage.getItem(g) || o.assistant;
		if (sessionStorage.removeItem(h), sessionStorage.removeItem(g), !e || e !== i) {
			_(n("authErrors.loopbackStateMismatch"));
			return;
		}
		if (!t) {
			_(n("authErrors.loopbackNoToken"));
			return;
		}
		if (!/^[a-zA-Z0-9]+$/.test(t)) {
			_(n("authErrors.loopbackInvalidToken"));
			return;
		}
		(async () => {
			if (!await m(t)) {
				_("Login failed: couldn't reach the local Cadet server to store the session. Please try again.");
				return;
			}
			await s.getState().refreshSession();
			try {
				let e = await a();
				if (e.ok && e.data.length > 0) {
					f(o.assistant, { replace: !0 });
					return;
				}
			} catch {}
			f(c, { replace: !0 });
		})();
	}, [
		r,
		f,
		n
	]), p ? /* @__PURE__ */ u("div", {
		className: "flex min-h-screen items-center justify-center bg-[var(--surface-base)] text-[var(--content-default)]",
		children: /* @__PURE__ */ d("div", {
			className: "max-w-md text-center",
			children: [/* @__PURE__ */ u("p", {
				className: "text-body-medium-default",
				children: p
			}), /* @__PURE__ */ u("button", {
				type: "button",
				className: "mt-4 rounded-lg border border-[var(--border-disabled)] px-4 py-2 text-sm hover:bg-[var(--surface-lift)]",
				onClick: () => void f(o.index),
				children: n("platformLoopbackPage.backToWelcome")
			})]
		})
	}) : /* @__PURE__ */ u("div", {
		className: "flex min-h-screen items-center justify-center bg-[var(--surface-base)] text-[var(--content-default)]",
		children: /* @__PURE__ */ u("p", {
			className: "text-body-medium-default",
			children: n("platformLoopbackPage.completing")
		})
	});
}
//#endregion
export { _ as CloudLoopbackPage };
