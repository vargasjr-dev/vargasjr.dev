//#region src/assistant/describe-error.ts
function e(e) {
	return e instanceof Error ? e.stack ?? `${e.name}: ${e.message}` : typeof e == "string" ? e : JSON.stringify(e);
}
//#endregion
export { e as t };
