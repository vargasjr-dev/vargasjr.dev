//#region src/i18n/locales/zh/onboarding.json
var e = {
	continue: "继续",
	back: "返回",
	forward: "前进",
	cancel: "取消",
	add: "添加",
	adding: "正在添加…",
	tryAgain: "重试",
	remove: "移除 {value}",
	downloadMacOSApp: "下载 macOS 应用",
	downloadWindowsApp: "下载 Windows 应用",
	claim: "认领"
}, t = {
	addOption: "添加“{value}”",
	enterHint: "↵ 回车",
	freeTextHint: "输入任意内容并按 ↵ 添加您自己的"
}, n = { ariaLabel: "第 {current} 步，共 {total} 步" }, r = {
	greetingNamed: "嘿，{name}！",
	greeting: "嘿！",
	introNamed: "我是 {name}，您的新 AI 助手。",
	intro: "我是您的新 AI 助手。"
}, i = {
	setupLine: "您可能用过只会回答问题的 AI。",
	helpLine: "我帮助得越多，",
	punchLine: "我与众不同。",
	betterLine: "我就越好，",
	lessLine: "您需要做的就越少。"
}, a = {
	title: "创建我的个性",
	lockedBody: "个性已锁定，请与您的助手聊天以进行更多更新",
	axisAriaLabel: "从 {left} 到 {right}",
	axes: {
		companionCoworker: {
			left: "伙伴",
			right: "同事"
		},
		genzBoomer: {
			left: "Z世代",
			right: "婴儿潮一代"
		},
		executeCollaborate: {
			left: "独立",
			right: "协作"
		},
		playfulSerious: {
			left: "活泼",
			right: "严肃"
		},
		politeUnfiltered: {
			left: "礼貌",
			right: "直率"
		}
	}
}, o = {
	title: "给我一个形象和名字",
	previousCharacter: "上一个形象",
	nextCharacter: "下一个形象",
	namePlaceholder: "为您的助手命名",
	nameAriaLabel: "助手名称",
	editName: "编辑名称",
	shuffle: "随机名称和外观",
	hearVoice: "听我的声音",
	stopVoice: "停止语音示例"
}, s = { title: "这里有一些初始用法<br></br>供您开始。" }, c = {
	title: "我们从您开始。",
	firstNameLabel: "我该怎么称呼您？",
	firstNamePlaceholder: "您的名字",
	skip: "跳过初始设置"
}, l = {
	titleNamed: "{name} 已启动并正在运行",
	title: "您的助手已启动并正在运行",
	bodyNamed: "你们之间有历史：个性、记忆和过去的对话。再次运行设置将覆盖 {name} 现在的身份。",
	body: "你们之间有历史：个性、记忆和过去的对话。再次运行设置将覆盖您的助手现在的身份。",
	keepNamed: "保留 {name} 并开始聊天",
	keep: "保留您的助手并开始聊天",
	redoNamed: "重新开始并重建 {name} 的个性",
	redo: "重新开始并重建其个性"
}, u = {
	searching: "正在搜索网络以了解您…",
	readingProfiles: "正在阅读公开资料…",
	skimming: "正在浏览要点…",
	connectingDots: "正在连接点滴信息…",
	piecing: "正在整合信息…",
	almostThere: "快完成了…"
}, d = {
	updatingPersonality: "正在更新我的个性…",
	findingVoice: "正在寻找我的声音…",
	gettingIntoCharacter: "正在进入角色…",
	almostThere: "快完成了…"
}, f = {
	title: "这是我找到的关于您的信息",
	bodyLoadingWithClaims: "仍在检查其余信息。您可以在信息出现时进行查看。",
	bodyReadyWithClaims: "我搜索了网络。请随意删除任何不真实的信息。",
	bodyLoadingEmpty: "仍在整理中…",
	removeClaim: "移除“{claim}”",
	notMe: "这不是我",
	stillSearching: "仍在搜索…"
}, p = {
	title: "这是我们首先可以做的事情",
	pickOne: "选择一个开始，或自行创建。<skip>跳过并开始聊天</skip>",
	loading: "正在整理一些想法…",
	alreadySetUp: "已设置 <plugins></plugins> {count, plural, other {# 个}} 插件以帮助您完成工作",
	listAnd: " 和 ",
	listCommaAnd: "，和",
	listComma: "，",
	fallbacks: {
		brief: {
			suggestion: "我将为您整理一份关于您领域最新动态的简报",
			prompt: "给我一份关于我领域最新动态的简报。"
		},
		weekly: {
			suggestion: "我将每周发送一份关于您领域新闻的简报",
			prompt: "设置每周发送一份关于我领域新闻的简报。"
		},
		week: {
			suggestion: "我将帮助您掌控您的一周",
			prompt: "帮助我掌控我的一周。"
		},
		draft: {
			suggestion: "我将根据一些粗略的笔记起草内容",
			prompt: "根据我提供的一些粗略笔记起草内容。"
		}
	}
}, m = {
	genericFailure: "发生错误。请重试。",
	signupClosed: "抱歉，Cadet 目前不接受新用户注册。欢迎稍后再试。",
	providerSignup: "该登录尚未关联 Cadet 账户。请先注册，然后登录。",
	loginIncomplete: "您的账户需要额外步骤才能完成登录。请在网页上登录，然后重试。",
	desktopUpdateRequired: "此版本的 Cadet 桌面应用无法登录。请更新应用，然后重试。"
}, h = {
	genericFailure: "发生了一些错误",
	localFallbackPitch: "立即开始使用本地助手"
}, g = {
	actions: e,
	onboardingAutocomplete: t,
	stepIndicator: n,
	introductionScreen: r,
	pitchStep: i,
	createPersonalityStep: a,
	giveMeAFaceScreen: o,
	integrationStep: s,
	researchOnboardingScreen: c,
	existingAssistantStep: l,
	lookingYouUpStep: u,
	finishingUpStep: d,
	researchResultsStep: f,
	suggestionsStep: p,
	authErrors: m,
	hatchingScreen: h
};
//#endregion
export { e as actions, m as authErrors, a as createPersonalityStep, g as default, l as existingAssistantStep, d as finishingUpStep, o as giveMeAFaceScreen, h as hatchingScreen, s as integrationStep, r as introductionScreen, u as lookingYouUpStep, t as onboardingAutocomplete, i as pitchStep, c as researchOnboardingScreen, f as researchResultsStep, n as stepIndicator, p as suggestionsStep };
