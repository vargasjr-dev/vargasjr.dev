import { t as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { t } from "./electron-bridge-VOSuV45z.js";
import { r as n } from "./i18n-BRf-wfgm.js";
import { t as r } from "./button-BrPHE1Q9.js";
import { t as i } from "./account-shell-D0S9QH7J.js";
import "./provider-DTIzxq2J.js";
import "./auth-flow-wtiOWtTR.js";
import "./provider-callback-BIm8IFvx.js";
import { useRef as a, useState as o } from "react";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/domains/account/native-auth-error.ts
var u = "authErrors.genericFailure", d = {
	signup_closed: "authErrors.signupClosed",
	provider_signup: "authErrors.providerSignup",
	login_incomplete: "authErrors.loginIncomplete",
	desktop_update_required: "authErrors.desktopUpdateRequired"
};
function f(e, t) {
	if (!(typeof e != "object" || !e || !(t in e))) return e[t];
}
function p(e) {
	let t = f(e, "code");
	return typeof t == "string" ? t : void 0;
}
function m(e) {
	return p(e) === "USER_CANCELLED";
}
function h(e) {
	if (p(e) !== "AUTH_ERROR") return;
	let t = f(f(e, "data"), "authError");
	return typeof t == "string" && t !== "" ? t : void 0;
}
function g(e) {
	let t = h(e);
	return t === void 0 ? u : d[t] ?? "authErrors.genericFailure";
}
//#endregion
//#region src/components/auth-welcome-screen.tsx
function _({ children: e }) {
	return /* @__PURE__ */ c(i, { children: /* @__PURE__ */ c("div", {
		className: "flex flex-col items-center py-12 text-[var(--content-default)]",
		children: e
	}) });
}
function v({ error: e, children: t }) {
	let { t: r } = n("account");
	return /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("h1", {
			className: "text-5xl font-normal tracking-tight md:text-4xl lg:text-5xl xl:text-6xl",
			style: {
				fontFamily: "var(--font-serif)",
				animation: "fadeInUp 0.5s ease-out 0.1s both"
			},
			children: r("welcome.title")
		}),
		/* @__PURE__ */ c("p", {
			className: "mt-3 text-center text-body-large-lighter text-[var(--content-tertiary)]",
			style: { animation: "fadeInUp 0.5s ease-out 0.3s both" },
			children: r("welcome.body")
		}),
		e && /* @__PURE__ */ c("p", {
			className: "mt-4 text-body-small-default text-[var(--system-negative-strong)]",
			children: e
		}),
		/* @__PURE__ */ c("div", {
			className: `${e ? "mt-4" : "mt-15"} flex w-full max-w-sm flex-col gap-3`,
			style: { animation: "fadeInUp 0.5s ease-out 0.5s both" },
			children: t
		})
	] });
}
function y({ returnTo: i, secondary: s, errorContext: u }) {
	let { t: d } = n("account"), [f, p] = o(!1), [m, h] = o(null), g = a(0), y = () => {
		g.current++, p(!1), h(null), t() && t()?.auth?.cancelOAuth?.();
	};
	t();
	let b = () => {
		f && y(), s.onSelect?.();
	}, x = "h-11 text-base", S = s.href ? /* @__PURE__ */ c(r, {
		variant: "ghost",
		size: "regular",
		fullWidth: !0,
		className: x,
		asChild: !0,
		children: /* @__PURE__ */ c(e, {
			to: s.href,
			onClick: b,
			children: s.label
		})
	}) : /* @__PURE__ */ c(r, {
		variant: "ghost",
		size: "regular",
		fullWidth: !0,
		className: x,
		onClick: b,
		children: s.label
	});
	return /* @__PURE__ */ c(_, { children: /* @__PURE__ */ l(v, {
		error: m,
		children: [/* @__PURE__ */ c(r, {
			variant: "primary",
			size: "large",
			fullWidth: !0,
			disabled: !0,
			children: d("welcome.comingSoon")
		}), S]
	}) });
}
//#endregion
export { h as a, m as i, v as n, g as o, _ as r, y as t };
