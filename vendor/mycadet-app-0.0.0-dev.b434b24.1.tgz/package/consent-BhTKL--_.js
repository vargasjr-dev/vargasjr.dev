//#region src/i18n/locales/zh-TW/consent.json
var e = {
	whatsChanged: "更新內容",
	agreements: "協議",
	agreeTo: "我同意 <0>{policy}</0>"
}, t = {
	continue: "繼續",
	logOut: "登出"
}, n = {
	consentControls: e,
	actions: t
};
//#endregion
export { t as actions, e as consentControls, n as default };
