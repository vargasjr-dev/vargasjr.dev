import { n as e, t } from "./loader-circle-Ch7lYSrj.js";
import { t as n } from "./check-DPXe7vV_.js";
import { n as r } from "./select-B4GhYADp.js";
import { a as i, i as a, r as o, t as s } from "./src-DLa8cepg.js";
import { t as c } from "./circle-check-CBLio8rp.js";
import { t as l } from "./ellipsis-vertical-Bx7DMtpt.js";
import { t as u } from "./external-anchor--Bf99ulE.js";
import { v as d } from "./confirm-dialog-DH3yi6Nk.js";
import { a as f, i as p, n as m, o as h, s as g, t as _ } from "./create-selectors-CR7eHVH6.js";
import { a as ee } from "./request-Dbjf-LtL.js";
import { a as v, c as y, d as b, h as x, i as S, l as C, m as w, o as T, p as E, r as D, t as O } from "./schemas-D8_brjAQ.js";
import { n as k, r as A } from "./i18n-BRf-wfgm.js";
import { t as j } from "./button-BrPHE1Q9.js";
import { _ as M, a as N, c as P, f as F, p as I, t as L } from "./capture-error-DAZY091e.js";
import { i as te, n as ne, r as re, t as ie } from "./copy-to-clipboard-_taVOi2S.js";
import * as R from "react";
import { useCallback as z, useEffect as B, useMemo as V, useRef as H, useState as U } from "react";
import { createPortal as ae } from "react-dom";
import { Fragment as oe, jsx as W, jsxs as G } from "react/jsx-runtime";
var se = e("arrow-up", [["path", {
	d: "m5 12 7-7 7 7",
	key: "hav0vg"
}], ["path", {
	d: "M12 19V5",
	key: "x0mq9r"
}]]), ce = e("chevron-up", [["path", {
	d: "m18 15-6-6-6 6",
	key: "153udz"
}]]), le = e("circle-x", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "m15 9-6 6",
		key: "1uzhvr"
	}],
	["path", {
		d: "m9 9 6 6",
		key: "z0biqf"
	}]
]), K = e("clipboard-copy", [
	["rect", {
		width: "8",
		height: "4",
		x: "8",
		y: "2",
		rx: "1",
		ry: "1",
		key: "tgr4d6"
	}],
	["path", {
		d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2",
		key: "4jdomd"
	}],
	["path", {
		d: "M16 4h2a2 2 0 0 1 2 2v4",
		key: "3hqy98"
	}],
	["path", {
		d: "M21 14H11",
		key: "1bme5i"
	}],
	["path", {
		d: "m15 10-4 4 4 4",
		key: "5dvupr"
	}]
]), ue = e("hard-drive", [
	["path", {
		d: "M10 16h.01",
		key: "1bzywj"
	}],
	["path", {
		d: "M2.212 11.577a2 2 0 0 0-.212.896V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5.527a2 2 0 0 0-.212-.896L18.55 5.11A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
		key: "18tbho"
	}],
	["path", {
		d: "M21.946 12.013H2.054",
		key: "zqlbp7"
	}],
	["path", {
		d: "M6 16h.01",
		key: "1pmjb7"
	}]
]), q = e("message-square-text", [
	["path", {
		d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
		key: "18887p"
	}],
	["path", {
		d: "M7 11h10",
		key: "1twpyw"
	}],
	["path", {
		d: "M7 15h6",
		key: "d9of3u"
	}],
	["path", {
		d: "M7 7h8",
		key: "af5zfr"
	}]
]), de = e("play", [["path", {
	d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
	key: "10ikf1"
}]]), fe = e("shield", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}]]), pe = e("thumbs-down", [["path", {
	d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
	key: "m61m77"
}], ["path", {
	d: "M17 14V2",
	key: "8ymqnk"
}]]), me = e("thumbs-up", [["path", {
	d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
	key: "emmmcr"
}], ["path", {
	d: "M7 10v12",
	key: "1qc93n"
}]]), he = e("wrench", [["path", {
	d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
	key: "1ngwbx"
}]]);
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/mutation.js
function ge() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: !1,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/mutationObserver.js
var _e = class extends M {
	#e;
	#t = void 0;
	#n;
	#r;
	constructor(e, t) {
		super(), this.#e = e, this.setOptions(t), this.bindMethods(), this.#i();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this), this.reset = this.reset.bind(this);
	}
	setOptions(e) {
		let t = this.options;
		this.options = this.#e.defaultMutationOptions(e), F(this.options, t) || this.#e.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#n,
			observer: this
		}), t?.mutationKey && this.options.mutationKey && N(t.mutationKey) !== N(this.options.mutationKey) ? this.reset() : this.#n?.state.status === "pending" && this.#n.setOptions(this.options);
	}
	onUnsubscribe() {
		this.hasListeners() || this.#n?.removeObserver(this);
	}
	onMutationUpdate(e) {
		this.#i(), this.#a(e);
	}
	getCurrentResult() {
		return this.#t;
	}
	reset() {
		this.#n?.removeObserver(this), this.#n = void 0, this.#i(), this.#a();
	}
	mutate(e, t) {
		return this.#r = t, this.#n?.removeObserver(this), this.#n = this.#e.getMutationCache().build(this.#e, this.options), this.#n.addObserver(this), this.#n.execute(e);
	}
	#i() {
		let e = this.#n?.state ?? ge();
		this.#t = {
			...e,
			isPending: e.status === "pending",
			isSuccess: e.status === "success",
			isError: e.status === "error",
			isIdle: e.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#a(e) {
		h.batch(() => {
			if (this.#r && this.hasListeners()) {
				let t = this.#t.variables, n = this.#t.context, r = {
					client: this.#e,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (e?.type === "success") {
					try {
						this.#r.onSuccess?.(e.data, t, n, r);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#r.onSettled?.(e.data, null, t, n, r);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (e?.type === "error") {
					try {
						this.#r.onError?.(e.error, t, n, r);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#r.onSettled?.(void 0, e.error, t, n, r);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((e) => {
				e(this.#t);
			});
		});
	}
};
//#endregion
//#region ../../node_modules/.bun/@tanstack+react-query@5.90.21+d86b59289c1a13ae/node_modules/@tanstack/react-query/build/modern/useMutation.js
function ve(e, t) {
	let n = f(t), [r] = R.useState(() => new _e(n, e));
	R.useEffect(() => {
		r.setOptions(e);
	}, [r, e]);
	let i = R.useSyncExternalStore(R.useCallback((e) => r.subscribe(h.batchCalls(e)), [r]), () => r.getCurrentResult(), () => r.getCurrentResult()), a = R.useCallback((e, t) => {
		r.mutate(e, t).catch(P);
	}, [r]);
	if (i.error && I(r.options.throwOnError, [i.error])) throw i.error;
	return {
		...i,
		mutate: a,
		mutateAsync: i.mutate
	};
}
//#endregion
//#region src/domains/account/doctor/doctor-avatar.tsx
var ye = "0 0 724 691", J = "#DB4B77", Y = "#F2F2F2", X = "#1A1A1A", be = "M707.996 341.488C683.572 371.035 643.096 379.081 606.995 383.544C585.458 386.205 563.817 387.947 542.142 388.871C531.271 389.34 520.394 389.578 509.517 389.597C509.127 389.597 508.73 389.604 508.34 389.604C539.98 409.658 571.958 431.456 594.664 461.683C615.354 489.223 627.369 524.084 618.659 558.345C614.714 573.858 606.844 588.374 594.889 599.167C581.012 611.696 562.615 618.079 543.959 615.227C524.928 612.31 508.592 601.272 493.122 590.513C477.163 579.416 461.759 567.586 446.956 554.985C432.226 542.449 418.071 529.273 404.782 515.212C401.597 511.845 398.478 508.439 395.411 504.987C395.332 506.221 395.246 507.449 395.16 508.67C393.64 530.804 390.508 552.813 385.876 574.505C381.812 593.503 376.631 612.297 370.221 630.642C364.769 646.24 357.917 662.018 345.916 673.761C335.032 684.415 319.932 690.693 304.614 689.954C288.622 689.175 276.49 679.894 268.619 666.374C260.055 651.654 254.761 634.51 250.294 618.172C245.424 600.355 242.173 582.096 240.561 563.692C238.882 544.456 238.677 524.613 240.752 505.093C240.164 505.898 239.57 506.703 238.955 507.509C233.457 514.704 227.14 521.378 220.716 527.755C208.154 540.218 194.349 551.433 179.54 561.131C166.422 569.719 152.519 577.132 138.073 583.238C122.86 589.674 106.333 595.787 89.7861 597.351C74.8317 598.764 59.4075 595.437 49.4026 583.548C40.8116 573.336 37.4353 559.13 38.4529 546.02C39.6691 530.33 47.6584 515.879 57.1277 503.647C68.289 489.237 81.7962 476.568 94.8805 463.941C112.63 446.817 130.797 429.759 149.769 413.758C133.652 415.052 117.487 415.257 101.562 414.385C83.9244 413.414 65.996 411.269 49.079 406.015C34.3755 401.454 19.6257 393.756 10.2747 381.167C2.05413 370.11 -2.30039 355.053 1.24128 341.481C5.30564 325.922 19.0643 317.597 32.7163 311.115C64.555 296.005 99.8366 290.097 134.834 288.763C152.538 288.09 170.274 288.71 187.945 289.879C189.611 289.984 191.276 290.097 192.948 290.209C176.744 285.403 161.776 275.713 148.831 265.151C134.458 253.42 121.869 239.663 110.318 225.193C99.3547 211.456 88.8807 197.112 79.3448 182.351C69.558 167.188 61.3172 149.748 63.1485 131.237C66.4331 98.0067 102.368 85.2731 131.491 90.3755C149.836 93.5902 166.349 102.892 181.588 113.209C196.325 123.19 210.724 133.792 224.615 144.922C235.558 153.695 246.224 162.923 256.142 172.858C254.979 152.288 253.539 131.614 254.438 111.017C255.224 92.9499 258.066 74.7764 265.348 58.1084C272.082 42.6945 282.748 29.3267 296.143 19.1613C309.34 9.15344 326.309 1.12634 343.035 0.0771651C360.441 -1.01881 374.92 9.70203 384.813 23.1751C403.157 48.167 404.803 82.1373 400.666 111.764C397.904 131.527 392.564 150.843 388.461 170.35C386.386 180.225 384.575 190.166 383.524 200.207C383.445 200.973 383.379 201.738 383.313 202.511C384.529 200.299 385.863 198.121 387.284 195.949C392.887 187.394 399.146 179.149 405.674 171.274C418.838 155.398 433.225 140.565 448.688 126.907C474.956 103.711 506.371 78.8764 542.863 76.8298C551.982 76.3212 561.479 77.3051 569.778 81.319C576.968 84.7978 582.638 90.5806 586.583 97.4655C594.909 112.028 596.74 129.666 594.387 146.05C589.213 182.06 565.7 211.211 538.798 234.164C524.716 246.184 509.576 256.879 494.542 267.665C492.553 269.091 490.564 270.517 488.575 271.942C500.847 267.367 513.29 263.228 525.807 259.459C547.515 252.917 569.593 247.537 592.101 244.567C611.965 241.946 632.332 241.095 652.289 243.26C667.541 244.916 683.03 248.686 696.346 256.528C710.032 264.595 720.156 277.487 722.555 293.423C725.144 310.667 718.966 328.22 707.996 341.488Z", xe = [
	{
		d: "M320.715 343.724C320.838 359.862 316.431 375.655 310.169 390.408C310.138 390.482 310.107 390.555 310.07 390.629C307.833 395.777 305.299 400.893 302.372 405.757C296.079 416.243 287.955 425.559 277.045 431.507C262.264 439.554 242.097 440.564 229.523 427.806C219.821 417.961 217.343 402.876 219.161 389.644C221.017 376.135 227.365 363.661 231.267 350.694C233.246 344.106 234.793 337.265 234.398 330.338C233.998 323.381 230.971 317.932 226.94 312.433C222.909 306.929 220.468 301.067 221.042 294.11C221.578 287.632 224.148 281.58 228.352 276.63C238.627 264.543 255.953 264.131 269.612 270.165C277.057 273.453 283.597 278.464 289.644 283.858C293.749 287.515 297.737 291.333 301.41 295.427C302.884 297.065 304.301 298.746 305.663 300.476C315.513 313.012 320.592 327.789 320.715 343.724Z",
		fill: Y
	},
	{
		d: "M305.663 300.476C304.301 298.746 302.884 297.065 301.41 295.427C297.737 291.333 293.749 287.515 289.644 283.858C283.597 278.464 277.057 273.453 269.612 270.165C255.953 264.131 238.627 264.543 228.352 276.63C224.148 281.58 221.578 287.632 221.042 294.11C220.468 301.067 222.909 306.929 226.94 312.433C230.971 317.932 233.998 323.381 234.398 330.338C234.793 337.265 233.246 344.106 231.267 350.694C227.365 363.661 221.017 376.135 219.161 389.644C217.343 402.876 219.821 417.961 229.523 427.806C242.097 440.564 262.264 439.554 277.045 431.507C287.955 425.559 296.079 416.243 302.372 405.757C305.299 400.893 307.833 395.777 310.07 390.629C310.107 390.555 310.138 390.482 310.169 390.408C316.431 375.655 320.838 359.862 320.715 343.724C320.592 327.789 315.513 313.012 305.663 300.476ZM304.524 387.107C298.767 400.413 291.229 413.86 279.185 422.468C278.809 422.733 278.432 422.997 278.05 423.256C277.687 423.502 277.317 423.743 276.941 423.977C265.698 431.107 250.831 434.142 238.867 426.926C227.846 420.282 224.518 406.305 225.233 394.268C225.96 382.034 231.477 370.458 235.428 359.025C239.323 347.739 242.855 335.277 239.921 323.338C238.522 317.673 235.458 313.117 232.087 308.456C228.315 303.235 226.558 297.749 228.037 291.302C231.212 277.479 244.84 270.743 258.221 273.348C267.843 275.226 276.219 280.681 283.665 287.134C283.721 287.183 283.782 287.232 283.837 287.282C287.314 290.311 290.587 293.549 293.681 296.733C305.238 308.622 312.973 322.624 314.027 339.383C315.057 355.743 310.878 372.139 304.524 387.107Z",
		fill: Y
	},
	{
		d: "M320.716 343.724C320.839 359.862 316.432 375.655 310.17 390.408C310.139 390.481 310.108 390.555 310.071 390.629C307.833 395.777 305.3 400.893 302.372 405.757C299.642 409.766 296.597 413.571 293.145 417.043C293.022 417.13 292.893 417.21 292.769 417.29C288.011 420.43 282.574 422.85 276.941 423.976C270.58 425.251 263.972 424.882 257.803 422.031C244.686 415.978 243.435 402.371 248.662 390.796C254.745 377.97 263.658 365.853 265.575 351.691C266.647 343.699 265.051 336.243 262.672 328.602C260.465 321.491 257.956 314.225 258.197 306.726C258.548 295.587 266.604 288.944 278.094 287.558C279.912 287.331 281.779 287.189 283.666 287.134C286.643 287.029 289.669 287.14 292.664 287.478C293.028 287.78 293.379 288.082 293.737 288.39C296.363 290.662 298.945 292.995 301.411 295.427C302.884 297.065 304.302 298.746 305.664 300.476C315.513 313.012 320.592 327.789 320.716 343.724Z",
		fill: X
	},
	{
		d: "M449.963 343.724C450.086 359.862 445.679 375.655 439.417 390.408C439.386 390.482 439.355 390.555 439.318 390.629C437.081 395.777 434.548 400.893 431.62 405.757C425.327 416.243 417.203 425.559 406.293 431.507C391.512 439.554 371.345 440.564 358.771 427.806C349.069 417.961 346.591 402.876 348.409 389.644C350.265 376.135 356.613 363.661 360.515 350.694C362.493 344.106 364.041 337.265 363.646 330.338C363.245 323.381 360.219 317.932 356.188 312.433C352.157 306.929 349.716 301.067 350.289 294.11C350.826 287.632 353.396 281.58 357.599 276.63C367.874 264.543 385.201 264.131 398.859 270.165C406.305 273.453 412.845 278.464 418.891 283.858C422.996 287.515 426.985 291.333 430.658 295.427C432.131 297.065 433.549 298.746 434.911 300.476C444.761 313.012 449.84 327.789 449.963 343.724Z",
		fill: Y
	},
	{
		d: "M434.911 300.476C433.549 298.746 432.131 297.065 430.658 295.427C426.985 291.333 422.996 287.515 418.891 283.858C412.845 278.464 406.305 273.453 398.859 270.165C385.201 264.131 367.874 264.543 357.599 276.63C353.396 281.58 350.826 287.632 350.289 294.11C349.716 301.067 352.157 306.929 356.188 312.433C360.219 317.932 363.245 323.381 363.646 330.338C364.041 337.265 362.493 344.106 360.515 350.694C356.613 363.661 350.265 376.135 348.409 389.644C346.591 402.876 349.069 417.961 358.771 427.806C371.345 440.564 391.512 439.554 406.293 431.507C417.203 425.559 425.327 416.243 431.62 405.757C434.548 400.893 437.081 395.777 439.318 390.629C439.355 390.555 439.386 390.482 439.417 390.408C445.679 375.655 450.086 359.862 449.963 343.724C449.84 327.789 444.761 313.012 434.911 300.476ZM433.771 387.107C428.014 400.413 420.476 413.86 408.432 422.468C408.056 422.733 407.68 422.997 407.298 423.256C406.935 423.502 406.565 423.743 406.189 423.977C394.946 431.107 380.079 434.142 368.115 426.926C357.094 420.282 353.766 406.305 354.481 394.268C355.208 382.034 360.724 370.458 364.675 359.025C368.571 347.739 372.103 335.277 369.169 323.338C367.77 317.673 364.706 313.117 361.335 308.456C357.562 303.235 355.806 297.749 357.285 291.302C360.46 277.479 374.087 270.743 387.469 273.348C397.09 275.226 405.467 280.681 412.913 287.134C412.968 287.183 413.03 287.232 413.085 287.282C416.562 290.311 419.835 293.549 422.929 296.733C434.486 308.622 442.221 322.624 443.275 339.383C444.305 355.743 440.125 372.139 433.771 387.107Z",
		fill: Y
	},
	{
		d: "M449.964 343.724C450.087 359.862 445.68 375.655 439.418 390.408C439.387 390.481 439.356 390.555 439.319 390.629C437.081 395.777 434.548 400.893 431.621 405.757C428.89 409.766 425.845 413.571 422.393 417.043C422.27 417.13 422.141 417.21 422.017 417.29C417.259 420.43 411.823 422.85 406.189 423.976C399.828 425.251 393.221 424.882 387.051 422.031C373.934 415.978 372.683 402.371 377.91 390.796C383.993 377.97 392.906 365.853 394.823 351.691C395.896 343.699 394.299 336.243 391.92 328.602C389.713 321.491 387.205 314.225 387.445 306.726C387.797 295.587 395.852 288.944 407.342 287.558C409.16 287.331 411.028 287.189 412.914 287.134C415.891 287.029 418.917 287.14 421.913 287.478C422.276 287.78 422.628 288.082 422.985 288.39C425.611 290.662 428.193 292.995 430.659 295.427C432.132 297.065 433.55 298.746 434.912 300.476C444.762 313.012 449.841 327.789 449.964 343.724Z",
		fill: X
	}
];
function Se({ className: e }) {
	return /* @__PURE__ */ G("svg", {
		viewBox: ye,
		xmlns: "http://www.w3.org/2000/svg",
		className: e,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ W("path", {
				d: be,
				fill: J
			}),
			xe.map((e, t) => /* @__PURE__ */ W("path", {
				d: e.d,
				fill: e.fill
			}, t)),
			/* @__PURE__ */ G("g", {
				transform: "translate(370 510) scale(1.37) translate(-370 -510)",
				children: [
					/* @__PURE__ */ W("path", {
						d: "M 230 440 Q 210 560 320 585 Q 430 610 500 540",
						stroke: "#1F1F23",
						strokeWidth: "22",
						strokeLinecap: "round",
						fill: "none"
					}),
					/* @__PURE__ */ W("circle", {
						cx: "230",
						cy: "435",
						r: "16",
						fill: "#1F1F23"
					}),
					/* @__PURE__ */ W("circle", {
						cx: "510",
						cy: "525",
						r: "58",
						fill: "#E4E4E7",
						stroke: "#1F1F23",
						strokeWidth: "10"
					}),
					/* @__PURE__ */ W("circle", {
						cx: "510",
						cy: "525",
						r: "34",
						fill: "#52525B"
					}),
					/* @__PURE__ */ W("circle", {
						cx: "500",
						cy: "515",
						r: "10",
						fill: "#A1A1AA",
						opacity: "0.55"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/detail-panel-stop-button.tsx
function Ce({ onStop: e, ariaLabel: t, disabled: n }) {
	let { t: r } = A();
	return /* @__PURE__ */ W(j, {
		variant: "dangerOutline",
		iconOnly: /* @__PURE__ */ W(g, {}),
		"aria-label": t,
		tooltip: r("detailPanelStopButton.tooltip"),
		onClick: e,
		disabled: n,
		className: "shrink-0 hover:border-[var(--system-negative-strong)] hover:bg-[var(--system-negative-weak)] hover:[--vbtn-fg:var(--system-negative-strong)]"
	});
}
//#endregion
//#region src/components/doctor-feedback-modal.tsx
var we = [
	{
		value: "bug_report",
		labelKey: "shareFeedbackModal.reasonBugReport",
		placeholderKey: "shareFeedbackModal.messagePlaceholderBug"
	},
	{
		value: "feature_request",
		labelKey: "shareFeedbackModal.reasonFeatureRequest",
		placeholderKey: "shareFeedbackModal.messagePlaceholderFeature"
	},
	{
		value: "other",
		labelKey: "shareFeedbackModal.reasonOther",
		placeholderKey: "shareFeedbackModal.messagePlaceholderOther"
	}
];
function Te({ open: e, onClose: t, initialReason: n, initialMessage: r, onSubmitted: i, doctorSessionId: a, doctorSessionLog: o }) {
	let { t: s } = A("doctor"), c = H(null), [l, u] = U(n ?? "bug_report"), [d, f] = U(""), [p, m] = U(null), [h, g] = U(!1), _ = !!o?.trim();
	if (B(() => {
		if (!e) return;
		u(n ?? "bug_report"), f(r ?? ""), m(null), g(!1);
		let t = setTimeout(() => c.current?.focus(), 50);
		return () => clearTimeout(t);
	}, [
		e,
		n,
		r
	]), !e) return null;
	let v = d.trim().length > 0;
	return ae(/* @__PURE__ */ W("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4",
		onClick: (e) => {
			e.target === e.currentTarget && t();
		},
		role: "presentation",
		children: /* @__PURE__ */ G("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": s("shareFeedbackModal.title"),
			className: "flex w-full max-w-lg flex-col gap-4 rounded-xl border border-[var(--border-base)] bg-[var(--surface-raised)] p-6 shadow-xl",
			children: [
				/* @__PURE__ */ W("h2", {
					id: "doctor-feedback-title",
					className: "text-title-small text-[var(--content-default)]",
					children: s("shareFeedbackModal.title")
				}),
				/* @__PURE__ */ W("div", {
					className: "flex flex-col gap-2",
					children: we.map((e) => /* @__PURE__ */ G("label", {
						className: "flex cursor-pointer items-center gap-2 text-body-medium text-[var(--content-default)]",
						children: [/* @__PURE__ */ W("input", {
							type: "radio",
							name: "doctor-feedback-reason",
							value: e.value,
							checked: l === e.value,
							onChange: () => u(e.value)
						}), s(e.labelKey)]
					}, e.value))
				}),
				/* @__PURE__ */ W("textarea", {
					ref: c,
					value: d,
					onChange: (e) => f(e.target.value),
					placeholder: s(we.find((e) => e.value === l)?.placeholderKey ?? "shareFeedbackModal.messagePlaceholderOther"),
					rows: 5,
					className: "w-full resize-y rounded-lg border border-[var(--border-base)] bg-[var(--surface-base)] p-3 text-body-medium text-[var(--content-default)]"
				}),
				_ && /* @__PURE__ */ W("p", {
					className: "text-body-small-lighter text-[var(--content-tertiary)]",
					children: s("shareFeedbackModal.doctorSessionAttached")
				}),
				p && /* @__PURE__ */ W("p", {
					className: "text-body-small text-[var(--system-negative-strong)]",
					children: p
				}),
				/* @__PURE__ */ G("div", {
					className: "flex items-center justify-end gap-2",
					children: [/* @__PURE__ */ W(j, {
						variant: "ghost",
						onClick: t,
						children: s("shareFeedbackModal.cancel")
					}), /* @__PURE__ */ W(j, {
						variant: "primary",
						onClick: async () => {
							if (!(!v || h)) {
								m(null), g(!0);
								try {
									let e = new FormData();
									if (e.append("message", d.trim()), e.append("classification", l), e.append("client", "web"), a && e.append("doctor_session_id", a), _) {
										let t = new Blob([o ?? ""], { type: "text/plain" });
										e.append("logs_file", t, "doctor-session.txt");
									}
									let n = await ee("/v1/feedback/", e);
									if (!n.ok) {
										m(n.error.detail);
										return;
									}
									i?.(), t();
								} finally {
									g(!1);
								}
							}
						},
						disabled: !v || h,
						children: s("shareFeedbackModal.submit")
					})]
				})
			]
		})
	}), document.body);
}
//#endregion
//#region src/lib/host-navigation.ts
function Ee(e) {
	window.history.pushState(null, "", e), window.dispatchEvent(new PopStateEvent("popstate"));
}
//#endregion
//#region src/hooks/use-copy-to-clipboard.ts
var De = 1500;
function Oe({ errorMessage: e, successMessage: t }) {
	let [n, r] = U(!1), i = H(null), a = H(!0);
	return B(() => (a.current = !0, () => {
		a.current = !1, i.current && clearTimeout(i.current);
	}), []), {
		copy: z((n, o) => {
			ie(n, {
				errorMessage: e,
				successMessage: t,
				onCopied: () => {
					a.current && (r(!0), i.current && clearTimeout(i.current), i.current = setTimeout(() => r(!1), De), o?.());
				}
			});
		}, [e, t]),
		copied: n,
		reset: z(() => {
			i.current &&= (clearTimeout(i.current), null), r(!1);
		}, [])
	};
}
//#endregion
//#region src/domains/account/doctor/doctor-chat-blocks.tsx
function ke({ text: e }) {
	let { t } = A("doctor"), { copy: r, copied: i } = Oe({ errorMessage: t("doctorChatBlocks.copyError") });
	return /* @__PURE__ */ W(j, {
		variant: "ghost",
		size: "compact",
		iconOnly: /* @__PURE__ */ G("div", {
			className: "relative h-3.5 w-3.5",
			children: [/* @__PURE__ */ W(n, { className: `absolute inset-0 h-3.5 w-3.5 text-[var(--system-positive-strong)] transition-opacity duration-150 ${i ? "opacity-100" : "opacity-0"}` }), /* @__PURE__ */ W(a, { className: `absolute inset-0 h-3.5 w-3.5 transition-opacity duration-150 ${i ? "opacity-0" : "opacity-100"}` })]
		}),
		expandOnMobile: !1,
		onClick: () => r(e),
		tooltip: t(i ? "doctorChatBlocks.copyTitleCopied" : "doctorChatBlocks.copyTitle"),
		"aria-label": t(i ? "doctorChatBlocks.copyAriaCopied" : "doctorChatBlocks.copyAria"),
		"data-reveal": "",
		className: "bg-[var(--surface-overlay)]"
	});
}
function Ae({ entry: e }) {
	let { t: n } = A("doctor"), [i, a] = U(!1), { toolName: o, input: s, result: l, isError: u, status: d } = e.meta, f = d === "running", p = n(f ? "doctorChatBlocks.runningStep" : u ? "doctorChatBlocks.failedStep" : "doctorChatBlocks.completedStep"), m = !f && (l !== void 0 || Object.keys(s).length > 0);
	return /* @__PURE__ */ G("div", {
		className: "my-1 w-full",
		children: [/* @__PURE__ */ G("button", {
			type: "button",
			"aria-expanded": m ? i : void 0,
			onClick: () => {
				m && a(!i);
			},
			className: `flex w-full items-center gap-2 rounded-lg px-3 py-2 transition-colors ${u ? "bg-[var(--system-negative-weak)]" : "bg-[var(--surface-base)]"} ${m ? "cursor-pointer hover:bg-[var(--surface-hover)]" : "cursor-default"} ${i ? "rounded-b-none" : ""}`,
			children: [
				f ? /* @__PURE__ */ W(t, { className: "h-4 w-4 shrink-0 animate-spin text-[var(--content-disabled)]" }) : u ? /* @__PURE__ */ W(le, { className: "h-4 w-4 shrink-0 text-[var(--system-negative-strong)]" }) : /* @__PURE__ */ W(c, { className: "h-4 w-4 shrink-0 text-[var(--system-positive-strong)]" }),
				/* @__PURE__ */ W("span", {
					className: `text-body-medium-default ${u ? "text-[var(--system-negative-strong)]" : "text-[var(--content-default)]"}`,
					children: p
				}),
				/* @__PURE__ */ W("span", {
					className: "ml-auto flex items-center gap-1.5 text-[var(--content-tertiary)]",
					children: m && W(i ? ce : r, { className: "h-4 w-4" })
				})
			]
		}), i && m && /* @__PURE__ */ G("div", {
			className: `rounded-b-lg border-t px-3 pb-3 ${u ? "border-[var(--system-negative-weak)] bg-[var(--system-negative-weak)]" : "border-[var(--border-base)] bg-[var(--surface-base)] dark:bg-[var(--surface-lift)]"}`,
			children: [
				/* @__PURE__ */ G("div", {
					className: "flex items-center gap-2 py-2",
					children: [/* @__PURE__ */ W(he, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ W("span", {
						className: "text-body-medium-lighter text-[var(--content-default)]",
						children: o
					})]
				}),
				/* @__PURE__ */ W("div", { className: "border-t border-[var(--border-base)]" }),
				/* @__PURE__ */ G("div", {
					className: "mt-2.5",
					children: [/* @__PURE__ */ W("div", {
						className: "mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--content-disabled)]",
						children: n("doctorChatBlocks.technicalDetails")
					}), Object.entries(s).map(([e, t]) => /* @__PURE__ */ G("div", {
						className: "mt-0.5",
						children: [
							/* @__PURE__ */ G("span", {
								className: "text-body-medium-default text-[var(--content-default)]",
								children: [e, ":"]
							}),
							" ",
							/* @__PURE__ */ W("span", {
								className: "text-body-medium-lighter text-[var(--content-tertiary)]",
								children: typeof t == "string" ? t.length > 200 ? t.slice(0, 200) + "..." : t : JSON.stringify(t)
							})
						]
					}, e))]
				}),
				l !== void 0 && /* @__PURE__ */ G("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ W("div", {
						className: "mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--content-disabled)]",
						children: n("doctorChatBlocks.output")
					}), /* @__PURE__ */ W("div", {
						className: `rounded-md border p-3 ${u ? "border-[var(--system-negative-weak)] bg-[var(--system-negative-weak)]/50" : "border-[var(--border-element)] bg-[var(--surface-base)]"}`,
						children: /* @__PURE__ */ W("pre", {
							className: `max-h-60 overflow-y-auto whitespace-pre-wrap break-words text-body-small-default ${u ? "text-[var(--system-negative-strong)]" : "text-[var(--content-default)]"}`,
							children: l.length > 2e3 ? l.slice(0, 2e3) + "..." : l
						})
					})]
				})
			]
		})]
	});
}
function je({ entry: e, onRespond: t, disabled: n }) {
	let { t: r } = A("doctor"), { toolName: a, description: o, input: s } = e.meta, [c, l] = U(!1), u = !!a || !!o || !!s, d = a === "exec_command";
	return /* @__PURE__ */ G("div", {
		className: "rounded-lg border border-[var(--border-base)] bg-[var(--surface-lift)] p-4",
		children: [/* @__PURE__ */ G("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
			children: [/* @__PURE__ */ G("div", {
				className: "flex min-w-0 flex-1 items-start gap-2",
				children: [/* @__PURE__ */ W(fe, { className: "mt-0.5 h-4 w-4 shrink-0 text-[var(--content-disabled)]" }), /* @__PURE__ */ W("span", {
					className: "text-body-medium-default text-[var(--content-default)]",
					children: r("doctorChatBlocks.confirmationRequired")
				})]
			}), /* @__PURE__ */ G("div", {
				className: "flex shrink-0 gap-2",
				children: [
					/* @__PURE__ */ W("button", {
						type: "button",
						disabled: n,
						onClick: () => t("approve"),
						className: "flex items-center gap-1.5 rounded-md bg-[var(--system-positive-strong)] px-3 py-1.5 text-body-small-default text-white transition-colors hover:bg-[var(--system-positive-strong)] disabled:cursor-not-allowed disabled:opacity-50",
						children: r("doctorChatBlocks.allowOnce")
					}),
					d && /* @__PURE__ */ W("button", {
						type: "button",
						disabled: n,
						onClick: () => t("approve all exec"),
						className: "flex items-center gap-1.5 rounded-md border border-[var(--system-positive-strong)] bg-[var(--surface-lift)] px-3 py-1.5 text-body-small-default text-[var(--system-positive-strong)] transition-colors hover:bg-[var(--system-positive-weak)] disabled:cursor-not-allowed disabled:opacity-50",
						children: r("doctorChatBlocks.alwaysAllow")
					}),
					/* @__PURE__ */ W("button", {
						type: "button",
						disabled: n,
						onClick: () => t("deny"),
						className: "flex items-center gap-1.5 rounded-md border border-[var(--system-negative-strong)] bg-[var(--surface-lift)] px-3 py-1.5 text-body-small-default text-[var(--system-negative-strong)] transition-colors hover:bg-[var(--system-negative-weak)] disabled:cursor-not-allowed disabled:opacity-50",
						children: r("doctorChatBlocks.deny")
					})
				]
			})]
		}), u && /* @__PURE__ */ G("div", {
			className: "mt-3",
			children: [/* @__PURE__ */ G("button", {
				type: "button",
				onClick: () => l(!c),
				"aria-expanded": c,
				className: "flex items-center gap-1 text-body-small-default text-[var(--content-tertiary)] transition-colors hover:text-[var(--content-default)]",
				children: [/* @__PURE__ */ W(i, { className: `h-3 w-3 transition-transform ${c ? "rotate-90" : ""}` }), r(c ? "doctorChatBlocks.hideDetails" : "doctorChatBlocks.showDetails")]
			}), c && /* @__PURE__ */ G("div", {
				className: "mt-2 space-y-1.5",
				children: [
					a && /* @__PURE__ */ G("div", {
						className: "flex items-center gap-1.5 text-body-small-default text-[var(--content-tertiary)]",
						children: [/* @__PURE__ */ W("span", { children: r("doctorChatBlocks.toolLabel") }), /* @__PURE__ */ W("code", {
							className: "rounded bg-[var(--surface-base)] px-1.5 py-0.5 font-mono text-[var(--content-secondary)] dark:bg-[var(--surface-lift)] dark:text-[var(--content-default)]",
							children: a
						})]
					}),
					o && /* @__PURE__ */ W("p", {
						className: "text-body-small-default text-[var(--content-tertiary)]",
						children: o
					}),
					s && Object.keys(s).length > 0 && /* @__PURE__ */ W("pre", {
						className: "overflow-x-auto whitespace-pre-wrap rounded bg-[var(--surface-base)] p-2 text-label-medium-default text-[var(--content-secondary)] dark:bg-[var(--surface-lift)] dark:text-[var(--content-default)]",
						children: JSON.stringify(s, null, 2)
					})
				]
			})]
		})]
	});
}
function Me({ entry: e, onRespond: t, disabled: n }) {
	let { t: r } = A("doctor"), { toolName: i } = e.meta;
	return /* @__PURE__ */ W("div", {
		className: "rounded-lg border border-[var(--border-base)] bg-[var(--surface-lift)] p-4",
		children: /* @__PURE__ */ G("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
			children: [/* @__PURE__ */ G("div", {
				className: "flex min-w-0 flex-1 items-start gap-2",
				children: [/* @__PURE__ */ W(ue, { className: "mt-0.5 h-4 w-4 shrink-0 text-[var(--content-disabled)]" }), /* @__PURE__ */ G("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ W("span", {
						className: "text-body-medium-default text-[var(--content-default)]",
						children: r("doctorChatBlocks.backupPromptTitle")
					}), /* @__PURE__ */ W("span", {
						className: "text-body-small-default text-[var(--content-tertiary)]",
						children: /* @__PURE__ */ W(k, {
							ns: "doctor",
							i18nKey: "doctorChatBlocks.backupPromptBody",
							values: { toolName: i },
							components: { toolCode: /* @__PURE__ */ W("code", { className: "rounded bg-[var(--surface-base)] px-1 py-0.5 font-mono text-[var(--content-secondary)]" }) }
						})
					})]
				})]
			}), /* @__PURE__ */ G("div", {
				className: "flex shrink-0 gap-2",
				children: [/* @__PURE__ */ W(j, {
					variant: "primary",
					disabled: n,
					onClick: () => t("backup"),
					children: r("doctorChatBlocks.backUp")
				}), /* @__PURE__ */ W(j, {
					variant: "outlined",
					disabled: n,
					onClick: () => t("skip_backup"),
					children: r("doctorChatBlocks.skip")
				})]
			})]
		})
	});
}
function Ne({ onOpenFeedback: e }) {
	let { t } = A("doctor");
	return /* @__PURE__ */ W("div", {
		className: "rounded-lg border border-[var(--border-base)] bg-[var(--surface-lift)] p-4",
		children: /* @__PURE__ */ G("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
			children: [/* @__PURE__ */ G("div", {
				className: "flex min-w-0 flex-1 items-start gap-2",
				children: [/* @__PURE__ */ W(q, { className: "mt-0.5 h-4 w-4 shrink-0 text-[var(--content-disabled)]" }), /* @__PURE__ */ G("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ W("span", {
						className: "text-body-medium-default text-[var(--content-default)]",
						children: t("doctorChatBlocks.feedbackTitle")
					}), /* @__PURE__ */ W("span", {
						className: "text-body-small-default text-[var(--content-tertiary)]",
						children: t("doctorChatBlocks.feedbackBody")
					})]
				})]
			}), /* @__PURE__ */ W("div", {
				className: "flex shrink-0",
				children: /* @__PURE__ */ W(j, {
					variant: "outlined",
					onClick: e,
					leftIcon: /* @__PURE__ */ W(q, {}),
					children: t("doctorChatBlocks.shareFeedback")
				})
			})]
		})
	});
}
function Pe({ question: e, answer: t, onRespond: n, disabled: r }) {
	let { t: i } = A("doctor");
	return /* @__PURE__ */ W("div", {
		className: "rounded-lg border border-[var(--border-base)] bg-[var(--surface-lift)] p-4",
		children: /* @__PURE__ */ G("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ G("div", {
				className: "flex min-w-0 flex-1 items-start gap-2",
				children: [/* @__PURE__ */ W(c, { className: "mt-0.5 h-4 w-4 shrink-0 text-[var(--content-disabled)]" }), /* @__PURE__ */ W("span", {
					className: "text-body-medium-default text-[var(--content-default)]",
					children: e
				})]
			}), t ? /* @__PURE__ */ W("span", {
				className: "flex shrink-0 items-center gap-1.5 text-body-small-default text-[var(--content-tertiary)]",
				children: t === "resolved" ? /* @__PURE__ */ G(oe, { children: [/* @__PURE__ */ W(me, { className: "h-4 w-4 text-[var(--system-positive-strong)]" }), i("doctorChatBlocks.gladSolved")] }) : /* @__PURE__ */ G(oe, { children: [/* @__PURE__ */ W(pe, { className: "h-4 w-4" }), i("doctorChatBlocks.notSolved")] })
			}) : /* @__PURE__ */ G("div", {
				className: "flex shrink-0 gap-2",
				children: [/* @__PURE__ */ W(j, {
					variant: "outlined",
					onClick: () => n(!0),
					disabled: r,
					iconOnly: /* @__PURE__ */ W(me, {}),
					"aria-label": i("doctorChatBlocks.solvedAria"),
					title: i("doctorChatBlocks.solvedAria")
				}), /* @__PURE__ */ W(j, {
					variant: "outlined",
					onClick: () => n(!1),
					disabled: r,
					iconOnly: /* @__PURE__ */ W(pe, {}),
					"aria-label": i("doctorChatBlocks.notSolvedAria"),
					title: i("doctorChatBlocks.notSolvedAria")
				})]
			})]
		})
	});
}
function Fe({ entry: e }) {
	return /* @__PURE__ */ G("div", {
		"data-reveal-row": "",
		className: "flex items-start justify-end gap-1.5",
		children: [/* @__PURE__ */ W("div", {
			className: "flex shrink-0 items-center self-center",
			children: /* @__PURE__ */ W(ke, { text: e.content })
		}), /* @__PURE__ */ W("div", {
			className: "max-w-[80%] whitespace-pre-wrap rounded-lg bg-[var(--surface-lift)] px-4 py-3 text-chat text-[var(--content-default)]",
			children: e.content
		})]
	});
}
var Ie = ({ href: e, children: t }) => /* @__PURE__ */ W(u, {
	href: e,
	tone: "default",
	children: t
});
function Le({ entry: e }) {
	return /* @__PURE__ */ G("div", {
		"data-reveal-row": "",
		className: "flex items-start justify-start gap-1.5",
		children: [/* @__PURE__ */ W("div", {
			className: "w-full text-chat text-[var(--content-default)]",
			children: /* @__PURE__ */ W(s, {
				content: e.content,
				linkComponent: Ie
			})
		}), /* @__PURE__ */ W("div", {
			className: "flex shrink-0 items-center pt-0.5",
			children: /* @__PURE__ */ W(ke, { text: e.content })
		})]
	});
}
function Re({ entry: e }) {
	return /* @__PURE__ */ G("div", {
		className: "flex items-start gap-2 text-body-small-default text-[var(--system-negative-strong)]",
		children: [/* @__PURE__ */ W(d, { className: "mt-0.5 h-3.5 w-3.5 shrink-0" }), /* @__PURE__ */ W("span", { children: e.content })]
	});
}
function ze({ entry: e }) {
	return /* @__PURE__ */ W("div", {
		className: "text-center text-body-small-default text-[var(--content-disabled)]",
		children: e.content
	});
}
//#endregion
//#region src/domains/account/doctor/doctor-history.ts
var Be = "Did the Doctor solve your problem?";
function Ve(e) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : {};
}
function He(e) {
	for (let t = e.length - 1; t >= 0; --t) if (e[t]?.kind === "user") return t;
	return -1;
}
function Ue(e) {
	return e.slice(He(e) + 1).some((e) => e.kind === "feedback_prompt");
}
function We(e) {
	let t = He(e) + 1, n = [], r = [];
	return e.forEach((e, i) => {
		if (i >= t && e.kind === "user_outcome_prompt") {
			r.push(e);
			return;
		}
		n.push(e);
	}), {
		transcript: n,
		trailingPrompts: r
	};
}
var Ge = /^\d+-\d+$/;
function Ke(e) {
	let t = e.reason ?? e.classification;
	return t === "bug_report" || t === "feature_request" || t === "other" ? t : void 0;
}
function qe(e) {
	return typeof e == "string" && Ge.test(e);
}
function Je(e) {
	return e.map((e) => e.source_event_id).filter(qe);
}
function Ye(e) {
	for (let t = e.length - 1; t >= 0; --t) {
		let n = e[t]?.source_event_id;
		if (qe(n)) return n;
	}
	return null;
}
function Xe(e) {
	let t = [];
	for (let n of e) {
		let e = Date.parse(n.occurred_at), r = Ve(n.metadata);
		switch (n.kind) {
			case "user":
				t.push({
					id: n.id,
					kind: "user",
					content: n.content,
					timestamp: e
				});
				break;
			case "assistant":
				t.push({
					id: n.id,
					kind: "assistant",
					content: n.content,
					timestamp: e
				});
				break;
			case "tool_call": {
				let i = typeof r.toolName == "string" ? r.toolName : n.content;
				t.push({
					id: n.id,
					kind: "tool_call",
					content: i,
					timestamp: e,
					meta: {
						toolName: i,
						input: r.input ?? {},
						toolCallId: typeof r.id == "string" ? r.id : n.id,
						status: "running"
					}
				});
				break;
			}
			case "tool_result": {
				let e = r.toolCallId, i = r.isError === !0, a = t.findIndex((t) => t.kind === "tool_call" && t.meta.toolCallId === e);
				if (a === -1) break;
				let o = t[a];
				if (o.kind !== "tool_call") break;
				t[a] = {
					...o,
					meta: {
						...o.meta,
						result: n.content,
						isError: i,
						status: i ? "error" : "completed"
					}
				};
				break;
			}
			case "approval": {
				let i = typeof r.toolName == "string" ? r.toolName : n.content;
				t.push({
					id: n.id,
					kind: "approval",
					content: i,
					timestamp: e,
					meta: {
						toolName: i,
						input: r.input ?? {},
						toolCallId: typeof r.id == "string" ? r.id : n.id,
						description: typeof r.description == "string" ? r.description : ""
					}
				});
				break;
			}
			case "status":
				if (n.content === "completed") t.push({
					id: n.id,
					kind: "status",
					content: "Session completed",
					timestamp: e
				});
				else if (n.content === "error") t.push({
					id: n.id,
					kind: "status",
					content: "Session ended with error",
					timestamp: e
				});
				else if (n.content === "feedback_prompt") {
					let i = typeof r.summary == "string" ? r.summary.trim() : "", a = Ke(r);
					t.push({
						id: n.id,
						kind: "feedback_prompt",
						content: i || "Share feedback",
						...a ? { meta: { reason: a } } : {},
						timestamp: e
					});
				} else n.content === "user_outcome_prompt" && t.push({
					id: n.id,
					kind: "user_outcome_prompt",
					content: Be,
					timestamp: e
				});
				break;
			case "error":
				t.push({
					id: n.id,
					kind: "error",
					content: n.content,
					timestamp: e
				});
				break;
			default: break;
		}
	}
	return t;
}
function Ze(e) {
	switch (e) {
		case "active": return "active";
		case "completed": return "completed";
		case "error": return "error";
	}
}
function Qe(e, t) {
	return t !== "resolved" && t !== "not_resolved" ? e : e.map((e) => e.kind === "user_outcome_prompt" ? {
		...e,
		meta: {
			...e.meta,
			answer: t
		}
	} : e);
}
function $e(e) {
	for (let t = e.length - 1; t >= 0; --t) {
		let n = e[t];
		if (n && !(n.kind === "status" || n.kind === "feedback_prompt" || n.kind === "user_outcome_prompt")) return n.kind === "approval";
	}
	return !1;
}
function et(e) {
	for (let t = e.length - 1; t >= 0; --t) {
		let n = e[t];
		if (n && !(n.kind === "status" || n.kind === "feedback_prompt" || n.kind === "user_outcome_prompt")) return n.kind === "backup_prompt";
	}
	return !1;
}
function tt(e) {
	let t = [];
	for (let n of e) switch (n.kind) {
		case "user":
			t.push(`User: ${n.content}`);
			break;
		case "assistant":
			t.push(`Doctor: ${n.content}`);
			break;
		case "feedback_prompt":
			t.push(`Feedback Prompt: ${n.content}`);
			break;
		case "user_outcome_prompt":
			t.push(`User Outcome Prompt: ${n.content}${n.meta?.answer ? ` (answered: ${n.meta.answer === "resolved" ? "Yes" : "No"})` : ""}`);
			break;
		case "tool_call": {
			let { toolName: e, input: r, result: i, isError: a } = n.meta;
			t.push(`Tool Call: ${e}`), Object.keys(r).length > 0 && t.push(`  Input: ${JSON.stringify(r, null, 2)}`), i !== void 0 && t.push(`  ${a ? "Error" : "Output"}: ${i}`);
			break;
		}
		case "approval": {
			let { toolName: e, description: r, input: i } = n.meta;
			t.push(`Approval Required: ${e}${r ? ` — ${r}` : ""}`), Object.keys(i).length > 0 && t.push(`  Input: ${JSON.stringify(i, null, 2)}`);
			break;
		}
		case "backup_prompt":
			t.push(`Backup Prompt: ${n.meta.toolName}`);
			break;
		case "error":
			t.push(`Error: ${n.content}`);
			break;
		case "status":
			t.push(`--- ${n.content} ---`);
			break;
	}
	return t.join("\n\n");
}
function nt(e) {
	return e[0] ?? null;
}
var Z = _(m()((e, t) => ({
	entries: [],
	inputValue: "",
	thinking: !1,
	sessionId: null,
	sessionStatus: "idle",
	pendingApproval: !1,
	pendingBackup: !1,
	historyDismissed: !1,
	streamingEntryId: null,
	entryCounter: 0,
	lastAssistantId: null,
	latestReplayableSourceEventId: null,
	processedSourceEventIds: /* @__PURE__ */ new Set(),
	nextId: () => {
		let n = t().entryCounter + 1;
		return e({ entryCounter: n }), `entry-${n}`;
	},
	appendEntry: (n) => {
		let r = t().nextId();
		e((e) => ({ entries: [...e.entries, {
			...n,
			id: r,
			timestamp: Date.now()
		}] }));
	},
	updateEntries: (t) => {
		e((e) => ({ entries: t(e.entries) }));
	},
	teardown: () => {
		e({
			sessionId: null,
			sessionStatus: "completed",
			pendingApproval: !1,
			pendingBackup: !1,
			thinking: !1,
			streamingEntryId: null,
			latestReplayableSourceEventId: null,
			processedSourceEventIds: /* @__PURE__ */ new Set()
		});
	},
	reset: () => {
		e({
			entries: [],
			inputValue: "",
			thinking: !1,
			sessionId: null,
			sessionStatus: "idle",
			pendingApproval: !1,
			pendingBackup: !1,
			historyDismissed: !1,
			streamingEntryId: null,
			entryCounter: 0,
			latestReplayableSourceEventId: null,
			processedSourceEventIds: /* @__PURE__ */ new Set()
		});
	},
	resetForNewSession: () => {
		e({
			entries: [],
			inputValue: "",
			thinking: !1,
			sessionId: null,
			sessionStatus: "idle",
			pendingApproval: !1,
			pendingBackup: !1,
			historyDismissed: !0,
			streamingEntryId: null,
			entryCounter: 0,
			latestReplayableSourceEventId: null,
			processedSourceEventIds: /* @__PURE__ */ new Set()
		});
	},
	setInputValue: (t) => e({ inputValue: t }),
	setThinking: (t) => e({ thinking: t }),
	setPendingApproval: (t) => e({ pendingApproval: t }),
	setPendingBackup: (t) => e({ pendingBackup: t }),
	setSessionId: (t) => e({ sessionId: t }),
	setSessionStatus: (t) => e({ sessionStatus: t }),
	setHistoryDismissed: (t) => e({ historyDismissed: t }),
	setStreamingEntryId: (t) => e({ streamingEntryId: t }),
	setEntries: (t) => e({ entries: t }),
	resetReplayState: () => {
		e({
			latestReplayableSourceEventId: null,
			processedSourceEventIds: /* @__PURE__ */ new Set()
		});
	},
	seedReplayState: (t, n) => {
		e({
			latestReplayableSourceEventId: n,
			processedSourceEventIds: new Set(t)
		});
	},
	recordReplayableSourceEventId: (n) => {
		let r = t().processedSourceEventIds;
		return r.has(n) ? !1 : (e({
			latestReplayableSourceEventId: n,
			processedSourceEventIds: new Set(r).add(n)
		}), !0);
	}
})));
//#endregion
//#region src/domains/account/doctor/doctor-session-menu.tsx
function rt({ onShareFeedback: e, onCopySession: t, defaultOpen: n }) {
	let { t: r } = A("doctor"), i = r("doctorPanel.sessionMenu");
	return !e && !t ? null : /* @__PURE__ */ G(o.Root, {
		defaultOpen: n,
		children: [/* @__PURE__ */ W(o.Trigger, {
			asChild: !0,
			children: /* @__PURE__ */ W(j, {
				variant: "ghost",
				size: "regular",
				expandOnMobile: !1,
				iconOnly: /* @__PURE__ */ W(l, {}),
				"aria-label": i
			})
		}), /* @__PURE__ */ G(o.Content, {
			title: i,
			align: "end",
			children: [e ? /* @__PURE__ */ W(o.Item, {
				icon: q,
				label: r("doctorPanel.shareFeedback"),
				onSelect: e
			}) : null, t ? /* @__PURE__ */ W(o.Item, {
				icon: K,
				label: r("doctorPanel.copySession"),
				onSelect: t
			}) : null]
		})]
	});
}
//#endregion
//#region src/domains/account/doctor/doctor-api.ts
var it = C({
	id: E(),
	kind: O([
		"user",
		"assistant",
		"tool_call",
		"tool_result",
		"approval",
		"status",
		"error"
	]),
	content: E(),
	metadata: x(),
	sequence: y(),
	source_event_id: E().nullable(),
	occurred_at: E()
}), at = C({ results: D(C({
	id: E(),
	status: E(),
	last_message_at: E().nullable(),
	created: E()
})) }), ot = C({
	status: O([
		"active",
		"completed",
		"error"
	]),
	messages: D(it),
	user_outcome: E().nullable()
}), st = C({ session_id: E() });
async function Q(e, t) {
	let { response: n, data: r, detail: i, networkError: a } = await ne(e, t);
	if (a || !n) throw a ?? /* @__PURE__ */ Error("The doctor dial failed without a response.");
	return {
		data: n.ok ? r : null,
		error: i === null ? null : { detail: i },
		response: n
	};
}
async function ct(e) {
	let t = await Q(`/v1/assistant/doctor/history/${e.query?.limit ? `?limit=${encodeURIComponent(e.query.limit)}` : ""}`), n = at.safeParse(t.data);
	return {
		...t,
		data: n.success ? n.data : null
	};
}
async function lt(e) {
	let t = await Q(`/v1/assistant/doctor/history/${encodeURIComponent(e.path.doctor_session_id)}/`), n = ot.safeParse(t.data);
	return {
		...t,
		data: n.success ? n.data : null
	};
}
async function ut(e) {
	let t = await Q("/v1/assistant/doctor/sessions/", { method: "POST" }), n = st.safeParse(t.data);
	return {
		...t,
		data: n.success ? n.data : null
	};
}
async function dt(e) {
	return {
		...await Q(`/v1/assistant/doctor/sessions/${encodeURIComponent(e.path.session_id)}/`, { method: "DELETE" }),
		data: null
	};
}
async function ft(e) {
	return Q(`/v1/assistant/doctor/sessions/${encodeURIComponent(e.path.session_id)}/messages/`, {
		method: "POST",
		body: JSON.stringify(e.body)
	});
}
async function pt(e) {
	return Q(`/v1/assistant/doctor/sessions/${encodeURIComponent(e.path.session_id)}/user-outcome/`, {
		method: "POST",
		body: JSON.stringify(e.body)
	});
}
//#endregion
//#region src/domains/account/doctor/doctor-session-actions.ts
var mt = "Hi! I'm the Doctor. State the nature of the issue you're experiencing with your assistant and I'll help diagnose and fix it.", ht = new Set([
	"approve",
	"approve all exec",
	"approve all future exec commands",
	"approve_all_exec",
	"deny"
]);
function gt(e) {
	dt({ path: { session_id: e } }).catch((e) => L(e, { context: "doctor_cleanup_destroy" }));
}
//#endregion
//#region src/domains/account/doctor/doctor-event-schema.ts
var $ = { source_event_id: E().nullable().optional() }, _t = v("type", [
	C({
		...$,
		type: T("message"),
		content: E()
	}),
	C({
		...$,
		type: T("message_delta"),
		content: E()
	}),
	C({
		...$,
		type: T("tool_call"),
		toolName: E(),
		input: b(E(), x()),
		id: E()
	}),
	C({
		...$,
		type: T("tool_result"),
		toolCallId: E(),
		content: E(),
		isError: S()
	}),
	C({
		...$,
		type: T("approval_required"),
		toolName: E(),
		input: b(E(), x()),
		id: E(),
		description: E()
	}),
	C({
		...$,
		type: T("backup_prompt"),
		toolName: E()
	}),
	C({
		...$,
		type: T("feedback_prompt"),
		summary: E().optional(),
		reason: O([
			"bug_report",
			"feature_request",
			"other"
		]).optional(),
		classification: O([
			"bug_report",
			"feature_request",
			"other"
		]).optional()
	}),
	C({
		...$,
		type: T("user_outcome_prompt")
	}),
	C({
		...$,
		type: T("status"),
		status: w([
			T("active"),
			T("completed"),
			T("error")
		])
	}),
	C({
		...$,
		type: T("error"),
		message: E()
	})
]);
function vt(e) {
	try {
		let t = typeof e == "string" ? JSON.parse(e) : e, n = _t.safeParse(t);
		return n.success ? n.data : null;
	} catch {
		return null;
	}
}
//#endregion
//#region src/domains/account/doctor/doctor-event-handlers.ts
function yt(e, t) {
	e.setThinking(!1);
	let n = e.getStreamingEntryId();
	if (n) e.updateEntries((e) => e.map((e) => e.id === n ? {
		...e,
		content: e.content + t.content
	} : e));
	else {
		let n = e.nextId();
		e.setStreamingEntryId(n), e.updateEntries((e) => [...e, {
			id: n,
			kind: "assistant",
			content: t.content,
			timestamp: Date.now()
		}]);
	}
}
function bt(e) {
	e.setThinking(!1), e.setStreamingEntryId(null);
}
function xt(e, t) {
	e.setThinking(!1), e.setStreamingEntryId(null), e.appendEntry({
		kind: "tool_call",
		content: t.toolName,
		meta: {
			toolName: t.toolName,
			input: t.input,
			toolCallId: t.id,
			status: "running"
		}
	});
}
function St(e, t) {
	e.updateEntries((e) => {
		let n = e.findIndex((e) => e.kind === "tool_call" && e.meta.toolCallId === t.toolCallId);
		if (n === -1) return e;
		let r = e[n];
		if (r.kind !== "tool_call") return e;
		let i = [...e];
		return i[n] = {
			...r,
			meta: {
				...r.meta,
				result: t.content,
				isError: t.isError,
				status: t.isError ? "error" : "completed"
			}
		}, i;
	});
}
function Ct(e, t) {
	e.setThinking(!1), e.setPendingApproval(!0), e.appendEntry({
		kind: "approval",
		content: t.toolName,
		meta: {
			toolName: t.toolName,
			input: t.input,
			toolCallId: t.id,
			description: t.description
		}
	});
}
function wt(e, t) {
	e.setThinking(!1), e.setPendingBackup(!0), e.appendEntry({
		kind: "backup_prompt",
		content: t.toolName,
		meta: { toolName: t.toolName }
	});
}
function Tt(e, t) {
	let n = t.summary?.trim(), r = t.reason ?? t.classification;
	if (Ue(e.getEntries())) {
		(n || r) && e.updateEntries((e) => e.map((t, i) => t.kind === "feedback_prompt" && !e.slice(i + 1).some((e) => e.kind === "feedback_prompt") ? {
			...t,
			...n ? { content: n } : {},
			...r ? { meta: {
				...t.meta,
				reason: r
			} } : {}
		} : t));
		return;
	}
	e.appendEntry({
		kind: "feedback_prompt",
		content: n || "Share feedback",
		...r ? { meta: { reason: r } } : {}
	});
}
function Et(e) {
	e.setThinking(!0), e.appendEntry({
		kind: "user_outcome_prompt",
		content: Be
	});
}
function Dt(e, t) {
	return t.status === "completed" || t.status === "error" ? (e.setThinking(!1), e.setSessionStatus(t.status), e.appendEntry({
		kind: "status",
		content: t.status === "completed" ? "Session completed" : "Session ended with error"
	}), !0) : (e.setSessionStatus(t.status), !1);
}
function Ot(e, t) {
	e.setThinking(!1), e.setPendingApproval(!1), e.setPendingBackup(!1), e.setStreamingEntryId(null), e.appendEntry({
		kind: "error",
		content: t.message
	});
}
//#endregion
//#region src/domains/account/doctor/doctor-sse-reconnect.ts
function kt(e) {
	return e;
}
//#endregion
//#region src/lib/streaming/sse-payload.ts
function At(e) {
	if (typeof e == "string") {
		try {
			let t = JSON.parse(e);
			if (t && typeof t == "object" && !Array.isArray(t)) return t;
		} catch {}
		return null;
	}
	return e && typeof e == "object" && !Array.isArray(e) ? e : null;
}
function jt(e) {
	let t = e.message;
	return t && typeof t == "object" && !Array.isArray(t) ? t : e;
}
//#endregion
//#region src/domains/account/doctor/operator-sse.ts
var Mt = class extends Error {
	status;
	code;
	constructor(e, t = null) {
		super(t ? `Doctor stream failed (${e}, ${t}).` : `Doctor stream failed (HTTP ${e}).`), this.name = "OperatorSseError", this.status = e, this.code = t;
	}
};
async function Nt(e) {
	let { path: t, headers: n, signal: r, onSseEvent: i, onSseError: a } = e;
	try {
		let e = await fetch(t, {
			headers: {
				Accept: "text/event-stream",
				...n
			},
			signal: r
		});
		if (!e.ok || !e.body) {
			let t = null;
			if (e.status === 409) {
				let n = await e.clone().json().catch(() => null);
				t = typeof n?.code == "string" ? n.code : null;
			}
			a(new Mt(e.status, t));
			return;
		}
		let o = e.body.getReader(), s = new TextDecoder(), c = "";
		for (;;) {
			let { done: e, value: t } = await o.read();
			if (e) return;
			c += s.decode(t, { stream: !0 });
			let n = c.split("\n\n");
			c = n.pop() ?? "";
			for (let e of n) {
				let t = e.split("\n").filter((e) => e.startsWith("data:")).map((e) => e.slice(5).trim());
				if (t.length === 0) {
					await i({});
					continue;
				}
				let n = At(t.join("\n"));
				n ? await i({ data: jt(n) }) : await i({});
			}
		}
	} catch (e) {
		if (e instanceof DOMException && e.name === "AbortError") return;
		a(e);
	}
}
//#endregion
//#region src/lib/diagnostics.ts
var Pt = "mycadet-app-lifecycle-diagnostics", Ft = 200;
function It() {
	try {
		let e = sessionStorage.getItem(Pt);
		if (!e) return [];
		let t = JSON.parse(e);
		return Array.isArray(t) ? t.filter((e) => !!e && typeof e == "object" && typeof e.kind == "string") : [];
	} catch {
		return [];
	}
}
function Lt(e) {
	try {
		sessionStorage.setItem(Pt, JSON.stringify(e.slice(-Ft)));
	} catch {}
}
function Rt(e, t = {}) {
	let n = It();
	n.push({
		ts: (/* @__PURE__ */ new Date()).toISOString(),
		kind: e,
		details: t
	}), Lt(n);
}
//#endregion
//#region src/lib/streaming/stream-watchdog.ts
function zt(e) {
	let { idleTimeoutMs: t, assistantId: n, getActiveTurnSending: r } = e, i = null, a = null, o = 0, s = 0, c = null, l = () => {
		i &&= (clearTimeout(i), null);
	};
	return {
		arm: (e, u) => {
			l(), i = setTimeout(() => {
				i = null, c = "watchdog";
				let l = null;
				try {
					l = r?.() ?? null;
				} catch {}
				let d = a === null ? null : Date.now() - a;
				Rt("sse_watchdog_fired", {
					assistantId: n,
					attempt: u,
					idleTimeoutMs: t,
					wasTurnSending: l,
					lastByteAgeMs: d,
					keepalivesReceivedSinceConnect: o,
					dataFramesReceivedSinceConnect: s
				}), e.abort();
			}, t);
		},
		clear: l,
		resetCounters: () => {
			a = null, o = 0, s = 0;
		},
		recordTraffic: (e) => {
			e ? s++ : o++, a = Date.now();
		},
		consumeLastAbortCause: () => {
			let e = c;
			return c = null, e;
		}
	};
}
//#endregion
//#region src/utils/to-error.ts
function Bt(e, t) {
	return e instanceof Error ? e : Error(t);
}
//#endregion
//#region src/domains/account/doctor/use-doctor-sse.ts
var Vt = new Set([404, 410]), Ht = "replay_gap", Ut = 5, Wt = 500, Gt = 5e3, Kt = 45e3;
function qt(e) {
	let t = Wt * 2 ** e, n = Math.floor(Math.random() * 250);
	return Math.min(t, Gt) + n;
}
function Jt(e, t) {
	return new Promise((n) => {
		if (t.aborted) {
			n();
			return;
		}
		let r = setTimeout(n, e);
		t.addEventListener("abort", () => {
			clearTimeout(r), n();
		}, { once: !0 });
	});
}
function Yt(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) return null;
	let t = e.id;
	return typeof t == "string" && t.length > 0 ? t : null;
}
function Xt(e, t) {
	let n = Xe(t), r = Ze(e), i = Z.getState();
	return i.setEntries(n), i.setSessionStatus(r), i.setPendingApproval(r === "active" && $e(n)), i.setPendingBackup(r === "active" && et(n)), i.seedReplayState(Je(t), Ye(t)), r;
}
async function Zt(e) {
	let t = await lt({ path: { doctor_session_id: e } });
	return !t.response?.ok || !t.data ? null : Xt(t.data.status, t.data.messages ?? []) === "active" ? (Z.getState().setSessionId(e), "active") : "terminal";
}
function Qt() {
	let e = H(null);
	return {
		connectSSE: z((t) => {
			e.current?.abort();
			let n = new AbortController();
			e.current = n;
			let r = !1, i = () => e.current === n, a = {
				getEntries: () => Z.getState().entries,
				updateEntries: (e) => Z.getState().updateEntries(e),
				setThinking: (e) => Z.getState().setThinking(e),
				setPendingApproval: (e) => Z.getState().setPendingApproval(e),
				setPendingBackup: (e) => Z.getState().setPendingBackup(e),
				setSessionStatus: (e) => Z.getState().setSessionStatus(e),
				appendEntry: (e) => Z.getState().appendEntry(e),
				nextId: () => Z.getState().nextId(),
				getStreamingEntryId: () => Z.getState().streamingEntryId,
				setStreamingEntryId: (e) => Z.getState().setStreamingEntryId(e)
			}, o = (t) => {
				if (!i()) return;
				e.current = null;
				let n = Z.getState();
				n.setThinking(!1), n.setPendingApproval(!1), n.setPendingBackup(!1), n.setStreamingEntryId(null), n.setSessionStatus("error"), n.appendEntry({
					kind: "error",
					content: t
				});
			};
			function s(e) {
				if (!i()) return;
				let t = e.source_event_id;
				if (!(qe(t) && !Z.getState().recordReplayableSourceEventId(t))) switch (e.type) {
					case "message_delta":
						yt(a, e);
						break;
					case "message":
						bt(a);
						break;
					case "tool_call":
						xt(a, e);
						break;
					case "tool_result":
						St(a, e);
						break;
					case "approval_required":
						Ct(a, e);
						break;
					case "backup_prompt":
						wt(a, e);
						break;
					case "feedback_prompt":
						Tt(a, e);
						break;
					case "user_outcome_prompt":
						Et(a);
						break;
					case "status":
						Dt(a, e) && (r = !0);
						break;
					case "error":
						Ot(a, e);
						break;
				}
			}
			(async () => {
				let e = 0, a = 0;
				for (; !n.signal.aborted && i();) {
					let c = new AbortController(), l = () => {
						c.abort();
					};
					n.signal.addEventListener("abort", l, { once: !0 });
					let u = zt({
						idleTimeoutMs: Kt,
						assistantId: ""
					});
					u.resetCounters();
					let d = null, f = !1, p = !1, m = null, h = !1, g = null;
					try {
						let r = Z.getState().latestReplayableSourceEventId, a = {};
						r && (a["Last-Event-ID"] = r), await Nt({
							path: `/v1/assistant/doctor/sessions/${encodeURIComponent(t)}/events/`,
							headers: a,
							signal: c.signal,
							onSseEvent: (t) => {
								let r = t.data !== void 0;
								if (r && (h = !0, e = 0, g = Yt(t)), u.recordTraffic(r), !n.signal.aborted && i() && u.arm(c, e), !i()) return;
								let a = g;
								g = null;
								let o = t.data;
								if (!r || o === void 0) return;
								let l = vt(o);
								l && s(l.source_event_id || !a ? l : {
									...l,
									source_event_id: a
								});
							},
							onSseError: (e) => {
								f || p || (e instanceof Mt && (m = e.status, Vt.has(e.status) && (f = !0), e.status === 409 && e.code === Ht && (p = !0)), d = Bt(e, "Doctor stream disconnected"));
							}
						});
					} catch (e) {
						if (n.signal.aborted) return;
						d = u.consumeLastAbortCause() === "watchdog" ? Bt(e, "Doctor stream stalled") : Bt(e, "Doctor stream connection failed");
					} finally {
						u.clear(), n.signal.removeEventListener("abort", l);
					}
					if (!i() || r) return;
					if (p) {
						if (a >= 1) {
							o("Doctor event history changed while reconnecting. Start a new session to continue.");
							return;
						}
						a += 1;
						let e = null;
						try {
							e = await Zt(t);
						} catch (e) {
							L(e, { context: "doctor_replay_gap_refresh" });
						}
						if (!i()) return;
						if (e === "active") continue;
						if (e === "terminal") {
							r = !0;
							return;
						}
						o("Doctor event history changed while reconnecting. Start a new session to continue.");
						return;
					}
					if (f) {
						r = !0;
						let e = Z.getState();
						e.setThinking(!1), e.setStreamingEntryId(null), e.setSessionStatus("completed"), e.setPendingApproval(!1), e.setPendingBackup(!1), e.appendEntry({
							kind: "status",
							content: "Previous session expired. Start a new session to continue."
						});
						return;
					}
					if (d ||= /* @__PURE__ */ Error("Doctor event stream ended before the session completed."), kt(h) && (e = 0), e >= Ut) {
						L(d, { context: "doctor_sse_stream" }), o(m ? `Failed to connect to event stream (${m}). Start a new session to continue.` : "Event stream disconnected. Start a new session to continue.");
						return;
					}
					await Jt(qt(e), n.signal), e += 1;
				}
			})();
		}, []),
		abort: z(() => {
			e.current?.abort(), e.current = null;
		}, [])
	};
}
//#endregion
//#region src/domains/account/doctor/use-doctor-auto-scroll.ts
var $t = 64, en = 240;
function tn(e) {
	let [t, n] = U(null), [r, i] = U(!1), a = H(!0), o = z((e) => {
		n((t) => (e !== t && (a.current = !0, i(!1)), e));
	}, []), s = z(() => {
		let e = t;
		if (!e) return;
		let n = Math.max(0, e.scrollHeight - e.clientHeight), r = Math.max(0, n - e.scrollTop);
		a.current = r <= $t, i(r > en);
	}, [t]);
	return B(() => {
		a.current && t && t.scrollTo({
			top: t.scrollHeight,
			behavior: "auto"
		});
	}, [e, t]), B(() => {
		if (t) return t.addEventListener("scroll", s, { passive: !0 }), () => {
			t.removeEventListener("scroll", s);
		};
	}, [t, s]), B(() => {
		s();
	}, [e, s]), B(() => {
		if (!t || typeof ResizeObserver > "u") return;
		let e = t.firstElementChild;
		if (!e) return;
		let n = new ResizeObserver(() => {
			a.current && t.scrollTo({
				top: t.scrollHeight,
				behavior: "auto"
			}), s();
		});
		return n.observe(e), () => {
			n.disconnect();
		};
	}, [t, s]), {
		scrollContainerRef: o,
		showScrollToLatest: r,
		scrollToLatest: z(() => {
			t && (a.current = !0, t.scrollTo({
				top: t.scrollHeight,
				behavior: "auto"
			}), i(!1));
		}, [t])
	};
}
//#endregion
//#region src/utils/pointer.ts
var nn = "(pointer: coarse)";
function rn() {
	return typeof window < "u" && window.matchMedia(nn).matches;
}
//#endregion
//#region src/domains/account/doctor/doctor-handoff.ts
var an = "mycadet-doctor-handoff";
function on() {
	try {
		let e = sessionStorage.getItem(an);
		if (!e) return null;
		let t = JSON.parse(e);
		return t && typeof t == "object" && typeof t.prompt == "string" ? t.prompt : null;
	} catch {
		return null;
	}
}
function sn() {
	try {
		let e = sessionStorage.getItem(an);
		if (!e) return null;
		sessionStorage.removeItem(an);
		let t = JSON.parse(e);
		return t && typeof t == "object" && typeof t.prompt == "string" ? t.prompt : null;
	} catch {
		return null;
	}
}
//#endregion
//#region src/domains/account/doctor/doctor-panel.tsx
function cn({ entry: e, onRespond: t }) {
	return /* @__PURE__ */ W("div", {
		className: "max-w-[90%]",
		children: /* @__PURE__ */ W(Pe, {
			question: e.content,
			answer: e.meta?.answer,
			onRespond: (n) => t(e.id, n)
		})
	});
}
function ln() {
	let { t: e } = A("doctor"), n = Z.use.entries(), i = Z.use.inputValue(), a = Z.use.pendingApproval(), o = Z.use.pendingBackup(), s = Z.use.thinking(), c = Z.use.streamingEntryId(), l = Z.use.sessionId(), u = Z.use.sessionStatus(), d = Z.use.historyDismissed(), [f, m] = U(!1), [h, g] = U(null), _ = H(null), ee = H(null), v = H(!1), { connectSSE: y, abort: b } = Qt(), x = l === null && !d && n.length === 0, S = p({
		queryKey: ["doctor-history"],
		queryFn: () => ct({ query: { limit: "1" } }),
		enabled: x
	}), C = (S.data?.data ? nt(S.data.data.results ?? []) : null)?.id ?? null, w = p({
		queryKey: ["doctor-history-detail", C],
		queryFn: () => lt({ path: { doctor_session_id: C ?? "" } }),
		enabled: !!C && !d && l === null && n.length === 0
	}), T = d ? void 0 : w.data, E = T?.data ?? null, D = E ? Ze(E.status) : null, O = V(() => E ? Qe(Xe(E.messages ?? []), E.user_outcome) : [], [E]);
	B(() => {
		if (d || l !== null || n.length > 0 || !T || !C || D !== "active") return;
		let e = Z.getState(), t = T.data?.messages ?? [], r = Qe(Xe(t), T.data?.user_outcome ?? null);
		e.setEntries(r), e.setPendingApproval($e(r)), e.setPendingBackup(et(r)), e.seedReplayState(Je(t), Ye(t)), e.setSessionId(C), e.setSessionStatus("active"), y(C);
	}, [
		d,
		l,
		n.length,
		T,
		D,
		C,
		y
	]), B(() => {
		S.error && L(S.error, { context: "doctor_history_list" });
	}, [S.error]), B(() => {
		w.error && L(w.error, { context: "doctor_history_detail" });
	}, [w.error]);
	let k = ve({
		async mutationFn() {
			let { data: e, error: t, response: n } = await ut();
			if (t) throw n?.status === 429 ? new re(429, "You've used all of your available Doctor sessions for this month. Please try again next month.") : t;
			return e;
		},
		onSuccess(e) {
			let t = Z.getState();
			t.resetReplayState(), t.setSessionId(e.session_id), t.setSessionStatus("active"), t.setEntries([{
				kind: "assistant",
				content: mt,
				id: "greeting",
				timestamp: Date.now()
			}]), y(e.session_id);
		},
		onError(e) {
			e instanceof re && e.status === 429 || L(e, { context: "start_doctor_session" });
			let t = Z.getState();
			t.setSessionStatus("error"), t.appendEntry({
				kind: "error",
				content: e instanceof re ? e.message : te(e, void 0, "Failed to start doctor session")
			});
		}
	}), M = ve({
		mutationFn: (e) => ft(e),
		onMutate(e) {
			let t = e.body.content, n = Z.getState();
			n.appendEntry({
				kind: "user",
				content: t
			}), n.setInputValue(""), n.setThinking(!0), ht.has(t.toLowerCase()) && n.setPendingApproval(!1);
		},
		onError(e) {
			L(e, { context: "send_doctor_message" }), Z.getState().setThinking(!1), Z.getState().appendEntry({
				kind: "error",
				content: te(e, void 0, "Failed to send message")
			});
		}
	}), N = k.isPending, P = M.isPending, F = (e) => {
		let t = e.trim();
		!t || !l || (J(), M.mutate({
			path: { session_id: l },
			body: { content: t }
		}));
	}, I = z((e) => {
		g({
			message: e?.message?.trim() || void 0,
			reason: e?.reason
		}), m(!0);
	}, []), ne = z(() => {
		m(!1), g(null);
	}, []), R = w.refetch, ae = z((e, t) => {
		let n = Z.getState(), r = n.sessionId === null, i = n.sessionId ?? C;
		if (!i) return;
		let a = n.entries.find((t) => t.id === e), o = a?.kind === "user_outcome_prompt" ? a.meta?.answer : void 0, s = t ? "resolved" : "not_resolved", c = (t) => {
			n.updateEntries((n) => n.map((n) => n.id === e && n.kind === "user_outcome_prompt" ? {
				...n,
				meta: {
					...n.meta,
					answer: t
				}
			} : n));
		};
		c(s), pt({
			path: { session_id: i },
			body: { resolved: t }
		}).then(({ error: t }) => {
			if (t) {
				let n = Z.getState(), r = n.entries.find((t) => t.id === e);
				n.sessionId === i && r?.kind === "user_outcome_prompt" && r.meta?.answer === s && c(o), L(t, { context: "doctor_session_user_outcome" });
			} else r && R();
		}), t || I({ message: "The Doctor wasn't able to solve my problem: " });
	}, [
		C,
		I,
		R
	]), ce = () => {
		b();
		let e = Z.getState();
		e.sessionId && gt(e.sessionId), e.teardown();
	}, le = () => {
		b();
		let e = Z.getState();
		e.sessionId && gt(e.sessionId), e.resetForNewSession();
	}, K = V(() => l || n.length > 0 ? n : d ? [] : O, [
		l,
		n,
		d,
		O
	]), ue = l ?? (d ? null : C), q = V(() => tt(K), [K]), fe = z(() => {
		ie(q, {
			successMessage: e("doctorPanel.copiedToast"),
			errorMessage: e("doctorPanel.copyFailed")
		});
	}, [q, e]), { transcript: pe, trailingPrompts: me } = V(() => We(K), [K]), he = s || c !== null, ge = V(() => {
		if (!(l !== null || n.length > 0)) return null;
		let e = null;
		for (let t = K.length - 1; t >= 0; t--) {
			let n = K[t];
			if (!(n.kind !== "tool_call" || n.meta.status !== "completed" || n.meta.isError)) {
				if (n.meta.toolName === "list_assistant_backups") return {
					entryId: n.id,
					refreshKey: e ?? n.id
				};
				e === null && (n.meta.toolName === "create_doctor_backup" || n.meta.toolName === "restore_assistant_backup") && (e = n.id);
			}
		}
		return null;
	}, [
		K,
		l,
		n
	]), { scrollContainerRef: _e, showScrollToLatest: ye, scrollToLatest: J } = tn(K);
	B(() => {
		if (on() !== null) return;
		let e = Z.getState();
		e.sessionStatus === "active" && e.sessionId && y(e.sessionId), e.historyDismissed && !e.sessionId && Z.setState({ historyDismissed: !1 });
	}, []), B(() => {
		let e = Z.getState();
		e.sessionStatus === "active" && (e.sessionId && gt(e.sessionId), b(), e.reset());
	}, [b]), B(() => () => {
		b();
	}, [b]), B(() => {
		if (v.current) return;
		let e = sn();
		if (e === null) return;
		v.current = !0;
		let t = Z.getState();
		b(), t.sessionId && gt(t.sessionId), t.resetForNewSession(), ee.current = e.length > 0 ? e : null, k.mutate();
	}, [b, k]);
	let Y = l !== null && u === "active", X = !Y && n.length > 0 && (u === "completed" || u === "error"), be = Y || X ? u : D ?? "idle", xe = x && (S.isLoading || !!C && w.isLoading);
	return B(() => {
		let e = ee.current;
		e && (!Y || !l || (ee.current = null, J(), M.mutate({
			path: { session_id: l },
			body: { content: e }
		})));
	}, [
		Y,
		l,
		J,
		M
	]), /* @__PURE__ */ G("div", {
		className: "flex min-h-0 flex-1 flex-col gap-2 rounded-xl bg-[var(--surface-base)] p-5 ring-1 ring-[var(--border-base)]",
		children: [
			/* @__PURE__ */ G("div", {
				className: "flex shrink-0 items-center justify-between",
				children: [/* @__PURE__ */ G("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ W(Se, { className: "h-10 w-10 shrink-0" }), /* @__PURE__ */ W("h2", {
						className: "text-title-small text-[var(--content-default)]",
						children: e("doctorPanel.title")
					})]
				}), /* @__PURE__ */ G("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ W(rt, {
						onShareFeedback: I,
						onCopySession: K.length > 0 ? fe : void 0
					}), Y && /* @__PURE__ */ W(Ce, {
						onStop: ce,
						ariaLabel: e("doctorPanel.endSession")
					})]
				})]
			}),
			xe ? /* @__PURE__ */ G("div", {
				className: "flex items-center gap-2 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: [/* @__PURE__ */ W("span", { className: "h-4 w-4 animate-spin rounded-full border-2 border-[var(--border-element)] border-t-[var(--content-secondary)]" }), e("doctorPanel.loading")]
			}) : be === "idle" ? /* @__PURE__ */ G("div", {
				className: "flex flex-1 flex-col items-center justify-center gap-4 py-12",
				children: [
					/* @__PURE__ */ W(Se, { className: "h-24 w-24 shrink-0" }),
					/* @__PURE__ */ G("div", {
						className: "text-center",
						children: [/* @__PURE__ */ W("h3", {
							className: "text-title-medium text-[var(--content-default)]",
							children: e("doctorPanel.idleTitle")
						}), /* @__PURE__ */ W("p", {
							className: "mt-1 max-w-md text-body-medium-lighter text-[var(--content-tertiary)]",
							children: e("doctorPanel.idleDescription")
						})]
					}),
					/* @__PURE__ */ G("button", {
						type: "button",
						onClick: () => k.mutate(),
						disabled: N,
						className: "flex cursor-pointer items-center gap-2 rounded-lg bg-[var(--primary-base)] px-5 py-2.5 text-body-medium-default text-[var(--content-inset)] transition-colors hover:bg-[var(--primary-hover)] disabled:cursor-not-allowed disabled:opacity-50",
						children: [N ? /* @__PURE__ */ W(t, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ W(de, { className: "h-4 w-4" }), e("doctorPanel.startSession")]
					})
				]
			}) : /* @__PURE__ */ G(oe, { children: [
				/* @__PURE__ */ G("div", {
					className: "relative min-h-0 flex-1",
					children: [/* @__PURE__ */ W("div", {
						ref: _e,
						className: "h-full overflow-y-auto",
						children: /* @__PURE__ */ G("div", {
							className: "mx-auto max-w-3xl space-y-3",
							children: [
								pe.map((t) => {
									switch (t.kind) {
										case "user": return /* @__PURE__ */ W(Fe, { entry: t }, t.id);
										case "assistant": return /* @__PURE__ */ W(Le, { entry: t }, t.id);
										case "tool_call": return /* @__PURE__ */ W("div", {
											className: "flex justify-start",
											children: /* @__PURE__ */ G("div", {
												className: "w-full",
												children: [/* @__PURE__ */ W(Ae, { entry: t }), t.id === ge?.entryId && /* @__PURE__ */ W("div", {
													className: "mt-2 rounded-lg border border-[var(--border-base)] bg-[var(--surface-lift)] p-4",
													children: /* @__PURE__ */ W("button", {
														type: "button",
														className: "text-body-medium text-[var(--content-link)] underline-offset-2 hover:underline",
														onClick: () => Ee("/assistant/settings/debug"),
														children: e("doctorPanel.openBackups")
													})
												})]
											})
										}, t.id);
										case "approval": return /* @__PURE__ */ W("div", {
											className: "max-w-[90%]",
											children: /* @__PURE__ */ W(je, {
												entry: t,
												onRespond: F,
												disabled: !a || P
											})
										}, t.id);
										case "backup_prompt": return /* @__PURE__ */ W("div", {
											className: "max-w-[90%]",
											children: /* @__PURE__ */ W(Me, {
												entry: t,
												onRespond: (e) => {
													Z.getState().setPendingBackup(!1), F(e);
												},
												disabled: !o || P
											})
										}, t.id);
										case "feedback_prompt": return /* @__PURE__ */ W("div", {
											className: "max-w-[90%]",
											children: /* @__PURE__ */ W(Ne, { onOpenFeedback: () => I({
												message: t.content === "Share feedback" ? void 0 : t.content,
												reason: t.meta?.reason
											}) })
										}, t.id);
										case "user_outcome_prompt": return /* @__PURE__ */ W(cn, {
											entry: t,
											onRespond: ae
										}, t.id);
										case "error": return /* @__PURE__ */ W(Re, { entry: t }, t.id);
										case "status": return /* @__PURE__ */ W(ze, { entry: t }, t.id);
										default: return null;
									}
								}),
								s && /* @__PURE__ */ W("div", {
									className: "flex justify-start",
									children: /* @__PURE__ */ G("div", {
										className: "flex items-center gap-[5px] rounded-[var(--radius-lg)] bg-[var(--surface-overlay)] px-4 py-3",
										children: [[
											-.333,
											0,
											-.667
										].map((e, t) => /* @__PURE__ */ W("span", {
											"aria-hidden": !0,
											className: "typing-dot block h-2 w-2 rounded-full bg-[var(--content-tertiary)]",
											style: {
												animation: "typing-dot-pulse 1s ease-in-out infinite",
												animationDelay: `${e}s`
											}
										}, t)), /* @__PURE__ */ W("span", {
											className: "sr-only",
											children: e("doctorPanel.thinking")
										})]
									})
								}),
								!he && me.map((e) => /* @__PURE__ */ W(cn, {
									entry: e,
									onRespond: ae
								}, e.id)),
								Y && !K.length && /* @__PURE__ */ G("div", {
									className: "flex items-center gap-2 text-body-medium-lighter text-[var(--content-disabled)]",
									children: [/* @__PURE__ */ W(t, { className: "h-4 w-4 animate-spin" }), e("doctorPanel.connecting")]
								})
							]
						})
					}), ye && /* @__PURE__ */ G("button", {
						type: "button",
						onClick: J,
						"aria-label": e("doctorPanel.goToNewestAria"),
						className: "pointer-events-auto absolute bottom-3 left-1/2 -translate-x-1/2 z-10 inline-flex items-center gap-1 rounded-full bg-[var(--surface-lift)] px-3 py-2 text-body-medium-default text-[var(--content-emphasised)] shadow-md transition-colors hover:text-[var(--content-default)]",
						children: [e("doctorPanel.goToNewest"), /* @__PURE__ */ W(r, { className: "h-3 w-3" })]
					})]
				}),
				Y && /* @__PURE__ */ G("form", {
					onSubmit: (e) => {
						e.preventDefault(), i.trim() && !P && (F(i), _.current && (_.current.style.height = "auto"));
					},
					className: "mx-auto w-full max-w-3xl shrink-0 overflow-hidden rounded-[10px] bg-[var(--surface-lift)] shadow-sm ring-1 ring-transparent focus-within:ring-[var(--ring)]",
					children: [/* @__PURE__ */ W("textarea", {
						ref: _,
						value: i,
						onChange: (e) => {
							Z.getState().setInputValue(e.target.value), e.target.style.height = "auto", e.target.style.height = `${Math.min(e.target.scrollHeight, 160)}px`;
						},
						onKeyDown: (e) => {
							e.key !== "Enter" || e.shiftKey || e.nativeEvent.isComposing || e.keyCode === 229 || rn() || (e.preventDefault(), i.trim() && !P && (F(i), _.current && (_.current.style.height = "auto")));
						},
						placeholder: e(a ? "doctorPanel.placeholderApproval" : "doctorPanel.placeholderMessage"),
						disabled: P,
						rows: 1,
						className: "w-full resize-none border-none bg-transparent px-4 pb-2 pt-3 text-body-medium-lighter text-[var(--content-default)] placeholder:text-[var(--content-tertiary)] focus:outline-none disabled:opacity-50"
					}), /* @__PURE__ */ W("div", {
						className: "flex items-center justify-end px-3 pb-2",
						children: /* @__PURE__ */ W(j, {
							variant: "primary",
							iconOnly: /* @__PURE__ */ W(se, {
								className: "h-4 w-4",
								strokeWidth: 2.5
							}),
							type: "submit",
							disabled: !i.trim() || P,
							"aria-label": e("doctorPanel.sendMessageAria")
						})
					})]
				}),
				(X || !Y && D && D !== "active") && /* @__PURE__ */ W("div", {
					className: "flex shrink-0 items-center justify-center gap-3 py-2",
					children: /* @__PURE__ */ G("button", {
						type: "button",
						onClick: le,
						className: "flex cursor-pointer items-center gap-2 rounded-lg bg-[var(--primary-base)] px-4 py-2 text-body-medium-default text-[var(--content-inset)] transition-colors hover:bg-[var(--primary-hover)]",
						children: [/* @__PURE__ */ W(de, { className: "h-4 w-4" }), e("doctorPanel.newSession")]
					})
				})
			] }),
			/* @__PURE__ */ W(Te, {
				open: f,
				onClose: ne,
				initialReason: h?.reason,
				initialMessage: h?.message,
				doctorSessionId: ue,
				doctorSessionLog: q
			})
		]
	});
}
//#endregion
//#region src/domains/account/pages/doctor-page.tsx
function un() {
	let { t: e } = A("doctor");
	return p({
		queryKey: ["doctor-page-assistants"],
		queryFn: async () => {
			let e = await fetch("/v1/assistants/");
			return e.ok ? await e.json() : null;
		}
	}).data?.status === "empty" ? /* @__PURE__ */ G("div", {
		className: "flex flex-1 flex-col items-center justify-center gap-4 py-12",
		children: [/* @__PURE__ */ W(Se, { className: "h-24 w-24 shrink-0" }), /* @__PURE__ */ W("p", {
			className: "max-w-md text-center text-body-medium-lighter text-[var(--content-tertiary)]",
			children: e("doctorPage.empty")
		})]
	}) : /* @__PURE__ */ W(ln, {});
}
function dn() {
	return /* @__PURE__ */ W("div", {
		className: "flex min-h-dvh flex-col bg-[var(--surface-canvas)]",
		children: /* @__PURE__ */ W("div", {
			className: "mx-auto flex w-full max-w-3xl flex-1 flex-col p-4",
			children: /* @__PURE__ */ W(un, {})
		})
	});
}
//#endregion
export { dn as DoctorPage };
