import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { t } from "./check-DPXe7vV_.js";
import { a as n, i as r, o as i } from "./dist-CB0DYkRa.js";
import { t as a } from "./typography-DAhYh88V.js";
import * as o from "react";
import { useId as s } from "react";
import "react-dom";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
var d = e("minus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}]]);
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-context@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-context/dist/index.mjs
function f(e, t = []) {
	let n = [];
	function r(t, r) {
		let i = o.createContext(r), a = n.length;
		n = [...n, r];
		let s = (t) => {
			let { scope: n, children: r, ...s } = t, c = n?.[e]?.[a] || i, u = o.useMemo(() => s, Object.values(s));
			return /* @__PURE__ */ l(c.Provider, {
				value: u,
				children: r
			});
		};
		s.displayName = t + "Provider";
		function c(n, s) {
			let c = s?.[e]?.[a] || i, l = o.useContext(c);
			if (l) return l;
			if (r !== void 0) return r;
			throw Error(`\`${n}\` must be used within \`${t}\``);
		}
		return [s, c];
	}
	let i = () => {
		let t = n.map((e) => o.createContext(e));
		return function(n) {
			let r = n?.[e] || t;
			return o.useMemo(() => ({ [`__scope${e}`]: {
				...n,
				[e]: r
			} }), [n, r]);
		};
	};
	return i.scopeName = e, [r, p(i, ...t)];
}
function p(...e) {
	let t = e[0];
	if (e.length === 1) return t;
	let n = () => {
		let n = e.map((e) => ({
			useScope: e(),
			scopeName: e.scopeName
		}));
		return function(e) {
			let r = n.reduce((t, { useScope: n, scopeName: r }) => {
				let i = n(e)[`__scope${r}`];
				return {
					...t,
					...i
				};
			}, {});
			return o.useMemo(() => ({ [`__scope${t.scopeName}`]: r }), [r]);
		};
	};
	return n.scopeName = t.scopeName, n;
}
typeof window < "u" && window.document && window.document.createElement;
function m(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return function(r) {
		if (e?.(r), n === !1 || !r.defaultPrevented) return t?.(r);
	};
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-layout-effect@1.1.1+bf264c7668a20073/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var h = globalThis?.document ? o.useLayoutEffect : () => {}, g = o.useInsertionEffect || h;
function _({ prop: e, defaultProp: t, onChange: n = () => {}, caller: r }) {
	let [i, a, s] = v({
		defaultProp: t,
		onChange: n
	}), c = e !== void 0, l = c ? e : i;
	{
		let t = o.useRef(e !== void 0);
		o.useEffect(() => {
			let e = t.current;
			e !== c && console.warn(`${r} is changing from ${e ? "controlled" : "uncontrolled"} to ${c ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`), t.current = c;
		}, [c, r]);
	}
	return [l, o.useCallback((t) => {
		if (c) {
			let n = y(t) ? t(e) : t;
			n !== e && s.current?.(n);
		} else a(t);
	}, [
		c,
		e,
		a,
		s
	])];
}
function v({ defaultProp: e, onChange: t }) {
	let [n, r] = o.useState(e), i = o.useRef(n), a = o.useRef(t);
	return g(() => {
		a.current = t;
	}, [t]), o.useEffect(() => {
		i.current !== n && (a.current?.(n), i.current = n);
	}, [n, i]), [
		n,
		r,
		a
	];
}
function y(e) {
	return typeof e == "function";
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-previous@1.1.1+bf264c7668a20073/node_modules/@radix-ui/react-use-previous/dist/index.mjs
function b(e) {
	let t = o.useRef({
		value: e,
		previous: e
	});
	return o.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-size@1.1.1+bf264c7668a20073/node_modules/@radix-ui/react-use-size/dist/index.mjs
function x(e) {
	let [t, n] = o.useState(void 0);
	return h(() => {
		if (e) {
			n({
				width: e.offsetWidth,
				height: e.offsetHeight
			});
			let t = new ResizeObserver((t) => {
				if (!Array.isArray(t) || !t.length) return;
				let r = t[0], i, a;
				if ("borderBoxSize" in r) {
					let e = r.borderBoxSize, t = Array.isArray(e) ? e[0] : e;
					i = t.inlineSize, a = t.blockSize;
				} else i = e.offsetWidth, a = e.offsetHeight;
				n({
					width: i,
					height: a
				});
			});
			return t.observe(e, { box: "border-box" }), () => t.unobserve(e);
		} else n(void 0);
	}, [e]), t;
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-presence@1.1.5+07ecf1aa3bcbed22/node_modules/@radix-ui/react-presence/dist/index.mjs
function S(e, t) {
	return o.useReducer((e, n) => t[e][n] ?? e, e);
}
var C = (e) => {
	let { present: t, children: r } = e, i = w(t), a = typeof r == "function" ? r({ present: i.isPresent }) : o.Children.only(r), s = n(i.ref, E(a));
	return typeof r == "function" || i.isPresent ? o.cloneElement(a, { ref: s }) : null;
};
C.displayName = "Presence";
function w(e) {
	let [t, n] = o.useState(), r = o.useRef(null), i = o.useRef(e), a = o.useRef("none"), [s, c] = S(e ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	return o.useEffect(() => {
		let e = T(r.current);
		a.current = s === "mounted" ? e : "none";
	}, [s]), h(() => {
		let t = r.current, n = i.current;
		if (n !== e) {
			let r = a.current, o = T(t);
			e ? c("MOUNT") : o === "none" || t?.display === "none" ? c("UNMOUNT") : c(n && r !== o ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
		}
	}, [e, c]), h(() => {
		if (t) {
			let e, n = t.ownerDocument.defaultView ?? window, o = (a) => {
				let o = T(r.current).includes(CSS.escape(a.animationName));
				if (a.target === t && o && (c("ANIMATION_END"), !i.current)) {
					let r = t.style.animationFillMode;
					t.style.animationFillMode = "forwards", e = n.setTimeout(() => {
						t.style.animationFillMode === "forwards" && (t.style.animationFillMode = r);
					});
				}
			}, s = (e) => {
				e.target === t && (a.current = T(r.current));
			};
			return t.addEventListener("animationstart", s), t.addEventListener("animationcancel", o), t.addEventListener("animationend", o), () => {
				n.clearTimeout(e), t.removeEventListener("animationstart", s), t.removeEventListener("animationcancel", o), t.removeEventListener("animationend", o);
			};
		} else c("ANIMATION_END");
	}, [t, c]), {
		isPresent: ["mounted", "unmountSuspended"].includes(s),
		ref: o.useCallback((e) => {
			r.current = e ? getComputedStyle(e) : null, n(e);
		}, [])
	};
}
function T(e) {
	return e?.animationName || "none";
}
function E(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-slot@1.2.3+bf264c7668a20073/node_modules/@radix-ui/react-slot/dist/index.mjs
/* @__NO_SIDE_EFFECTS__ */
function D(e) {
	let t = /* @__PURE__ */ O(e), n = o.forwardRef((e, n) => {
		let { children: r, ...i } = e, a = o.Children.toArray(r), s = a.find(A);
		if (s) {
			let e = s.props.children, r = a.map((t) => t === s ? o.Children.count(e) > 1 ? o.Children.only(null) : o.isValidElement(e) ? e.props.children : null : t);
			return /* @__PURE__ */ l(t, {
				...i,
				ref: n,
				children: o.isValidElement(e) ? o.cloneElement(e, void 0, r) : null
			});
		}
		return /* @__PURE__ */ l(t, {
			...i,
			ref: n,
			children: r
		});
	});
	return n.displayName = `${e}.Slot`, n;
}
/* @__NO_SIDE_EFFECTS__ */
function O(e) {
	let t = o.forwardRef((e, t) => {
		let { children: n, ...i } = e;
		if (o.isValidElement(n)) {
			let e = M(n), a = j(i, n.props);
			return n.type !== o.Fragment && (a.ref = t ? r(t, e) : e), o.cloneElement(n, a);
		}
		return o.Children.count(n) > 1 ? o.Children.only(null) : null;
	});
	return t.displayName = `${e}.SlotClone`, t;
}
var k = Symbol("radix.slottable");
function A(e) {
	return o.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === k;
}
function j(e, t) {
	let n = { ...t };
	for (let r in t) {
		let i = e[r], a = t[r];
		/^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
			let t = a(...e);
			return i(...e), t;
		} : i && (n[r] = i) : r === "style" ? n[r] = {
			...i,
			...a
		} : r === "className" && (n[r] = [i, a].filter(Boolean).join(" "));
	}
	return {
		...e,
		...n
	};
}
function M(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-primitive@2.1.3+07ecf1aa3bcbed22/node_modules/@radix-ui/react-primitive/dist/index.mjs
var N = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((e, t) => {
	let n = /* @__PURE__ */ D(`Primitive.${t}`), r = o.forwardRef((e, r) => {
		let { asChild: i, ...a } = e, o = i ? n : t;
		return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ l(o, {
			...a,
			ref: r
		});
	});
	return r.displayName = `Primitive.${t}`, {
		...e,
		[t]: r
	};
}, {}), P = "Checkbox", [F, I] = f(P), [L, R] = F(P);
function z(e) {
	let { __scopeCheckbox: t, checked: n, children: r, defaultChecked: i, disabled: a, form: s, name: c, onCheckedChange: u, required: d, value: f = "on", internal_do_not_use_render: p } = e, [m, h] = _({
		prop: n,
		defaultProp: i ?? !1,
		onChange: u,
		caller: P
	}), [g, v] = o.useState(null), [y, b] = o.useState(null), x = o.useRef(!1), S = g ? !!s || !!g.closest("form") : !0, C = {
		checked: m,
		disabled: a,
		setChecked: h,
		control: g,
		setControl: v,
		name: c,
		form: s,
		value: f,
		hasConsumerStoppedPropagationRef: x,
		required: d,
		defaultChecked: J(i) ? !1 : i,
		isFormControl: S,
		bubbleInput: y,
		setBubbleInput: b
	};
	return /* @__PURE__ */ l(L, {
		scope: t,
		...C,
		children: q(p) ? p(C) : r
	});
}
var B = "CheckboxTrigger", V = o.forwardRef(({ __scopeCheckbox: e, onKeyDown: t, onClick: r, ...i }, a) => {
	let { control: s, value: c, disabled: u, checked: d, required: f, setControl: p, setChecked: h, hasConsumerStoppedPropagationRef: g, isFormControl: _, bubbleInput: v } = R(B, e), y = n(a, p), b = o.useRef(d);
	return o.useEffect(() => {
		let e = s?.form;
		if (e) {
			let t = () => h(b.current);
			return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
		}
	}, [s, h]), /* @__PURE__ */ l(N.button, {
		type: "button",
		role: "checkbox",
		"aria-checked": J(d) ? "mixed" : d,
		"aria-required": f,
		"data-state": Y(d),
		"data-disabled": u ? "" : void 0,
		disabled: u,
		value: c,
		...i,
		ref: y,
		onKeyDown: m(t, (e) => {
			e.key === "Enter" && e.preventDefault();
		}),
		onClick: m(r, (e) => {
			h((e) => J(e) ? !0 : !e), v && _ && (g.current = e.isPropagationStopped(), g.current || e.stopPropagation());
		})
	});
});
V.displayName = B;
var H = o.forwardRef((e, t) => {
	let { __scopeCheckbox: n, name: r, checked: i, defaultChecked: a, required: o, disabled: s, value: d, onCheckedChange: f, form: p, ...m } = e;
	return /* @__PURE__ */ l(z, {
		__scopeCheckbox: n,
		checked: i,
		defaultChecked: a,
		disabled: s,
		required: o,
		onCheckedChange: f,
		name: r,
		form: p,
		value: d,
		internal_do_not_use_render: ({ isFormControl: e }) => /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(V, {
			...m,
			ref: t,
			__scopeCheckbox: n
		}), e && /* @__PURE__ */ l(K, { __scopeCheckbox: n })] })
	});
});
H.displayName = P;
var U = "CheckboxIndicator", W = o.forwardRef((e, t) => {
	let { __scopeCheckbox: n, forceMount: r, ...i } = e, a = R(U, n);
	return /* @__PURE__ */ l(C, {
		present: r || J(a.checked) || a.checked === !0,
		children: /* @__PURE__ */ l(N.span, {
			"data-state": Y(a.checked),
			"data-disabled": a.disabled ? "" : void 0,
			...i,
			ref: t,
			style: {
				pointerEvents: "none",
				...e.style
			}
		})
	});
});
W.displayName = U;
var G = "CheckboxBubbleInput", K = o.forwardRef(({ __scopeCheckbox: e, ...t }, r) => {
	let { control: i, hasConsumerStoppedPropagationRef: a, checked: s, defaultChecked: c, required: u, disabled: d, name: f, value: p, form: m, bubbleInput: h, setBubbleInput: g } = R(G, e), _ = n(r, g), v = b(s), y = x(i);
	o.useEffect(() => {
		let e = h;
		if (!e) return;
		let t = window.HTMLInputElement.prototype, n = Object.getOwnPropertyDescriptor(t, "checked").set, r = !a.current;
		if (v !== s && n) {
			let t = new Event("click", { bubbles: r });
			e.indeterminate = J(s), n.call(e, J(s) ? !1 : s), e.dispatchEvent(t);
		}
	}, [
		h,
		v,
		s,
		a
	]);
	let S = o.useRef(J(s) ? !1 : s);
	return /* @__PURE__ */ l(N.input, {
		type: "checkbox",
		"aria-hidden": !0,
		defaultChecked: c ?? S.current,
		required: u,
		disabled: d,
		name: f,
		value: p,
		form: m,
		...t,
		tabIndex: -1,
		ref: _,
		style: {
			...t.style,
			...y,
			position: "absolute",
			pointerEvents: "none",
			opacity: 0,
			margin: 0,
			transform: "translateX(-100%)"
		}
	});
});
K.displayName = G;
function q(e) {
	return typeof e == "function";
}
function J(e) {
	return e === "indeterminate";
}
function Y(e) {
	return J(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
//#endregion
//#region ../../packages/design-library/src/components/checkbox.tsx
function X({ checked: e, onCheckedChange: n, label: r, helperText: o, disabled: c = !1, id: f, name: p, className: m, ref: h, "aria-label": g, ..._ }) {
	let v = s(), y = f ?? v, b = r ? `${y}-label` : void 0, x = o ? `${y}-helper` : void 0, S = e === "indeterminate", C = i("inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-[4px]", "border-2 transition-colors outline-none cursor-pointer", "keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0", "bg-[var(--field-bg)] border-[var(--content-tertiary)]", "data-[state=checked]:bg-[var(--primary-active)] data-[state=checked]:border-transparent", "data-[state=indeterminate]:bg-[var(--primary-active)] data-[state=indeterminate]:border-transparent", "disabled:cursor-not-allowed disabled:bg-[var(--surface-overlay)]", "disabled:data-[state=checked]:bg-[var(--surface-overlay)]", "disabled:data-[state=indeterminate]:bg-[var(--surface-overlay)]", "disabled:border-[var(--border-disabled)]"), w = i("h-3 w-3", c ? "text-[color:var(--content-disabled)]" : "text-[color:var(--content-inset)]"), T = /* @__PURE__ */ l(H, {
		..._,
		ref: h,
		id: y,
		name: p,
		checked: e,
		disabled: c,
		onCheckedChange: n,
		"aria-label": r ? void 0 : g,
		"aria-labelledby": r ? b : void 0,
		"aria-describedby": x,
		"data-slot": "checkbox",
		className: C,
		children: /* @__PURE__ */ l(W, {
			forceMount: !0,
			className: "flex items-center justify-center",
			children: S ? /* @__PURE__ */ l(d, {
				className: w,
				strokeWidth: 3,
				"aria-hidden": "true"
			}) : e === !0 ? /* @__PURE__ */ l(t, {
				className: w,
				strokeWidth: 3,
				"aria-hidden": "true"
			}) : null
		})
	});
	return !r && !o ? /* @__PURE__ */ l("span", {
		"data-slot": "checkbox",
		className: m,
		children: T
	}) : /* @__PURE__ */ u("div", {
		"data-slot": "checkbox",
		className: i("flex gap-2", o ? "items-start" : "items-center", m),
		children: [T, /* @__PURE__ */ u("div", {
			className: "flex min-w-0 flex-col gap-0.5",
			children: [r ? /* @__PURE__ */ l(a, {
				as: "label",
				variant: "body-medium-lighter",
				id: b,
				htmlFor: y,
				className: i("cursor-pointer select-none", c ? "cursor-not-allowed text-[color:var(--content-disabled)]" : "text-[color:var(--content-default)]"),
				children: r
			}) : null, o ? /* @__PURE__ */ l("span", {
				id: x,
				className: "text-body-small-default text-[color:var(--content-tertiary)]",
				children: o
			}) : null]
		})]
	});
}
//#endregion
export { X as t };
