import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { t } from "./confirm-dialog-DH3yi6Nk.js";
import { r as n } from "./i18n-BRf-wfgm.js";
import { r } from "./api-DnMWUBLS.js";
import { a as i, o as a } from "./assistant-selection-ZCXVlG5B.js";
import { jsx as o } from "react/jsx-runtime";
var s = e("cloud-off", [
	["path", {
		d: "M10.94 5.274A7 7 0 0 1 15.71 10h1.79a4.5 4.5 0 0 1 4.222 6.057",
		key: "1uxyv8"
	}],
	["path", {
		d: "M18.796 18.81A4.5 4.5 0 0 1 17.5 19H9A7 7 0 0 1 5.79 5.78",
		key: "99tcn7"
	}],
	["path", {
		d: "m2 2 20 20",
		key: "1ooewy"
	}]
]);
//#endregion
//#region src/components/retire-confirm-dialog.tsx
function c({ open: e, error: r, isPending: i, onConfirm: a, onCancel: s }) {
	let { t: c } = n();
	return /* @__PURE__ */ o(t, {
		open: e,
		title: c("retireConfirmDialog.title"),
		message: c("retireConfirmDialog.message"),
		error: r,
		confirmLabel: c("retireConfirmDialog.confirmLabel"),
		destructive: !0,
		isPending: i,
		onConfirm: a,
		onCancel: s
	});
}
//#endregion
//#region src/assistant/retire-assistant.ts
async function l(e) {
	let t = await r(e);
	return !t.ok && t.status !== 404 ? {
		ok: !1,
		error: t.error.detail
	} : (a() === e && i(), { ok: !0 });
}
//#endregion
export { c as n, s as r, l as t };
