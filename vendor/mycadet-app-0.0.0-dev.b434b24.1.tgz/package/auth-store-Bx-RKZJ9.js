import { t as e } from "./electron-bridge-VOSuV45z.js";
import { i as t, n, r, t as i } from "./session-token-HN3JX-0v.js";
import { h as a, i as o, l as s, o as c, p as l, r as u } from "./schemas-D8_brjAQ.js";
import { a as d, c as f, d as p } from "./i18n-BRf-wfgm.js";
import { r as m } from "./routes-DW44XTQk.js";
import { r as h } from "./dist-BTjb3IwJ.js";
import { t as g } from "./native-platform-B_Xfpl9d.js";
import { useEffect as _, useSyncExternalStore as v } from "react";
//#region ../../node_modules/.bun/@capacitor+app@8.1.0+33da1c2fb16abc29/node_modules/@capacitor/app/dist/esm/index.js
var y = h("App", { web: () => import("./web-CurgxicO.js").then((e) => new e.AppWeb()) }), b = 0;
function x() {
	b++;
	let e = !1;
	return () => {
		e || (e = !0, b--);
	};
}
function S() {
	return b > 0;
}
//#endregion
//#region src/lib/auth/auth-response.ts
var C = s({
	id: l(),
	is_pending: o().optional()
}), w = s({
	id: l().optional(),
	display: l().optional(),
	email: l().optional(),
	username: l().optional(),
	is_staff: o().optional(),
	first_name: l().optional(),
	last_name: l().optional()
}), T = s({ user: w.nullable().optional() }), E = s({ user: w }), D = s({
	errors: u(s({
		code: l(),
		message: l(),
		param: l().optional()
	})).optional(),
	data: s({ flows: u(C).optional() }).optional()
});
function O(e, t) {
	let n = D.safeParse(e);
	if (!n.success) return {
		ok: !1,
		status: t,
		errors: []
	};
	if (n.data.errors) return {
		ok: !1,
		status: t,
		errors: n.data.errors
	};
	let r = n.data.data?.flows;
	return {
		ok: !1,
		status: t,
		errors: [],
		...r ? { flows: r } : {}
	};
}
//#endregion
//#region src/lib/auth/auth-request.ts
async function k(a, o, c, l) {
	try {
		let u = new Headers({
			Accept: "application/json",
			"Accept-Language": d()
		}), f = l?.method ?? (c === void 0 ? "GET" : "POST"), p = i();
		if (p && u.set("X-Session-Token", p), f !== "GET" && (c !== void 0 && u.set("Content-Type", "application/json"), !e())) {
			await n();
			let e = r();
			e && u.set("X-CSRFToken", e);
		}
		let m = await fetch(t(a), {
			method: f,
			headers: u,
			credentials: "same-origin",
			...l?.signal ? { signal: l.signal } : {},
			...c === void 0 ? {} : { body: JSON.stringify(c) }
		}), h = await m.json().catch(() => null), g = s({ data: o }).safeParse(h);
		return m.ok && g.success ? {
			ok: !0,
			data: g.data.data
		} : O(h, m.status);
	} catch {
		return {
			ok: !1,
			errors: []
		};
	}
}
//#endregion
//#region src/lib/auth/session-client.ts
function A(e) {
	return k("auth/session", T, void 0, { signal: e });
}
async function j() {
	let e = await k("auth/session", a(), void 0, { method: "DELETE" });
	if (!(e.ok || !e.ok && (e.status === 401 || e.status !== void 0 && e.status >= 200 && e.status < 300))) throw Error("Unable to sign out of the cloud account.");
}
//#endregion
//#region src/runtime/native-biometric.ts
var M = h("NativeBiometric");
({
	faceId: "Face ID",
	touchId: "Touch ID",
	opticId: "Optic ID",
	fingerprint: "your fingerprint",
	face: "face recognition",
	biometric: "biometrics",
	none: "biometrics"
}).none;
function N() {
	return new URL(window.location.origin).origin;
}
async function P(e) {
	if (!g()) return !1;
	try {
		return await M.storeToken({
			token: e,
			server: N()
		}), !0;
	} catch (e) {
		return console.error("[native-biometric] failed to store token:", e), !1;
	}
}
async function F() {
	if (g()) for (let e of [N(), m]) try {
		await M.deleteToken({ server: e });
	} catch {}
}
function I() {
	return f("biometricEnabled", !0);
}
function L(e) {
	p("biometricEnabled", e);
}
//#endregion
//#region src/lib/auth/logout-account.ts
async function R() {
	try {
		await j();
	} finally {
		let t = e();
		await Promise.allSettled([
			Promise.resolve().then(() => t?.auth?.signOut?.()),
			F(),
			t ? Promise.resolve() : fetch("/v1/session", { method: "DELETE" })
		]);
	}
}
//#endregion
//#region src/stores/account-user-snapshot.ts
var z = "cadet:account:userSnapshot", B = s({
	kind: c("cloud"),
	id: l().nullable().catch(null),
	username: l().nullable().catch(null),
	email: l().nullable().catch(null),
	isStaff: o().catch(!1),
	firstName: l().catch(""),
	lastName: l().catch("")
}), V = {
	read() {
		try {
			let e = JSON.parse(localStorage.getItem(z) ?? "null"), t = B.safeParse(e);
			return t.success ? {
				...t.data,
				kind: "cloud"
			} : null;
		} catch {
			return null;
		}
	},
	write(e) {
		if (e.kind === "cloud") try {
			localStorage.setItem(z, JSON.stringify(e));
		} catch {}
	},
	clear() {
		try {
			localStorage.removeItem(z);
		} catch {}
	}
};
//#endregion
//#region src/stores/account-user.ts
function H(e) {
	return {
		kind: "cloud",
		id: e.id ?? e.email ?? e.username ?? null,
		username: e.username ?? null,
		email: e.email ?? null,
		isStaff: e.is_staff ?? !1,
		firstName: e.first_name ?? "",
		lastName: e.last_name ?? ""
	};
}
//#endregion
//#region src/stores/account-session-policy.ts
function U(e) {
	return !e.ok && e.status !== void 0 && [
		401,
		403,
		410
	].includes(e.status);
}
//#endregion
//#region src/stores/account-session-source.ts
function W(e) {
	let t = /* @__PURE__ */ new Set(), n, r = 0, i = 0, a = 0, o, s, c, l;
	function u(e) {
		l = {
			...l,
			...e
		}, t.forEach((e) => e());
	}
	function d() {
		r++, a++, s?.abort(), o = void 0, c = void 0, e.snapshot.clear(), u({
			user: null,
			sessionStatus: "unauthenticated",
			cloudSession: "absent"
		});
		let t = !1;
		return () => {
			t || (t = !0, r++, a--, e.snapshot.clear());
		};
	}
	function f(t = !1) {
		if (a > 0) return Promise.resolve(!1);
		if (o && !t) return o;
		t && s?.abort();
		let n = new AbortController();
		s = n;
		let c = r, d = ++i, f = (async () => {
			let t, a = setTimeout(() => n.abort(), e.probeTimeoutMs ?? 5e3);
			try {
				t = await e.getSession(n.signal);
			} catch {
				t = {
					ok: !1,
					errors: []
				};
			} finally {
				clearTimeout(a);
			}
			if (c !== r || d !== i) return !1;
			if (t.ok && t.data.user) {
				let n = H(t.data.user);
				return e.snapshot.write(n), u({
					user: n,
					sessionStatus: "authenticated",
					cloudSession: "present"
				}), !0;
			}
			if (t.ok || U(t)) return e.snapshot.clear(), u({
				user: null,
				sessionStatus: "unauthenticated",
				cloudSession: "absent"
			}), !1;
			if (l.sessionStatus === "initializing") {
				let t = e.snapshot.read(), n = t?.kind === "cloud" ? t : null;
				u({
					user: n,
					sessionStatus: n ? "authenticated" : "unauthenticated",
					cloudSession: n ? "present" : "unknown"
				});
			}
			return l.sessionStatus === "authenticated";
		})();
		o = f;
		let p = () => {
			o === f && (o = void 0), s === n && (s = void 0);
		};
		return f.then(p, p), f;
	}
	return l = {
		user: null,
		sessionStatus: "initializing",
		cloudSession: "unknown",
		initSession() {
			return n ??= f().then(() => {}), n;
		},
		refreshSession() {
			if (a > 0) return Promise.resolve(!1);
			if (c) return c;
			let e = r, t = (async () => (await f(!0), e !== r || a > 0 ? !1 : e === r && l.sessionStatus === "authenticated"))();
			c = t;
			let n = () => {
				c === t && (c = void 0);
			};
			return t.then(n, n), t;
		},
		async logout() {
			let t = d();
			try {
				await e.logout();
			} finally {
				t();
			}
		}
	}, {
		getSnapshot: () => l,
		subscribe(e) {
			return t.add(e), () => {
				t.delete(e);
			};
		},
		observeSession: f
	};
}
//#endregion
//#region src/stores/account-auth-source.ts
var G = W({
	getSession: A,
	snapshot: V,
	logout: R
}), K = 0, q;
function J() {
	if (K++ === 0) {
		let e = !1, t = () => {
			!e && !S() && G.observeSession().catch((e) => console.warn("account session probe failed", e));
		}, n = () => {
			document.visibilityState === "visible" && t();
		};
		window.addEventListener("online", t), document.addEventListener("visibilitychange", n);
		let r = g() ? y.addListener("appStateChange", (e) => {
			e.isActive && t();
		}).catch(() => void 0) : void 0;
		t(), q = () => {
			e || (e = !0, window.removeEventListener("online", t), document.removeEventListener("visibilitychange", n), r && r.then((e) => e?.remove()).catch(() => {}));
		};
	}
	let e = !1;
	return () => {
		e || (e = !0, --K === 0 && (q?.(), q = void 0));
	};
}
//#endregion
//#region src/stores/auth-store.ts
function Y(e) {
	_(() => (G.getSnapshot().initSession().catch((e) => console.warn("account session initialization failed", e)), J()), []);
	let t = () => e(G.getSnapshot());
	return v(G.subscribe, t, t);
}
var X = Object.assign(Y, {
	getState: G.getSnapshot,
	use: {
		user: () => Y((e) => e.user),
		logout: () => Y((e) => e.logout),
		refreshSession: () => Y((e) => e.refreshSession)
	}
});
function Z() {
	return Y((e) => e.sessionStatus === "authenticated");
}
function Q() {
	return Y((e) => e.sessionStatus === "initializing");
}
//#endregion
export { L as a, k as c, x as d, S as f, I as i, E as l, Z as n, P as o, Q as r, A as s, X as t, T as u };
