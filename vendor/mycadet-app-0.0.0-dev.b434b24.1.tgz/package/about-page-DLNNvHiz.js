import { o as e } from "./dist-CB0DYkRa.js";
import { t } from "./electron-bridge-VOSuV45z.js";
import { r as n } from "./i18n-BRf-wfgm.js";
import { t as r } from "./is-electron-CTF8PPHw.js";
import { t as i } from "./dist-BTjb3IwJ.js";
import { t as a } from "./native-platform-B_Xfpl9d.js";
import { t as o } from "./text-link-DoFyv9Mp.js";
import { useEffect as s, useState as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/runtime/client-os.ts
function d() {
	if (t()) {
		if (typeof navigator > "u") return "web";
		let e = navigator.platform.toLowerCase();
		return e.includes("win") ? "windows" : e.includes("linux") ? "linux" : "macos";
	}
	if (a()) return i.getPlatform() === "android" ? "android" : "ios";
	if (typeof navigator < "u") {
		if (/iPhone|iPod/.test(navigator.userAgent) || /iPad/.test(navigator.userAgent) || /Mac/.test(navigator.platform) && navigator.maxTouchPoints > 1) return "ios";
		if (/Android/i.test(navigator.userAgent)) return "android";
	}
	return "web";
}
//#endregion
//#region src/components/about-page.tsx
function f() {
	let { t } = n(), i = d() === "windows", [a, f] = c(null);
	s(() => {
		r() && window.cadet?.app.versionInfo().then(f);
	}, []);
	let m = a ?? p;
	return /* @__PURE__ */ u("div", {
		className: "flex h-svh w-screen flex-col items-center justify-center bg-background px-8 pt-14 pb-8 text-center text-foreground select-none",
		children: [
			/* @__PURE__ */ l("h1", {
				className: "mt-4 text-2xl font-semibold",
				children: m.appName
			}),
			/* @__PURE__ */ l("p", {
				className: "text-muted-foreground mt-1 mb-7 text-xs",
				children: t(i ? "aboutPage.taglineWindows" : "aboutPage.taglineMacOS")
			}),
			/* @__PURE__ */ u("dl", {
				className: "mb-7 grid grid-cols-[auto_auto] gap-x-4 gap-y-1.5 text-sm",
				children: [
					/* @__PURE__ */ l("dt", {
						className: "text-muted-foreground text-right",
						children: t("aboutPage.version")
					}),
					/* @__PURE__ */ l("dd", {
						className: "text-left font-mono tabular-nums select-text",
						children: m.version
					}),
					/* @__PURE__ */ l("dt", {
						className: "text-muted-foreground text-right",
						children: t("aboutPage.build")
					}),
					/* @__PURE__ */ l("dd", {
						className: "text-left font-mono tabular-nums select-text",
						children: m.commitSha
					})
				]
			}),
			/* @__PURE__ */ l("a", {
				href: m.website,
				className: e(o(), "text-sm"),
				onClick: (e) => {
					r() && (e.preventDefault(), window.cadet?.app.openWebsite());
				},
				children: new URL(m.website).host
			}),
			/* @__PURE__ */ l("div", {
				className: "text-muted-foreground mt-auto pt-6 text-[11px]",
				children: m.copyright
			})
		]
	});
}
var p = {
	appName: "Cadet",
	version: "—",
	commitSha: "—",
	copyright: `© ${(/* @__PURE__ */ new Date()).getFullYear()} Cadet`,
	website: "https://mycadet.ai"
};
//#endregion
export { f as AboutPage };
