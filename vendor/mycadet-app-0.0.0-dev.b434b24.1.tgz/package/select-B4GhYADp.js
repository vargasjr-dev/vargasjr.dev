import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { t } from "./check-DPXe7vV_.js";
import { o as n } from "./dist-CB0DYkRa.js";
import { _ as r, b as i, g as a, h as o, i as s, m as c, n as l, p as u, v as d, x as f, y as p } from "./button-BrPHE1Q9.js";
import { a as m, i as h, n as g, t as _ } from "./es2015-B_BDkut6.js";
import * as v from "react";
import { useId as y } from "react";
import * as b from "react-dom";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
var ee = e("chevron-down", [["path", {
	d: "m6 9 6 6 6-6",
	key: "qrunsl"
}]]), w = Object.defineProperty, T = (e, t) => w(e, "name", {
	value: t,
	configurable: !0
});
function E(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
T(E, "clamp");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+primitive@1.1.7/node_modules/@radix-ui/primitive/dist/index.mjs
var D = Object.defineProperty, O = (e, t) => D(e, "name", {
	value: t,
	configurable: !0
}), k = !!(typeof window < "u" && window.document && window.document.createElement);
function A(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return /* @__PURE__ */ O(function(r) {
		if (e?.(r), n === !1 || !r || !r.defaultPrevented) return t?.(r);
	}, "handleEvent");
}
O(A, "composeEventHandlers");
function te(e) {
	if (!k) throw Error("Cannot access window outside of the DOM");
	return e?.ownerDocument?.defaultView ?? window;
}
O(te, "getOwnerWindow");
function j(e) {
	if (!k) throw Error("Cannot access document outside of the DOM");
	return e?.ownerDocument ?? document;
}
O(j, "getOwnerDocument");
function M(e, t = !1) {
	let { activeElement: n } = j(e);
	if (!n?.nodeName) return null;
	if (N(n) && n.contentDocument) return M(n.contentDocument.body, t);
	if (t) {
		let e = n.getAttribute("aria-activedescendant");
		if (e) {
			let t = j(n).getElementById(e);
			if (t) return t;
		}
	}
	return n;
}
O(M, "getActiveElement");
function N(e) {
	return e.tagName === "IFRAME";
}
O(N, "isFrame");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-context@1.2.2+bf264c7668a20073/node_modules/@radix-ui/react-context/dist/index.mjs
var ne = Object.defineProperty, P = (e, t) => ne(e, "name", {
	value: t,
	configurable: !0
});
/* @__NO_SIDE_EFFECTS__ */
function F(e, t) {
	let n = v.createContext(t);
	n.displayName = e + "Context";
	let r = /* @__PURE__ */ P((e) => {
		let { children: t, ...r } = e, i = v.useMemo(() => r, Object.values(r));
		return /* @__PURE__ */ S(n.Provider, {
			value: i,
			children: t
		});
	}, "Provider");
	r.displayName = e + "Provider";
	function i(r, i = {}) {
		let { optional: a = !1 } = i, o = v.useContext(n);
		if (o) return o;
		if (t !== void 0) return t;
		if (!a) throw Error(`\`${r}\` must be used within \`${e}\``);
	}
	return P(i, "useContext"), [r, i];
}
P(F, "createContext");
/* @__NO_SIDE_EFFECTS__ */
function I(e, t = []) {
	let n = [];
	function r(t, r) {
		let i = v.createContext(r);
		i.displayName = t + "Context";
		let a = n.length;
		n = [...n, r];
		let o = /* @__PURE__ */ P((t) => {
			let { scope: n, children: r, ...o } = t, s = n?.[e]?.[a] || i, c = v.useMemo(() => o, Object.values(o));
			return /* @__PURE__ */ S(s.Provider, {
				value: c,
				children: r
			});
		}, "Provider");
		o.displayName = t + "Provider";
		function s(n, o, s = {}) {
			let { optional: c = !1 } = s, l = o?.[e]?.[a] || i, u = v.useContext(l);
			if (u) return u;
			if (r !== void 0) return r;
			if (!c) throw Error(`\`${n}\` must be used within \`${t}\``);
		}
		return P(s, "useContext"), [o, s];
	}
	P(r, "createContext");
	let i = /* @__PURE__ */ P(() => {
		let t = n.map((e) => v.createContext(e));
		return /* @__PURE__ */ P(function(n) {
			let r = n?.[e] || t;
			return v.useMemo(() => ({ [`__scope${e}`]: {
				...n,
				[e]: r
			} }), [n, r]);
		}, "useScope");
	}, "createScope");
	return i.scopeName = e, [r, L(i, ...t)];
}
P(I, "createContextScope");
function L(...e) {
	let t = e[0];
	if (e.length === 1) return t;
	let n = /* @__PURE__ */ P(() => {
		let n = e.map((e) => ({
			useScope: e(),
			scopeName: e.scopeName
		}));
		return /* @__PURE__ */ P(function(e) {
			let r = n.reduce((t, { useScope: n, scopeName: r }) => {
				let i = n(e)[`__scope${r}`];
				return {
					...t,
					...i
				};
			}, {});
			return v.useMemo(() => ({ [`__scope${t.scopeName}`]: r }), [r]);
		}, "useComposedScopes");
	}, "createScope");
	return n.scopeName = t.scopeName, n;
}
P(L, "composeContextScopes");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-compose-refs@1.1.5+bf264c7668a20073/node_modules/@radix-ui/react-compose-refs/dist/index.mjs
var re = Object.defineProperty, R = (e, t) => re(e, "name", {
	value: t,
	configurable: !0
});
function z(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
R(z, "setRef");
function B(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = z(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : z(e[t], null);
			}
		};
	};
}
R(B, "composeRefs");
function V(...e) {
	return v.useCallback(B(...e), e);
}
R(V, "useComposedRefs");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-slot@1.3.3+bf264c7668a20073/node_modules/@radix-ui/react-slot/dist/index.mjs
var ie = Object.defineProperty, H = (e, t) => ie(e, "name", {
	value: t,
	configurable: !0
});
/* @__NO_SIDE_EFFECTS__ */
function U(e) {
	let t = v.forwardRef((t, n) => {
		let { children: r, ...i } = t, a = null, o = !1, s = [];
		fe(r) && typeof ge == "function" && (r = ge(r._payload)), v.Children.forEach(r, (e) => {
			if (ue(e)) {
				o = !0;
				let t = e, n = "child" in t.props ? t.props.child : t.props.children;
				fe(n) && typeof ge == "function" && (n = ge(n._payload)), a = se(t, n), s.push(a?.props?.children);
			} else s.push(e);
		}), a ? a = v.cloneElement(a, void 0, s) : !o && v.Children.count(r) === 1 && v.isValidElement(r) && (a = r);
		let c = a ? le(a) : void 0, l = V(n, c);
		if (!a) {
			if (r || r === 0) throw Error(o ? he(e) : me(e));
			return r;
		}
		let u = ce(i, a.props ?? {});
		return a.type !== v.Fragment && (u.ref = n ? l : c), v.cloneElement(a, u);
	});
	return t.displayName = `${e}.Slot`, t;
}
H(U, "createSlot");
var ae = Symbol.for("radix.slottable");
/* @__NO_SIDE_EFFECTS__ */
function oe(e) {
	let t = /* @__PURE__ */ H((e) => "child" in e ? e.children(e.child) : e.children, "Slottable");
	return t.displayName = `${e}.Slottable`, t.__radixId = ae, t;
}
H(oe, "createSlottable");
var se = /* @__PURE__ */ H((e, t) => {
	if ("child" in e.props) {
		let t = e.props.child;
		return v.isValidElement(t) ? v.cloneElement(t, void 0, e.props.children(t.props.children)) : null;
	}
	return v.isValidElement(t) ? t : null;
}, "getSlottableElementFromSlottable");
function ce(e, t) {
	let n = { ...t };
	for (let r in t) {
		let i = e[r], a = t[r];
		/^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
			let t = a(...e);
			return i(...e), t;
		} : i && (n[r] = i) : r === "style" ? n[r] = {
			...i,
			...a
		} : r === "className" && (n[r] = [i, a].filter(Boolean).join(" "));
	}
	return {
		...e,
		...n
	};
}
H(ce, "mergeProps");
function le(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
H(le, "getElementRef");
function ue(e) {
	return v.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === ae;
}
H(ue, "isSlottable");
var de = Symbol.for("react.lazy");
function fe(e) {
	return typeof e == "object" && !!e && "$$typeof" in e && e.$$typeof === de && "_payload" in e && pe(e._payload);
}
H(fe, "isLazyComponent");
function pe(e) {
	return typeof e == "object" && !!e && "then" in e;
}
H(pe, "isPromiseLike");
var me = /* @__PURE__ */ H((e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, "createSlotError"), he = /* @__PURE__ */ H((e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, "createSlottableError"), ge = v.use, _e = Object.defineProperty, W = (e, t) => _e(e, "name", {
	value: t,
	configurable: !0
});
/* @__NO_SIDE_EFFECTS__ */
function ve(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ I(t), [i, a] = n(t, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	}), o = /* @__PURE__ */ W((e) => {
		let { scope: t, children: n } = e, r = v.useRef(null), a = v.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ S(i, {
			scope: t,
			itemMap: a,
			collectionRef: r,
			children: n
		});
	}, "CollectionProvider");
	o.displayName = t;
	let s = e + "CollectionSlot", c = /* @__PURE__ */ U(s), l = v.forwardRef((e, t) => {
		let { scope: n, children: r } = e;
		return /* @__PURE__ */ S(c, {
			ref: V(t, a(s, n).collectionRef),
			children: r
		});
	});
	l.displayName = s;
	let u = e + "CollectionItemSlot", d = "data-radix-collection-item", f = /* @__PURE__ */ U(u), p = v.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = v.useRef(null), s = V(t, o), c = a(u, n);
		return v.useEffect(() => (c.itemMap.set(o, {
			ref: o,
			...i
		}), () => void c.itemMap.delete(o))), /* @__PURE__ */ S(f, {
			[d]: "",
			ref: s,
			children: r
		});
	});
	p.displayName = u;
	function m(t) {
		let n = a(e + "CollectionConsumer", t);
		return v.useCallback(() => {
			let e = n.collectionRef.current;
			if (!e) return [];
			let t = Array.from(e.querySelectorAll(`[${d}]`));
			return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
		}, [n.collectionRef, n.itemMap]);
	}
	return W(m, "useCollection"), [
		{
			Provider: o,
			Slot: l,
			ItemSlot: p
		},
		m,
		r
	];
}
W(ve, "createCollection");
var ye = /* @__PURE__ */ new WeakMap(), be = class e extends Map {
	static {
		W(this, "OrderedDict");
	}
	#e;
	constructor(e) {
		super(e), this.#e = [...super.keys()], ye.set(this, !0);
	}
	set(e, t) {
		return ye.get(this) && (this.has(e) ? this.#e[this.#e.indexOf(e)] = e : this.#e.push(e)), super.set(e, t), this;
	}
	insert(e, t, n) {
		let r = this.has(t), i = this.#e.length, a = Ce(e), o = a >= 0 ? a : i + a, s = o < 0 || o >= i ? -1 : o;
		if (s === this.size || r && s === this.size - 1 || s === -1) return this.set(t, n), this;
		let c = this.size + +!r;
		a < 0 && o++;
		let l = [...this.#e], u, d = !1;
		for (let e = o; e < c; e++) if (o === e) {
			let i = l[e];
			l[e] === t && (i = l[e + 1]), r && this.delete(t), u = this.get(i), this.set(t, n);
		} else {
			!d && l[e - 1] === t && (d = !0);
			let n = l[d ? e : e - 1], r = u;
			u = this.get(n), this.delete(n), this.set(n, r);
		}
		return this;
	}
	with(t, n, r) {
		let i = new e(this);
		return i.insert(t, n, r), i;
	}
	before(e) {
		let t = this.#e.indexOf(e) - 1;
		if (!(t < 0)) return this.entryAt(t);
	}
	setBefore(e, t, n) {
		let r = this.#e.indexOf(e);
		return r === -1 ? this : this.insert(r, t, n);
	}
	after(e) {
		let t = this.#e.indexOf(e);
		if (t = t === -1 || t === this.size - 1 ? -1 : t + 1, t !== -1) return this.entryAt(t);
	}
	setAfter(e, t, n) {
		let r = this.#e.indexOf(e);
		return r === -1 ? this : this.insert(r + 1, t, n);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		return this.#e = [], super.clear();
	}
	delete(e) {
		let t = super.delete(e);
		return t && this.#e.splice(this.#e.indexOf(e), 1), t;
	}
	deleteAt(e) {
		let t = this.keyAt(e);
		return t === void 0 ? !1 : this.delete(t);
	}
	at(e) {
		let t = xe(this.#e, e);
		if (t !== void 0) return this.get(t);
	}
	entryAt(e) {
		let t = xe(this.#e, e);
		if (t !== void 0) return [t, this.get(t)];
	}
	indexOf(e) {
		return this.#e.indexOf(e);
	}
	keyAt(e) {
		return xe(this.#e, e);
	}
	from(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.at(r);
	}
	keyFrom(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.keyAt(r);
	}
	find(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return r;
			n++;
		}
	}
	findIndex(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return n;
			n++;
		}
		return -1;
	}
	filter(t, n) {
		let r = [], i = 0;
		for (let e of this) Reflect.apply(t, n, [
			e,
			i,
			this
		]) && r.push(e), i++;
		return new e(r);
	}
	map(t, n) {
		let r = [], i = 0;
		for (let e of this) r.push([e[0], Reflect.apply(t, n, [
			e,
			i,
			this
		])]), i++;
		return new e(r);
	}
	reduce(...e) {
		let [t, n] = e, r = 0, i = n ?? this.at(0);
		for (let n of this) i = r === 0 && e.length === 1 ? n : Reflect.apply(t, this, [
			i,
			n,
			r,
			this
		]), r++;
		return i;
	}
	reduceRight(...e) {
		let [t, n] = e, r = n ?? this.at(-1);
		for (let n = this.size - 1; n >= 0; n--) {
			let i = this.at(n);
			r = n === this.size - 1 && e.length === 1 ? i : Reflect.apply(t, this, [
				r,
				i,
				n,
				this
			]);
		}
		return r;
	}
	toSorted(t) {
		return new e([...this.entries()].sort(t));
	}
	toReversed() {
		let t = new e();
		for (let e = this.size - 1; e >= 0; e--) {
			let n = this.keyAt(e), r = this.get(n);
			t.set(n, r);
		}
		return t;
	}
	toSpliced(...t) {
		let n = [...this.entries()];
		return n.splice(...t), new e(n);
	}
	slice(t, n) {
		let r = new e(), i = this.size - 1;
		if (t === void 0) return r;
		t < 0 && (t += this.size), n !== void 0 && n > 0 && (i = n - 1);
		for (let e = t; e <= i; e++) {
			let t = this.keyAt(e), n = this.get(t);
			r.set(t, n);
		}
		return r;
	}
	every(e, t) {
		let n = 0;
		for (let r of this) {
			if (!Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !1;
			n++;
		}
		return !0;
	}
	some(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !0;
			n++;
		}
		return !1;
	}
};
function xe(e, t) {
	if ("at" in Array.prototype) return Array.prototype.at.call(e, t);
	let n = Se(e, t);
	return n === -1 ? void 0 : e[n];
}
W(xe, "at");
function Se(e, t) {
	let n = e.length, r = Ce(t), i = r >= 0 ? r : n + r;
	return i < 0 || i >= n ? -1 : i;
}
W(Se, "toSafeIndex");
function Ce(e) {
	return e !== e || e === 0 ? 0 : Math.trunc(e);
}
W(Ce, "toSafeInteger");
/* @__NO_SIDE_EFFECTS__ */
function we(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ I(t), [i, a] = n(t, {
		collectionElement: null,
		collectionRef: { current: null },
		collectionRefObject: { current: null },
		itemMap: new be(),
		setItemMap: /* @__PURE__ */ W(() => void 0, "setItemMap")
	}), o = /* @__PURE__ */ W(({ state: e, ...t }) => e ? /* @__PURE__ */ S(c, {
		...t,
		state: e
	}) : /* @__PURE__ */ S(s, { ...t }), "CollectionProvider");
	o.displayName = t;
	let s = /* @__PURE__ */ W((e) => {
		let t = h();
		return /* @__PURE__ */ S(c, {
			...e,
			state: t
		});
	}, "CollectionInit");
	s.displayName = t + "Init";
	let c = /* @__PURE__ */ W((e) => {
		let { scope: t, children: n, state: r } = e, a = v.useRef(null), [o, s] = v.useState(null), c = V(a, s), [l, u] = r;
		return v.useEffect(() => {
			if (!o) return;
			let e = Oe(() => {});
			return e.observe(o, {
				childList: !0,
				subtree: !0
			}), () => {
				e.disconnect();
			};
		}, [o]), /* @__PURE__ */ S(i, {
			scope: t,
			itemMap: l,
			setItemMap: u,
			collectionRef: c,
			collectionRefObject: a,
			collectionElement: o,
			children: n
		});
	}, "CollectionProviderImpl");
	c.displayName = t + "Impl";
	let l = e + "CollectionSlot", u = /* @__PURE__ */ U(l), d = v.forwardRef((e, t) => {
		let { scope: n, children: r } = e;
		return /* @__PURE__ */ S(u, {
			ref: V(t, a(l, n).collectionRef),
			children: r
		});
	});
	d.displayName = l;
	let f = e + "CollectionItemSlot", p = /* @__PURE__ */ U(f), m = v.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = v.useRef(null), [s, c] = v.useState(null), l = V(t, o, c), { setItemMap: u } = a(f, n), d = v.useRef(i);
		Te(d.current, i) || (d.current = i);
		let m = d.current;
		return v.useEffect(() => {
			let e = m;
			return u((t) => s ? t.has(s) ? t.set(s, {
				...e,
				element: s
			}).toSorted(De) : (t.set(s, {
				...e,
				element: s
			}), t.toSorted(De)) : t), () => {
				u((e) => !s || !e.has(s) ? e : (e.delete(s), new be(e)));
			};
		}, [
			s,
			m,
			u
		]), /* @__PURE__ */ S(p, {
			"data-radix-collection-item": "",
			ref: l,
			children: r
		});
	});
	m.displayName = f;
	function h() {
		return v.useState(new be());
	}
	W(h, "useInitCollection");
	function g(t) {
		let { itemMap: n } = a(e + "CollectionConsumer", t);
		return n;
	}
	return W(g, "useCollection"), [{
		Provider: o,
		Slot: d,
		ItemSlot: m
	}, {
		createCollectionScope: r,
		useCollection: g,
		useInitCollection: h
	}];
}
W(we, "createCollection");
function Te(e, t) {
	if (e === t) return !0;
	if (typeof e != "object" || typeof t != "object" || e == null || t == null) return !1;
	let n = Object.keys(e), r = Object.keys(t);
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
	return !0;
}
W(Te, "shallowEqual");
function Ee(e, t) {
	return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING);
}
W(Ee, "isElementPreceding");
function De(e, t) {
	return !e[1].element || !t[1].element ? 0 : Ee(e[1].element, t[1].element) ? -1 : 1;
}
W(De, "sortByDocumentPosition");
function Oe(e) {
	return new MutationObserver((t) => {
		for (let n of t) if (n.type === "childList") {
			e();
			return;
		}
	});
}
W(Oe, "getChildListObserver");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-direction@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-direction/dist/index.mjs
var ke = Object.defineProperty, Ae = (e, t) => ke(e, "name", {
	value: t,
	configurable: !0
}), je = v.createContext(void 0);
function Me(e) {
	let t = v.useContext(je);
	return e || t || "ltr";
}
Ae(Me, "useDirection");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-primitive@2.1.10+07ecf1aa3bcbed22/node_modules/@radix-ui/react-primitive/dist/index.mjs
var Ne = Object.defineProperty, Pe = (e, t) => Ne(e, "name", {
	value: t,
	configurable: !0
}), G = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((e, t) => {
	let n = /* @__PURE__ */ U(`Primitive.${t}`), r = v.forwardRef((e, r) => {
		let { asChild: i, ...a } = e, o = i ? n : t;
		return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ S(o, {
			...a,
			ref: r
		});
	});
	return r.displayName = `Primitive.${t}`, {
		...e,
		[t]: r
	};
}, {});
function Fe(e, t) {
	e && b.flushSync(() => e.dispatchEvent(t));
}
Pe(Fe, "dispatchDiscreteCustomEvent");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-callback-ref@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var Ie = Object.defineProperty, Le = (e, t) => Ie(e, "name", {
	value: t,
	configurable: !0
});
function K(e) {
	let t = v.useRef(e);
	return v.useEffect(() => {
		t.current = e;
	}), v.useMemo(() => ((...e) => t.current?.(...e)), []);
}
Le(K, "useCallbackRef");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-dismissable-layer@1.1.19+07ecf1aa3bcbed22/node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var Re = Object.defineProperty, q = (e, t) => Re(e, "name", {
	value: t,
	configurable: !0
}), ze = "dismissableLayer.update", Be = "dismissableLayer.pointerDownOutside", Ve = "dismissableLayer.focusOutside", He, Ue = v.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
}), We = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ q(function(e, t) {
	let { disableOutsidePointerEvents: n = !1, deferPointerDownOutside: r = !1, onEscapeKeyDown: i, onPointerDownOutside: a, onFocusOutside: o, onInteractOutside: s, onDismiss: c, ...l } = e, u = v.useContext(Ue), [d, f] = v.useState(null), p = d?.ownerDocument ?? globalThis?.document, [, m] = v.useState({}), h = V(t, f), g = Array.from(u.layers), [_] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1), y = _ ? g.indexOf(_) : -1, b = d ? g.indexOf(d) : -1, x = u.layersWithOutsidePointerEventsDisabled.size > 0, C = b >= y, ee = v.useRef(!1), w = qe((e) => {
		a?.(e), s?.(e), e.defaultPrevented || c?.();
	}, {
		ownerDocument: p,
		deferPointerDownOutside: r,
		isDeferredPointerDownOutsideRef: ee,
		dismissableSurfaces: u.dismissableSurfaces,
		shouldHandlePointerDownOutside: v.useCallback((e) => {
			if (!(e instanceof Node)) return !1;
			let t = [...u.branches].some((t) => t.contains(e));
			return C && !t;
		}, [u.branches, C])
	}), T = Je((e) => {
		if (r && ee.current) return;
		let t = e.target;
		[...u.branches].some((e) => e.contains(t)) || (o?.(e), s?.(e), e.defaultPrevented || c?.());
	}, p), E = d ? b === g.length - 1 : !1, D = K((e) => {
		e.key === "Escape" && (i?.(e), !e.defaultPrevented && c && (e.preventDefault(), c()));
	});
	return v.useEffect(() => {
		if (E) return p.addEventListener("keydown", D, { capture: !0 }), () => p.removeEventListener("keydown", D, { capture: !0 });
	}, [
		p,
		E,
		D
	]), v.useEffect(() => {
		if (d) return n && (u.layersWithOutsidePointerEventsDisabled.size === 0 && (He = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), Ye(), () => {
			n && (u.layersWithOutsidePointerEventsDisabled.delete(d), u.layersWithOutsidePointerEventsDisabled.size === 0 && (p.body.style.pointerEvents = He));
		};
	}, [
		d,
		p,
		n,
		u
	]), v.useEffect(() => () => {
		d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), Ye());
	}, [d, u]), v.useEffect(() => {
		let e = /* @__PURE__ */ q(() => m({}), "handleUpdate");
		return document.addEventListener(ze, e), () => document.removeEventListener(ze, e);
	}, []), /* @__PURE__ */ S(G.div, {
		...l,
		ref: h,
		style: {
			pointerEvents: x ? C ? "auto" : "none" : void 0,
			...e.style
		},
		onFocusCapture: A(e.onFocusCapture, T.onFocusCapture),
		onBlurCapture: A(e.onBlurCapture, T.onBlurCapture),
		onPointerDownCapture: A(e.onPointerDownCapture, w.onPointerDownCapture)
	});
}, "DismissableLayer"));
function Ge() {
	let e = v.useContext(Ue), [t, n] = v.useState(null);
	return v.useEffect(() => {
		if (t) return e.dismissableSurfaces.add(t), () => {
			e.dismissableSurfaces.delete(t);
		};
	}, [t, e.dismissableSurfaces]), n;
}
q(Ge, "useDismissableLayerSurface");
var Ke = /* @__PURE__ */ q(() => !0, "IS_TRUE");
function qe(e, t) {
	let { ownerDocument: n = globalThis?.document, deferPointerDownOutside: r = !1, isDeferredPointerDownOutsideRef: i, dismissableSurfaces: a, shouldHandlePointerDownOutside: o = Ke } = t, s = K(e), c = v.useRef(!1), l = v.useRef(!1), u = v.useRef(/* @__PURE__ */ new Map()), d = v.useRef(() => {});
	return v.useEffect(() => {
		function e() {
			l.current = !1, i.current = !1, u.current.clear();
		}
		q(e, "resetOutsideInteraction");
		function t() {
			return Array.from(u.current.values()).some(Boolean);
		}
		q(t, "isOutsideInteractionIntercepted");
		function f(e) {
			if (!l.current) return;
			let t = e.target;
			t instanceof Node && [...a].some((e) => e.contains(t)) || u.current.set(e.type, !0), e.type === "click" && window.setTimeout(() => {
				l.current && d.current();
			}, 0);
		}
		q(f, "handleInteractionCapture");
		function p(e) {
			l.current && u.current.set(e.type, !1);
		}
		q(p, "handleInteractionBubble");
		let m = /* @__PURE__ */ q((a) => {
			if (a.target && !c.current) {
				let f = function() {
					n.removeEventListener("click", d.current);
					let r = t();
					e(), r || Xe(Be, s, p, { discrete: !0 });
				};
				if (q(f, "handleAndDispatchPointerDownOutsideEvent"), !o(a.target)) {
					n.removeEventListener("click", d.current), e(), c.current = !1;
					return;
				}
				let p = { originalEvent: a };
				l.current = !0, i.current = r && a.button === 0, u.current.clear(), !r || a.button !== 0 ? f() : (n.removeEventListener("click", d.current), d.current = f, n.addEventListener("click", d.current, { once: !0 }));
			} else n.removeEventListener("click", d.current), e();
			c.current = !1;
		}, "handlePointerDown"), h = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (let e of h) n.addEventListener(e, f, !0), n.addEventListener(e, p);
		let g = window.setTimeout(() => {
			n.addEventListener("pointerdown", m);
		}, 0);
		return () => {
			window.clearTimeout(g), n.removeEventListener("pointerdown", m), n.removeEventListener("click", d.current);
			for (let e of h) n.removeEventListener(e, f, !0), n.removeEventListener(e, p);
		};
	}, [
		n,
		s,
		r,
		i,
		a,
		o
	]), { onPointerDownCapture: /* @__PURE__ */ q(() => c.current = !0, "onPointerDownCapture") };
}
q(qe, "usePointerDownOutside");
function Je(e, t = globalThis?.document) {
	let n = K(e), r = v.useRef(!1);
	return v.useEffect(() => {
		let e = /* @__PURE__ */ q((e) => {
			e.target && !r.current && Xe(Ve, n, { originalEvent: e }, { discrete: !1 });
		}, "handleFocus");
		return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e);
	}, [t, n]), {
		onFocusCapture: /* @__PURE__ */ q(() => r.current = !0, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ q(() => r.current = !1, "onBlurCapture")
	};
}
q(Je, "useFocusOutside");
function Ye() {
	let e = new CustomEvent(ze);
	document.dispatchEvent(e);
}
q(Ye, "dispatchUpdate");
function Xe(e, t, n, { discrete: r }) {
	let i = n.originalEvent.target, a = new CustomEvent(e, {
		bubbles: !1,
		cancelable: !0,
		detail: n
	});
	t && i.addEventListener(e, t, { once: !0 }), r ? Fe(i, a) : i.dispatchEvent(a);
}
q(Xe, "handleAndDispatchCustomEvent");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-focus-guards@1.1.6+bf264c7668a20073/node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var Ze = Object.defineProperty, Qe = (e, t) => Ze(e, "name", {
	value: t,
	configurable: !0
}), $e = 0, et = null;
function tt(e) {
	return nt(), e.children;
}
Qe(tt, "FocusGuards");
function nt() {
	v.useEffect(() => {
		et ||= {
			start: rt(),
			end: rt()
		};
		let { start: e, end: t } = et;
		return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), $e++, () => {
			$e === 1 && (et?.start.remove(), et?.end.remove(), et = null), $e = Math.max(0, $e - 1);
		};
	}, []);
}
Qe(nt, "useFocusGuards");
function rt() {
	let e = document.createElement("span");
	return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
Qe(rt, "createFocusGuard");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-focus-scope@1.1.16+07ecf1aa3bcbed22/node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var it = Object.defineProperty, J = (e, t) => it(e, "name", {
	value: t,
	configurable: !0
}), at = "focusScope.autoFocusOnMount", ot = "focusScope.autoFocusOnUnmount", st = {
	bubbles: !1,
	cancelable: !0
}, ct = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ J(function(e, t) {
	let { loop: n = !1, trapped: r = !1, onMountAutoFocus: i, onUnmountAutoFocus: a, ...o } = e, [s, c] = v.useState(null), l = K(i), u = K(a), d = v.useRef(null), f = V(t, c), p = v.useRef({
		paused: !1,
		pause() {
			this.paused = !0;
		},
		resume() {
			this.paused = !1;
		}
	}).current;
	v.useEffect(() => {
		if (r) {
			let e = function(e) {
				if (p.paused || !s) return;
				let t = e.target;
				s.contains(t) ? d.current = t : Y(d.current, { select: !0 });
			}, t = function(e) {
				if (p.paused || !s) return;
				let t = e.relatedTarget;
				t !== null && (s.contains(t) || Y(d.current, { select: !0 }));
			}, n = function(e) {
				if (document.activeElement === document.body) for (let t of e) t.removedNodes.length > 0 && Y(s);
			};
			J(e, "handleFocusIn"), J(t, "handleFocusOut"), J(n, "handleMutations"), document.addEventListener("focusin", e), document.addEventListener("focusout", t);
			let r = new MutationObserver(n);
			return s && r.observe(s, {
				childList: !0,
				subtree: !0
			}), () => {
				document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), r.disconnect();
			};
		}
	}, [
		r,
		s,
		p.paused
	]), v.useEffect(() => {
		if (s) {
			ht.add(p);
			let e = document.activeElement;
			if (!s.contains(e)) {
				let t = new CustomEvent(at, st);
				s.addEventListener(at, l), s.dispatchEvent(t), t.defaultPrevented || (lt(vt(dt(s)), { select: !0 }), document.activeElement === e && Y(s));
			}
			return () => {
				s.removeEventListener(at, l), setTimeout(() => {
					let t = new CustomEvent(ot, st);
					s.addEventListener(ot, u), s.dispatchEvent(t), t.defaultPrevented || Y(e ?? document.body, { select: !0 }), s.removeEventListener(ot, u), ht.remove(p);
				}, 0);
			};
		}
	}, [
		s,
		l,
		u,
		p
	]);
	let m = v.useCallback((e) => {
		if (!n && !r || p.paused) return;
		let t = e.key === "Tab" && !e.altKey && !e.ctrlKey && !e.metaKey, i = document.activeElement;
		if (t && i) {
			let t = e.currentTarget, [r, a] = ut(t);
			r && a ? !e.shiftKey && i === a ? (e.preventDefault(), n && Y(r, { select: !0 })) : e.shiftKey && i === r && (e.preventDefault(), n && Y(a, { select: !0 })) : i === t && e.preventDefault();
		}
	}, [
		n,
		r,
		p.paused
	]);
	return /* @__PURE__ */ S(G.div, {
		tabIndex: -1,
		...o,
		ref: f,
		onKeyDown: m
	});
}, "FocusScope"));
function lt(e, { select: t = !1 } = {}) {
	let n = document.activeElement;
	for (let r of e) if (Y(r, { select: t }), document.activeElement !== n) return;
}
J(lt, "focusFirst");
function ut(e) {
	let t = dt(e);
	return [ft(t, e), ft(t.reverse(), e)];
}
J(ut, "getTabbableEdges");
function dt(e) {
	let t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ J((e) => {
		let t = e.tagName === "INPUT" && e.type === "hidden";
		return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	for (; n.nextNode();) t.push(n.currentNode);
	return t;
}
J(dt, "getTabbableCandidates");
function ft(e, t) {
	let n = typeof t.checkVisibility == "function" && t.checkVisibility({ checkVisibilityCSS: !0 });
	for (let r of e) if (!(n ? !r.checkVisibility({ checkVisibilityCSS: !0 }) : pt(r, { upTo: t }))) return r;
}
J(ft, "findVisible");
function pt(e, { upTo: t }) {
	if (getComputedStyle(e).visibility === "hidden") return !0;
	for (; e;) {
		if (t !== void 0 && e === t) return !1;
		if (getComputedStyle(e).display === "none") return !0;
		e = e.parentElement;
	}
	return !1;
}
J(pt, "isHidden");
function mt(e) {
	return e instanceof HTMLInputElement && "select" in e;
}
J(mt, "isSelectableInput");
function Y(e, { select: t = !1 } = {}) {
	if (e && e.focus) {
		let n = document.activeElement;
		e.focus({ preventScroll: !0 }), e !== n && mt(e) && t && e.select();
	}
}
J(Y, "focus");
var ht = gt();
function gt() {
	let e = [];
	return {
		add(t) {
			let n = e[0];
			t !== n && n?.pause(), e = _t(e, t), e.unshift(t);
		},
		remove(t) {
			e = _t(e, t), e[0]?.resume();
		}
	};
}
J(gt, "createFocusScopesStack");
function _t(e, t) {
	let n = [...e], r = n.indexOf(t);
	return r !== -1 && n.splice(r, 1), n;
}
J(_t, "arrayRemove");
function vt(e) {
	return e.filter((e) => e.tagName !== "A");
}
J(vt, "removeLinks");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-layout-effect@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var X = globalThis?.document ? v.useLayoutEffect : () => {}, yt = Object.defineProperty, bt = (e, t) => yt(e, "name", {
	value: t,
	configurable: !0
}), xt = v.useId || (() => void 0), St = 0;
function Ct(e) {
	let [t, n] = v.useState(xt());
	return X(() => {
		e || n((e) => e ?? String(St++));
	}, [e]), e || (t ? `radix-${t}` : "");
}
bt(Ct, "useId");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-size@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-use-size/dist/index.mjs
var wt = Object.defineProperty, Tt = (e, t) => wt(e, "name", {
	value: t,
	configurable: !0
});
function Et(e) {
	let [t, n] = v.useState(void 0);
	return X(() => {
		if (e) {
			n({
				width: e.offsetWidth,
				height: e.offsetHeight
			});
			let t = new ResizeObserver((t) => {
				if (!Array.isArray(t) || !t.length) return;
				let r = t[0], i, a;
				if ("borderBoxSize" in r) {
					let e = r.borderBoxSize, t = Array.isArray(e) ? e[0] : e;
					i = t.inlineSize, a = t.blockSize;
				} else i = e.offsetWidth, a = e.offsetHeight;
				n({
					width: i,
					height: a
				});
			});
			return t.observe(e, { box: "border-box" }), () => t.unobserve(e);
		} else n(void 0);
	}, [e]), t;
}
Tt(Et, "useSize");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-popper@1.3.7+07ecf1aa3bcbed22/node_modules/@radix-ui/react-popper/dist/index.mjs
var Dt = Object.defineProperty, Ot = (e, t) => Dt(e, "name", {
	value: t,
	configurable: !0
}), kt = "Popper", [At, jt] = /* @__PURE__ */ I(kt), [Mt, Nt] = At(kt), Pt = /* @__PURE__ */ Ot((e) => {
	let { __scopePopper: t, children: n } = e, [r, i] = v.useState(null), [a, o] = v.useState(void 0);
	return /* @__PURE__ */ S(Mt, {
		scope: t,
		anchor: r,
		onAnchorChange: i,
		placementState: a,
		setPlacementState: o,
		children: n
	});
}, "Popper"), Ft = "PopperAnchor", It = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Ot(function(e, t) {
	let { __scopePopper: n, virtualRef: r, ...i } = e, a = Nt(Ft, n), o = v.useRef(null), s = a.onAnchorChange, c = V(t, v.useCallback((e) => {
		o.current = e, e && s(e);
	}, [s])), l = v.useRef(null);
	v.useEffect(() => {
		if (!r) return;
		let e = l.current;
		l.current = r.current, e !== l.current && s(l.current);
	});
	let u = a.placementState && Ut(a.placementState), d = u?.[0], f = u?.[1];
	return r ? null : /* @__PURE__ */ S(G.div, {
		"data-radix-popper-side": d,
		"data-radix-popper-align": f,
		...i,
		ref: c
	});
}, "PopperAnchor")), Lt = "PopperContent", [Rt, zt] = At(Lt), Bt = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Ot(function(e, t) {
	let { __scopePopper: n, side: s = "bottom", sideOffset: l = 0, align: m = "center", alignOffset: h = 0, arrowPadding: g = 0, avoidCollisions: _ = !0, collisionBoundary: y = [], collisionPadding: b = 0, sticky: x = "partial", hideWhenDetached: C = !1, updatePositionStrategy: ee = "optimized", onPlaced: w, ...T } = e, E = Nt(Lt, n), [D, O] = v.useState(null), k = V(t, O), [A, te] = v.useState(null), j = Et(A), M = j?.width ?? 0, N = j?.height ?? 0, ne = s + (m === "center" ? "" : "-" + m), P = typeof b == "number" ? b : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...b
	}, F = Array.isArray(y) ? y : [y], I = F.length > 0, L = {
		padding: P,
		boundary: F.filter(Vt),
		altBoundary: I
	}, { refs: re, floatingStyles: R, placement: z, isPositioned: B, middlewareData: ie } = i({
		strategy: "fixed",
		placement: ne,
		whileElementsMounted: /* @__PURE__ */ Ot((...e) => f(...e, { animationFrame: ee === "always" }), "whileElementsMounted"),
		elements: { reference: E.anchor },
		middleware: [
			r({
				mainAxis: l + N,
				alignmentAxis: h
			}),
			_ && d({
				mainAxis: !0,
				crossAxis: !1,
				limiter: x === "partial" ? a() : void 0,
				...L
			}),
			_ && c({ ...L }),
			p({
				...L,
				apply: /* @__PURE__ */ Ot(({ elements: e, rects: t, availableWidth: n, availableHeight: r }) => {
					let { width: i, height: a } = t.reference, o = e.floating.style;
					o.setProperty("--radix-popper-available-width", `${n}px`), o.setProperty("--radix-popper-available-height", `${r}px`), o.setProperty("--radix-popper-anchor-width", `${i}px`), o.setProperty("--radix-popper-anchor-height", `${a}px`);
				}, "apply")
			}),
			A && u({
				element: A,
				padding: g
			}),
			Ht({
				arrowWidth: M,
				arrowHeight: N
			}),
			C && o({
				strategy: "referenceHidden",
				...L,
				boundary: I ? L.boundary : void 0
			})
		]
	}), H = E.setPlacementState;
	X(() => (H(z), () => {
		H(void 0);
	}), [z, H]);
	let [U, ae] = Ut(z), oe = K(w);
	X(() => {
		B && oe?.();
	}, [B, oe]);
	let se = ie.arrow?.x, ce = ie.arrow?.y, le = ie.arrow?.centerOffset !== 0, [ue, de] = v.useState();
	return X(() => {
		D && de(window.getComputedStyle(D).zIndex);
	}, [D]), /* @__PURE__ */ S("div", {
		ref: re.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...R,
			transform: B ? R.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: ue,
			"--radix-popper-transform-origin": [ie.transformOrigin?.x, ie.transformOrigin?.y].join(" "),
			...ie.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: e.dir,
		children: /* @__PURE__ */ S(Rt, {
			scope: n,
			placedSide: U,
			placedAlign: ae,
			onArrowChange: te,
			arrowX: se,
			arrowY: ce,
			shouldHideArrow: le,
			children: /* @__PURE__ */ S(G.div, {
				"data-side": U,
				"data-align": ae,
				...T,
				ref: k,
				style: {
					...T.style,
					animation: B ? T.style?.animation : "none"
				}
			})
		})
	});
}, "PopperContent"));
function Vt(e) {
	return e !== null;
}
Ot(Vt, "isNotNull");
var Ht = /* @__PURE__ */ Ot((e) => ({
	name: "transformOrigin",
	options: e,
	fn(t) {
		let { placement: n, rects: r, middlewareData: i } = t, a = i.arrow?.centerOffset !== 0, o = a ? 0 : e.arrowWidth, s = a ? 0 : e.arrowHeight, [c, l] = Ut(n), u = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[l], d = (i.arrow?.x ?? 0) + o / 2, f = (i.arrow?.y ?? 0) + s / 2, p = "", m = "";
		return c === "bottom" ? (p = a ? u : `${d}px`, m = `${-s}px`) : c === "top" ? (p = a ? u : `${d}px`, m = `${r.floating.height + s}px`) : c === "right" ? (p = `${-s}px`, m = a ? u : `${f}px`) : c === "left" && (p = `${r.floating.width + s}px`, m = a ? u : `${f}px`), { data: {
			x: p,
			y: m
		} };
	}
}), "transformOrigin");
function Ut(e) {
	let [t, n = "center"] = e.split("-");
	return [t, n];
}
Ot(Ut, "getSideAndAlignFromPlacement");
var Wt = Pt, Gt = It, Kt = Bt, qt = Object.defineProperty, Jt = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ ((e, t) => qt(e, "name", {
	value: t,
	configurable: !0
}))(function(e, t) {
	let { container: n, ...r } = e, [i, a] = v.useState(!1);
	X(() => a(!0), []);
	let o = n || i && globalThis?.document?.body;
	return o ? b.createPortal(/* @__PURE__ */ S(G.div, {
		...r,
		ref: t
	}), o) : null;
}, "Portal")), Yt = Object.defineProperty, Z = (e, t) => Yt(e, "name", {
	value: t,
	configurable: !0
});
function Xt(e, t) {
	return v.useReducer((e, n) => t[e][n] ?? e, e);
}
Z(Xt, "useStateMachine");
var Zt = /* @__PURE__ */ Z((e) => {
	let { present: t, children: n } = e, r = Qt(t), i = typeof n == "function" ? n({ present: r.isPresent }) : v.Children.only(n), a = en(r.ref, nn(i));
	return typeof n == "function" || r.isPresent ? v.cloneElement(i, { ref: a }) : null;
}, "Presence");
function Qt(e) {
	let [t, n] = v.useState(), r = v.useRef(null), i = v.useRef(e), a = v.useRef("none"), o = v.useRef(void 0), [s, c] = Xt(e ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	return v.useEffect(() => {
		s === "mounted" ? (a.current = o.current ?? tn(r.current), o.current = void 0) : a.current = "none";
	}, [s]), X(() => {
		let t = r.current, n = i.current;
		if (n !== e) {
			let r = a.current, s = tn(t);
			e ? (o.current = s, c("MOUNT")) : s === "none" || t?.display === "none" ? c("UNMOUNT") : c(n && r !== s ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
		}
	}, [e, c]), X(() => {
		if (t) {
			let e, n = t.ownerDocument.defaultView ?? window, o = /* @__PURE__ */ Z((a) => {
				let o = tn(r.current).includes(CSS.escape(a.animationName));
				if (a.target === t && o && (c("ANIMATION_END"), !i.current)) {
					let r = t.style.animationFillMode;
					t.style.animationFillMode = "forwards", e = n.setTimeout(() => {
						t.style.animationFillMode === "forwards" && (t.style.animationFillMode = r);
					});
				}
			}, "handleAnimationEnd"), s = /* @__PURE__ */ Z((e) => {
				e.target === t && (a.current = tn(r.current));
			}, "handleAnimationStart");
			return t.addEventListener("animationstart", s), t.addEventListener("animationcancel", o), t.addEventListener("animationend", o), () => {
				n.clearTimeout(e), t.removeEventListener("animationstart", s), t.removeEventListener("animationcancel", o), t.removeEventListener("animationend", o);
			};
		} else c("ANIMATION_END");
	}, [t, c]), {
		isPresent: ["mounted", "unmountSuspended"].includes(s),
		ref: v.useCallback((e) => {
			if (e) {
				let t = getComputedStyle(e);
				r.current = t, o.current = tn(t);
			} else r.current = null;
			n(e);
		}, [])
	};
}
Z(Qt, "usePresence");
function $t(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
Z($t, "setRef");
function en(...e) {
	let t = v.useRef(e);
	return t.current = e, v.useCallback((e) => {
		let n = t.current, r = !1, i = n.map((t) => {
			let n = $t(t, e);
			return !r && typeof n == "function" && (r = !0), n;
		});
		if (r) return () => {
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				typeof t == "function" ? t() : $t(n[e], null);
			}
		};
	}, []);
}
Z(en, "useStableComposedRefs");
function tn(e) {
	return e?.animationName || "none";
}
Z(tn, "getAnimationName");
function nn(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
Z(nn, "getElementRef");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-effect-event@0.0.5+bf264c7668a20073/node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var rn = Object.defineProperty, an = (e, t) => rn(e, "name", {
	value: t,
	configurable: !0
}), on = v.useEffectEvent, sn = v.useInsertionEffect;
function cn(e) {
	if (typeof on == "function") return on(e);
	let t = v.useRef(() => {
		throw Error("Cannot call an event handler while rendering.");
	});
	return typeof sn == "function" ? sn(() => {
		t.current = e;
	}) : X(() => {
		t.current = e;
	}), v.useMemo(() => ((...e) => t.current?.(...e)), []);
}
an(cn, "useEffectEvent");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-controllable-state@1.2.6+bf264c7668a20073/node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var ln = Object.defineProperty, un = (e, t) => ln(e, "name", {
	value: t,
	configurable: !0
}), dn = v.useInsertionEffect || X;
function fn({ prop: e, defaultProp: t, onChange: n = /* @__PURE__ */ un(() => {}, "onChange"), caller: r }) {
	let [i, a, o] = pn({
		defaultProp: t,
		onChange: n
	}), s = e !== void 0;
	return [s ? e : i, v.useCallback((t) => {
		if (s) {
			let n = mn(t) ? t(e) : t;
			n !== e && o.current?.(n);
		} else a(t);
	}, [
		s,
		e,
		a,
		o
	])];
}
un(fn, "useControllableState");
function pn({ defaultProp: e, onChange: t }) {
	let [n, r] = v.useState(e), i = v.useRef(n), a = v.useRef(t);
	return dn(() => {
		a.current = t;
	}, [t]), v.useEffect(() => {
		i.current !== n && (a.current?.(n), i.current = n);
	}, [n, i]), [
		n,
		r,
		a
	];
}
un(pn, "useUncontrolledState");
function mn(e) {
	return typeof e == "function";
}
un(mn, "isFunction");
var hn = Symbol("RADIX:SYNC_STATE");
function gn(e, t, n, r) {
	let { prop: i, defaultProp: a, onChange: o, caller: s } = t, c = i !== void 0, l = cn(o), u = [{
		...n,
		state: a
	}];
	r && u.push(r);
	let [d, f] = v.useReducer((t, n) => {
		if (n.type === hn) return {
			...t,
			state: n.state
		};
		let r = e(t, n);
		return c && !Object.is(r.state, t.state) && l(r.state), r;
	}, ...u), p = d.state, m = v.useRef(p);
	v.useEffect(() => {
		m.current !== p && (m.current = p, c || l(p));
	}, [
		p,
		m,
		c
	]);
	let h = v.useMemo(() => i === void 0 ? d : {
		...d,
		state: i
	}, [d, i]);
	return v.useEffect(() => {
		c && !Object.is(i, d.state) && f({
			type: hn,
			state: i
		});
	}, [
		i,
		d.state,
		c
	]), [h, f];
}
un(gn, "useControllableStateReducer");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-use-previous@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-use-previous/dist/index.mjs
var _n = Object.defineProperty, vn = (e, t) => _n(e, "name", {
	value: t,
	configurable: !0
});
function yn(e) {
	let t = v.useRef({
		value: e,
		previous: e
	});
	return v.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
vn(yn, "usePrevious");
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-visually-hidden@1.2.11+07ecf1aa3bcbed22/node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var bn = Object.freeze({
	position: "absolute",
	border: 0,
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	wordWrap: "normal"
}), xn = Object.defineProperty, Q = (e, t) => xn(e, "name", {
	value: t,
	configurable: !0
}), Sn = [
	" ",
	"Enter",
	"ArrowUp",
	"ArrowDown"
], Cn = [" ", "Enter"], wn = "Select", [Tn, En, Dn] = /* @__PURE__ */ ve(wn), [On, kn] = /* @__PURE__ */ I(wn, [Dn, jt]), An = jt(), [jn, Mn] = On(wn), [Nn, Pn] = On(wn);
function Fn(e) {
	let { __scopeSelect: t, children: n, open: r, defaultOpen: i, onOpenChange: a, value: o, defaultValue: s, onValueChange: c, dir: l, name: u, autoComplete: d, disabled: f, required: p, form: m, internal_do_not_use_render: h } = e, g = An(t), [_, y] = v.useState(null), [b, x] = v.useState(null), [C, ee] = v.useState(!1), w = Me(l), [T, E] = fn({
		prop: r,
		defaultProp: i ?? !1,
		onChange: a,
		caller: wn
	}), [D, O] = fn({
		prop: o,
		defaultProp: s,
		onChange: c,
		caller: wn
	}), k = v.useRef(null), A = v.useRef(D);
	v.useEffect(() => {
		let e = m ? _?.ownerDocument.getElementById(m) : _?.form;
		if (e instanceof HTMLFormElement) {
			let t = /* @__PURE__ */ Q(() => O(A.current), "reset");
			return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
		}
	}, [
		m,
		_,
		O
	]);
	let te = _ ? !!m || !!_.closest("form") : !0, [j, M] = v.useState(/* @__PURE__ */ new Set()), N = Ct(), ne = Array.from(j).map((e) => e.props.value).join(";"), P = v.useCallback((e) => {
		M((t) => new Set(t).add(e));
	}, []), F = v.useCallback((e) => {
		M((t) => {
			let n = new Set(t);
			return n.delete(e), n;
		});
	}, []), I = {
		required: p,
		trigger: _,
		onTriggerChange: y,
		valueNode: b,
		onValueNodeChange: x,
		valueNodeHasChildren: C,
		onValueNodeHasChildrenChange: ee,
		contentId: N,
		value: D,
		onValueChange: O,
		open: T,
		onOpenChange: E,
		dir: w,
		triggerPointerDownPosRef: k,
		disabled: f,
		name: u,
		autoComplete: d,
		form: m,
		nativeOptions: j,
		nativeSelectKey: ne,
		isFormControl: te
	};
	return /* @__PURE__ */ S(Wt, {
		...g,
		children: /* @__PURE__ */ S(jn, {
			scope: t,
			...I,
			children: /* @__PURE__ */ S(Tn.Provider, {
				scope: t,
				children: /* @__PURE__ */ S(Nn, {
					scope: t,
					onNativeOptionAdd: P,
					onNativeOptionRemove: F,
					children: gr(h) ? h(I) : n
				})
			})
		})
	});
}
Q(Fn, "SelectProvider");
var In = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, children: n, ...r } = e;
	return /* @__PURE__ */ S(Fn, {
		__scopeSelect: t,
		...r,
		internal_do_not_use_render: ({ isFormControl: e }) => /* @__PURE__ */ C(x, { children: [n, e ? /* @__PURE__ */ S(hr, { __scopeSelect: t }) : null] })
	});
}, "Select"), Ln = "SelectTrigger", Rn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, disabled: r = !1, ...i } = e, a = An(n), o = Mn(Ln, n), s = o.disabled || r, c = V(t, o.onTriggerChange), l = En(n), u = v.useRef("touch"), [d, f, p] = vr((e) => {
		let t = l().filter((e) => !e.disabled), n = yr(t, e, t.find((e) => e.value === o.value));
		n !== void 0 && o.onValueChange(n.value);
	}), m = /* @__PURE__ */ Q((e) => {
		s || (o.onOpenChange(!0), p()), e && (o.triggerPointerDownPosRef.current = {
			x: Math.round(e.pageX),
			y: Math.round(e.pageY)
		});
	}, "handleOpen");
	return /* @__PURE__ */ S(Gt, {
		asChild: !0,
		...a,
		children: /* @__PURE__ */ S(G.button, {
			type: "button",
			role: "combobox",
			"aria-controls": o.open ? o.contentId : void 0,
			"aria-expanded": o.open,
			"aria-required": o.required,
			"aria-autocomplete": "none",
			dir: o.dir,
			"data-state": o.open ? "open" : "closed",
			disabled: s,
			"data-disabled": s ? "" : void 0,
			"data-placeholder": _r(o.value) ? "" : void 0,
			...i,
			ref: c,
			onClick: A(i.onClick, (e) => {
				e.currentTarget.focus(), u.current !== "mouse" && m(e);
			}),
			onPointerDown: A(i.onPointerDown, (e) => {
				u.current = e.pointerType;
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId), e.button === 0 && e.ctrlKey === !1 && e.pointerType === "mouse" && (m(e), e.preventDefault());
			}),
			onKeyDown: A(i.onKeyDown, (e) => {
				let t = d.current !== "";
				!(e.ctrlKey || e.altKey || e.metaKey) && e.key.length === 1 && f(e.key), !(t && e.key === " ") && Sn.includes(e.key) && (m(), e.preventDefault());
			})
		})
	});
}, "SelectTrigger")), zn = "SelectValue", Bn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, children: a, placeholder: o = "", ...s } = e, c = Mn(zn, n), { onValueNodeHasChildrenChange: l } = c, u = a !== void 0, d = V(t, c.onValueNodeChange);
	X(() => {
		l(u);
	}, [l, u]);
	let f = _r(c.value);
	return /* @__PURE__ */ S(G.span, {
		...s,
		asChild: f ? !1 : s.asChild,
		ref: d,
		style: { pointerEvents: "none" },
		children: /* @__PURE__ */ S(v.Fragment, { children: f ? o : a }, f ? "placeholder" : "value")
	});
}, "SelectValue")), Vn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, ...i } = e;
	return /* @__PURE__ */ S(G.span, {
		"aria-hidden": !0,
		...i,
		ref: t,
		children: r || "▼"
	});
}, "SelectIcon")), [Hn, Un] = On("SelectPortal", { forceMount: void 0 }), Wn = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, forceMount: n, ...r } = e;
	return /* @__PURE__ */ S(Hn, {
		scope: e.__scopeSelect,
		forceMount: n,
		children: /* @__PURE__ */ S(Jt, {
			asChild: !0,
			...r
		})
	});
}, "SelectPortal"), Gn = "SelectContent", Kn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Un(Gn, e.__scopeSelect), { forceMount: r = n.forceMount, ...i } = e, a = Mn(Gn, e.__scopeSelect), [o, s] = v.useState();
	return X(() => {
		s(new DocumentFragment());
	}, []), /* @__PURE__ */ S(Zt, {
		present: r || a.open,
		children: ({ present: e }) => e ? /* @__PURE__ */ S(Zn, {
			...i,
			ref: t
		}) : /* @__PURE__ */ S(qn, {
			...i,
			fragment: o
		})
	});
}, "SelectContent")), qn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, fragment: i } = e;
	return i ? b.createPortal(/* @__PURE__ */ S(Jn, {
		scope: n,
		children: /* @__PURE__ */ S(Tn.Slot, {
			scope: n,
			children: /* @__PURE__ */ S("div", {
				ref: t,
				children: r
			})
		})
	}), i) : null;
}, "SelectContentFragment")), $ = 10, [Jn, Yn] = On(Gn), Xn = /* @__PURE__ */ U("SelectContent.RemoveScroll"), Zn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n } = e, { position: r = "item-aligned", onCloseAutoFocus: i, onEscapeKeyDown: a, onPointerDownOutside: o, side: s, sideOffset: c, align: l, alignOffset: u, arrowPadding: d, collisionBoundary: f, collisionPadding: p, sticky: m, hideWhenDetached: h, avoidCollisions: y, ...b } = e, x = Mn(Gn, n), [C, ee] = v.useState(null), [w, T] = v.useState(null), E = V(t, ee), [D, O] = v.useState(null), [k, te] = v.useState(null), j = En(n), [M, N] = v.useState(!1), ne = v.useRef(!1);
	v.useEffect(() => {
		if (C) return _(C);
	}, [C]), nt();
	let P = v.useCallback((e) => {
		let [t, ...n] = j().map((e) => e.ref.current), [r] = n.slice(-1), i = document.activeElement;
		for (let n of e) if (n === i || (n?.scrollIntoView({ block: "nearest" }), n === t && w && (w.scrollTop = 0), n === r && w && (w.scrollTop = w.scrollHeight), n?.focus(), document.activeElement !== i)) return;
	}, [j, w]), F = v.useCallback(() => P([D, C]), [
		P,
		D,
		C
	]);
	v.useEffect(() => {
		M && F();
	}, [M, F]);
	let { onOpenChange: I, triggerPointerDownPosRef: L } = x;
	v.useEffect(() => {
		if (C) {
			let e = {
				x: 0,
				y: 0
			}, t = /* @__PURE__ */ Q((t) => {
				e = {
					x: Math.abs(Math.round(t.pageX) - (L.current?.x ?? 0)),
					y: Math.abs(Math.round(t.pageY) - (L.current?.y ?? 0))
				};
			}, "handlePointerMove"), n = /* @__PURE__ */ Q((n) => {
				e.x <= 10 && e.y <= 10 ? n.preventDefault() : n.composedPath().includes(C) || I(!1), document.removeEventListener("pointermove", t), L.current = null;
			}, "handlePointerUp");
			return L.current !== null && (document.addEventListener("pointermove", t), document.addEventListener("pointerup", n, {
				capture: !0,
				once: !0
			})), () => {
				document.removeEventListener("pointermove", t), document.removeEventListener("pointerup", n, { capture: !0 });
			};
		}
	}, [
		C,
		I,
		L
	]), v.useEffect(() => {
		let e = /* @__PURE__ */ Q(() => I(!1), "close");
		return window.addEventListener("blur", e), window.addEventListener("resize", e), () => {
			window.removeEventListener("blur", e), window.removeEventListener("resize", e);
		};
	}, [I]);
	let [re, R] = vr((e) => {
		let t = j().filter((e) => !e.disabled), n = yr(t, e, t.find((e) => e.ref.current === document.activeElement));
		n && setTimeout(() => n.ref.current?.focus());
	}), z = v.useCallback((e, t, n) => {
		let r = !ne.current && !n;
		(x.value !== void 0 && x.value === t || r) && (O(e), r && (ne.current = !0));
	}, [x.value]), B = v.useCallback(() => C?.focus(), [C]), ie = v.useCallback((e, t, n) => {
		let r = !ne.current && !n;
		(x.value !== void 0 && x.value === t || r) && te(e);
	}, [x.value]), H = r === "popper" ? $n : Qn, U = H === $n ? {
		side: s,
		sideOffset: c,
		align: l,
		alignOffset: u,
		arrowPadding: d,
		collisionBoundary: f,
		collisionPadding: p,
		sticky: m,
		hideWhenDetached: h,
		avoidCollisions: y
	} : {};
	return /* @__PURE__ */ S(Jn, {
		scope: n,
		content: C,
		viewport: w,
		onViewportChange: T,
		itemRefCallback: z,
		selectedItem: D,
		onItemLeave: B,
		itemTextRefCallback: ie,
		focusSelectedItem: F,
		selectedItemText: k,
		position: r,
		isPositioned: M,
		searchRef: re,
		children: /* @__PURE__ */ S(g, {
			as: Xn,
			allowPinchZoom: !0,
			children: /* @__PURE__ */ S(ct, {
				asChild: !0,
				trapped: x.open,
				onMountAutoFocus: (e) => {
					e.preventDefault();
				},
				onUnmountAutoFocus: A(i, (e) => {
					x.trigger?.focus({ preventScroll: !0 }), e.preventDefault();
				}),
				children: /* @__PURE__ */ S(We, {
					asChild: !0,
					disableOutsidePointerEvents: !0,
					onEscapeKeyDown: a,
					onPointerDownOutside: o,
					onFocusOutside: (e) => e.preventDefault(),
					onDismiss: () => x.onOpenChange(!1),
					children: /* @__PURE__ */ S(H, {
						role: "listbox",
						id: x.contentId,
						"data-state": x.open ? "open" : "closed",
						dir: x.dir,
						onContextMenu: (e) => e.preventDefault(),
						...b,
						...U,
						onPlaced: () => N(!0),
						ref: E,
						style: {
							display: "flex",
							flexDirection: "column",
							outline: "none",
							...b.style
						},
						onKeyDown: A(b.onKeyDown, (e) => {
							let t = e.ctrlKey || e.altKey || e.metaKey;
							if (e.key === "Tab" && e.preventDefault(), !t && e.key.length === 1 && R(e.key), [
								"ArrowUp",
								"ArrowDown",
								"Home",
								"End"
							].includes(e.key)) {
								let t = j().filter((e) => !e.disabled).map((e) => e.ref.current);
								if (["ArrowUp", "End"].includes(e.key) && (t = t.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(e.key)) {
									let n = e.target, r = t.indexOf(n);
									t = t.slice(r + 1);
								}
								setTimeout(() => P(t)), e.preventDefault();
							}
						})
					})
				})
			})
		})
	});
}, "SelectContentImpl")), Qn = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, onPlaced: r, ...i } = e, a = Mn(Gn, n), o = Yn(Gn, n), [s, c] = v.useState(null), [l, u] = v.useState(null), d = V(t, u), f = En(n), p = v.useRef(!1), m = v.useRef(!0), { viewport: h, selectedItem: g, selectedItemText: _, focusSelectedItem: y } = o, b = v.useCallback(() => {
		if (a.trigger && a.valueNode && s && l && h && g && _) {
			let e = a.trigger.getBoundingClientRect(), t = l.getBoundingClientRect(), n = a.valueNode.getBoundingClientRect(), i = _.getBoundingClientRect();
			if (a.dir !== "rtl") {
				let r = i.left - t.left, a = n.left - r, o = e.left - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - $, d = E(a, [$, Math.max($, u - l)]);
				s.style.minWidth = c + "px", s.style.left = d + "px";
			} else {
				let r = t.right - i.right, a = window.innerWidth - n.right - r, o = window.innerWidth - e.right - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - $, d = E(a, [$, Math.max($, u - l)]);
				s.style.minWidth = c + "px", s.style.right = d + "px";
			}
			let o = f(), c = window.innerHeight - $ * 2, u = h.scrollHeight, d = window.getComputedStyle(l), m = parseInt(d.borderTopWidth, 10), v = parseInt(d.paddingTop, 10), y = parseInt(d.borderBottomWidth, 10), b = parseInt(d.paddingBottom, 10), x = m + v + u + b + y, S = Math.min(g.offsetHeight * 5, x), C = window.getComputedStyle(h), ee = parseInt(C.paddingTop, 10), w = parseInt(C.paddingBottom, 10), T = e.top + e.height / 2 - $, D = c - T, O = g.offsetHeight / 2, k = g.offsetTop + O, A = m + v + k, te = x - A;
			if (A <= T) {
				let e = o.length > 0 && g === o[o.length - 1].ref.current;
				s.style.bottom = "0px";
				let t = l.clientHeight - h.offsetTop - h.offsetHeight, n = A + Math.max(D, O + (e ? w : 0) + t + y);
				s.style.height = n + "px";
			} else {
				let e = o.length > 0 && g === o[0].ref.current;
				s.style.top = "0px";
				let t = Math.max(T, m + h.offsetTop + (e ? ee : 0) + O) + te;
				s.style.height = t + "px", h.scrollTop = A - T + h.offsetTop;
			}
			s.style.margin = `${$}px 0`, s.style.minHeight = S + "px", s.style.maxHeight = c + "px", r?.(), requestAnimationFrame(() => p.current = !0);
		}
	}, [
		f,
		a.trigger,
		a.valueNode,
		s,
		l,
		h,
		g,
		_,
		a.dir,
		r
	]);
	X(() => b(), [b]);
	let [x, C] = v.useState();
	return X(() => {
		l && C(window.getComputedStyle(l).zIndex);
	}, [l]), /* @__PURE__ */ S(er, {
		scope: n,
		contentWrapper: s,
		shouldExpandOnScrollRef: p,
		onScrollButtonChange: v.useCallback((e) => {
			e && m.current === !0 && (b(), y?.(), m.current = !1);
		}, [b, y]),
		children: /* @__PURE__ */ S("div", {
			ref: c,
			style: {
				display: "flex",
				flexDirection: "column",
				position: "fixed",
				zIndex: x
			},
			children: /* @__PURE__ */ S(G.div, {
				...i,
				ref: d,
				style: {
					boxSizing: "border-box",
					maxHeight: "100%",
					...i.style
				}
			})
		})
	});
}, "SelectItemAlignedPosition")), $n = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, align: r = "start", collisionPadding: i = $, ...a } = e;
	return /* @__PURE__ */ S(Kt, {
		...An(n),
		...a,
		ref: t,
		align: r,
		collisionPadding: i,
		style: {
			boxSizing: "border-box",
			...a.style,
			"--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-select-content-available-width": "var(--radix-popper-available-width)",
			"--radix-select-content-available-height": "var(--radix-popper-available-height)",
			"--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "SelectPopperPosition")), [er, tr] = On(Gn, {}), nr = "SelectViewport", rr = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, nonce: r, ...i } = e, a = Yn(nr, n), o = tr(nr, n), s = V(t, a.onViewportChange), c = v.useRef(0);
	return /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("style", {
		dangerouslySetInnerHTML: { __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}" },
		nonce: r
	}), /* @__PURE__ */ S(Tn.Slot, {
		scope: n,
		children: /* @__PURE__ */ S(G.div, {
			"data-radix-select-viewport": "",
			role: "presentation",
			...i,
			ref: s,
			style: {
				position: "relative",
				flex: 1,
				overflow: "hidden auto",
				...i.style
			},
			onScroll: A(i.onScroll, (e) => {
				let t = e.currentTarget, { contentWrapper: n, shouldExpandOnScrollRef: r } = o;
				if (r?.current && n) {
					let e = Math.abs(c.current - t.scrollTop);
					if (e > 0) {
						let r = window.innerHeight - $ * 2, i = parseFloat(n.style.minHeight), a = parseFloat(n.style.height), o = Math.max(i, a);
						if (o < r) {
							let i = o + e, a = Math.min(r, i), s = i - a;
							n.style.height = a + "px", n.style.bottom === "0px" && (t.scrollTop = s > 0 ? s : 0, n.style.justifyContent = "flex-end");
						}
					}
				}
				c.current = t.scrollTop;
			})
		})
	})] });
}, "SelectViewport")), [ir, ar] = On("SelectGroup"), or = "SelectItem", [sr, cr] = On(or), lr = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, value: r, disabled: i = !1, textValue: a, ...o } = e, s = Mn(or, n), c = Yn(or, n), l = s.value === r, [u, d] = v.useState(a ?? ""), [f, p] = v.useState(!1), m = V(t, K((e) => c.itemRefCallback?.(e, r, i))), h = Ct(), g = v.useRef("touch"), _ = /* @__PURE__ */ Q(() => {
		i || (s.onValueChange(r), s.onOpenChange(!1));
	}, "handleSelect");
	return /* @__PURE__ */ S(sr, {
		scope: n,
		value: r,
		disabled: i,
		textId: h,
		isSelected: l,
		onItemTextChange: v.useCallback((e) => {
			d((t) => t || (e?.textContent ?? "").trim());
		}, []),
		children: /* @__PURE__ */ S(Tn.ItemSlot, {
			scope: n,
			value: r,
			disabled: i,
			textValue: u,
			children: /* @__PURE__ */ S(G.div, {
				role: "option",
				"aria-labelledby": h,
				"data-highlighted": f ? "" : void 0,
				"aria-selected": l && f,
				"data-state": l ? "checked" : "unchecked",
				"aria-disabled": i || void 0,
				"data-disabled": i ? "" : void 0,
				tabIndex: i ? void 0 : -1,
				...o,
				ref: m,
				onFocus: A(o.onFocus, () => p(!0)),
				onBlur: A(o.onBlur, () => p(!1)),
				onClick: A(o.onClick, () => {
					g.current !== "mouse" && _();
				}),
				onPointerUp: A(o.onPointerUp, () => {
					g.current === "mouse" && _();
				}),
				onPointerDown: A(o.onPointerDown, (e) => {
					g.current = e.pointerType;
				}),
				onPointerMove: A(o.onPointerMove, (e) => {
					g.current = e.pointerType, i ? c.onItemLeave?.() : g.current === "mouse" && e.currentTarget.focus({ preventScroll: !0 });
				}),
				onPointerLeave: A(o.onPointerLeave, (e) => {
					e.currentTarget === document.activeElement && c.onItemLeave?.();
				}),
				onKeyDown: A(o.onKeyDown, (e) => {
					i || e.target !== e.currentTarget || c.searchRef?.current !== "" && e.key === " " || (Cn.includes(e.key) && _(), e.key === " " && e.preventDefault());
				})
			})
		})
	});
}, "SelectItem")), ur = "SelectItemText", dr = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, ...a } = e, o = Mn(ur, n), s = Yn(ur, n), c = cr(ur, n), l = Pn(ur, n), [u, d] = v.useState(null), f = K((e) => s.itemTextRefCallback?.(e, c.value, c.disabled)), p = V(t, d, c.onItemTextChange, f), m = u?.textContent, h = v.useMemo(() => /* @__PURE__ */ S("option", {
		value: c.value,
		disabled: c.disabled,
		children: m
	}, c.value), [
		c.disabled,
		c.value,
		m
	]), { onNativeOptionAdd: g, onNativeOptionRemove: _ } = l;
	return X(() => (g(h), () => _(h)), [
		g,
		_,
		h
	]), /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(G.span, {
		id: c.textId,
		...a,
		ref: p
	}), c.isSelected && o.valueNode && !o.valueNodeHasChildren && !_r(o.value) ? b.createPortal(a.children, o.valueNode) : null] });
}, "SelectItemText")), fr = "SelectItemIndicator", pr = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, ...r } = e;
	return cr(fr, n).isSelected ? /* @__PURE__ */ S(G.span, {
		"aria-hidden": !0,
		...r,
		ref: t
	}) : null;
}, "SelectItemIndicator")), mr = "SelectBubbleInput", hr = /* @__PURE__ */ v.forwardRef(/* @__PURE__ */ Q(function({ __scopeSelect: e, ...t }, n) {
	let r = Mn(mr, e), { value: i, onValueChange: a, required: o, disabled: s, name: c, autoComplete: l, form: u } = r, { nativeOptions: d, nativeSelectKey: f } = r, p = v.useRef(null), m = V(n, p), h = i ?? "", g = yn(h), _ = Array.from(d).some((e) => (e.props.value ?? "") === "");
	return v.useEffect(() => {
		let e = p.current;
		if (!e) return;
		let t = window.HTMLSelectElement.prototype, n = Object.getOwnPropertyDescriptor(t, "value").set;
		if (g !== h && n) {
			let t = new Event("change", { bubbles: !0 });
			n.call(e, h), e.dispatchEvent(t);
		}
	}, [g, h]), /* @__PURE__ */ C(G.select, {
		"aria-hidden": !0,
		required: o,
		tabIndex: -1,
		name: c,
		autoComplete: l,
		disabled: s,
		form: u,
		onChange: (e) => a(e.target.value),
		...t,
		style: {
			...bn,
			...t.style
		},
		ref: m,
		defaultValue: h,
		children: [_r(i) && !_ ? /* @__PURE__ */ S("option", { value: "" }) : null, Array.from(d)]
	}, f);
}, "SelectBubbleInput"));
function gr(e) {
	return typeof e == "function";
}
Q(gr, "isFunction");
function _r(e) {
	return e === "" || e === void 0;
}
Q(_r, "shouldShowPlaceholder");
function vr(e) {
	let t = K(e), n = v.useRef(""), r = v.useRef(0), i = v.useCallback((e) => {
		let i = n.current + e;
		t(i), (/* @__PURE__ */ Q((function e(t) {
			n.current = t, window.clearTimeout(r.current), t !== "" && (r.current = window.setTimeout(() => e(""), 1e3));
		}), "updateSearch"))(i);
	}, [t]), a = v.useCallback(() => {
		n.current = "", window.clearTimeout(r.current);
	}, []);
	return v.useEffect(() => () => window.clearTimeout(r.current), []), [
		n,
		i,
		a
	];
}
Q(vr, "useTypeaheadSearch");
function yr(e, t, n) {
	let r = t.length > 1 && Array.from(t).every((e) => e === t[0]) ? t[0] : t, i = n ? e.indexOf(n) : -1, a = br(e, Math.max(i, 0));
	r.length === 1 && (a = a.filter((e) => e !== n));
	let o = a.find((e) => e.textValue.toLowerCase().startsWith(r.toLowerCase()));
	return o === n ? void 0 : o;
}
Q(yr, "findNextItem");
function br(e, t) {
	return e.map((n, r) => e[(t + r) % e.length]);
}
Q(br, "wrapArray");
//#endregion
//#region ../../packages/design-library/src/components/select.tsx
var xr = 280, Sr = {
	regular: "h-9 px-3 text-body-medium-lighter",
	compact: "h-7 px-2.5 text-body-small-default"
}, Cr = {
	regular: "px-3 py-2 text-body-medium-default",
	compact: "px-2.5 py-1.5 text-body-small-default"
}, wr = {
	regular: "scroll-pb-10",
	compact: "scroll-pb-8"
}, Tr = {
	regular: "h-3.5 w-3.5",
	compact: "h-3 w-3"
}, Er = {
	regular: "px-2 py-1 text-body-medium-lighter",
	compact: "px-1.5 py-0.5 text-body-small-default"
};
function Dr({ options: e, value: r, onChange: i, placeholder: a, disabled: o = !1, size: c = "regular", variant: u = "default", className: d, style: f, id: p, name: g, menuMaxHeight: _ = xr, menuMinWidth: v = 0, menuAlign: b = "start", "aria-label": x, "aria-labelledby": w, "aria-describedby": T, onSelectNone: E, "data-testid": D, label: O, helperText: k, errorText: A, fullWidth: te = !0, wrapperClassName: j }) {
	let M = s(), N = u === "ghost", ne = y(), P = p ?? `select-${ne}`, F = !!A, I = T ?? m(P, F, !!k), L = e.filter((e) => e.value !== ""), re = (() => {
		let e = new Set(L.flatMap((e) => e.value === null ? [] : [e.value])), t = "\0none";
		for (; e.has(t);) t += "\0";
		return t;
	})(), R = (e) => e === null ? re : e, z = L.find((e) => e.value === r), B = L.some((e) => e.sticky), V = /* @__PURE__ */ C(In, {
		value: r === null ? re : r,
		onValueChange: (e) => {
			let t = L.find((t) => R(t.value) === e);
			if (t) {
				if (t.value === null) {
					E?.();
					return;
				}
				i(t.value);
			}
		},
		disabled: o,
		name: g,
		children: [/* @__PURE__ */ S("div", {
			"data-slot": "select",
			className: n("relative", N && "inline-flex", d),
			style: f,
			children: /* @__PURE__ */ C(Rn, {
				id: P,
				"aria-label": x,
				"aria-labelledby": w ?? (O ? `${P}-label` : void 0),
				"aria-describedby": I,
				"aria-invalid": F || void 0,
				"aria-disabled": o || void 0,
				"data-testid": D,
				"data-slot": "select-trigger",
				className: n("flex items-center gap-2 rounded-md border text-left transition-colors disabled:cursor-not-allowed disabled:opacity-60", N || "focus:outline-none", N ? "w-auto bg-transparent hover:bg-[var(--field-bg)] data-[state=open]:bg-[var(--field-bg)]" : "w-full bg-[var(--field-bg)]", F ? "border-[var(--system-negative-strong)] data-[state=open]:border-[var(--system-negative-strong)]" : N ? "border-0 outline outline-1 -outline-offset-1 outline-transparent hover:outline-[var(--field-border)] focus-visible:outline-[var(--field-border)] data-[state=open]:outline-[var(--border-active)]" : "border-[var(--field-border)] data-[state=open]:border-[var(--border-active)]", N ? Er[c] : Sr[c]),
				style: { color: z ? "var(--content-default)" : "var(--content-tertiary)" },
				children: [
					z?.icon && /* @__PURE__ */ S("span", {
						className: "flex shrink-0 items-center",
						style: { color: "var(--content-tertiary)" },
						"aria-hidden": !0,
						children: z.icon
					}),
					/* @__PURE__ */ C("span", {
						className: "flex min-w-0 flex-1 items-center gap-2",
						children: [/* @__PURE__ */ S("span", {
							className: "min-w-0 flex-1 truncate",
							title: z?.label || void 0,
							children: /* @__PURE__ */ S(Bn, {
								placeholder: a ?? "",
								children: z?.label ?? a ?? ""
							})
						}), z?.suffix && /* @__PURE__ */ S("span", {
							className: "shrink-0",
							children: z.suffix
						})]
					}),
					/* @__PURE__ */ S(Vn, {
						asChild: !0,
						children: /* @__PURE__ */ S(ee, {
							className: n("shrink-0", Tr[c]),
							style: { color: "var(--content-tertiary)" },
							"aria-hidden": !0
						})
					})
				]
			})
		}), /* @__PURE__ */ S(Wn, {
			container: M ?? void 0,
			children: /* @__PURE__ */ S(Kn, {
				position: "popper",
				side: "bottom",
				align: b,
				sideOffset: 4,
				collisionPadding: 8,
				"data-slot": "select-menu",
				className: "pointer-events-auto z-50 overflow-hidden rounded-md border border-[var(--field-border)] bg-[var(--field-bg)] shadow-xl focus:outline-none",
				style: {
					minWidth: `max(var(--radix-select-trigger-width), ${v}px)`,
					maxWidth: "var(--radix-select-content-available-width)",
					maxHeight: `min(${_}px, var(--radix-select-content-available-height))`
				},
				children: /* @__PURE__ */ S(rr, {
					className: n("pt-1", B ? n("pb-0", wr[c]) : "pb-1"),
					children: L.map((e) => {
						let r = /* @__PURE__ */ C(lr, {
							value: R(e.value),
							disabled: e.disabled,
							"data-slot": "select-option",
							className: n("flex items-center gap-2 outline-none transition-colors", Cr[c], e.disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer data-[highlighted]:bg-[var(--surface-hover)]"),
							style: { color: "var(--content-default)" },
							children: [
								e.icon && /* @__PURE__ */ S("span", {
									className: "flex shrink-0 items-center",
									style: { color: "var(--content-tertiary)" },
									"aria-hidden": !0,
									children: e.icon
								}),
								/* @__PURE__ */ C("span", {
									className: "flex min-w-0 flex-1 items-center gap-2",
									children: [/* @__PURE__ */ S(dr, { children: /* @__PURE__ */ S("span", {
										className: "min-w-0 flex-1 truncate",
										title: e.tooltip ? void 0 : e.label || void 0,
										children: e.label
									}) }), e.suffix && /* @__PURE__ */ S("span", {
										className: "shrink-0",
										children: e.suffix
									})]
								}),
								/* @__PURE__ */ S(pr, {
									asChild: !0,
									children: /* @__PURE__ */ S(t, {
										className: "h-3.5 w-3.5 shrink-0",
										style: { color: "var(--system-positive-strong)" },
										"aria-hidden": !0
									})
								})
							]
						}, R(e.value)), i = e.tooltip ? /* @__PURE__ */ S(l, {
							content: e.tooltip,
							side: "right",
							children: r
						}, R(e.value)) : r;
						return e.sticky ? /* @__PURE__ */ S("div", {
							"data-slot": "select-pinned-option",
							role: "presentation",
							className: "sticky bottom-0 z-10 border-t border-[var(--border-element)] bg-[var(--field-bg)]",
							children: i
						}, R(e.value)) : i;
					})
				})
			})
		})]
	});
	return O == null && k == null && A == null ? V : /* @__PURE__ */ S(h, {
		id: P,
		label: O,
		helperText: k,
		errorText: A,
		fullWidth: te,
		disabled: o,
		className: j,
		children: V
	});
}
//#endregion
export { ee as n, Dr as t };
