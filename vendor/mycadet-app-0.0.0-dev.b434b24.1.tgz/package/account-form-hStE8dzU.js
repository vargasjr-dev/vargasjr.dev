import "./src-DLa8cepg.js";
import { n as e } from "./confirm-dialog-DH3yi6Nk.js";
import { Fragment as t, jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/components/account/account-form.tsx
var i = /* @__PURE__ */ n("svg", {
	width: "20",
	height: "20",
	viewBox: "0 0 20 20",
	fill: "none",
	xmlns: "http://www.w3.org/2000/svg",
	children: /* @__PURE__ */ n("path", {
		d: "M7.5 15L12.5 10L7.5 5",
		stroke: "currentColor",
		strokeWidth: "1.67",
		strokeLinecap: "round",
		strokeLinejoin: "round"
	})
});
function a({ onSubmit: a, error: o, children: s, submitLabel: c, submittingLabel: l, isSubmitting: u, footer: d }) {
	return /* @__PURE__ */ r(t, { children: [/* @__PURE__ */ r("form", {
		onSubmit: a,
		className: "flex flex-col gap-4",
		children: [
			o && /* @__PURE__ */ n(e, {
				tone: "error",
				children: o
			}),
			/* @__PURE__ */ n("div", {
				className: "flex flex-col gap-3",
				children: s
			}),
			/* @__PURE__ */ r("button", {
				type: "submit",
				disabled: u,
				className: "mt-2 inline-flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg bg-[var(--primary-base)] px-6 py-3 text-sm font-medium text-[var(--content-inset)] transition-colors hover:bg-[var(--primary-hover)] disabled:cursor-wait disabled:opacity-50",
				children: [u ? l : c, i]
			})
		]
	}), d && /* @__PURE__ */ n("div", {
		className: "mt-8 text-center",
		children: d
	})] });
}
function o(e) {
	return /* @__PURE__ */ n("input", {
		...e,
		className: "w-full rounded-lg border border-[var(--border-base)] bg-[var(--surface-overlay)] px-4 py-3 text-sm text-[var(--content-default)] outline-none placeholder:text-[var(--content-tertiary)] focus:border-[var(--primary-base)]/50"
	});
}
function s({ title: e, subtitle: t }) {
	return /* @__PURE__ */ r("div", {
		className: "mb-8 text-center",
		children: [/* @__PURE__ */ n("h1", {
			className: "mb-2 font-serif text-[2rem] font-bold italic text-[var(--content-default)]",
			children: e
		}), t && /* @__PURE__ */ n("p", {
			className: "text-sm text-[var(--content-secondary)]",
			children: t
		})]
	});
}
//#endregion
export { s as n, o as r, a as t };
