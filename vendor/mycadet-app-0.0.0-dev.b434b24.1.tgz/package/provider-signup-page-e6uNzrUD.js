import { c as e, d as t, t as n } from "./chunk-5KNZJZUH-DggPzR22.js";
import { o as r } from "./dist-CB0DYkRa.js";
import { r as i } from "./i18n-BRf-wfgm.js";
import { n as a } from "./routes-DW44XTQk.js";
import { c as o, l as s, t as c, u as l } from "./auth-store-Bx-RKZJ9.js";
import { t as u } from "./text-link-DoFyv9Mp.js";
import { n as d, r as f, t as p } from "./account-form-hStE8dzU.js";
import { t as m } from "./account-shell-D0S9QH7J.js";
import { t as h } from "./returning-user-B8ql5mWL.js";
import { t as g } from "./post-auth-destination-DPiH-YiC.js";
import { t as _ } from "./signup-shell-Cs5VH0Xk.js";
import { useEffect as v, useRef as y, useState as b } from "react";
import { jsx as x, jsxs as S } from "react/jsx-runtime";
//#region src/lib/auth/provider-signup-client.ts
function C() {
	return o("auth/provider/signup", s);
}
function w(e) {
	return o("auth/provider/signup", l, e);
}
function T(e) {
	return !e.ok && e.status === 409;
}
//#endregion
//#region src/lib/auth/signup-onboarding-handoff.ts
var E = "signup.onboarding.firstName";
function D() {
	try {
		return globalThis.sessionStorage ?? null;
	} catch {
		return null;
	}
}
function O(e) {
	let t = e.trim(), n = D();
	if (n !== null) try {
		n.removeItem(E), t && n.setItem(E, t);
	} catch {}
}
//#endregion
//#region src/domains/account/pages/provider-signup-page.tsx
function k() {
	let { t: o } = i("account"), s = e(), [l] = t(), E = c.use.refreshSession(), D = l.get("returnTo"), [k, A] = b(""), [j, M] = b(""), [N, P] = b(""), [F, I] = b(""), [L, R] = b(""), [z, B] = b(null), [V, H] = b(!1), [U, W] = b(!0), G = y(!1);
	v(() => {
		G.current || (G.current = !0, (async () => {
			try {
				let e = await C();
				if (!e.ok) {
					s(a.account.login, { replace: !0 });
					return;
				}
				A(e.data.user.email ?? ""), M(e.data.user.username ?? ""), P(e.data.user.first_name ?? ""), I(e.data.user.last_name ?? ""), W(!1);
			} catch {
				s(a.account.login, { replace: !0 });
			}
		})());
	}, [s]);
	let K = async () => {
		let e = await w({
			email: k,
			username: j
		});
		if (!e.ok) {
			if (T(e)) {
				await E();
				let e = g({
					returnTo: D,
					fallback: a.account.root,
					authIntent: "login",
					returningUser: await h()
				});
				e.requiresFullPageNavigation ? window.location.href = e.destination : s(e.destination);
				return;
			}
			B(e.errors[0]?.message ?? "Failed to complete signup.");
			return;
		}
		await E();
		let t = g({
			returnTo: D,
			fallback: a.account.root,
			authIntent: "signup",
			returningUser: await h()
		});
		t.requiresFullPageNavigation ? window.location.href = t.destination : s(t.destination);
	}, q = async (e) => {
		e.preventDefault(), B(null), H(!0);
		try {
			await K();
		} catch {
			B(o("authErrors.genericFailure"));
		} finally {
			H(!1);
		}
	}, J = async (e) => {
		if (e.preventDefault(), N.trim()) {
			B(null), H(!0);
			try {
				O(N), await K();
			} catch {
				B(o("authErrors.genericFailure"));
			} finally {
				H(!1);
			}
		}
	};
	if (U) return /* @__PURE__ */ x(m, { children: /* @__PURE__ */ x(d, {
		title: o("providerSignupPage.completingTitle"),
		subtitle: o("providerSignupPage.completingSubtitle")
	}) });
	if (k && j) {
		let e = N.trim().length > 0 && !V;
		return /* @__PURE__ */ x(_, { children: /* @__PURE__ */ S("form", {
			onSubmit: J,
			className: "signup-details__thread",
			children: [
				/* @__PURE__ */ S("h2", {
					className: "signup-details__heading",
					children: [
						o("providerSignupPage.headingLine1"),
						/* @__PURE__ */ x("br", {}),
						o("providerSignupPage.headingLine2")
					]
				}),
				z && /* @__PURE__ */ x("p", {
					className: "signup-details__error",
					children: z
				}),
				/* @__PURE__ */ S("div", {
					className: "signup-details__step",
					children: [/* @__PURE__ */ S("span", {
						className: "signup-details__label",
						children: [
							o("providerSignupPage.firstNameQuestion"),
							" ",
							/* @__PURE__ */ x("span", {
								className: "signup-details__req",
								children: "*"
							})
						]
					}), /* @__PURE__ */ x("input", {
						className: "signup-details__input",
						type: "text",
						placeholder: o("providerSignupPage.firstNamePlaceholder"),
						value: N,
						onChange: (e) => P(e.target.value),
						autoComplete: "given-name",
						autoFocus: !0,
						required: !0
					})]
				}),
				/* @__PURE__ */ S("div", {
					className: "signup-details__step",
					children: [/* @__PURE__ */ S("span", {
						className: "signup-details__label",
						children: [
							o("providerSignupPage.lastNameQuestion"),
							" ",
							/* @__PURE__ */ x("span", {
								className: "signup-details__req",
								children: "*"
							})
						]
					}), /* @__PURE__ */ x("input", {
						className: "signup-details__input",
						type: "text",
						placeholder: o("providerSignupPage.lastNamePlaceholder"),
						value: F,
						readOnly: !0,
						disabled: !0
					})]
				}),
				/* @__PURE__ */ S("div", {
					className: "signup-details__step",
					children: [/* @__PURE__ */ x("span", {
						className: "signup-details__label",
						children: o("providerSignupPage.roleQuestion")
					}), /* @__PURE__ */ x("input", {
						className: "signup-details__input",
						type: "text",
						autoComplete: "organization-title",
						placeholder: o("providerSignupPage.rolePlaceholder"),
						value: L,
						onChange: (e) => R(e.target.value)
					})]
				}),
				/* @__PURE__ */ x("div", {
					className: "signup-details__step",
					children: /* @__PURE__ */ x("button", {
						type: "submit",
						className: "signup-details__continue",
						disabled: !e,
						children: o(V ? "providerSignupPage.submitting" : "providerSignupPage.submit")
					})
				})
			]
		}) });
	}
	return /* @__PURE__ */ S(m, { children: [/* @__PURE__ */ x(d, {
		title: o("providerSignupPage.completeAccountTitle"),
		subtitle: o("providerSignupPage.completeAccountSubtitle")
	}), /* @__PURE__ */ S(p, {
		onSubmit: q,
		error: z,
		submitLabel: o("providerSignupPage.completeSignup"),
		submittingLabel: o("providerSignupPage.completingSignup"),
		isSubmitting: V,
		footer: /* @__PURE__ */ x(n, {
			to: a.account.login,
			className: r(u({ tone: "quiet" }), "text-sm text-[var(--content-secondary)]"),
			children: o("providerSignupPage.backToSignIn")
		}),
		children: [/* @__PURE__ */ x(f, {
			id: "email",
			type: "email",
			autoComplete: "email",
			placeholder: o("providerSignupPage.emailPlaceholder"),
			value: k,
			onChange: (e) => A(e.target.value),
			required: !0
		}), /* @__PURE__ */ x(f, {
			id: "username",
			type: "text",
			autoComplete: "username",
			placeholder: o("providerSignupPage.usernamePlaceholder"),
			value: j,
			onChange: (e) => M(e.target.value),
			required: !0
		})]
	})] });
}
//#endregion
export { k as ProviderSignupPage };
