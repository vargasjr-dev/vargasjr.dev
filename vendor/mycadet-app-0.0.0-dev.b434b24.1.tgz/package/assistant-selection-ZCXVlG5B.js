import { l as e, p as t } from "./schemas-D8_brjAQ.js";
import { _ as n, g as r, h as i, m as a } from "./i18n-BRf-wfgm.js";
import { n as o, t as s } from "./remote-web-pairing-DV2Q8AE4.js";
import { n as c } from "./routes-DW44XTQk.js";
//#region src/assistant/selected-assistant-storage.ts
var l = "cadet:selectedAssistantId";
function u(e) {
	n("cadet:selectedAssistantId", e) || i(l, e);
}
function d() {
	let e = a(l, "");
	return e === "" ? void 0 : e;
}
function f() {
	r(l), i(l, "");
}
//#endregion
//#region src/utils/pairing-address.ts
var p = c.account.pair;
function m(e, t) {
	let n;
	try {
		n = o(e);
	} catch {
		return null;
	}
	return s({
		verificationUri: `${n}${p}`,
		deviceCode: t
	});
}
function h(e, t) {
	return e === null ? null : t === null ? e : m(e, t) ?? e;
}
//#endregion
//#region src/assistant/assistant-selection.ts
var g = e({ assistantSelection: e({
	id: t().min(1),
	apiBase: t().min(1).optional()
}) });
function _(e, t) {
	return { assistantSelection: t ? {
		id: e,
		apiBase: t
	} : { id: e } };
}
function v(e) {
	let t = g.safeParse(e);
	return t.success ? t.data.assistantSelection : void 0;
}
//#endregion
export { f as a, m as i, v as n, d as o, h as r, u as s, _ as t };
