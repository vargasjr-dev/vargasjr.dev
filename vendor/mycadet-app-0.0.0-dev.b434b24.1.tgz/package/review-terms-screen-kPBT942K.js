import { c as e, d as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n } from "./loader-circle-Ch7lYSrj.js";
import { t as r } from "./external-anchor--Bf99ulE.js";
import { t as i } from "./checkbox-r-BQDIah.js";
import { n as a, r as o } from "./i18n-BRf-wfgm.js";
import { t as s } from "./button-BrPHE1Q9.js";
import { n as c, t as l } from "./routes-DW44XTQk.js";
import { t as u } from "./auth-store-Bx-RKZJ9.js";
import { i as d, r as f } from "./consent-persistence-C5xQGklP.js";
import { t as p } from "./return-to-BrgpQtYw.js";
import { useCallback as m, useState as h } from "react";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
var v = n("shield-check", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), y = {}, b = { "2026-06-22": ["Introduces Together AI as a new managed model provider"] };
function x(e) {
	return y[e] ?? [];
}
function S(e) {
	return b[e] ?? [];
}
//#endregion
//#region src/domains/consent/review-terms-screen.tsx
function C({ href: e, policy: t }) {
	return /* @__PURE__ */ g("span", {
		className: "text-body-medium-lighter",
		children: /* @__PURE__ */ g(a, {
			i18nKey: "consentControls.agreeTo",
			ns: "consent",
			values: { policy: t },
			components: [/* @__PURE__ */ g(r, {
				href: e,
				tone: "quiet",
				glyph: !1
			})]
		})
	});
}
function w() {
	let { t: n } = o("consent"), r = e(), [a] = t(), y = u.use.user(), b = u.use.logout(), w = y?.id ?? null, [T] = h(() => f(w)), E = !T.tos, D = !T.privacy, O = !T.hasConsentRecord, k = E, A = D, [j, M] = h(!E), [N, P] = h(!D), F = k && !j || A && !N, I = m(() => {
		d({
			userId: w,
			tos: j,
			privacy: N
		}), r(p(a.get("returnTo"), c.assistant), { replace: !0 });
	}, [
		N,
		r,
		a,
		j,
		w
	]), L = m(async () => {
		await b(), r(c.account.login, { replace: !0 });
	}, [b, r]);
	return /* @__PURE__ */ g("div", {
		className: "flex min-h-full items-center justify-center bg-[var(--surface-base)] px-6 py-16 text-[var(--content-default)]",
		children: /* @__PURE__ */ _("div", {
			className: "flex w-full max-w-xl flex-col items-center",
			children: [
				/* @__PURE__ */ g("div", {
					className: "flex h-12 w-12 items-center justify-center rounded-full border border-[var(--border-subtle)] bg-[var(--surface-lift)]",
					children: /* @__PURE__ */ g(v, {
						className: "h-6 w-6 text-[var(--content-secondary)]",
						strokeWidth: 1.75
					})
				}),
				/* @__PURE__ */ g("h1", {
					className: "mt-5 text-3xl font-semibold tracking-tight",
					children: O ? "Welcome to Cadet" : "Updated terms"
				}),
				/* @__PURE__ */ g("p", {
					className: "mt-3.5 text-center text-body-medium-lighter text-[var(--content-tertiary)]",
					children: O ? "Please review and accept our terms to get started." : "We've updated our terms. Please review and accept to continue."
				}),
				/* @__PURE__ */ _("section", {
					className: "mt-6 w-full",
					children: [
						/* @__PURE__ */ g("p", {
							className: "text-body-small-default font-medium text-[var(--content-secondary)]",
							children: n("consentControls.agreements")
						}),
						k && /* @__PURE__ */ _("label", {
							className: "mt-3 flex items-start gap-3",
							children: [/* @__PURE__ */ g(i, {
								checked: j,
								onCheckedChange: (e) => M(e === !0)
							}), /* @__PURE__ */ g(C, {
								href: l(c.docs.legal.termsOfUse),
								policy: "Terms of Service"
							})]
						}),
						A && /* @__PURE__ */ _("label", {
							className: "mt-3 flex items-start gap-3",
							children: [/* @__PURE__ */ g(i, {
								checked: N,
								onCheckedChange: (e) => P(e === !0)
							}), /* @__PURE__ */ g(C, {
								href: l(c.docs.legal.privacyPolicy),
								policy: "the Privacy Policy"
							})]
						}),
						!O && k && x("2026-06-08").length > 0 && /* @__PURE__ */ _("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ g("p", {
								className: "text-body-small-default font-medium text-[var(--content-secondary)]",
								children: n("consentControls.whatsChanged")
							}), /* @__PURE__ */ g("ul", {
								className: "mt-2 flex flex-col gap-1.5",
								children: x("2026-06-08").map((e) => /* @__PURE__ */ _("li", {
									className: "flex gap-2.5 text-body-medium-lighter",
									children: [/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "mt-[0.5em] h-1 w-1 flex-none rounded-full bg-[var(--content-tertiary)]"
									}), /* @__PURE__ */ g("span", { children: e })]
								}, e))
							})]
						}),
						!O && A && S("2026-06-22").length > 0 && /* @__PURE__ */ _("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ g("p", {
								className: "text-body-small-default font-medium text-[var(--content-secondary)]",
								children: n("consentControls.whatsChanged")
							}), /* @__PURE__ */ g("ul", {
								className: "mt-2 flex flex-col gap-1.5",
								children: S("2026-06-22").map((e) => /* @__PURE__ */ _("li", {
									className: "flex gap-2.5 text-body-medium-lighter",
									children: [/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "mt-[0.5em] h-1 w-1 flex-none rounded-full bg-[var(--content-tertiary)]"
									}), /* @__PURE__ */ g("span", { children: e })]
								}, e))
							})]
						})
					]
				}),
				/* @__PURE__ */ _("div", {
					className: "mt-9 flex w-full flex-col gap-2",
					children: [/* @__PURE__ */ g(s, {
						variant: "primary",
						size: "large",
						fullWidth: !0,
						disabled: F,
						onClick: I,
						children: n("actions.continue")
					}), /* @__PURE__ */ g(s, {
						variant: "outlined",
						size: "large",
						fullWidth: !0,
						onClick: () => void L(),
						children: n("actions.logOut")
					})]
				})
			]
		})
	});
}
//#endregion
export { w as ReviewTermsScreen };
