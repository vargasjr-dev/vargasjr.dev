import { c as e, t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n } from "./loader-circle-Ch7lYSrj.js";
import { r } from "./src-DLa8cepg.js";
import { n as i, r as a, t as o } from "./retire-assistant-kQPSXcqh.js";
import { t as s } from "./ellipsis-vertical-Bx7DMtpt.js";
import { t as c } from "./confirm-dialog-DH3yi6Nk.js";
import { t as l } from "./electron-bridge-VOSuV45z.js";
import { _ as u, o as d, r as f, v as p } from "./i18n-BRf-wfgm.js";
import { i as m, t as ee } from "./assistant-selection-ZCXVlG5B.js";
import { t as h } from "./button-BrPHE1Q9.js";
import { n as g } from "./routes-DW44XTQk.js";
import { r as _, t as v } from "./dist-BTjb3IwJ.js";
import { n as te } from "./account-form-hStE8dzU.js";
import { t as y } from "./account-shell-D0S9QH7J.js";
import { t as b } from "./use-assistant-choices-Dluxsq-7.js";
import { t as x } from "./radio-card-nav-CdLpHF6H.js";
import { useCallback as S, useEffect as ne, useState as C, useSyncExternalStore as w } from "react";
import { Fragment as T, jsx as E, jsxs as D } from "react/jsx-runtime";
var O = n("globe", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",
		key: "13o1zl"
	}],
	["path", {
		d: "M2 12h20",
		key: "9i4pu4"
	}]
]), k = n("link-2", [
	["path", {
		d: "M9 17H7A5 5 0 0 1 7 7h2",
		key: "8i5ue5"
	}],
	["path", {
		d: "M15 7h2a5 5 0 1 1 0 10h-2",
		key: "1b9ql8"
	}],
	["line", {
		x1: "8",
		x2: "16",
		y1: "12",
		y2: "12",
		key: "1jonct"
	}]
]), A = "cadet:remembered-origins";
function j(e) {
	let t = e.trim();
	if (t === "") return null;
	let n;
	try {
		n = new URL(t);
	} catch {
		return null;
	}
	return n.protocol !== "https:" || n.hostname === "" ? null : `${n.origin}${n.pathname.replace(/\/+$/, "")}`;
}
function M(e) {
	let t;
	try {
		t = JSON.parse(e);
	} catch {
		return null;
	}
	return Array.isArray(t) ? N(t) : null;
}
function N(e, t) {
	let n = [], r = /* @__PURE__ */ new Set(), i = t ?? (/* @__PURE__ */ new Date()).toISOString();
	for (let t of e) {
		if (typeof t != "object" || !t) continue;
		let { url: e, name: a, addedAt: o } = t;
		if (typeof e != "string") continue;
		let s = j(e);
		s === null || r.has(s) || (r.add(s), n.push({
			url: s,
			...typeof a == "string" && a !== "" ? { name: a } : {},
			addedAt: typeof o == "string" ? o : i
		}));
	}
	return n;
}
var P = {
	load: async () => {
		let e = null;
		try {
			e = window.localStorage.getItem(A);
		} catch {
			throw Error("storage unavailable");
		}
		if (e === null) return [];
		let t = M(e);
		if (t === null) throw Error("unusable stored value");
		return t;
	},
	save: async (e) => u(A, JSON.stringify(e)),
	watch: (e) => p(A, e)
}, F = {
	origins: [],
	hydrated: !1
}, I = /* @__PURE__ */ new Set();
function L() {
	return {
		...F,
		...B
	};
}
function R(e) {
	F = {
		...F,
		...e
	};
	for (let e of I) e();
}
function z(e) {
	return I.add(e), () => {
		I.delete(e);
	};
}
var B = {
	hydrate: () => K(),
	addOrigin: q,
	removeOrigin: J
}, V = Promise.resolve();
function H(e) {
	let t = V.then(e, e);
	return V = t.catch(() => void 0), t;
}
var U = null, W = !1;
function G() {
	return H(async () => {
		try {
			let e = await P.load();
			L().hydrated ? R({ origins: e }) : U === null ? K() : W = !0;
		} catch {}
	});
}
function K() {
	return U ??= (async () => {
		await Promise.resolve();
		try {
			R({
				origins: await P.load(),
				hydrated: !0
			}), W && (W = !1, G());
		} catch {
			U = null;
		}
	})(), U;
}
async function q(e) {
	let t = j(e.url);
	return t === null ? { ok: !1 } : H(async () => {
		if (await K(), !L().hydrated) return { ok: !1 };
		let n;
		try {
			n = await P.load();
		} catch {
			return { ok: !1 };
		}
		let r = e.name?.trim(), i = n.find((e) => e.url === t), a = i ?? {
			url: t,
			addedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, o = r ? {
			...a,
			name: r
		} : a, s = i ? n.map((e) => e.url === t ? o : e) : [...n, o], c = !1;
		try {
			c = await P.save(s);
		} catch {
			c = !1;
		}
		return c ? (R({ origins: s }), {
			ok: !0,
			origin: o
		}) : { ok: !1 };
	});
}
async function J(e) {
	let t = j(e);
	t !== null && await H(async () => {
		if (await K(), !L().hydrated) return;
		let e;
		try {
			e = await P.load();
		} catch {
			return;
		}
		let n = e.filter((e) => e.url !== t);
		if (n.length !== e.length) {
			let e = !1;
			try {
				e = await P.save(n);
			} catch {
				e = !1;
			}
			if (!e) return;
		}
		R({ origins: n });
	});
}
P.watch(() => void G());
function Y(e) {
	return w(z, () => e(F), () => e(F));
}
var X = Object.assign(Y, {
	getState: L,
	...B,
	use: {
		origins: () => Y((e) => e.origins),
		hydrated: () => Y((e) => e.hydrated)
	}
});
//#endregion
//#region src/components/remove-from-device-dialog.tsx
function re({ url: e, open: t, assistantName: n, closeDialog: r }) {
	let { t: i } = f(), [a, o] = C(!1), [s, l] = C(null), u = S(async () => {
		if (!a) {
			if (o(!0), await X.removeOrigin(e), o(!1), X.getState().origins.some((t) => t.url === e)) {
				l(i("removeFromDeviceDialog.removeFailed"));
				return;
			}
			r();
		}
	}, [
		a,
		e,
		r,
		i
	]), d = S(() => {
		l(null), r();
	}, [r]);
	return /* @__PURE__ */ E(c, {
		open: t,
		title: i("removeFromDeviceDialog.title"),
		message: /* @__PURE__ */ D(T, { children: [i("removeFromDeviceDialog.messageOrigin", { assistantName: n }), s && /* @__PURE__ */ E("span", {
			className: "mt-2 block text-[var(--system-negative-strong)]",
			children: s
		})] }),
		confirmLabel: i("removeFromDeviceDialog.confirm"),
		destructive: !0,
		isPending: a,
		onConfirm: u,
		onCancel: d
	});
}
//#endregion
//#region src/components/account/origin-card-menu.tsx
function ie({ label: e, onRemove: t }) {
	let { t: n } = f("account"), i = n("selectAssistantScreen.rowActionsAriaLabel", { name: e });
	return /* @__PURE__ */ D(r.Root, { children: [/* @__PURE__ */ E(r.Trigger, {
		asChild: !0,
		children: /* @__PURE__ */ E(h, {
			variant: "ghost",
			iconOnly: /* @__PURE__ */ E(s, {}),
			"aria-label": i
		})
	}), /* @__PURE__ */ E(r.Content, {
		title: i,
		align: "end",
		sideOffset: 4,
		children: /* @__PURE__ */ E(r.Item, {
			tone: "destructive",
			label: n("selectAssistantScreen.removeFromDevice"),
			onSelect: t
		})
	})] });
}
//#endregion
//#region src/components/account/retire-card-menu.tsx
function ae({ label: e, onRetire: t }) {
	let { t: n } = f("account"), i = n("selectAssistantScreen.rowActionsAriaLabel", { name: e });
	return /* @__PURE__ */ D(r.Root, { children: [/* @__PURE__ */ E(r.Trigger, {
		asChild: !0,
		children: /* @__PURE__ */ E(h, {
			variant: "ghost",
			iconOnly: /* @__PURE__ */ E(s, {}),
			"aria-label": i
		})
	}), /* @__PURE__ */ E(r.Content, {
		title: i,
		align: "end",
		sideOffset: 4,
		children: /* @__PURE__ */ E(r.Item, {
			tone: "destructive",
			label: n("selectAssistantScreen.retire"),
			onSelect: t
		})
	})] });
}
//#endregion
//#region src/components/account/chooser-avatar-chip.tsx
function oe({ avatarUrl: e, name: t, size: n = 20 }) {
	let [r, i] = C(null), a = e && e !== r ? e : null;
	return /* @__PURE__ */ E("span", {
		"aria-hidden": "true",
		children: a ? /* @__PURE__ */ E("img", {
			src: a,
			alt: "",
			width: n,
			height: n,
			className: "rounded-full object-cover",
			style: {
				width: n,
				height: n,
				flexShrink: 0
			},
			onError: () => i(a)
		}) : /* @__PURE__ */ E("span", {
			className: "flex shrink-0 items-center justify-center rounded-full bg-[var(--surface-lift)] text-[color:var(--content-tertiary)]",
			style: {
				width: n,
				height: n,
				fontSize: Math.max(9, Math.round(n * .45))
			},
			children: t.charAt(0).toUpperCase()
		})
	});
}
//#endregion
//#region src/components/account/chooser-card.tsx
function Z({ icon: e, title: t, subtitle: n, removeMenu: r, selected: i = !1, tabStop: a = !1, disabled: o = !1, onSelect: s }) {
	return /* @__PURE__ */ D("div", {
		role: "radio",
		"aria-checked": i,
		"aria-disabled": o || void 0,
		tabIndex: o ? -1 : a ? 0 : -1,
		onClick: o ? void 0 : () => s?.(),
		onKeyDown: (e) => {
			o || (e.key === "Enter" || e.key === " ") && (e.preventDefault(), s?.());
		},
		className: ["group flex w-full items-center gap-4 rounded-2xl border px-[18px] py-4 text-left", o ? "cursor-default border-[var(--border-base)] bg-[var(--surface-lift)]/40 opacity-60" : [
			"cursor-pointer transition-all duration-200 ease-out",
			"focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--primary-base)]",
			i ? "border-[var(--primary-base)] bg-[var(--surface-lift)]" : "border-[var(--border-base)] bg-[var(--surface-lift)]/60 hover:border-[var(--border-element)] hover:bg-[var(--surface-lift)]"
		].join(" ")].join(" "),
		children: [
			/* @__PURE__ */ E("div", {
				className: ["flex h-12 w-12 shrink-0 items-center justify-center rounded-[10px] transition-colors duration-200", i ? "bg-[var(--primary-base)] text-[var(--surface-base)]" : "bg-[var(--surface-active)]/40 text-[var(--content-secondary)]"].join(" "),
				children: e
			}),
			/* @__PURE__ */ D("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ E("span", {
					className: "block text-body-medium-default text-[var(--content-default)]",
					children: t
				}), n && /* @__PURE__ */ E("span", {
					className: "mt-1 block text-body-small-lighter text-[var(--content-tertiary)]",
					children: n
				})]
			}),
			r && /* @__PURE__ */ E("div", {
				className: "flex shrink-0 items-center",
				onClick: (e) => e.stopPropagation(),
				onKeyDown: (e) => e.stopPropagation(),
				children: r
			})
		]
	});
}
//#endregion
//#region src/runtime/self-hosted-servers.ts
var Q = _("SelfHostedServers");
async function se(e) {
	try {
		return await Q.switchTo({ url: e }), !0;
	} catch (e) {
		return console.debug("[self-hosted-servers] switchTo unavailable:", e), !1;
	}
}
async function ce(e, t) {
	try {
		return await Q.switchToPath({
			url: e,
			path: t
		}), !0;
	} catch (e) {
		return console.debug("[self-hosted-servers] switchToPath unavailable:", e), !1;
	}
}
//#endregion
//#region src/assistant/switch-origin.ts
var le = g.account.pair;
function ue(e) {
	return j(window.location.origin) === e.url;
}
async function de(e, t) {
	let n = t ? m(e.url, t) : null, r = t && n !== null ? `${le}?${new URLSearchParams({ device_code: t }).toString()}` : null, i = () => window.location.assign(n ?? `${e.url}${g.assistant}`), a = l();
	if (a) {
		await a.mainWindow.navigateTo(n ?? `${e.url}${g.assistant}`);
		return;
	}
	if (!v.isNativePlatform()) {
		i();
		return;
	}
	(r === null ? await se(e.url) : await ce(e.url, r)) || i();
}
//#endregion
//#region src/utils/format-date.ts
function fe(e) {
	if (!e) return "—";
	let t = new Date(e), n = (/* @__PURE__ */ new Date()).getTime() - t.getTime(), r = 1e3 * 60, i = r * 60, a = 1440;
	if (r * a, n < 0) {
		let e = -n;
		if (e < i) return "in <1h";
		let t = Math.round(e / r), o = Math.round(t / 60);
		return o < 24 ? `in ${o}h` : `in ${Math.round(t / a)}d`;
	}
	let o = Math.floor(n / 864e5);
	if (o === 0) {
		let e = Math.floor(n / i);
		if (e === 0) {
			let e = Math.floor(n / r);
			return e <= 1 ? "just now" : `${e}m ago`;
		}
		return `${e}h ago`;
	}
	return o === 1 ? "yesterday" : o < 7 ? `${o}d ago` : o < 30 ? `${Math.floor(o / 7)}w ago` : t.toLocaleDateString(d());
}
//#endregion
//#region src/domains/account/pages/select-assistant-screen.tsx
function pe(e, t) {
	return t ? `${e} · Created ${fe(t)}` : e;
}
function $(e) {
	return e.name ?? new URL(e.url).hostname;
}
function me({ icon: e, label: t, disabled: n, onClick: r }) {
	return /* @__PURE__ */ D("button", {
		type: "button",
		onClick: r,
		disabled: n,
		className: [
			"flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[var(--border-element)]/50 px-5 py-3 text-[var(--content-tertiary)]",
			"cursor-pointer transition-all duration-200 ease-out",
			"hover:border-[var(--border-element)] hover:bg-[var(--surface-hover)] hover:text-[var(--content-default)]",
			"disabled:cursor-not-allowed disabled:opacity-50"
		].join(" "),
		children: [e, /* @__PURE__ */ E("span", {
			className: "text-body-medium-default",
			children: t
		})]
	});
}
function he() {
	let { t: n } = f("account"), r = e(), [s, c] = C(null), [l, u] = C(!1), [d, p] = C(null), m = X.use.origins(), [_, v] = C(null), { state: S, retry: w } = b(), A = S.status === "selection" && S.assistants.length === 0 ? "empty" : S.status, j = () => {
		l || (c(null), p(null));
	};
	ne(() => {
		X.hydrate();
	}, []);
	let M = () => {
		v(null);
	}, N = async () => {
		if (!s || l) return;
		u(!0);
		let e = await o(s.id);
		if (u(!1), !e.ok) {
			p(e.error);
			return;
		}
		j(), w();
	};
	return /* @__PURE__ */ D(y, { children: [/* @__PURE__ */ E(te, { title: n("appShell.selection") }), /* @__PURE__ */ D("div", {
		role: "radiogroup",
		"aria-label": n("selectAssistantScreen.listAriaLabel"),
		onKeyDown: x,
		className: "flex flex-col gap-3",
		children: [
			S.status === "selection" && S.assistants.map((e, t) => /* @__PURE__ */ E(Z, {
				icon: /* @__PURE__ */ E(oe, {
					avatarUrl: e.avatar_url,
					name: e.name,
					size: 48
				}),
				title: e.name,
				subtitle: pe(e.remote === "cloud" ? n("selectAssistantScreen.cloudHosted") : n("selectAssistantScreen.selfHosted"), e.created),
				removeMenu: /* @__PURE__ */ E(ae, {
					label: e.name,
					onRetire: () => c({
						id: e.id,
						name: e.name
					})
				}),
				tabStop: t === 0,
				onSelect: () => {
					r(g.assistant, { state: ee(e.id) });
				}
			}, e.id)),
			A === "error" && /* @__PURE__ */ E(Z, {
				icon: /* @__PURE__ */ E(a, {
					size: 22,
					"aria-hidden": "true",
					className: "text-[var(--content-tertiary)]"
				}),
				title: n("appShell.error"),
				disabled: !0
			}),
			m.map((e, t) => {
				let i = ue(e);
				return /* @__PURE__ */ E(Z, {
					icon: /* @__PURE__ */ E(O, { className: "h-5 w-5" }),
					title: $(e),
					subtitle: n(i ? "selectAssistantScreen.currentWithHost" : "selectAssistantScreen.remoteWithHost", { host: new URL(e.url).hostname }),
					removeMenu: /* @__PURE__ */ E(ie, {
						label: $(e),
						onRemove: () => v(e)
					}),
					tabStop: S.status === "selection" && S.assistants.length === 0 && t === 0,
					onSelect: () => {
						i ? r(g.assistant) : de(e);
					}
				}, e.url);
			}),
			A === "empty" ? /* @__PURE__ */ E(h, {
				variant: "primary",
				onClick: () => r(g.account.onboarding.hosting),
				children: n("selectAssistantScreen.hatchAssistant")
			}) : /* @__PURE__ */ E(me, {
				icon: /* @__PURE__ */ E(k, { className: "h-4 w-4" }),
				label: n("selectAssistantScreen.hatchAssistant"),
				onClick: () => r(g.account.onboarding.hosting)
			}),
			A === "unauthenticated" && /* @__PURE__ */ D(T, { children: [/* @__PURE__ */ E("p", {
				role: "status",
				children: n(`appShell.${A}`)
			}), /* @__PURE__ */ E(t, {
				to: g.account.login,
				children: n("accountPage.signIn")
			})] }),
			A === "error" && /* @__PURE__ */ E(h, {
				variant: "outlined",
				onClick: w,
				children: n("appShell.retry")
			}),
			/* @__PURE__ */ E(i, {
				open: s != null,
				error: d,
				isPending: l,
				onConfirm: () => void N(),
				onCancel: j
			}),
			/* @__PURE__ */ E(re, {
				url: _?.url ?? "",
				open: _ != null,
				assistantName: _ ? $(_) : n("selectAssistantScreen.unnamedAssistant"),
				closeDialog: M
			})
		]
	})] });
}
//#endregion
export { he as SelectAssistantScreen };
