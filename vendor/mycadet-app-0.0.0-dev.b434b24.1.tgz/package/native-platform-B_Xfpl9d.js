import { t as e } from "./dist-BTjb3IwJ.js";
import { useSyncExternalStore as t } from "react";
//#region src/runtime/native-platform.ts
function n() {
	return typeof window < "u" && e.isNativePlatform();
}
var r = () => () => {};
function i() {
	return t(r, n, () => !1);
}
//#endregion
export { i as n, n as t };
