import { i as e, n as t } from "./request-Dbjf-LtL.js";
import { i as n, l as r, p as i } from "./schemas-D8_brjAQ.js";
import { t as a } from "./organization-DMy3nLTu.js";
import { t as o } from "./capture-error-DAZY091e.js";
//#region src/types/avatar.ts
function s(e) {
	if (typeof e != "object" || !e) return !1;
	let t = e;
	return typeof t.bodyShape == "string" && typeof t.eyeStyle == "string" && typeof t.color == "string";
}
//#endregion
//#region src/assistant/avatar-traits.ts
var c = r({ content: i() }), l = "data/avatar/character-traits.json";
async function u(e) {
	let n = await a();
	if (!n.ok) return null;
	let r = await t(`/v1/assistants/${encodeURIComponent(e)}/workspace/file?path=${encodeURIComponent(l)}`, c, { organizationId: n.data });
	if (!r.ok) return null;
	try {
		let e = JSON.parse(r.data.content);
		return s(e) ? e : null;
	} catch {
		return null;
	}
}
async function d(t, i) {
	let o = await a();
	return o.ok ? e(`/v1/assistants/${encodeURIComponent(t)}/avatar/render-from-traits`, r({ ok: n() }), i, { organizationId: o.data }) : o;
}
async function f(e, t) {
	try {
		if (await u(e)) return;
		await d(e, t);
	} catch (e) {
		o(e, { context: "onboarding_avatar_sync" });
	}
}
//#endregion
//#region src/utils/avatar-svg-compositor.ts
function p(e, t) {
	let n = e.viewBox, r = Math.min(t / n.width, t / n.height);
	return {
		bodyScale: r,
		bodyTx: (t - n.width * r) / 2,
		bodyTy: (t - n.height * r) / 2
	};
}
function m(e, t) {
	let { bodyScale: n, bodyTx: r, bodyTy: i } = p(e, t);
	return `matrix(${n},0,0,${n},${r},${i})`;
}
function h(e, t, n, r) {
	let i = n.faceCenterOverrides.find((n) => n.bodyShape === e.id && n.eyeStyle === t.id), a = i ? i.faceCenter : e.faceCenter, o = e.viewBox, { bodyScale: s, bodyTx: c, bodyTy: l } = p(e, r), u = t.sourceViewBox, d = Math.min(o.width / u.width, o.height / u.height), f = a.x - t.eyeCenter.x * d, m = a.y - t.eyeCenter.y * d, h = s * d, g = s * f + c, _ = s * m + l;
	return {
		bodyTransform: `matrix(${s},0,0,${s},${c},${l})`,
		eyeTransform: `matrix(${h},0,0,${h},${g},${_})`
	};
}
function g(e, t, n, r) {
	let i = e.bodyShapes.find((e) => e.id === t);
	if (!i) return null;
	let a;
	if (n != null && (a = e.eyeStyles.find((e) => e.id === n), !a)) return null;
	let o = e.colors.find((e) => e.id === r);
	return o ? {
		bodyShape: i,
		eyeStyle: a,
		color: o
	} : null;
}
function _(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function v(e, t, n, r, i = 512) {
	let a = g(e, t, n, r);
	return a ? y(a.bodyShape, a.eyeStyle, a.color, e, i) : null;
}
function y(e, t, n, r, i = 512) {
	if (!t) {
		let t = m(e, i);
		return `<svg xmlns="http://www.w3.org/2000/svg" width="${i}" height="${i}" viewBox="0 0 ${i} ${i}">${`<path d="${_(e.svgPath)}" fill="${_(n.hex)}" transform="${t}"/>`}</svg>`;
	}
	let { bodyTransform: a, eyeTransform: o } = h(e, t, r, i);
	return `<svg xmlns="http://www.w3.org/2000/svg" width="${i}" height="${i}" viewBox="0 0 ${i} ${i}">${`<path d="${_(e.svgPath)}" fill="${_(n.hex)}" transform="${a}"/>`}${t.paths.map((e) => `<path d="${_(e.svgPath)}" fill="${_(e.color)}" transform="${o}"/>`).join("")}</svg>`;
}
//#endregion
//#region src/utils/avatar-random.ts
function b(e) {
	let t = (e) => e[Math.floor(Math.random() * e.length)];
	return {
		bodyShape: t(e.bodyShapes).id,
		eyeStyle: t(e.eyeStyles).id,
		color: t(e.colors).id
	};
}
//#endregion
export { d as a, g as i, v as n, f as o, h as r, b as t };
