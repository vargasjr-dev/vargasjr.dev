import { n as e } from "./routes-DW44XTQk.js";
import { t } from "./return-to-BrgpQtYw.js";
import { t as n } from "./full-page-navigation-BvH_lAEU.js";
//#region src/domains/account/post-auth-destination.ts
function r({ returnTo: r, fallback: i, authIntent: a, returningUser: o }) {
	let s = t(r, i);
	if (!(a === "signup" && (s === "/import" || s.startsWith("/import?") || s.startsWith("/import/")))) if (o) {
		let t = new URL(s, "http://placeholder.invalid");
		t.searchParams.get("new_assistant") !== "1" && [e.onboarding.privacy, e.onboarding.research].some((e) => e === t.pathname) && (s = i);
	} else a === "signup" && (s = e.onboarding.privacy);
	return {
		destination: s,
		requiresFullPageNavigation: n(s)
	};
}
//#endregion
export { r as t };
