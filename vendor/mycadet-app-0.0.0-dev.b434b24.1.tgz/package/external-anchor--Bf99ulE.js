import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { o as t } from "./dist-CB0DYkRa.js";
import { t as n } from "./electron-bridge-VOSuV45z.js";
import { t as r } from "./dist-BTjb3IwJ.js";
import { t as i } from "./native-platform-B_Xfpl9d.js";
import { t as a } from "./text-link-DoFyv9Mp.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
var c = e("external-link", [
	["path", {
		d: "M15 3h6v6",
		key: "1q9fwt"
	}],
	["path", {
		d: "M10 14 21 3",
		key: "gplh6r"
	}],
	["path", {
		d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",
		key: "a6xqqp"
	}]
]);
//#endregion
//#region ../../packages/design-library/src/components/external-anchor.tsx
function l(e) {
	return /^https?:\/\//i.test(e ?? "");
}
function u() {
	return /* @__PURE__ */ o(c, {
		"aria-hidden": !0,
		className: "ml-0.5 inline h-3.5 w-3.5 shrink-0 align-[-0.125em]"
	});
}
function d({ href: e, children: n, glyph: r = !0, tone: i, className: c, ...d }) {
	return /* @__PURE__ */ s("a", {
		...d,
		className: i === void 0 ? c : t(a({ tone: i }), c),
		"data-slot": i === void 0 ? void 0 : "text-link",
		href: e,
		target: "_blank",
		rel: "noopener noreferrer",
		children: [n, r && l(e) ? /* @__PURE__ */ o(u, {}) : null]
	});
}
//#endregion
//#region src/runtime/browser.ts
var f = async (e, t) => {
	if (n()) {
		window.open(e, "_blank");
		return;
	}
	if (r.isNativePlatform()) try {
		let { Browser: t } = await import("./esm-Dp1h7Egw.js");
		await t.open({
			url: e,
			presentationStyle: "popover"
		});
	} catch {
		t(e);
	}
	else t(e);
}, p = (e) => f(e, (e) => {
	window.location.href = e;
});
//#endregion
//#region src/utils/native-anchor.ts
function m(e, t) {
	!t || !i() || (e.preventDefault(), p(t));
}
//#endregion
//#region src/components/external-anchor.tsx
function h({ onOpen: e, ...t }) {
	return /* @__PURE__ */ o(d, {
		...t,
		onClick: (n) => {
			e?.(), m(n, t.href);
		}
	});
}
//#endregion
export { h as t };
