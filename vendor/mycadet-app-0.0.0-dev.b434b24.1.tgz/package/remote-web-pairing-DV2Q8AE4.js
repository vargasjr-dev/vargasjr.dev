import { c as e, l as t, o as n, p as r } from "./schemas-D8_brjAQ.js";
t({
	deviceCode: r(),
	userCode: r(),
	verificationUri: r(),
	publicBaseUrl: r(),
	expiresAt: r(),
	expiresInSeconds: e(),
	intervalSeconds: e()
}), t({
	status: n("approved"),
	verificationUri: r(),
	expiresAt: r()
});
function i(e) {
	let t = new URL(e);
	t.search = "", t.hash = "";
	let n = t.pathname.split("/").filter(Boolean), r = n.indexOf("account");
	return r >= 0 && n.splice(r), t.pathname = n.length ? `/${n.join("/")}` : "/", t.toString().replace(/\/+$/, "");
}
function a(e) {
	let t = new URL(e.verificationUri);
	return t.hash = new URLSearchParams({ device_code: e.deviceCode }).toString(), t.toString();
}
var o = "https://pairing.invalid";
function s(e, ...t) {
	for (let n of t) {
		let t = e.get(n)?.trim();
		if (t) return t;
	}
	return null;
}
function c(e) {
	let t = new URLSearchParams(e.search), n = e.hash.startsWith("#") ? e.hash.slice(1) : e.hash;
	for (let [e, r] of new URLSearchParams(n)) t.has(e) || t.set(e, r);
	return t;
}
function l(e) {
	let t = c(typeof e == "string" ? new URL(e, o) : e);
	return {
		deviceCode: s(t, "deviceCode", "device_code"),
		userCode: s(t, "userCode", "user_code")
	};
}
var u = {
	"invalid-address": !1,
	"unknown-session": !1,
	expired: !1,
	unreachable: !0,
	"gateway-retryable": !0,
	gateway: !1,
	import: !1,
	"import-precheck": !1
};
new Set(Object.keys(u).filter((e) => u[e]));
//#endregion
export { i as n, l as r, a as t };
