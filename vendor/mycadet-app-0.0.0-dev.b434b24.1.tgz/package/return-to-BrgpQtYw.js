import { i as e } from "./routes-DW44XTQk.js";
//#region src/utils/return-to.ts
var t = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//;
function n(n, r) {
	if (!n) return r;
	if (t.test(n)) {
		try {
			let t = new URL(n);
			if (t.protocol === "https:" && e(t.hostname)) return n;
		} catch {}
		return r;
	}
	return n.startsWith("//") || n.includes("\\") || !n.startsWith("/") ? r : n;
}
//#endregion
export { n as t };
