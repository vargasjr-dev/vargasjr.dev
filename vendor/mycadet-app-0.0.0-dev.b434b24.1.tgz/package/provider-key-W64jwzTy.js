//#region src/domains/onboarding/provider-key.ts
var e = "onboarding.providerKey";
function t(t) {
	try {
		if (t === null) {
			sessionStorage.removeItem(e);
			return;
		}
		sessionStorage.setItem(e, JSON.stringify(t));
	} catch {}
}
function n(e) {
	return typeof e == "object" && !!e && "provider" in e && typeof e.provider == "string" && "key" in e && typeof e.key == "string" && (!("model" in e) || typeof e.model == "string") && (!("baseUrl" in e) || typeof e.baseUrl == "string") && (!("customModels" in e) || typeof e.customModels == "string");
}
function r() {
	try {
		let t = sessionStorage.getItem(e);
		if (!t) return null;
		let r = JSON.parse(t);
		return n(r) ? r : null;
	} catch {
		return null;
	}
}
//#endregion
export { t as n, r as t };
