import { d as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { n, t as r } from "./native-deep-link-D8F5_kmQ.js";
import { t as i } from "./oauth-popup-UrZVjT5L.js";
import { useEffect as a } from "react";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/domains/account/pages/oauth-popup-complete-page.tsx
function c() {
	return /* @__PURE__ */ s("svg", {
		className: "oauth-icon",
		viewBox: "0 0 56 56",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		children: [/* @__PURE__ */ o("circle", {
			cx: "28",
			cy: "28",
			r: "28",
			fill: "var(--oauth-positive-bg)"
		}), /* @__PURE__ */ o("path", {
			className: "oauth-check",
			d: "M17 28.5L24.5 36L39 21",
			stroke: "var(--oauth-positive-fg)",
			strokeWidth: "3.5",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			fill: "none"
		})]
	});
}
function l() {
	return /* @__PURE__ */ s("svg", {
		className: "oauth-icon",
		viewBox: "0 0 56 56",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			/* @__PURE__ */ o("circle", {
				cx: "28",
				cy: "28",
				r: "28",
				fill: "var(--oauth-negative-bg)"
			}),
			/* @__PURE__ */ o("path", {
				className: "oauth-cross oauth-cross-1",
				d: "M20 20L36 36",
				stroke: "var(--oauth-negative-fg)",
				strokeWidth: "3.5",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ o("path", {
				className: "oauth-cross oauth-cross-2",
				d: "M36 20L20 36",
				stroke: "var(--oauth-negative-fg)",
				strokeWidth: "3.5",
				strokeLinecap: "round",
				fill: "none"
			})
		]
	});
}
var u = "\n  :root {\n    --oauth-surface: #F5F3EB;\n    --oauth-surface-card: #FFFFFF;\n    --oauth-card-border: #E8E6DA;\n    --oauth-text-primary: #2A2A28;\n    --oauth-text-secondary: #4A4A46;\n    --oauth-positive-bg: #D4DFD0;\n    --oauth-positive-fg: #516748;\n    --oauth-negative-bg: #F7DAC9;\n    --oauth-negative-fg: #DA491A;\n    --oauth-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06);\n    --oauth-font: -apple-system, BlinkMacSystemFont, \"SF Pro Text\", \"Helvetica Neue\", sans-serif;\n  }\n  @media (prefers-color-scheme: dark) {\n    :root:not(.light) {\n      --oauth-surface: #1A1A18;\n      --oauth-surface-card: #2A2A28;\n      --oauth-card-border: #3A3A37;\n      --oauth-text-primary: #F5F3EB;\n      --oauth-text-secondary: #BDB9A9;\n      --oauth-positive-bg: #1A2316;\n      --oauth-positive-fg: #7A8B6F;\n      --oauth-negative-bg: #4E281D;\n      --oauth-negative-fg: #E86B40;\n      --oauth-shadow: 0 1px 3px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.3);\n    }\n  }\n  :root[data-theme=\"dark\"] {\n    --oauth-surface: #1A1A18;\n    --oauth-surface-card: #2A2A28;\n    --oauth-card-border: #3A3A37;\n    --oauth-text-primary: #F5F3EB;\n    --oauth-text-secondary: #BDB9A9;\n    --oauth-positive-bg: #1A2316;\n    --oauth-positive-fg: #7A8B6F;\n    --oauth-negative-bg: #4E281D;\n    --oauth-negative-fg: #E86B40;\n    --oauth-shadow: 0 1px 3px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.3);\n  }\n  .oauth-page {\n    font-family: var(--oauth-font);\n    background: var(--oauth-surface);\n    color: var(--oauth-text-primary);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    min-height: 100vh;\n    margin: 0;\n    padding: 0;\n    -webkit-font-smoothing: antialiased;\n  }\n  .oauth-card {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    text-align: center;\n    padding: 48px 40px 40px;\n    background: var(--oauth-surface-card);\n    border: 1px solid var(--oauth-card-border);\n    border-radius: 16px;\n    box-shadow: var(--oauth-shadow);\n    max-width: 380px;\n    width: 100%;\n    opacity: 0;\n    transform: translateY(8px) scale(0.98);\n    animation: oauthCardIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) 0.1s forwards;\n  }\n  @keyframes oauthCardIn {\n    to { opacity: 1; transform: translateY(0) scale(1); }\n  }\n  .oauth-icon {\n    width: 56px;\n    height: 56px;\n    margin-bottom: 20px;\n    flex-shrink: 0;\n  }\n  .oauth-check {\n    stroke-dasharray: 32;\n    stroke-dashoffset: 32;\n    animation: oauthDraw 0.4s ease-out 0.45s forwards;\n  }\n  .oauth-cross {\n    stroke-dasharray: 22;\n    stroke-dashoffset: 22;\n  }\n  .oauth-cross-1 { animation: oauthDraw 0.3s ease-out 0.45s forwards; }\n  .oauth-cross-2 { animation: oauthDraw 0.3s ease-out 0.55s forwards; }\n  @keyframes oauthDraw {\n    to { stroke-dashoffset: 0; }\n  }\n  .oauth-card h1 {\n    font-size: 18px;\n    font-weight: 600;\n    letter-spacing: -0.2px;\n    color: var(--oauth-text-primary);\n    margin: 0 0 6px;\n  }\n  .oauth-card p {\n    font-size: 13px;\n    line-height: 1.5;\n    color: var(--oauth-text-secondary);\n    margin: 0;\n  }\n";
function d(e) {
	return e.split(/[-_]/).map((e) => e.charAt(0).toUpperCase() + e.slice(1)).join(" ");
}
function f() {
	let { t: f } = t("account"), [p] = e(), m = p.get("requestId"), h = p.get("oauth_status"), g = p.get("oauth_provider"), _ = p.get("oauth_code"), v = p.get("native") === "1", y = g ? d(g) : "", b = h === "connected", x = b ? y ? `Connected to ${y}` : "Authorization Successful" : "Authorization Failed", S = b ? "You can close this popup and return to the app." : `${y || "Service"} connection failed. Please try again.`;
	return a(() => {
		if (v && m) {
			let e = n(window.location.host);
			if (e) {
				window.location.href = r(e, {
					requestId: m,
					oauthStatus: h || null,
					oauthProvider: g || null,
					oauthCode: _ || null
				});
				return;
			}
		}
		let e = {
			type: "cadet:oauth-complete",
			requestId: m,
			oauthStatus: h || null,
			oauthProvider: g || null,
			oauthCode: _ || null
		};
		if (window.opener && m && window.opener.postMessage(e, window.location.origin), m) try {
			window.localStorage.setItem(i(m), JSON.stringify(e));
		} catch {}
		window.close();
	}, [
		m,
		h,
		g,
		_,
		v
	]), /* @__PURE__ */ s("div", {
		className: "oauth-page",
		children: [/* @__PURE__ */ o("style", { dangerouslySetInnerHTML: { __html: u } }), /* @__PURE__ */ s("div", {
			className: "oauth-card",
			children: [
				o(b ? c : l, {}),
				/* @__PURE__ */ o("h1", { children: x }),
				/* @__PURE__ */ o("p", { children: S }),
				!b && _ && /* @__PURE__ */ o("p", {
					style: {
						marginTop: 8,
						fontSize: 11,
						color: "var(--oauth-text-secondary)",
						opacity: .7
					},
					children: f("oauthComplete.errorCode", { code: _ })
				})
			]
		})]
	});
}
//#endregion
export { f as OAuthPopupCompletePage };
