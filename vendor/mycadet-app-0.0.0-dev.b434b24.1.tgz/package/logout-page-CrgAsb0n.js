import { d as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { t as n } from "./capture-error-DAZY091e.js";
import { n as r } from "./routes-DW44XTQk.js";
import { t as i } from "./auth-store-Bx-RKZJ9.js";
import { n as a } from "./account-form-hStE8dzU.js";
import { t as o } from "./account-shell-D0S9QH7J.js";
import { t as s } from "./hard-navigate-CQ88MENc.js";
import { t as c } from "./return-to-BrgpQtYw.js";
import { useEffect as l, useRef as u } from "react";
import { jsx as d } from "react/jsx-runtime";
//#region src/domains/account/pages/logout-page.tsx
function f() {
	let { t: f } = t("account"), [p] = e(), m = i.use.logout(), h = u(!1);
	return l(() => {
		if (h.current) return;
		h.current = !0;
		let e = c(p.get("returnTo"), r.account.login), t = e.startsWith("http") || e === r.account.login ? e : `${r.account.login}?returnTo=${encodeURIComponent(e)}`, i = !1;
		return m().then(() => {
			i || s(t);
		}, (e) => {
			n(e, { context: "account_logout" }), i || s(t);
		}), () => {
			i = !0;
		};
	}, [m, p]), /* @__PURE__ */ d(o, { children: /* @__PURE__ */ d(a, { title: f("logoutPage.title") }) });
}
//#endregion
export { f as LogoutPage };
