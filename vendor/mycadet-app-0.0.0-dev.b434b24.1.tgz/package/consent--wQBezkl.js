//#region src/i18n/locales/es/consent.json
var e = {
	agreeTo: "Acepto <0>{policy}</0>",
	whatsChanged: "Qué ha cambiado",
	agreements: "Acuerdos"
}, t = {
	continue: "Continuar",
	logOut: "Cerrar sesión"
}, n = {
	consentControls: e,
	actions: t
};
//#endregion
export { t as actions, e as consentControls, n as default };
