import { r as e } from "./dist-BTjb3IwJ.js";
//#region ../../node_modules/.bun/@capacitor+browser@8.0.3+33da1c2fb16abc29/node_modules/@capacitor/browser/dist/esm/index.js
var t = e("Browser", { web: () => import("./web-9nszRGqr.js").then((e) => new e.BrowserWeb()) });
//#endregion
export { t as Browser };
