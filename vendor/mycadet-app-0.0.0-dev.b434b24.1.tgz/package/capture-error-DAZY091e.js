//#region ../../packages/design-library/src/utils/normalize-error.ts
function e(e) {
	if (e instanceof Error) return e;
	if (typeof e == "object" && e) {
		let t = e, n = t.detail;
		if (typeof n == "string") {
			let t = Error(n);
			return t.cause = e, t;
		}
		let r = t.message;
		if (typeof r == "string") {
			let t = Error(r);
			return t.cause = e, t;
		}
		try {
			let t = Error(JSON.stringify(e));
			return t.cause = e, t;
		} catch {
			let t = /* @__PURE__ */ Error("Non-serializable error object");
			return t.cause = e, t;
		}
	}
	return Error(String(e));
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/subscribable.js
var t = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set(), this.subscribe = this.subscribe.bind(this);
	}
	subscribe(e) {
		return this.listeners.add(e), this.onSubscribe(), () => {
			this.listeners.delete(e), this.onUnsubscribe();
		};
	}
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
}, n = {
	setTimeout: (e, t) => setTimeout(e, t),
	clearTimeout: (e) => clearTimeout(e),
	setInterval: (e, t) => setInterval(e, t),
	clearInterval: (e) => clearInterval(e)
}, r = new class {
	#e = n;
	setTimeoutProvider(e) {
		this.#e = e;
	}
	setTimeout(e, t) {
		return this.#e.setTimeout(e, t);
	}
	clearTimeout(e) {
		this.#e.clearTimeout(e);
	}
	setInterval(e, t) {
		return this.#e.setInterval(e, t);
	}
	clearInterval(e) {
		this.#e.clearInterval(e);
	}
}();
function i(e) {
	setTimeout(e, 0);
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/utils.js
var a = typeof window > "u" || "Deno" in globalThis;
function o() {}
function s(e) {
	return typeof e == "number" && e >= 0 && e !== Infinity;
}
function c(e, t) {
	return Math.max(e + (t || 0) - Date.now(), 0);
}
function l(e, t) {
	return typeof e == "function" ? e(t) : e;
}
function u(e, t) {
	return typeof e == "function" ? e(t) : e;
}
function d(e) {
	return JSON.stringify(e, (e, t) => g(t) ? Object.keys(t).sort().reduce((e, n) => (e[n] = t[n], e), {}) : t);
}
var f = Object.prototype.hasOwnProperty;
function p(e, t, n = 0) {
	if (e === t) return e;
	if (n > 500) return t;
	let r = h(e) && h(t);
	if (!r && !(g(e) && g(t))) return t;
	let i = (r ? e : Object.keys(e)).length, a = r ? t : Object.keys(t), o = a.length, s = r ? Array(o) : {}, c = 0;
	for (let l = 0; l < o; l++) {
		let o = r ? l : a[l], u = e[o], d = t[o];
		if (u === d) {
			s[o] = u, (r ? l < i : f.call(e, o)) && c++;
			continue;
		}
		if (u === null || d === null || typeof u != "object" || typeof d != "object") {
			s[o] = d;
			continue;
		}
		let m = p(u, d, n + 1);
		s[o] = m, m === u && c++;
	}
	return i === o && c === i ? e : s;
}
function m(e, t) {
	if (!t || Object.keys(e).length !== Object.keys(t).length) return !1;
	for (let n in e) if (e[n] !== t[n]) return !1;
	return !0;
}
function h(e) {
	return Array.isArray(e) && e.length === Object.keys(e).length;
}
function g(e) {
	if (!_(e)) return !1;
	let t = e.constructor;
	if (t === void 0) return !0;
	let n = t.prototype;
	return !(!_(n) || !n.hasOwnProperty("isPrototypeOf") || Object.getPrototypeOf(e) !== Object.prototype);
}
function _(e) {
	return Object.prototype.toString.call(e) === "[object Object]";
}
function v(e, t, n) {
	return typeof n.structuralSharing == "function" ? n.structuralSharing(e, t) : n.structuralSharing === !1 ? t : p(e, t);
}
function y(e, t) {
	return typeof e == "function" ? e(...t) : !!e;
}
var b = new class extends t {
	#e;
	#t;
	#n;
	constructor() {
		super(), this.#n = (e) => {
			if (!a && window.addEventListener) {
				let t = () => e();
				return window.addEventListener("visibilitychange", t, !1), () => {
					window.removeEventListener("visibilitychange", t);
				};
			}
		};
	}
	onSubscribe() {
		this.#t || this.setEventListener(this.#n);
	}
	onUnsubscribe() {
		this.hasListeners() || (this.#t?.(), this.#t = void 0);
	}
	setEventListener(e) {
		this.#n = e, this.#t?.(), this.#t = e((e) => {
			typeof e == "boolean" ? this.setFocused(e) : this.onFocus();
		});
	}
	setFocused(e) {
		this.#e !== e && (this.#e = e, this.onFocus());
	}
	onFocus() {
		let e = this.isFocused();
		this.listeners.forEach((t) => {
			t(e);
		});
	}
	isFocused() {
		return typeof this.#e == "boolean" ? this.#e : globalThis.document?.visibilityState !== "hidden";
	}
}();
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/thenable.js
function x() {
	let e, t, n = new Promise((n, r) => {
		e = n, t = r;
	});
	n.status = "pending", n.catch(() => {});
	function r(e) {
		Object.assign(n, e), delete n.resolve, delete n.reject;
	}
	return n.resolve = (t) => {
		r({
			status: "fulfilled",
			value: t
		}), e(t);
	}, n.reject = (e) => {
		r({
			status: "rejected",
			reason: e
		}), t(e);
	}, n;
}
var S = new class extends t {
	#e = !0;
	#t;
	#n;
	constructor() {
		super(), this.#n = (e) => {
			if (!a && window.addEventListener) {
				let t = () => e(!0), n = () => e(!1);
				return window.addEventListener("online", t, !1), window.addEventListener("offline", n, !1), () => {
					window.removeEventListener("online", t), window.removeEventListener("offline", n);
				};
			}
		};
	}
	onSubscribe() {
		this.#t || this.setEventListener(this.#n);
	}
	onUnsubscribe() {
		this.hasListeners() || (this.#t?.(), this.#t = void 0);
	}
	setEventListener(e) {
		this.#n = e, this.#t?.(), this.#t = e(this.setOnline.bind(this));
	}
	setOnline(e) {
		this.#e !== e && (this.#e = e, this.listeners.forEach((t) => {
			t(e);
		}));
	}
	isOnline() {
		return this.#e;
	}
}();
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/retryer.js
function C(e) {
	return (e ?? "online") === "online" ? S.isOnline() : !0;
}
var w = class extends Error {
	constructor(e) {
		super("CancelledError"), this.revert = e?.revert, this.silent = e?.silent;
	}
};
function T(e) {
	return e instanceof w;
}
//#endregion
//#region ../../packages/design-library/src/utils/is-cancellation-error.ts
function E(e) {
	return T(e) ? !0 : typeof e == "object" && !!e && e.name === "AbortError";
}
//#endregion
//#region ../../packages/design-library/src/utils/is-transient-network-error.ts
function D(e) {
	if (!(e instanceof TypeError)) return !1;
	let t = e.message;
	return !!(t === "Failed to fetch" || t.startsWith("Failed to fetch (") && t.endsWith(")") || t === "Load failed" || t.startsWith("Load failed (") && t.endsWith(")") || t === "NetworkError when attempting to fetch resource" || t === "NetworkError when attempting to fetch resource.");
}
//#endregion
//#region ../../packages/design-library/src/utils/capture-error.ts
function O(t, n) {
	if (D(t) || E(t)) return;
	let r = e(t), i = { ...n.extra };
	r !== t && (i.originalError = t);
	let a = {};
	n.tags && Object.keys(n.tags).length > 0 && (a.tags = n.tags), Object.keys(i).length > 0 && (a.extra = i);
	let o = `[${n.context}]`, s = Object.keys(a).length > 0 ? a : "";
	if (n.level === "warning" || n.level === "info") {
		console.warn(o, r, s);
		return;
	}
	console.error(o, r, s);
}
//#endregion
export { t as _, d as a, o as c, l as d, m as f, r as g, i as h, b as i, v as l, c as m, C as n, a as o, y as p, x as r, s, O as t, u };
