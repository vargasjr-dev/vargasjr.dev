import { t as e } from "./electron-bridge-VOSuV45z.js";
import { n as t, r as n } from "./session-token-HN3JX-0v.js";
import { l as r, p as i } from "./schemas-D8_brjAQ.js";
import { f as a, l as o, u as s } from "./i18n-BRf-wfgm.js";
import { n as c } from "./routes-DW44XTQk.js";
import { r as l, t as u } from "./dist-BTjb3IwJ.js";
import { a as d, d as f, i as p, o as m, s as h, t as g } from "./auth-store-Bx-RKZJ9.js";
import { t as _ } from "./native-platform-B_Xfpl9d.js";
import { t as v } from "./return-to-BrgpQtYw.js";
import { t as y } from "./returning-user-B8ql5mWL.js";
//#region src/domains/account/attribution.ts
var b = [
	"utm_source",
	"utm_medium",
	"utm_campaign",
	"utm_content",
	"utm_term",
	"gclid",
	"gbraid",
	"wbraid",
	"msclkid",
	"fbclid",
	"ttclid",
	"li_fat_id",
	"twclid"
], x = 512;
function S(e) {
	let t = new URLSearchParams(e), n = {};
	for (let e of b) {
		let r = t.get(e);
		r && (n[e] = r.slice(0, x));
	}
	return n;
}
function C(e, t) {
	let n = e.indexOf("?"), r = new URLSearchParams(n === -1 ? "" : e.slice(n + 1)), i = new URLSearchParams();
	for (let [e, n] of Object.entries(S(t))) r.has(e) || i.append(e, n);
	let a = i.toString();
	return a === "" ? e : `${e}${n === -1 ? "?" : "&"}${a}`;
}
//#endregion
//#region src/runtime/install-referrer.ts
var w = l("InstallReferrer");
async function T() {
	if (u.getPlatform() !== "android") return {};
	if (s("installReferrer")) return S(o("installReferrer", ""));
	try {
		let { referrer: e } = await w.read(), t = S(e ?? ""), n = new URLSearchParams(t).toString();
		return n && a("installReferrer", n), t;
	} catch (e) {
		return console.debug("[install-referrer] read unavailable:", e), {};
	}
}
function E() {
	o("installReferrer", "") !== "" && a("installReferrer", "");
}
//#endregion
//#region src/runtime/native-attribution.ts
async function D(e) {
	let t = e ?? S(window.location.search);
	if (Object.keys(t).length > 0) return t;
	let n = await T();
	return Object.keys(n).length > 0 ? n : void 0;
}
//#endregion
//#region src/runtime/native-login.ts
var O = c.assistant, k = l("NativeAuth");
function A() {
	return `${window.location.protocol}//${window.location.host}`;
}
async function j(e) {
	let t = await D(e?.attribution), n = e?.baseURL ?? A(), r = v(e?.returnTo ?? null, O), { sessionToken: i } = await k.startAuth({
		baseURL: n,
		...e?.loginHint ? { loginHint: e.loginHint } : {},
		...e?.intent ? { intent: e.intent } : {},
		...t ? { attribution: t } : {},
		postAuthDestination: r
	});
	await M(i, r);
}
async function M(e, t) {
	P(e), _() && await N(), E(), p() && !await m(e) && u.getPlatform() === "android" && d(!1), window.location.href = t;
}
async function N() {
	for (let e = 0; e < 6; e++) {
		try {
			let e = await h();
			if (e.ok && e.data.user) return;
		} catch {}
		await new Promise((t) => setTimeout(t, 50 * (e + 1)));
	}
}
function P(e) {
	let t = "path=/; domain=.mycadet.ai; secure; samesite=lax; max-age=1209600";
	document.cookie = `sessionid=${e}; ${t}`, document.cookie = `__Secure-sessionid=${e}; ${t}`;
}
//#endregion
//#region src/lib/auth/provider-redirect.ts
var F = "/_allauth/browser/v1/auth/provider/redirect";
function I(e, t, n, r = {}) {
	let i = {
		provider: e,
		callback_url: new URL(t, n).href,
		process: "login"
	};
	r.intent && (i.intent = r.intent), r.loginHint && (i.login_hint = r.loginHint);
	for (let e of b) {
		let t = r.attribution?.[e];
		t && (i[e] = t);
	}
	return i;
}
function L(e) {
	if (!e) throw Error("Unable to start provider redirect: CSRF token is missing. The session may not be initialized. Please refresh the page and try again.");
}
async function R(e, r, i = {}) {
	await t();
	let a = n();
	L(a);
	let o = window.location.origin, s = document.createElement("form");
	s.method = "POST", s.action = `${o}${F}`;
	let c = I(e, r, o, {
		...i,
		attribution: i.attribution ?? S(window.location.search)
	});
	c.csrfmiddlewaretoken = a;
	for (let [e, t] of Object.entries(c)) {
		let n = document.createElement("input");
		n.type = "hidden", n.name = e, n.value = t, s.appendChild(n);
	}
	document.body.appendChild(s), s.submit();
}
//#endregion
//#region src/runtime/native-auth-context.ts
var z = { async read() {
	return { returningUser: await y() };
} }, B = r({ sessionToken: i().min(1) });
//#endregion
//#region src/runtime/native-post-auth-destination.ts
function V(e, t, n) {
	let r = e === "signup";
	if (n.returningUser) {
		let [e, n = ""] = (t ?? "").split(/[?#]/);
		return new URLSearchParams(n).get("new_assistant") !== "1" && [
			c.account.onboarding.hosting,
			c.onboarding.privacy,
			c.onboarding.research
		].some((t) => t === e) ? c.assistant : t ?? (r ? c.assistant : null);
	}
	return r ? c.onboarding.privacy : t ?? null;
}
//#endregion
//#region src/runtime/desktop-login.ts
async function H(t = {}) {
	let n = e()?.auth;
	if (!n?.startOAuth) throw Object.assign(/* @__PURE__ */ Error("The desktop auth bridge is unavailable. Update the app to sign in."), {
		code: "AUTH_ERROR",
		data: { authError: "desktop_update_required" }
	});
	let r = f();
	try {
		let e = await n.startOAuth({
			loginHint: t.loginHint,
			intent: t.intent
		});
		if (!B.safeParse(e).success) throw Error("The desktop auth bridge returned an invalid session.");
		await g.getState().refreshSession();
		let r = v(V(t.intent, t.returnTo, await z.read()), c.assistant);
		window.location.href = r;
	} finally {
		r();
	}
}
//#endregion
//#region src/lib/auth/auth-flow.ts
async function U(t, n, r = {}) {
	if (_()) {
		try {
			await j({
				returnTo: V(r.intent, r.returnTo, await z.read()),
				loginHint: r.loginHint,
				intent: r.intent,
				attribution: r.attribution
			});
		} catch (e) {
			if (e?.code === "USER_CANCELLED") return;
			throw e;
		}
		return;
	}
	if (e()) {
		await H(r);
		return;
	}
	await R(t, n, r);
}
//#endregion
export { j as n, C as r, U as t };
