import { n as e } from "./loader-circle-Ch7lYSrj.js";
var t = e("arrow-left", [["path", {
	d: "m12 19-7-7 7-7",
	key: "1l729n"
}], ["path", {
	d: "M19 12H5",
	key: "x3x0zl"
}]]);
//#endregion
export { t };
