import { t as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { t as n } from "./capture-error-DAZY091e.js";
import { n as r } from "./routes-DW44XTQk.js";
import { n as i, r as a, t as o } from "./auth-store-Bx-RKZJ9.js";
import { n as s } from "./account-form-hStE8dzU.js";
import { t as c } from "./account-shell-D0S9QH7J.js";
import { n as l, t as u } from "./provider-DTIzxq2J.js";
import { t as d } from "./hard-navigate-CQ88MENc.js";
import { t as f } from "./auth-flow-wtiOWtTR.js";
import { useState as p } from "react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
//#region src/domains/account/pages/account-page.tsx
function g() {
	let { t: g } = t("account"), _ = i(), v = a(), y = o.use.user(), b = o.use.logout(), [x, S] = p(null), [C, w] = p(!1), T = async () => {
		S(null), w(!0);
		try {
			await f(l, u);
		} catch (e) {
			console.error("[account] auth flow failed:", e), S(g("authErrors.genericFailure")), w(!1);
		}
	};
	return v ? /* @__PURE__ */ m(c, { children: /* @__PURE__ */ m(s, { title: g("accountPage.loading") }) }) : _ ? /* @__PURE__ */ h(c, { children: [/* @__PURE__ */ m(s, {
		title: y?.username ? g("accountPage.signedInTitleNamed", { name: y.username }) : g("accountPage.signedInTitle"),
		subtitle: g("accountPage.signedInSubtitle")
	}), /* @__PURE__ */ h("div", {
		className: "flex flex-col items-center gap-4",
		children: [
			/* @__PURE__ */ m(e, {
				to: r.assistant,
				className: "inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--primary-base)] px-6 py-3 text-sm font-medium text-[var(--content-inset)] no-underline transition-colors hover:bg-[var(--primary-hover)]",
				children: g("accountPage.goToAssistant")
			}),
			/* @__PURE__ */ m(e, {
				to: r.account.assistants,
				className: "inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[var(--border-base)] px-6 py-3 text-sm font-medium text-[var(--content-default)] no-underline transition-colors hover:bg-[var(--surface-lift)]",
				children: g("accountPage.manageAssistants")
			}),
			/* @__PURE__ */ m("button", {
				type: "button",
				onClick: async () => {
					try {
						await b();
					} catch (e) {
						n(e, { context: "account_logout" });
					} finally {
						d(r.account.login);
					}
				},
				className: "cursor-pointer bg-transparent text-sm font-normal text-[var(--content-secondary)] transition-colors hover:text-[var(--content-default)]",
				children: g("accountPage.signOut")
			})
		]
	})] }) : /* @__PURE__ */ h(c, { children: [
		/* @__PURE__ */ m(s, {
			title: g("accountPage.welcomeTitle"),
			subtitle: g("accountPage.welcomeSubtitle")
		}),
		x && /* @__PURE__ */ m("p", {
			className: "text-center text-sm text-[var(--system-negative-strong)]",
			children: x
		}),
		/* @__PURE__ */ m("div", {
			className: "flex flex-col items-center gap-4",
			children: /* @__PURE__ */ m("button", {
				type: "button",
				onClick: () => void T(),
				disabled: C,
				className: "inline-flex w-full cursor-pointer items-center justify-center gap-2 rounded-lg bg-[var(--primary-base)] px-6 py-3 text-sm font-medium text-[var(--content-inset)] transition-colors hover:bg-[var(--primary-hover)] disabled:opacity-50",
				children: g("accountPage.signIn")
			})
		})
	] });
}
//#endregion
export { g as AccountPage };
