import { s as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import "./src-DLa8cepg.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { t as n } from "./button-BrPHE1Q9.js";
import { t as r } from "./capture-error-DAZY091e.js";
import { n as i } from "./routes-DW44XTQk.js";
import { n as a } from "./native-platform-B_Xfpl9d.js";
import { n as o, r as s } from "./auth-flow-wtiOWtTR.js";
import { a as c, i as l, n as u, o as d, r as f, t as p } from "./auth-welcome-screen-GNygh2JH.js";
import { n as m, t as h } from "./use-return-to-short-circuit-BXFgxgX8.js";
import { useState as g } from "react";
import { jsx as _ } from "react/jsx-runtime";
//#region src/domains/account/pages/login-page.tsx
function v({ returnTo: e }) {
	let { t: i } = t("account"), [a, s] = g(null), [p, m] = g(!1), h = async () => {
		s(null), m(!0);
		try {
			await o({ returnTo: e ?? null });
		} catch (e) {
			if (l(e)) {
				m(!1);
				return;
			}
			r(e, {
				context: "native_login",
				tags: { authError: c(e) ?? "unclassified" }
			}), s(i(d(e))), m(!1);
		}
	};
	return /* @__PURE__ */ _(f, { children: /* @__PURE__ */ _(u, {
		error: a,
		children: /* @__PURE__ */ _(n, {
			type: "button",
			variant: "primary",
			size: "large",
			fullWidth: !0,
			onClick: () => {
				h();
			},
			disabled: p,
			children: i("loginPage.signIn")
		})
	}) });
}
function y({ returnTo: n }) {
	let { t: r } = t("account"), { search: a } = e(), o = s(n ? `${i.account.signup}?returnTo=${encodeURIComponent(n)}` : i.account.signup, a);
	return /* @__PURE__ */ _(p, {
		returnTo: n,
		errorContext: "web_login",
		secondary: {
			label: r("loginPage.signUp"),
			href: o
		}
	});
}
function b() {
	let e = a(), t = h();
	return t.kind === "wait" ? /* @__PURE__ */ _(f, { children: /* @__PURE__ */ _(m, {}) }) : t.kind === "redirect" ? t.node : _(e ? v : y, { returnTo: t.returnTo });
}
//#endregion
export { b as LoginPage };
