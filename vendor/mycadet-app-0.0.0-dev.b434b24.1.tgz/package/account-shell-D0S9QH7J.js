import { jsx as e } from "react/jsx-runtime";
//#region src/components/account/account-shell.tsx
function t({ children: t }) {
	return /* @__PURE__ */ e("div", {
		className: "flex min-h-screen items-center justify-center bg-[var(--surface-base)]",
		children: /* @__PURE__ */ e("div", {
			className: "w-full max-w-[480px] px-6",
			children: /* @__PURE__ */ e("div", {
				className: "flex flex-col items-center gap-10",
				children: /* @__PURE__ */ e("div", {
					className: "w-full",
					children: t
				})
			})
		})
	});
}
//#endregion
export { t };
