import { c as e, d as t, t as n } from "./chunk-5KNZJZUH-DggPzR22.js";
import { o as r } from "./dist-CB0DYkRa.js";
import { r as i } from "./i18n-BRf-wfgm.js";
import { n as a } from "./api-DnMWUBLS.js";
import { t as o } from "./capture-error-DAZY091e.js";
import { n as s } from "./routes-DW44XTQk.js";
import { s as c, t as l } from "./auth-store-Bx-RKZJ9.js";
import { t as u } from "./text-link-DoFyv9Mp.js";
import { n as d } from "./account-form-hStE8dzU.js";
import { t as f } from "./account-shell-D0S9QH7J.js";
import { t as p } from "./returning-user-B8ql5mWL.js";
import { n as m } from "./provider-callback-BIm8IFvx.js";
import { t as h } from "./post-auth-destination-DPiH-YiC.js";
import { useEffect as g, useRef as _, useState as v } from "react";
import { jsx as y, jsxs as b } from "react/jsx-runtime";
//#region src/domains/account/callback-flows.ts
function x(e, t) {
	return e ? { kind: "authenticated" } : t.some((e) => e.id === "provider_signup" && e.is_pending) ? { kind: "provider_signup" } : {
		kind: "error",
		message: "Unexpected authentication state."
	};
}
//#endregion
//#region src/domains/account/pages/provider-callback-page.tsx
function S() {
	let { t: S } = i("account"), [C] = t(), w = e(), T = l.use.refreshSession(), E = C.get("error"), [D, O] = v(null), k = _(!1), A = C.get("returnTo"), j = m(C);
	return g(() => {
		k.current || E || (k.current = !0, (async () => {
			try {
				let e = await c(), t = x(e.ok && !!e.data.user, e.ok ? [] : e.flows ?? []);
				switch (t.kind) {
					case "authenticated": {
						await T();
						try {
							let e = await a();
							if (e.ok && e.data.length > 0 && !A) {
								w(s.assistant, { replace: !0 });
								break;
							}
						} catch {}
						let e = s.assistant, { destination: t, requiresFullPageNavigation: n } = h({
							returnTo: A,
							fallback: e,
							authIntent: j,
							returningUser: await p()
						});
						n ? window.location.href = t : w(t, { replace: !0 });
						break;
					}
					case "provider_signup": {
						let e = C.get("returnTo");
						w(e ? `${s.account.providerSignup}?returnTo=${encodeURIComponent(e)}` : s.account.providerSignup, { replace: !0 });
						break;
					}
					case "error":
						O(t.message);
						break;
				}
			} catch (e) {
				o(e, { context: "provider_callback" }), O("Something went wrong. Please try signing in again.");
			}
		})());
	}, [
		j,
		E,
		T,
		A,
		w,
		C
	]), E === "signup_closed" ? /* @__PURE__ */ b(f, { children: [/* @__PURE__ */ y(d, {
		title: S("providerCallbackPage.signupClosedTitle"),
		subtitle: S("providerCallbackPage.signupClosedSubtitle")
	}), /* @__PURE__ */ y("div", {
		className: "flex flex-col items-center gap-4",
		children: /* @__PURE__ */ y(n, {
			to: s.account.login,
			className: r(u({ tone: "quiet" }), "text-sm font-medium text-[var(--content-emphasised)]"),
			children: S("providerCallbackPage.backToSignIn")
		})
	})] }) : E || D ? /* @__PURE__ */ b(f, { children: [/* @__PURE__ */ y(d, {
		title: S("providerCallbackPage.failedTitle"),
		subtitle: D ?? S("providerCallbackPage.failedSubtitle")
	}), /* @__PURE__ */ y("div", {
		className: "flex flex-col items-center gap-4",
		children: /* @__PURE__ */ y(n, {
			to: s.account.login,
			className: "inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--primary-base)] px-6 py-3 text-sm font-medium text-[var(--content-inset)] no-underline transition-colors hover:bg-[var(--primary-hover)]",
			children: S("providerCallbackPage.backToSignIn")
		})
	})] }) : /* @__PURE__ */ y(f, { children: /* @__PURE__ */ y(d, {
		title: S("providerCallbackPage.completingTitle"),
		subtitle: S("providerCallbackPage.completingSubtitle")
	}) });
}
//#endregion
export { S as ProviderCallbackPage };
