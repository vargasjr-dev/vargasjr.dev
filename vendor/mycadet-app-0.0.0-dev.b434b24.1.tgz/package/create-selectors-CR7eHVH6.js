import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { _ as t, c as n, d as r, f as i, g as a, h as o, i as s, l as c, m as l, n as u, o as d, p as f, r as p, s as m, u as h } from "./capture-error-DAZY091e.js";
import * as g from "react";
import _, { useCallback as v, useSyncExternalStore as y } from "react";
import "react/jsx-runtime";
var b = e("square", [["rect", {
	width: "18",
	height: "18",
	x: "3",
	y: "3",
	rx: "2",
	key: "afitv7"
}]]), x = o;
function S() {
	let e = [], t = 0, n = (e) => {
		e();
	}, r = (e) => {
		e();
	}, i = x, a = (r) => {
		t ? e.push(r) : i(() => {
			n(r);
		});
	}, o = () => {
		let t = e;
		e = [], t.length && i(() => {
			r(() => {
				t.forEach((e) => {
					n(e);
				});
			});
		});
	};
	return {
		batch: (e) => {
			let n;
			t++;
			try {
				n = e();
			} finally {
				t--, t || o();
			}
			return n;
		},
		batchCalls: (e) => (...t) => {
			a(() => {
				e(...t);
			});
		},
		schedule: a,
		setNotifyFunction: (e) => {
			n = e;
		},
		setBatchNotifyFunction: (e) => {
			r = e;
		},
		setScheduler: (e) => {
			i = e;
		}
	};
}
var C = S();
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/query.js
function w(e, t) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: u(t.networkMode) ? "fetching" : "paused",
		...e === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+query-core@5.90.20/node_modules/@tanstack/query-core/build/modern/queryObserver.js
var T = class extends t {
	constructor(e, t) {
		super(), this.options = t, this.#e = e, this.#s = null, this.#o = p(), this.bindMethods(), this.setOptions(t);
	}
	#e;
	#t = void 0;
	#n = void 0;
	#r = void 0;
	#i;
	#a;
	#o;
	#s;
	#c;
	#l;
	#u;
	#d;
	#f;
	#p;
	#m = /* @__PURE__ */ new Set();
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		this.listeners.size === 1 && (this.#t.addObserver(this), D(this.#t, this.options) ? this.#h() : this.updateResult(), this.#y());
	}
	onUnsubscribe() {
		this.hasListeners() || this.destroy();
	}
	shouldFetchOnReconnect() {
		return O(this.#t, this.options, this.options.refetchOnReconnect);
	}
	shouldFetchOnWindowFocus() {
		return O(this.#t, this.options, this.options.refetchOnWindowFocus);
	}
	destroy() {
		this.listeners = /* @__PURE__ */ new Set(), this.#b(), this.#x(), this.#t.removeObserver(this);
	}
	setOptions(e) {
		let t = this.options, n = this.#t;
		if (this.options = this.#e.defaultQueryOptions(e), this.options.enabled !== void 0 && typeof this.options.enabled != "boolean" && typeof this.options.enabled != "function" && typeof h(this.options.enabled, this.#t) != "boolean") throw Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#S(), this.#t.setOptions(this.options), t._defaulted && !i(this.options, t) && this.#e.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#t,
			observer: this
		});
		let a = this.hasListeners();
		a && k(this.#t, n, this.options, t) && this.#h(), this.updateResult(), a && (this.#t !== n || h(this.options.enabled, this.#t) !== h(t.enabled, this.#t) || r(this.options.staleTime, this.#t) !== r(t.staleTime, this.#t)) && this.#g();
		let o = this.#_();
		a && (this.#t !== n || h(this.options.enabled, this.#t) !== h(t.enabled, this.#t) || o !== this.#p) && this.#v(o);
	}
	getOptimisticResult(e) {
		let t = this.#e.getQueryCache().build(this.#e, e), n = this.createResult(t, e);
		return j(this, n) && (this.#r = n, this.#a = this.options, this.#i = this.#t.state), n;
	}
	getCurrentResult() {
		return this.#r;
	}
	trackResult(e, t) {
		return new Proxy(e, { get: (e, n) => (this.trackProp(n), t?.(n), n === "promise" && (this.trackProp("data"), !this.options.experimental_prefetchInRender && this.#o.status === "pending" && this.#o.reject(/* @__PURE__ */ Error("experimental_prefetchInRender feature flag is not enabled"))), Reflect.get(e, n)) });
	}
	trackProp(e) {
		this.#m.add(e);
	}
	getCurrentQuery() {
		return this.#t;
	}
	refetch({ ...e } = {}) {
		return this.fetch({ ...e });
	}
	fetchOptimistic(e) {
		let t = this.#e.defaultQueryOptions(e), n = this.#e.getQueryCache().build(this.#e, t);
		return n.fetch().then(() => this.createResult(n, t));
	}
	fetch(e) {
		return this.#h({
			...e,
			cancelRefetch: e.cancelRefetch ?? !0
		}).then(() => (this.updateResult(), this.#r));
	}
	#h(e) {
		this.#S();
		let t = this.#t.fetch(this.options, e);
		return e?.throwOnError || (t = t.catch(n)), t;
	}
	#g() {
		this.#b();
		let e = r(this.options.staleTime, this.#t);
		if (d || this.#r.isStale || !m(e)) return;
		let t = l(this.#r.dataUpdatedAt, e) + 1;
		this.#d = a.setTimeout(() => {
			this.#r.isStale || this.updateResult();
		}, t);
	}
	#_() {
		return (typeof this.options.refetchInterval == "function" ? this.options.refetchInterval(this.#t) : this.options.refetchInterval) ?? !1;
	}
	#v(e) {
		this.#x(), this.#p = e, !(d || h(this.options.enabled, this.#t) === !1 || !m(this.#p) || this.#p === 0) && (this.#f = a.setInterval(() => {
			(this.options.refetchIntervalInBackground || s.isFocused()) && this.#h();
		}, this.#p));
	}
	#y() {
		this.#g(), this.#v(this.#_());
	}
	#b() {
		this.#d &&= (a.clearTimeout(this.#d), void 0);
	}
	#x() {
		this.#f &&= (a.clearInterval(this.#f), void 0);
	}
	createResult(e, t) {
		let n = this.#t, r = this.options, i = this.#r, a = this.#i, o = this.#a, s = e === n ? this.#n : e.state, { state: l } = e, u = { ...l }, d = !1, f;
		if (t._optimisticResults) {
			let i = this.hasListeners(), a = !i && D(e, t), o = i && k(e, n, t, r);
			(a || o) && (u = {
				...u,
				...w(l.data, e.options)
			}), t._optimisticResults === "isRestoring" && (u.fetchStatus = "idle");
		}
		let { error: m, errorUpdatedAt: g, status: _ } = u;
		f = u.data;
		let v = !1;
		if (t.placeholderData !== void 0 && f === void 0 && _ === "pending") {
			let e;
			i?.isPlaceholderData && t.placeholderData === o?.placeholderData ? (e = i.data, v = !0) : e = typeof t.placeholderData == "function" ? t.placeholderData(this.#u?.state.data, this.#u) : t.placeholderData, e !== void 0 && (_ = "success", f = c(i?.data, e, t), d = !0);
		}
		if (t.select && f !== void 0 && !v) if (i && f === a?.data && t.select === this.#c) f = this.#l;
		else try {
			this.#c = t.select, f = t.select(f), f = c(i?.data, f, t), this.#l = f, this.#s = null;
		} catch (e) {
			this.#s = e;
		}
		this.#s && (m = this.#s, f = this.#l, g = Date.now(), _ = "error");
		let y = u.fetchStatus === "fetching", b = _ === "pending", x = _ === "error", S = b && y, C = f !== void 0, T = {
			status: _,
			fetchStatus: u.fetchStatus,
			isPending: b,
			isSuccess: _ === "success",
			isError: x,
			isInitialLoading: S,
			isLoading: S,
			data: f,
			dataUpdatedAt: u.dataUpdatedAt,
			error: m,
			errorUpdatedAt: g,
			failureCount: u.fetchFailureCount,
			failureReason: u.fetchFailureReason,
			errorUpdateCount: u.errorUpdateCount,
			isFetched: u.dataUpdateCount > 0 || u.errorUpdateCount > 0,
			isFetchedAfterMount: u.dataUpdateCount > s.dataUpdateCount || u.errorUpdateCount > s.errorUpdateCount,
			isFetching: y,
			isRefetching: y && !b,
			isLoadingError: x && !C,
			isPaused: u.fetchStatus === "paused",
			isPlaceholderData: d,
			isRefetchError: x && C,
			isStale: A(e, t),
			refetch: this.refetch,
			promise: this.#o,
			isEnabled: h(t.enabled, e) !== !1
		};
		if (this.options.experimental_prefetchInRender) {
			let t = T.data !== void 0, r = T.status === "error" && !t, i = (e) => {
				r ? e.reject(T.error) : t && e.resolve(T.data);
			}, a = () => {
				i(this.#o = T.promise = p());
			}, o = this.#o;
			switch (o.status) {
				case "pending":
					e.queryHash === n.queryHash && i(o);
					break;
				case "fulfilled":
					(r || T.data !== o.value) && a();
					break;
				case "rejected":
					(!r || T.error !== o.reason) && a();
					break;
			}
		}
		return T;
	}
	updateResult() {
		let e = this.#r, t = this.createResult(this.#t, this.options);
		this.#i = this.#t.state, this.#a = this.options, this.#i.data !== void 0 && (this.#u = this.#t), !i(t, e) && (this.#r = t, this.#C({ listeners: (() => {
			if (!e) return !0;
			let { notifyOnChangeProps: t } = this.options, n = typeof t == "function" ? t() : t;
			if (n === "all" || !n && !this.#m.size) return !0;
			let r = new Set(n ?? this.#m);
			return this.options.throwOnError && r.add("error"), Object.keys(this.#r).some((t) => {
				let n = t;
				return this.#r[n] !== e[n] && r.has(n);
			});
		})() }));
	}
	#S() {
		let e = this.#e.getQueryCache().build(this.#e, this.options);
		if (e === this.#t) return;
		let t = this.#t;
		this.#t = e, this.#n = e.state, this.hasListeners() && (t?.removeObserver(this), e.addObserver(this));
	}
	onQueryUpdate() {
		this.updateResult(), this.hasListeners() && this.#y();
	}
	#C(e) {
		C.batch(() => {
			e.listeners && this.listeners.forEach((e) => {
				e(this.#r);
			}), this.#e.getQueryCache().notify({
				query: this.#t,
				type: "observerResultsUpdated"
			});
		});
	}
};
function E(e, t) {
	return h(t.enabled, e) !== !1 && e.state.data === void 0 && !(e.state.status === "error" && t.retryOnMount === !1);
}
function D(e, t) {
	return E(e, t) || e.state.data !== void 0 && O(e, t, t.refetchOnMount);
}
function O(e, t, n) {
	if (h(t.enabled, e) !== !1 && r(t.staleTime, e) !== "static") {
		let r = typeof n == "function" ? n(e) : n;
		return r === "always" || r !== !1 && A(e, t);
	}
	return !1;
}
function k(e, t, n, r) {
	return (e !== t || h(r.enabled, e) === !1) && (!n.suspense || e.state.status !== "error") && A(e, n);
}
function A(e, t) {
	return h(t.enabled, e) !== !1 && e.isStaleByTime(r(t.staleTime, e));
}
function j(e, t) {
	return !i(e.getCurrentResult(), t);
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+react-query@5.90.21+d86b59289c1a13ae/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
var M = g.createContext(void 0), N = (e) => {
	let t = g.useContext(M);
	if (e) return e;
	if (!t) throw Error("No QueryClient set, use QueryClientProvider to set one");
	return t;
}, P = g.createContext(!1), F = () => g.useContext(P);
P.Provider;
//#endregion
//#region ../../node_modules/.bun/@tanstack+react-query@5.90.21+d86b59289c1a13ae/node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
function I() {
	let e = !1;
	return {
		clearReset: () => {
			e = !1;
		},
		reset: () => {
			e = !0;
		},
		isReset: () => e
	};
}
var L = g.createContext(I()), R = () => g.useContext(L), z = (e, t, n) => {
	let r = n?.state.error && typeof e.throwOnError == "function" ? f(e.throwOnError, [n.state.error, n]) : e.throwOnError;
	(e.suspense || e.experimental_prefetchInRender || r) && (t.isReset() || (e.retryOnMount = !1));
}, B = (e) => {
	g.useEffect(() => {
		e.clearReset();
	}, [e]);
}, V = ({ result: e, errorResetBoundary: t, throwOnError: n, query: r, suspense: i }) => e.isError && !t.isReset() && !e.isFetching && r && (i && e.data === void 0 || f(n, [e.error, r])), H = (e) => {
	if (e.suspense) {
		let t = 1e3, n = (e) => e === "static" ? e : Math.max(e ?? t, t), r = e.staleTime;
		e.staleTime = typeof r == "function" ? (...e) => n(r(...e)) : n(r), typeof e.gcTime == "number" && (e.gcTime = Math.max(e.gcTime, t));
	}
}, U = (e, t) => e.isLoading && e.isFetching && !t, W = (e, t) => e?.suspense && t.isPending, G = (e, t, n) => t.fetchOptimistic(e).catch(() => {
	n.clearReset();
});
//#endregion
//#region ../../node_modules/.bun/@tanstack+react-query@5.90.21+d86b59289c1a13ae/node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function K(e, t, r) {
	let i = F(), a = R(), o = N(r), s = o.defaultQueryOptions(e);
	o.getDefaultOptions().queries?._experimental_beforeQuery?.(s);
	let c = o.getQueryCache().get(s.queryHash);
	s._optimisticResults = i ? "isRestoring" : "optimistic", H(s), z(s, a, c), B(a);
	let l = !o.getQueryCache().get(s.queryHash), [u] = g.useState(() => new t(o, s)), f = u.getOptimisticResult(s), p = !i && e.subscribed !== !1;
	if (g.useSyncExternalStore(g.useCallback((e) => {
		let t = p ? u.subscribe(C.batchCalls(e)) : n;
		return u.updateResult(), t;
	}, [u, p]), () => u.getCurrentResult(), () => u.getCurrentResult()), g.useEffect(() => {
		u.setOptions(s);
	}, [s, u]), W(s, f)) throw G(s, u, a);
	if (V({
		result: f,
		errorResetBoundary: a,
		throwOnError: s.throwOnError,
		query: c,
		suspense: s.suspense
	})) throw f.error;
	return o.getDefaultOptions().queries?._experimental_afterQuery?.(s, f), s.experimental_prefetchInRender && !d && U(f, i) && (l ? G(s, u, a) : c?.promise)?.catch(n).finally(() => {
		u.updateResult();
	}), s.notifyOnChangeProps ? f : u.trackResult(f);
}
//#endregion
//#region ../../node_modules/.bun/@tanstack+react-query@5.90.21+d86b59289c1a13ae/node_modules/@tanstack/react-query/build/modern/useQuery.js
function q(e, t) {
	return K(e, T, t);
}
//#endregion
//#region src/hooks/use-media-query.ts
function J(e) {
	return y(v((t) => {
		let n = window.matchMedia(e);
		return n.addEventListener("change", t), () => n.removeEventListener("change", t);
	}, [e]), v(() => window.matchMedia(e).matches, [e]), () => !1);
}
//#endregion
//#region ../../node_modules/.bun/zustand@5.0.13+50519426e3d821ba/node_modules/zustand/esm/vanilla.mjs
var Y = (e) => {
	let t, n = /* @__PURE__ */ new Set(), r = (e, r) => {
		let i = typeof e == "function" ? e(t) : e;
		if (!Object.is(i, t)) {
			let e = t;
			t = r ?? (typeof i != "object" || !i) ? i : Object.assign({}, t, i), n.forEach((n) => n(t, e));
		}
	}, i = () => t, a = {
		setState: r,
		getState: i,
		getInitialState: () => o,
		subscribe: (e) => (n.add(e), () => n.delete(e))
	}, o = t = e(r, i, a);
	return a;
}, X = ((e) => e ? Y(e) : Y), Z = (e) => e;
function Q(e, t = Z) {
	let n = _.useSyncExternalStore(e.subscribe, _.useCallback(() => t(e.getState()), [e, t]), _.useCallback(() => t(e.getInitialState()), [e, t]));
	return _.useDebugValue(n), n;
}
var $ = (e) => {
	let t = X(e), n = (e) => Q(t, e);
	return Object.assign(n, t), n;
}, ee = ((e) => e ? $(e) : $);
//#endregion
//#region src/utils/create-selectors.ts
function te(e) {
	let t = e;
	return t.use = new Proxy({}, { get: (e, n) => () => t((e) => e[n]) }), t;
}
//#endregion
export { N as a, q as i, ee as n, C as o, J as r, b as s, te as t };
