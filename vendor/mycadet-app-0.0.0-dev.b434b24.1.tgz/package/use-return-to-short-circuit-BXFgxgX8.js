import { d as e, n as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { t as n } from "./loader-circle-Ch7lYSrj.js";
import { r } from "./i18n-BRf-wfgm.js";
import { n as i } from "./routes-DW44XTQk.js";
import { f as a, n as o, r as s, t as c } from "./auth-store-Bx-RKZJ9.js";
import { t as l } from "./hard-navigate-CQ88MENc.js";
import { t as u } from "./return-to-BrgpQtYw.js";
import { t as d } from "./full-page-navigation-BvH_lAEU.js";
import { useEffect as f, useState as p } from "react";
import { jsx as m } from "react/jsx-runtime";
//#region src/domains/account/components/auth-wait-spinner.tsx
function h() {
	let { t: e } = r("account");
	return /* @__PURE__ */ m(n, {
		className: "h-6 w-6 animate-spin text-[var(--content-tertiary)]",
		"aria-label": e("authWaitSpinner.loading")
	});
}
//#endregion
//#region src/domains/account/session-destination-paths.ts
var g = [i.account.root];
//#endregion
//#region src/domains/account/requires-cloud-session.ts
function _(e) {
	if (d(e)) return !0;
	let t = e.split(/[?#]/)[0] ?? e;
	return g.some((e) => t === e || t.startsWith(`${e}/`));
}
//#endregion
//#region src/lib/auth/account-session.ts
function v() {
	return c((e) => e.cloudSession);
}
//#endregion
//#region src/lib/auth/account-cloud-gate.ts
function y({ session: e }) {
	return e === "present" ? "full" : e === "unknown" ? "pending" : "disabled";
}
//#endregion
//#region src/hooks/use-deadline-passed.ts
function b(e, t) {
	let [n, r] = p(!1);
	return f(() => {
		if (!e) {
			r(!1);
			return;
		}
		let n = setTimeout(() => r(!0), t);
		return () => clearTimeout(n);
	}, [e, t]), n;
}
//#endregion
//#region src/hooks/use-account-cloud-gate.ts
var x = 5e3;
function S(e = x) {
	let t = y({ session: v() }), n = b(t === "pending", e);
	return t === "pending" && n ? "disabled" : t;
}
//#endregion
//#region src/domains/account/hooks/use-return-to-short-circuit.tsx
function C({ to: e }) {
	let n = d(e);
	return f(() => {
		n && l(e);
	}, [n, e]), n ? null : /* @__PURE__ */ m(t, {
		to: e,
		replace: !0
	});
}
function w() {
	let [t] = e(), n = o(), r = s(), c = S(), l = t.get("returnTo"), d = u(l, i.assistant);
	if (!l) return {
		kind: "proceed",
		returnTo: null
	};
	if (a()) return {
		kind: "proceed",
		returnTo: d
	};
	if (r) return { kind: "wait" };
	if (!n) return {
		kind: "proceed",
		returnTo: d
	};
	if (_(d)) {
		if (c === "pending") return { kind: "wait" };
		if (c === "disabled") return {
			kind: "proceed",
			returnTo: d
		};
	}
	return {
		kind: "redirect",
		node: /* @__PURE__ */ m(C, { to: d })
	};
}
//#endregion
export { h as n, w as t };
