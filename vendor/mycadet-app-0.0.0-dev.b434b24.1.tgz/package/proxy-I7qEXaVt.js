import { i as e, n as t, r as n } from "./chunk-C5e3QaDY.js";
import { Component as r, Fragment as i, createContext as a, createElement as o, forwardRef as s, useCallback as c, useContext as l, useEffect as u, useId as d, useInsertionEffect as f, useLayoutEffect as p, useMemo as m, useRef as h } from "react";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
//#region src/utils/public-asset.ts
function v(e) {
	return `./${e.startsWith("/") ? e.slice(1) : e}`;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/LayoutGroupContext.mjs
var y = a({});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/use-constant.mjs
function b(e) {
	let t = h(null);
	return t.current === null && (t.current = e()), t.current;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/use-isomorphic-effect.mjs
var x = typeof window < "u" ? p : u, S = /* @__PURE__ */ a(null);
//#endregion
//#region ../../node_modules/.bun/motion-utils@12.39.0/node_modules/motion-utils/dist/es/array.mjs
function C(e, t) {
	e.indexOf(t) === -1 && e.push(t);
}
function w(e, t) {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}
//#endregion
//#region ../../node_modules/.bun/motion-utils@12.39.0/node_modules/motion-utils/dist/es/clamp.mjs
var T = (e, t, n) => n > t ? t : n < e ? e : n, ee = () => {}, E = {}, te = (e) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e), ne = (e) => typeof e == "object" && !!e, re = (e) => /^0[^.\s]+$/u.test(e);
//#endregion
//#region ../../node_modules/.bun/motion-utils@12.39.0/node_modules/motion-utils/dist/es/memo.mjs
/* @__NO_SIDE_EFFECTS__ */
function ie(e) {
	let t;
	return () => (t === void 0 && (t = e()), t);
}
//#endregion
//#region ../../node_modules/.bun/motion-utils@12.39.0/node_modules/motion-utils/dist/es/noop.mjs
var D = /* @__NO_SIDE_EFFECTS__ */ (e) => e, ae = (...e) => e.reduce((e, t) => (n) => t(e(n))), oe = /* @__NO_SIDE_EFFECTS__ */ (e, t, n) => {
	let r = t - e;
	return r ? (n - e) / r : 1;
}, se = class {
	constructor() {
		this.subscriptions = [];
	}
	add(e) {
		return C(this.subscriptions, e), () => w(this.subscriptions, e);
	}
	notify(e, t, n) {
		let r = this.subscriptions.length;
		if (r) if (r === 1) this.subscriptions[0](e, t, n);
		else for (let i = 0; i < r; i++) {
			let r = this.subscriptions[i];
			r && r(e, t, n);
		}
	}
	getSize() {
		return this.subscriptions.length;
	}
	clear() {
		this.subscriptions.length = 0;
	}
}, O = /* @__NO_SIDE_EFFECTS__ */ (e) => e * 1e3, k = /* @__NO_SIDE_EFFECTS__ */ (e) => e / 1e3, ce = /* @__NO_SIDE_EFFECTS__ */ (e, t) => t ? 1e3 / t * e : 0, le = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e, ue = 1e-7, de = 12;
function fe(e, t, n, r, i) {
	let a, o, s = 0;
	do
		o = t + (n - t) / 2, a = le(o, r, i) - e, a > 0 ? n = o : t = o;
	while (Math.abs(a) > ue && ++s < de);
	return o;
}
/* @__NO_SIDE_EFFECTS__ */
function pe(e, t, n, r) {
	if (e === t && n === r) return D;
	let i = (t) => fe(t, 0, 1, e, n);
	return (e) => e === 0 || e === 1 ? e : le(i(e), t, r);
}
//#endregion
//#region ../../node_modules/.bun/motion-utils@12.39.0/node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs
var me = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2, he = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => 1 - e(1 - t), ge = /* @__PURE__ */ pe(.33, 1.53, .69, .99), _e = /* @__PURE__ */ he(ge), ve = /* @__PURE__ */ me(_e), ye = (e) => e >= 1 ? 1 : (e *= 2) < 1 ? .5 * _e(e) : .5 * (2 - 2 ** (-10 * (e - 1))), be = (e) => 1 - Math.sin(Math.acos(e)), xe = /* @__PURE__ */ he(be), Se = /* @__PURE__ */ me(be), Ce = /* @__PURE__ */ pe(.42, 0, 1, 1), we = /* @__PURE__ */ pe(0, 0, .58, 1), Te = /* @__PURE__ */ pe(.42, 0, .58, 1), Ee = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] != "number", De = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] == "number", Oe = {
	linear: D,
	easeIn: Ce,
	easeInOut: Te,
	easeOut: we,
	circIn: be,
	circInOut: Se,
	circOut: xe,
	backIn: _e,
	backInOut: ve,
	backOut: ge,
	anticipate: ye
}, ke = (e) => typeof e == "string", Ae = (e) => {
	if (/* @__PURE__ */ De(e)) {
		e.length;
		let [t, n, r, i] = e;
		return /* @__PURE__ */ pe(t, n, r, i);
	} else if (ke(e)) return Oe[e], `${e}`, Oe[e];
	return e;
}, je = [
	"setup",
	"read",
	"resolveKeyframes",
	"preUpdate",
	"update",
	"preRender",
	"render",
	"postRender"
];
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/render-step.mjs
function Me(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = !1, i = !1, a = /* @__PURE__ */ new WeakSet(), o = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	};
	function s(t) {
		a.has(t) && (c.schedule(t), e()), t(o);
	}
	let c = {
		schedule: (e, i = !1, o = !1) => {
			let s = o && r ? t : n;
			return i && a.add(e), s.add(e), e;
		},
		cancel: (e) => {
			n.delete(e), a.delete(e);
		},
		process: (e) => {
			if (o = e, r) {
				i = !0;
				return;
			}
			r = !0;
			let a = t;
			t = n, n = a, t.forEach(s), t.clear(), r = !1, i && (i = !1, c.process(e));
		}
	};
	return c;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/batcher.mjs
var Ne = 40;
function Pe(e, t) {
	let n = !1, r = !0, i = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	}, a = () => n = !0, o = je.reduce((e, t) => (e[t] = Me(a), e), {}), { setup: s, read: c, resolveKeyframes: l, preUpdate: u, update: d, preRender: f, render: p, postRender: m } = o, h = () => {
		let a = E.useManualTiming, o = a ? i.timestamp : performance.now();
		n = !1, a || (i.delta = r ? 1e3 / 60 : Math.max(Math.min(o - i.timestamp, Ne), 1)), i.timestamp = o, i.isProcessing = !0, s.process(i), c.process(i), l.process(i), u.process(i), d.process(i), f.process(i), p.process(i), m.process(i), i.isProcessing = !1, n && t && (r = !1, e(h));
	}, g = () => {
		n = !0, r = !0, i.isProcessing || e(h);
	};
	return {
		schedule: je.reduce((e, t) => {
			let r = o[t];
			return e[t] = (e, t = !1, i = !1) => (n || g(), r.schedule(e, t, i)), e;
		}, {}),
		cancel: (e) => {
			for (let t = 0; t < je.length; t++) o[je[t]].cancel(e);
		},
		state: i,
		steps: o
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/frame.mjs
var { schedule: A, cancel: j, state: M, steps: Fe } = /* @__PURE__ */ Pe(typeof requestAnimationFrame < "u" ? requestAnimationFrame : D, !0), Ie;
function Le() {
	Ie = void 0;
}
var N = {
	now: () => (Ie === void 0 && N.set(M.isProcessing || E.useManualTiming ? M.timestamp : performance.now()), Ie),
	set: (e) => {
		Ie = e, queueMicrotask(Le);
	}
}, Re = (e) => (t) => typeof t == "string" && t.startsWith(e), ze = /* @__PURE__ */ Re("--"), Be = /* @__PURE__ */ Re("var(--"), Ve = (e) => Be(e) ? He.test(e.split("/*")[0].trim()) : !1, He = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function Ue(e) {
	return typeof e == "string" ? e.split("/*")[0].includes("var(--") : !1;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/numbers/index.mjs
var We = {
	test: (e) => typeof e == "number",
	parse: parseFloat,
	transform: (e) => e
}, Ge = {
	...We,
	transform: (e) => T(0, 1, e)
}, Ke = {
	...We,
	default: 1
}, qe = (e) => Math.round(e * 1e5) / 1e5, Je = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/is-nullish.mjs
function Ye(e) {
	return e == null;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/single-color-regex.mjs
var Xe = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu, Ze = (e, t) => (n) => !!(typeof n == "string" && Xe.test(n) && n.startsWith(e) || t && !Ye(n) && Object.prototype.hasOwnProperty.call(n, t)), Qe = (e, t, n) => (r) => {
	if (typeof r != "string") return r;
	let [i, a, o, s] = r.match(Je);
	return {
		[e]: parseFloat(i),
		[t]: parseFloat(a),
		[n]: parseFloat(o),
		alpha: s === void 0 ? 1 : parseFloat(s)
	};
}, $e = (e) => T(0, 255, e), et = {
	...We,
	transform: (e) => Math.round($e(e))
}, tt = {
	test: /* @__PURE__ */ Ze("rgb", "red"),
	parse: /* @__PURE__ */ Qe("red", "green", "blue"),
	transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) => "rgba(" + et.transform(e) + ", " + et.transform(t) + ", " + et.transform(n) + ", " + qe(Ge.transform(r)) + ")"
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/color/hex.mjs
function nt(e) {
	let t = "", n = "", r = "", i = "";
	return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
		red: parseInt(t, 16),
		green: parseInt(n, 16),
		blue: parseInt(r, 16),
		alpha: i ? parseInt(i, 16) / 255 : 1
	};
}
var rt = {
	test: /* @__PURE__ */ Ze("#"),
	parse: nt,
	transform: tt.transform
}, it = /* @__NO_SIDE_EFFECTS__ */ (e) => ({
	test: (t) => typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
	parse: parseFloat,
	transform: (t) => `${t}${e}`
}), P = /* @__PURE__ */ it("deg"), F = /* @__PURE__ */ it("%"), I = /* @__PURE__ */ it("px"), at = /* @__PURE__ */ it("vh"), ot = /* @__PURE__ */ it("vw"), st = {
	...F,
	parse: (e) => F.parse(e) / 100,
	transform: (e) => F.transform(e * 100)
}, ct = {
	test: /* @__PURE__ */ Ze("hsl", "hue"),
	parse: /* @__PURE__ */ Qe("hue", "saturation", "lightness"),
	transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) => "hsla(" + Math.round(e) + ", " + F.transform(qe(t)) + ", " + F.transform(qe(n)) + ", " + qe(Ge.transform(r)) + ")"
}, L = {
	test: (e) => tt.test(e) || rt.test(e) || ct.test(e),
	parse: (e) => tt.test(e) ? tt.parse(e) : ct.test(e) ? ct.parse(e) : rt.parse(e),
	transform: (e) => typeof e == "string" ? e : e.hasOwnProperty("red") ? tt.transform(e) : ct.transform(e),
	getAnimatableNone: (e) => {
		let t = L.parse(e);
		return t.alpha = 0, L.transform(t);
	}
}, lt = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/complex/index.mjs
function ut(e) {
	return isNaN(e) && typeof e == "string" && (e.match(Je)?.length || 0) + (e.match(lt)?.length || 0) > 0;
}
var dt = "number", ft = "color", pt = "var", mt = "var(", ht = "${}", gt = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function _t(e) {
	let t = e.toString(), n = [], r = {
		color: [],
		number: [],
		var: []
	}, i = [], a = 0;
	return {
		values: n,
		split: t.replace(gt, (e) => (L.test(e) ? (r.color.push(a), i.push(ft), n.push(L.parse(e))) : e.startsWith(mt) ? (r.var.push(a), i.push(pt), n.push(e)) : (r.number.push(a), i.push(dt), n.push(parseFloat(e))), ++a, ht)).split(ht),
		indexes: r,
		types: i
	};
}
function vt(e) {
	return _t(e).values;
}
function yt({ split: e, types: t }) {
	let n = e.length;
	return (r) => {
		let i = "";
		for (let a = 0; a < n; a++) if (i += e[a], r[a] !== void 0) {
			let e = t[a];
			e === dt ? i += qe(r[a]) : e === ft ? i += L.transform(r[a]) : i += r[a];
		}
		return i;
	};
}
function bt(e) {
	return yt(_t(e));
}
var xt = (e) => typeof e == "number" ? 0 : L.test(e) ? L.getAnimatableNone(e) : e, St = (e, t) => typeof e == "number" ? t?.trim().endsWith("/") ? e : 0 : xt(e);
function Ct(e) {
	let t = _t(e);
	return yt(t)(t.values.map((e, n) => St(e, t.split[n])));
}
var R = {
	test: ut,
	parse: vt,
	createTransformer: bt,
	getAnimatableNone: Ct
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/color/hsla-to-rgba.mjs
function wt(e, t, n) {
	return n < 0 && (n += 1), n > 1 && --n, n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
}
function Tt({ hue: e, saturation: t, lightness: n, alpha: r }) {
	e /= 360, t /= 100, n /= 100;
	let i = 0, a = 0, o = 0;
	if (!t) i = a = o = n;
	else {
		let r = n < .5 ? n * (1 + t) : n + t - n * t, s = 2 * n - r;
		i = wt(s, r, e + 1 / 3), a = wt(s, r, e), o = wt(s, r, e - 1 / 3);
	}
	return {
		red: Math.round(i * 255),
		green: Math.round(a * 255),
		blue: Math.round(o * 255),
		alpha: r
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/immediate.mjs
function Et(e, t) {
	return (n) => n > 0 ? t : e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/number.mjs
var z = (e, t, n) => e + (t - e) * n, Dt = (e, t, n) => {
	let r = e * e, i = n * (t * t - r) + r;
	return i < 0 ? 0 : Math.sqrt(i);
}, Ot = [
	rt,
	tt,
	ct
], kt = (e) => Ot.find((t) => t.test(e));
function At(e) {
	let t = kt(e);
	if (`${e}`, !t) return !1;
	let n = t.parse(e);
	return t === ct && (n = Tt(n)), n;
}
var jt = (e, t) => {
	let n = At(e), r = At(t);
	if (!n || !r) return Et(e, t);
	let i = { ...n };
	return (e) => (i.red = Dt(n.red, r.red, e), i.green = Dt(n.green, r.green, e), i.blue = Dt(n.blue, r.blue, e), i.alpha = z(n.alpha, r.alpha, e), tt.transform(i));
}, Mt = new Set(["none", "hidden"]);
function Nt(e, t) {
	return Mt.has(e) ? (n) => n <= 0 ? e : t : (n) => n >= 1 ? t : e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/complex.mjs
function Pt(e, t) {
	return (n) => z(e, t, n);
}
function Ft(e) {
	return typeof e == "number" ? Pt : typeof e == "string" ? Ve(e) ? Et : L.test(e) ? jt : zt : Array.isArray(e) ? It : typeof e == "object" ? L.test(e) ? jt : Lt : Et;
}
function It(e, t) {
	let n = [...e], r = n.length, i = e.map((e, n) => Ft(e)(e, t[n]));
	return (e) => {
		for (let t = 0; t < r; t++) n[t] = i[t](e);
		return n;
	};
}
function Lt(e, t) {
	let n = {
		...e,
		...t
	}, r = {};
	for (let i in n) e[i] !== void 0 && t[i] !== void 0 && (r[i] = Ft(e[i])(e[i], t[i]));
	return (e) => {
		for (let t in r) n[t] = r[t](e);
		return n;
	};
}
function Rt(e, t) {
	let n = [], r = {
		color: 0,
		var: 0,
		number: 0
	};
	for (let i = 0; i < t.values.length; i++) {
		let a = t.types[i], o = e.indexes[a][r[a]];
		n[i] = e.values[o] ?? 0, r[a]++;
	}
	return n;
}
var zt = (e, t) => {
	let n = R.createTransformer(t), r = _t(e), i = _t(t);
	return r.indexes.var.length === i.indexes.var.length && r.indexes.color.length === i.indexes.color.length && r.indexes.number.length >= i.indexes.number.length ? Mt.has(e) && !i.values.length || Mt.has(t) && !r.values.length ? Nt(e, t) : ae(It(Rt(r, i), i.values), n) : (`${e}${t}`, Et(e, t));
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/mix/index.mjs
function Bt(e, t, n) {
	return typeof e == "number" && typeof t == "number" && typeof n == "number" ? z(e, t, n) : Ft(e)(e, t);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/drivers/frame.mjs
var Vt = (e) => {
	let t = ({ timestamp: t }) => e(t);
	return {
		start: (e = !0) => A.update(t, e),
		stop: () => j(t),
		now: () => M.isProcessing ? M.timestamp : N.now()
	};
}, Ht = (e, t, n = 10) => {
	let r = "", i = Math.max(Math.round(t / n), 2);
	for (let t = 0; t < i; t++) r += Math.round(e(t / (i - 1)) * 1e4) / 1e4 + ", ";
	return `linear(${r.substring(0, r.length - 2)})`;
}, Ut = 2e4;
function Wt(e) {
	let t = 0, n = e.next(t);
	for (; !n.done && t < 2e4;) t += 50, n = e.next(t);
	return t >= 2e4 ? Infinity : t;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/create-generator-easing.mjs
function Gt(e, t = 100, n) {
	let r = n({
		...e,
		keyframes: [0, t]
	}), i = Math.min(Wt(r), Ut);
	return {
		type: "keyframes",
		ease: (e) => r.next(i * e).value / t,
		duration: /* @__PURE__ */ k(i)
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/spring.mjs
var B = {
	stiffness: 100,
	damping: 10,
	mass: 1,
	velocity: 0,
	duration: 800,
	bounce: .3,
	visualDuration: .3,
	restSpeed: {
		granular: .01,
		default: 2
	},
	restDelta: {
		granular: .005,
		default: .5
	},
	minDuration: .01,
	maxDuration: 10,
	minDamping: .05,
	maxDamping: 1
};
function Kt(e, t) {
	return e * Math.sqrt(1 - t * t);
}
var qt = 12;
function Jt(e, t, n) {
	let r = n;
	for (let n = 1; n < qt; n++) r -= e(r) / t(r);
	return r;
}
var Yt = .001;
function Xt({ duration: e = B.duration, bounce: t = B.bounce, velocity: n = B.velocity, mass: r = B.mass }) {
	let i, a;
	B.maxDuration;
	let o = 1 - t;
	o = T(B.minDamping, B.maxDamping, o), e = T(B.minDuration, B.maxDuration, /* @__PURE__ */ k(e)), o < 1 ? (i = (t) => {
		let r = t * o, i = r * e, a = r - n, s = Kt(t, o), c = Math.exp(-i);
		return Yt - a / s * c;
	}, a = (t) => {
		let r = t * o * e, a = r * n + n, s = o ** 2 * t ** 2 * e, c = Math.exp(-r), l = Kt(t ** 2, o);
		return (-i(t) + Yt > 0 ? -1 : 1) * ((a - s) * c) / l;
	}) : (i = (t) => {
		let r = Math.exp(-t * e), i = (t - n) * e + 1;
		return -Yt + r * i;
	}, a = (t) => Math.exp(-t * e) * ((n - t) * (e * e)));
	let s = 5 / e, c = Jt(i, a, s);
	if (e = /* @__PURE__ */ O(e), isNaN(c)) return {
		stiffness: B.stiffness,
		damping: B.damping,
		duration: e
	};
	{
		let t = c ** 2 * r;
		return {
			stiffness: t,
			damping: o * 2 * Math.sqrt(r * t),
			duration: e
		};
	}
}
var Zt = ["duration", "bounce"], Qt = [
	"stiffness",
	"damping",
	"mass"
];
function $t(e, t) {
	return t.some((t) => e[t] !== void 0);
}
function en(e) {
	let t = {
		velocity: B.velocity,
		stiffness: B.stiffness,
		damping: B.damping,
		mass: B.mass,
		isResolvedFromDuration: !1,
		...e
	};
	if (!$t(e, Qt) && $t(e, Zt)) if (t.velocity = 0, e.visualDuration) {
		let n = e.visualDuration, r = 2 * Math.PI / (n * 1.2), i = r * r, a = 2 * T(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(i);
		t = {
			...t,
			mass: B.mass,
			stiffness: i,
			damping: a
		};
	} else {
		let n = Xt({
			...e,
			velocity: 0
		});
		t = {
			...t,
			...n,
			mass: B.mass
		}, t.isResolvedFromDuration = !0;
	}
	return t;
}
function tn(e = B.visualDuration, t = B.bounce) {
	let n = typeof e == "object" ? e : {
		visualDuration: e,
		keyframes: [0, 1],
		bounce: t
	}, { restSpeed: r, restDelta: i } = n, a = n.keyframes[0], o = n.keyframes[n.keyframes.length - 1], s = {
		done: !1,
		value: a
	}, { stiffness: c, damping: l, mass: u, duration: d, velocity: f, isResolvedFromDuration: p } = en({
		...n,
		velocity: -/* @__PURE__ */ k(n.velocity || 0)
	}), m = f || 0, h = l / (2 * Math.sqrt(c * u)), g = o - a, _ = /* @__PURE__ */ k(Math.sqrt(c / u)), v = Math.abs(g) < 5;
	r ||= v ? B.restSpeed.granular : B.restSpeed.default, i ||= v ? B.restDelta.granular : B.restDelta.default;
	let y, b, x, S, C, w;
	if (h < 1) x = Kt(_, h), S = (m + h * _ * g) / x, y = (e) => o - Math.exp(-h * _ * e) * (S * Math.sin(x * e) + g * Math.cos(x * e)), C = h * _ * S + g * x, w = h * _ * g - S * x, b = (e) => Math.exp(-h * _ * e) * (C * Math.sin(x * e) + w * Math.cos(x * e));
	else if (h === 1) {
		y = (e) => o - Math.exp(-_ * e) * (g + (m + _ * g) * e);
		let e = m + _ * g;
		b = (t) => Math.exp(-_ * t) * (_ * e * t - m);
	} else {
		let e = _ * Math.sqrt(h * h - 1);
		y = (t) => {
			let n = Math.exp(-h * _ * t), r = Math.min(e * t, 300);
			return o - n * ((m + h * _ * g) * Math.sinh(r) + e * g * Math.cosh(r)) / e;
		};
		let t = (m + h * _ * g) / e, n = h * _ * t - g * e, r = h * _ * g - t * e;
		b = (t) => {
			let i = Math.exp(-h * _ * t), a = Math.min(e * t, 300);
			return i * (n * Math.sinh(a) + r * Math.cosh(a));
		};
	}
	let T = {
		calculatedDuration: p && d || null,
		velocity: (e) => /* @__PURE__ */ O(b(e)),
		next: (e) => {
			if (!p && h < 1) {
				let t = Math.exp(-h * _ * e), n = Math.sin(x * e), a = Math.cos(x * e), c = o - t * (S * n + g * a), l = /* @__PURE__ */ O(t * (C * n + w * a));
				return s.done = Math.abs(l) <= r && Math.abs(o - c) <= i, s.value = s.done ? o : c, s;
			}
			let t = y(e);
			if (p) s.done = e >= d;
			else {
				let n = /* @__PURE__ */ O(b(e));
				s.done = Math.abs(n) <= r && Math.abs(o - t) <= i;
			}
			return s.value = s.done ? o : t, s;
		},
		toString: () => {
			let e = Math.min(Wt(T), Ut), t = Ht((t) => T.next(e * t).value, e, 30);
			return e + "ms " + t;
		},
		toTransition: () => {}
	};
	return T;
}
tn.applyToOptions = (e) => {
	let t = Gt(e, 100, tn);
	return e.ease = t.ease, e.duration = /* @__PURE__ */ O(t.duration), e.type = "keyframes", e;
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/velocity.mjs
var nn = 5;
function rn(e, t, n) {
	let r = Math.max(t - nn, 0);
	return /* @__PURE__ */ ce(n - e(r), t - r);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/inertia.mjs
function an({ keyframes: e, velocity: t = 0, power: n = .8, timeConstant: r = 325, bounceDamping: i = 10, bounceStiffness: a = 500, modifyTarget: o, min: s, max: c, restDelta: l = .5, restSpeed: u }) {
	let d = e[0], f = {
		done: !1,
		value: d
	}, p = (e) => s !== void 0 && e < s || c !== void 0 && e > c, m = (e) => s === void 0 ? c : c === void 0 || Math.abs(s - e) < Math.abs(c - e) ? s : c, h = n * t, g = d + h, _ = o === void 0 ? g : o(g);
	_ !== g && (h = _ - d);
	let v = (e) => -h * Math.exp(-e / r), y = (e) => _ + v(e), b = (e) => {
		let t = v(e), n = y(e);
		f.done = Math.abs(t) <= l, f.value = f.done ? _ : n;
	}, x, S, C = (e) => {
		p(f.value) && (x = e, S = tn({
			keyframes: [f.value, m(f.value)],
			velocity: rn(y, e, f.value),
			damping: i,
			stiffness: a,
			restDelta: l,
			restSpeed: u
		}));
	};
	return C(0), {
		calculatedDuration: null,
		next: (e) => {
			let t = !1;
			return !S && x === void 0 && (t = !0, b(e), C(e)), x !== void 0 && e >= x ? S.next(e - x) : (!t && b(e), f);
		}
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/interpolate.mjs
function on(e, t, n) {
	let r = [], i = n || E.mix || Bt, a = e.length - 1;
	for (let n = 0; n < a; n++) {
		let a = i(e[n], e[n + 1]);
		t && (a = ae(Array.isArray(t) ? t[n] || D : t, a)), r.push(a);
	}
	return r;
}
function sn(e, t, { clamp: n = !0, ease: r, mixer: i } = {}) {
	let a = e.length;
	if (t.length, a === 1) return () => t[0];
	if (a === 2 && t[0] === t[1]) return () => t[1];
	let o = e[0] === e[1];
	e[0] > e[a - 1] && (e = [...e].reverse(), t = [...t].reverse());
	let s = on(t, r, i), c = s.length, l = (n) => {
		if (o && n < e[0]) return t[0];
		let r = 0;
		if (c > 1) for (; r < e.length - 2 && !(n < e[r + 1]); r++);
		let i = /* @__PURE__ */ oe(e[r], e[r + 1], n);
		return s[r](i);
	};
	return n ? (t) => l(T(e[0], e[a - 1], t)) : l;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/fill.mjs
function cn(e, t) {
	let n = e[e.length - 1];
	for (let r = 1; r <= t; r++) {
		let i = /* @__PURE__ */ oe(0, t, r);
		e.push(z(n, 1, i));
	}
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/default.mjs
function ln(e) {
	let t = [0];
	return cn(t, e.length - 1), t;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/offsets/time.mjs
function un(e, t) {
	return e.map((e) => e * t);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/keyframes.mjs
function dn(e, t) {
	return e.map(() => t || Te).splice(0, e.length - 1);
}
function fn({ duration: e = 300, keyframes: t, times: n, ease: r = "easeInOut" }) {
	let i = /* @__PURE__ */ Ee(r) ? r.map(Ae) : Ae(r), a = {
		done: !1,
		value: t[0]
	}, o = sn(un(n && n.length === t.length ? n : ln(t), e), t, { ease: Array.isArray(i) ? i : dn(t, i) });
	return {
		calculatedDuration: e,
		next: (t) => (a.value = o(t), a.done = t >= e, a)
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/get-final.mjs
var pn = (e) => e !== null;
function mn(e, { repeat: t, repeatType: n = "loop" }, r, i = 1) {
	let a = e.filter(pn), o = i < 0 || t && n !== "loop" && t % 2 == 1 ? 0 : a.length - 1;
	return !o || r === void 0 ? a[o] : r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/replace-transition-type.mjs
var hn = {
	decay: an,
	inertia: an,
	tween: fn,
	keyframes: fn,
	spring: tn
};
function gn(e) {
	typeof e.type == "string" && (e.type = hn[e.type]);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/WithPromise.mjs
var _n = class {
	constructor() {
		this.updateFinished();
	}
	get finished() {
		return this._finished;
	}
	updateFinished() {
		this._finished = new Promise((e) => {
			this.resolve = e;
		});
	}
	notifyFinished() {
		this.resolve();
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
}, vn = (e) => e / 100, yn = class extends _n {
	constructor(e) {
		super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
			done: !1,
			value: void 0
		}, this.stop = () => {
			let { motionValue: e } = this.options;
			e && e.updatedAt !== N.now() && this.tick(N.now()), this.isStopped = !0, this.state !== "idle" && (this.teardown(), this.options.onStop?.());
		}, this.options = e, this.initAnimation(), this.play(), e.autoplay === !1 && this.pause();
	}
	initAnimation() {
		let { options: e } = this;
		gn(e);
		let { type: t = fn, repeat: n = 0, repeatDelay: r = 0, repeatType: i, velocity: a = 0 } = e, { keyframes: o } = e, s = t || fn;
		s !== fn && typeof o[0] != "number" && (this.mixKeyframes = ae(vn, Bt(o[0], o[1])), o = [0, 100]);
		let c = s({
			...e,
			keyframes: o
		});
		i === "mirror" && (this.mirroredGenerator = s({
			...e,
			keyframes: [...o].reverse(),
			velocity: -a
		})), c.calculatedDuration === null && (c.calculatedDuration = Wt(c));
		let { calculatedDuration: l } = c;
		this.calculatedDuration = l, this.resolvedDuration = l + r, this.totalDuration = this.resolvedDuration * (n + 1) - r, this.generator = c;
	}
	updateTime(e) {
		let t = Math.round(e - this.startTime) * this.playbackSpeed;
		this.holdTime === null ? this.currentTime = t : this.currentTime = this.holdTime;
	}
	tick(e, t = !1) {
		let { generator: n, totalDuration: r, mixKeyframes: i, mirroredGenerator: a, resolvedDuration: o, calculatedDuration: s } = this;
		if (this.startTime === null) return n.next(0);
		let { delay: c = 0, keyframes: l, repeat: u, repeatType: d, repeatDelay: f, type: p, onUpdate: m, finalKeyframe: h } = this.options;
		this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - r / this.speed, this.startTime)), t ? this.currentTime = e : this.updateTime(e);
		let g = this.currentTime - c * (this.playbackSpeed >= 0 ? 1 : -1), _ = this.playbackSpeed >= 0 ? g < 0 : g > r;
		this.currentTime = Math.max(g, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = r);
		let v = this.currentTime, y = n;
		if (u) {
			let e = Math.min(this.currentTime, r) / o, t = Math.floor(e), n = e % 1;
			!n && e >= 1 && (n = 1), n === 1 && t--, t = Math.min(t, u + 1), t % 2 && (d === "reverse" ? (n = 1 - n, f && (n -= f / o)) : d === "mirror" && (y = a)), v = T(0, 1, n) * o;
		}
		let b;
		_ ? (this.delayState.value = l[0], b = this.delayState) : b = y.next(v), i && !_ && (b.value = i(b.value));
		let { done: x } = b;
		!_ && s !== null && (x = this.playbackSpeed >= 0 ? this.currentTime >= r : this.currentTime <= 0);
		let S = this.holdTime === null && (this.state === "finished" || this.state === "running" && x);
		return S && p !== an && (b.value = mn(l, this.options, h, this.speed)), m && m(b.value), S && this.finish(), b;
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
	get duration() {
		return /* @__PURE__ */ k(this.calculatedDuration);
	}
	get iterationDuration() {
		let { delay: e = 0 } = this.options || {};
		return this.duration + /* @__PURE__ */ k(e);
	}
	get time() {
		return /* @__PURE__ */ k(this.currentTime);
	}
	set time(e) {
		e = /* @__PURE__ */ O(e), this.currentTime = e, this.startTime === null || this.holdTime !== null || this.playbackSpeed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = e, this.tick(e));
	}
	getGeneratorVelocity() {
		let e = this.currentTime;
		if (e <= 0) return this.options.velocity || 0;
		if (this.generator.velocity) return this.generator.velocity(e);
		let t = this.generator.next(e).value;
		return rn((e) => this.generator.next(e).value, e, t);
	}
	get speed() {
		return this.playbackSpeed;
	}
	set speed(e) {
		let t = this.playbackSpeed !== e;
		t && this.driver && this.updateTime(N.now()), this.playbackSpeed = e, t && this.driver && (this.time = /* @__PURE__ */ k(this.currentTime));
	}
	play() {
		if (this.isStopped) return;
		let { driver: e = Vt, startTime: t } = this.options;
		this.driver ||= e((e) => this.tick(e)), this.options.onPlay?.();
		let n = this.driver.now();
		this.state === "finished" ? (this.updateFinished(), this.startTime = n) : this.holdTime === null ? this.startTime ||= t ?? n : this.startTime = n - this.holdTime, this.state === "finished" && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start();
	}
	pause() {
		this.state = "paused", this.updateTime(N.now()), this.holdTime = this.currentTime;
	}
	complete() {
		this.state !== "running" && this.play(), this.state = "finished", this.holdTime = null;
	}
	finish() {
		this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete?.();
	}
	cancel() {
		this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel?.();
	}
	teardown() {
		this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null;
	}
	stopDriver() {
		this.driver &&= (this.driver.stop(), void 0);
	}
	sample(e) {
		return this.startTime = 0, this.tick(e, !0);
	}
	attachTimeline(e) {
		return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver?.stop(), e.observe(this);
	}
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/fill-wildcards.mjs
function bn(e) {
	for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1]);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/parse-transform.mjs
var V = (e) => e * 180 / Math.PI, xn = (e) => Cn(V(Math.atan2(e[1], e[0]))), Sn = {
	x: 4,
	y: 5,
	translateX: 4,
	translateY: 5,
	scaleX: 0,
	scaleY: 3,
	scale: (e) => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
	rotate: xn,
	rotateZ: xn,
	skewX: (e) => V(Math.atan(e[1])),
	skewY: (e) => V(Math.atan(e[2])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[2])) / 2
}, Cn = (e) => (e %= 360, e < 0 && (e += 360), e), wn = xn, Tn = (e) => Math.sqrt(e[0] * e[0] + e[1] * e[1]), En = (e) => Math.sqrt(e[4] * e[4] + e[5] * e[5]), Dn = {
	x: 12,
	y: 13,
	z: 14,
	translateX: 12,
	translateY: 13,
	translateZ: 14,
	scaleX: Tn,
	scaleY: En,
	scale: (e) => (Tn(e) + En(e)) / 2,
	rotateX: (e) => Cn(V(Math.atan2(e[6], e[5]))),
	rotateY: (e) => Cn(V(Math.atan2(-e[2], e[0]))),
	rotateZ: wn,
	rotate: wn,
	skewX: (e) => V(Math.atan(e[4])),
	skewY: (e) => V(Math.atan(e[1])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[4])) / 2
};
function On(e) {
	return +!!e.includes("scale");
}
function kn(e, t) {
	if (!e || e === "none") return On(t);
	let n = e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u), r, i;
	if (n) r = Dn, i = n;
	else {
		let t = e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
		r = Sn, i = t;
	}
	if (!i) return On(t);
	let a = r[t], o = i[1].split(",").map(jn);
	return typeof a == "function" ? a(o) : o[a];
}
var An = (e, t) => {
	let { transform: n = "none" } = getComputedStyle(e);
	return kn(n, t);
};
function jn(e) {
	return parseFloat(e.trim());
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/keys-transform.mjs
var Mn = [
	"transformPerspective",
	"x",
	"y",
	"z",
	"translateX",
	"translateY",
	"translateZ",
	"scale",
	"scaleX",
	"scaleY",
	"rotate",
	"rotateX",
	"rotateY",
	"rotateZ",
	"skew",
	"skewX",
	"skewY"
], Nn = new Set([...Mn, "pathRotation"]), Pn = (e) => e === We || e === I, Fn = new Set([
	"x",
	"y",
	"z"
]), In = Mn.filter((e) => !Fn.has(e));
function Ln(e) {
	let t = [];
	return In.forEach((n) => {
		let r = e.getValue(n);
		r !== void 0 && (t.push([n, r.get()]), r.set(+!!n.startsWith("scale")));
	}), t;
}
var H = {
	width: ({ x: e }, { paddingLeft: t = "0", paddingRight: n = "0", boxSizing: r }) => {
		let i = e.max - e.min;
		return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
	},
	height: ({ y: e }, { paddingTop: t = "0", paddingBottom: n = "0", boxSizing: r }) => {
		let i = e.max - e.min;
		return r === "border-box" ? i : i - parseFloat(t) - parseFloat(n);
	},
	top: (e, { top: t }) => parseFloat(t),
	left: (e, { left: t }) => parseFloat(t),
	bottom: ({ y: e }, { top: t }) => parseFloat(t) + (e.max - e.min),
	right: ({ x: e }, { left: t }) => parseFloat(t) + (e.max - e.min),
	x: (e, { transform: t }) => kn(t, "x"),
	y: (e, { transform: t }) => kn(t, "y")
};
H.translateX = H.x, H.translateY = H.y;
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/KeyframesResolver.mjs
var U = /* @__PURE__ */ new Set(), Rn = !1, zn = !1, Bn = !1;
function Vn() {
	if (zn) {
		let e = Array.from(U).filter((e) => e.needsMeasurement), t = new Set(e.map((e) => e.element)), n = /* @__PURE__ */ new Map();
		t.forEach((e) => {
			let t = Ln(e);
			t.length && (n.set(e, t), e.render());
		}), e.forEach((e) => e.measureInitialState()), t.forEach((e) => {
			e.render();
			let t = n.get(e);
			t && t.forEach(([t, n]) => {
				e.getValue(t)?.set(n);
			});
		}), e.forEach((e) => e.measureEndState()), e.forEach((e) => {
			e.suspendedScrollY !== void 0 && window.scrollTo(0, e.suspendedScrollY);
		});
	}
	zn = !1, Rn = !1, U.forEach((e) => e.complete(Bn)), U.clear();
}
function Hn() {
	U.forEach((e) => {
		e.readKeyframes(), e.needsMeasurement && (zn = !0);
	});
}
function Un() {
	Bn = !0, Hn(), Vn(), Bn = !1;
}
var Wn = class {
	constructor(e, t, n, r, i, a = !1) {
		this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = n, this.motionValue = r, this.element = i, this.isAsync = a;
	}
	scheduleResolve() {
		this.state = "scheduled", this.isAsync ? (U.add(this), Rn || (Rn = !0, A.read(Hn), A.resolveKeyframes(Vn))) : (this.readKeyframes(), this.complete());
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, name: t, element: n, motionValue: r } = this;
		if (e[0] === null) {
			let i = r?.get(), a = e[e.length - 1];
			if (i !== void 0) e[0] = i;
			else if (n && t) {
				let r = n.readValue(t, a);
				r != null && (e[0] = r);
			}
			e[0] === void 0 && (e[0] = a), r && i === void 0 && r.set(e[0]);
		}
		bn(e);
	}
	setFinalKeyframe() {}
	measureInitialState() {}
	renderEndStyles() {}
	measureEndState() {}
	complete(e = !1) {
		this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), U.delete(this);
	}
	cancel() {
		this.state === "scheduled" && (U.delete(this), this.state = "pending");
	}
	resume() {
		this.state === "pending" && this.scheduleResolve();
	}
}, Gn = (e) => e.startsWith("--");
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/style-set.mjs
function Kn(e, t, n) {
	Gn(t) ? e.style.setProperty(t, n) : e.style[t] = n;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/flags.mjs
var qn = {};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/memo.mjs
function Jn(e, t) {
	let n = /* @__PURE__ */ ie(e);
	return () => qn[t] ?? n();
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/supports/scroll-timeline.mjs
var Yn = /* @__PURE__ */ Jn(() => window.ScrollTimeline !== void 0, "scrollTimeline"), Xn = /* @__PURE__ */ Jn(() => {
	try {
		document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
	} catch {
		return !1;
	}
	return !0;
}, "linearEasing"), Zn = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`, Qn = {
	linear: "linear",
	ease: "ease",
	easeIn: "ease-in",
	easeOut: "ease-out",
	easeInOut: "ease-in-out",
	circIn: /* @__PURE__ */ Zn([
		0,
		.65,
		.55,
		1
	]),
	circOut: /* @__PURE__ */ Zn([
		.55,
		0,
		1,
		.45
	]),
	backIn: /* @__PURE__ */ Zn([
		.31,
		.01,
		.66,
		-.59
	]),
	backOut: /* @__PURE__ */ Zn([
		.33,
		1.53,
		.69,
		.99
	])
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/easing/map-easing.mjs
function $n(e, t) {
	if (e) return typeof e == "function" ? Xn() ? Ht(e, t) : "ease-out" : /* @__PURE__ */ De(e) ? Zn(e) : Array.isArray(e) ? e.map((e) => $n(e, t) || Qn.easeOut) : Qn[e];
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/start-waapi-animation.mjs
function er(e, t, n, { delay: r = 0, duration: i = 300, repeat: a = 0, repeatType: o = "loop", ease: s = "easeOut", times: c } = {}, l = void 0) {
	let u = { [t]: n };
	c && (u.offset = c);
	let d = $n(s, i);
	Array.isArray(d) && (u.easing = d);
	let f = {
		delay: r,
		duration: i,
		easing: Array.isArray(d) ? "linear" : d,
		fill: "both",
		iterations: a + 1,
		direction: o === "reverse" ? "alternate" : "normal"
	};
	return l && (f.pseudoElement = l), e.animate(u, f);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/generators/utils/is-generator.mjs
function tr(e) {
	return typeof e == "function" && "applyToOptions" in e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/utils/apply-generator.mjs
function nr({ type: e, ...t }) {
	return tr(e) && Xn() ? e.applyToOptions(t) : (t.duration ??= 300, t.ease ??= "easeOut", t);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/NativeAnimation.mjs
var rr = class extends _n {
	constructor(e) {
		if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !e) return;
		let { element: t, name: n, keyframes: r, pseudoElement: i, allowFlatten: a = !1, finalKeyframe: o, onComplete: s } = e;
		this.isPseudoElement = !!i, this.allowFlatten = a, this.options = e, e.type;
		let c = nr(e);
		this.animation = er(t, n, r, c, i), c.autoplay === !1 && this.animation.pause(), this.animation.onfinish = () => {
			if (this.finishedTime = this.time, !i) {
				let e = mn(r, this.options, o, this.speed);
				this.updateMotionValue && this.updateMotionValue(e), Kn(t, n, e), this.animation.cancel();
			}
			s?.(), this.notifyFinished();
		};
	}
	play() {
		this.isStopped || (this.manualStartTime = null, this.animation.play(), this.state === "finished" && this.updateFinished());
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.animation.finish?.();
	}
	cancel() {
		try {
			this.animation.cancel();
		} catch {}
	}
	stop() {
		if (this.isStopped) return;
		this.isStopped = !0;
		let { state: e } = this;
		e === "idle" || e === "finished" || (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel());
	}
	commitStyles() {
		let e = this.options?.element;
		!this.isPseudoElement && e?.isConnected && this.animation.commitStyles?.();
	}
	get duration() {
		let e = this.animation.effect?.getComputedTiming?.().duration || 0;
		return /* @__PURE__ */ k(Number(e));
	}
	get iterationDuration() {
		let { delay: e = 0 } = this.options || {};
		return this.duration + /* @__PURE__ */ k(e);
	}
	get time() {
		return /* @__PURE__ */ k(Number(this.animation.currentTime) || 0);
	}
	set time(e) {
		let t = this.finishedTime !== null;
		this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = /* @__PURE__ */ O(e), t && this.animation.pause();
	}
	get speed() {
		return this.animation.playbackRate;
	}
	set speed(e) {
		e < 0 && (this.finishedTime = null), this.animation.playbackRate = e;
	}
	get state() {
		return this.finishedTime === null ? this.animation.playState : "finished";
	}
	get startTime() {
		return this.manualStartTime ?? Number(this.animation.startTime);
	}
	set startTime(e) {
		this.manualStartTime = this.animation.startTime = e;
	}
	attachTimeline({ timeline: e, rangeStart: t, rangeEnd: n, observe: r }) {
		return this.allowFlatten && this.animation.effect?.updateTiming({ easing: "linear" }), this.animation.onfinish = null, e && Yn() ? (this.animation.timeline = e, t && (this.animation.rangeStart = t), n && (this.animation.rangeEnd = n), D) : r(this);
	}
}, ir = {
	anticipate: ye,
	backInOut: ve,
	circInOut: Se
};
function ar(e) {
	return e in ir;
}
function or(e) {
	typeof e.ease == "string" && ar(e.ease) && (e.ease = ir[e.ease]);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/NativeAnimationExtended.mjs
var sr = 10, cr = class extends rr {
	constructor(e) {
		or(e), gn(e), super(e), e.startTime !== void 0 && e.autoplay !== !1 && (this.startTime = e.startTime), this.options = e;
	}
	updateMotionValue(e) {
		let { motionValue: t, onUpdate: n, onComplete: r, element: i, ...a } = this.options;
		if (!t) return;
		if (e !== void 0) {
			t.set(e);
			return;
		}
		let o = new yn({
			...a,
			autoplay: !1
		}), s = Math.max(sr, N.now() - this.startTime), c = T(0, sr, s - sr), l = o.sample(s).value, { name: u } = this.options;
		i && u && Kn(i, u, l), t.setWithVelocity(o.sample(Math.max(0, s - c)).value, l, c), o.stop();
	}
}, lr = (e, t) => t === "zIndex" ? !1 : !!(typeof e == "number" || Array.isArray(e) || typeof e == "string" && (R.test(e) || e === "0") && !e.startsWith("url("));
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/can-animate.mjs
function ur(e) {
	let t = e[0];
	if (e.length === 1) return !0;
	for (let n = 0; n < e.length; n++) if (e[n] !== t) return !0;
}
function dr(e, t, n, r) {
	let i = e[0];
	if (i === null) return !1;
	if (t === "display" || t === "visibility") return !0;
	let a = e[e.length - 1], o = lr(i, t), s = lr(a, t);
	return `${t}${i}${a}${o ? a : i}`, !o || !s ? !1 : ur(e) || (n === "spring" || tr(n)) && r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/make-animation-instant.mjs
function fr(e) {
	e.duration = 0, e.type = "keyframes";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/utils/accelerated-values.mjs
var pr = new Set([
	"opacity",
	"clipPath",
	"filter",
	"transform",
	"backgroundColor"
]), mr = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function hr(e) {
	for (let t = 0; t < e.length; t++) if (typeof e[t] == "string" && mr.test(e[t])) return !0;
	return !1;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/waapi/supports/waapi.mjs
var gr = new Set([
	"color",
	"backgroundColor",
	"outlineColor",
	"fill",
	"stroke",
	"borderColor",
	"borderTopColor",
	"borderRightColor",
	"borderBottomColor",
	"borderLeftColor"
]), _r = /* @__PURE__ */ ie(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
function vr(e) {
	let { motionValue: t, name: n, repeatDelay: r, repeatType: i, damping: a, type: o, keyframes: s } = e, c = t?.owner?.current;
	if (!(c instanceof HTMLElement) && !(c instanceof SVGElement)) return !1;
	let { onUpdate: l, transformTemplate: u } = t.owner.getProps();
	return _r() && n && (pr.has(n) || gr.has(n) && hr(s)) && (n !== "transform" || !u) && !l && !r && i !== "mirror" && a !== 0 && o !== "inertia";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/AsyncMotionValueAnimation.mjs
var yr = 40, br = class extends _n {
	constructor({ autoplay: e = !0, delay: t = 0, type: n = "keyframes", repeat: r = 0, repeatDelay: i = 0, repeatType: a = "loop", keyframes: o, name: s, motionValue: c, element: l, ...u }) {
		super(), this.stop = () => {
			this._animation && (this._animation.stop(), this.stopTimeline?.()), this.keyframeResolver?.cancel();
		}, this.createdAt = N.now();
		let d = {
			autoplay: e,
			delay: t,
			type: n,
			repeat: r,
			repeatDelay: i,
			repeatType: a,
			name: s,
			motionValue: c,
			element: l,
			...u
		}, f = l?.KeyframeResolver || Wn;
		this.keyframeResolver = new f(o, (e, t, n) => this.onKeyframesResolved(e, t, d, !n), s, c, l), this.keyframeResolver?.scheduleResolve();
	}
	onKeyframesResolved(e, t, n, r) {
		this.keyframeResolver = void 0;
		let { name: i, type: a, velocity: o, delay: s, isHandoff: c, onUpdate: l } = n;
		this.resolvedAt = N.now();
		let u = !0;
		dr(e, i, a, o) || (u = !1, (E.instantAnimations || !s) && l?.(mn(e, n, t)), e[0] = e[e.length - 1], fr(n), n.repeat = 0);
		let d = {
			startTime: r ? this.resolvedAt && this.resolvedAt - this.createdAt > yr ? this.resolvedAt : this.createdAt : void 0,
			finalKeyframe: t,
			...n,
			keyframes: e
		}, f = u && !c && vr(d), p = d.motionValue?.owner?.current, m;
		if (f) try {
			m = new cr({
				...d,
				element: p
			});
		} catch {
			m = new yn(d);
		}
		else m = new yn(d);
		m.finished.then(() => {
			this.notifyFinished();
		}).catch(D), this.pendingTimeline &&= (this.stopTimeline = m.attachTimeline(this.pendingTimeline), void 0), this._animation = m;
	}
	get finished() {
		return this._animation ? this.animation.finished : this._finished;
	}
	then(e, t) {
		return this.finished.finally(e).then(() => {});
	}
	get animation() {
		return this._animation || (this.keyframeResolver?.resume(), Un()), this._animation;
	}
	get duration() {
		return this.animation.duration;
	}
	get iterationDuration() {
		return this.animation.iterationDuration;
	}
	get time() {
		return this.animation.time;
	}
	set time(e) {
		this.animation.time = e;
	}
	get speed() {
		return this.animation.speed;
	}
	get state() {
		return this.animation.state;
	}
	set speed(e) {
		this.animation.speed = e;
	}
	get startTime() {
		return this.animation.startTime;
	}
	attachTimeline(e) {
		return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop();
	}
	play() {
		this.animation.play();
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.animation.complete();
	}
	cancel() {
		this._animation && this.animation.cancel(), this.keyframeResolver?.cancel();
	}
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/calc-child-stagger.mjs
function xr(e, t, n, r = 0, i = 1) {
	let a = Array.from(e).sort((e, t) => e.sortNodePosition(t)).indexOf(t), o = e.size, s = (o - 1) * r;
	return typeof n == "function" ? n(a, o) : i === 1 ? a * r : s - a * r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/index.mjs
var Sr = 30, Cr = (e) => !isNaN(parseFloat(e)), wr = { current: void 0 }, Tr = class {
	constructor(e, t = {}) {
		this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (e) => {
			let t = N.now();
			if (this.updatedAt !== t && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && (this.events.change?.notify(this.current), this.dependents)) for (let e of this.dependents) e.dirty();
		}, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner;
	}
	setCurrent(e) {
		this.current = e, this.updatedAt = N.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = Cr(this.current));
	}
	setPrevFrameValue(e = this.current) {
		this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt;
	}
	onChange(e) {
		return this.on("change", e);
	}
	on(e, t) {
		this.events[e] || (this.events[e] = new se());
		let n = this.events[e].add(t);
		return e === "change" ? () => {
			n(), A.read(() => {
				this.events.change.getSize() || this.stop();
			});
		} : n;
	}
	clearListeners() {
		for (let e in this.events) this.events[e].clear();
	}
	attach(e, t) {
		this.passiveEffect = e, this.stopPassiveEffect = t;
	}
	set(e) {
		this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e);
	}
	setWithVelocity(e, t, n) {
		this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - n;
	}
	jump(e, t = !0) {
		this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, t && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
	}
	dirty() {
		this.events.change?.notify(this.current);
	}
	addDependent(e) {
		this.dependents ||= /* @__PURE__ */ new Set(), this.dependents.add(e);
	}
	removeDependent(e) {
		this.dependents && this.dependents.delete(e);
	}
	get() {
		return wr.current && wr.current.push(this), this.current;
	}
	getPrevious() {
		return this.prev;
	}
	getVelocity() {
		let e = N.now();
		if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > Sr) return 0;
		let t = Math.min(this.updatedAt - this.prevUpdatedAt, Sr);
		return /* @__PURE__ */ ce(parseFloat(this.current) - parseFloat(this.prevFrameValue), t);
	}
	start(e) {
		return this.stop(), new Promise((t) => {
			this.hasAnimated = !0, this.animation = e(t), this.events.animationStart && this.events.animationStart.notify();
		}).then(() => {
			this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation();
		});
	}
	stop() {
		this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation();
	}
	isAnimating() {
		return !!this.animation;
	}
	clearAnimation() {
		delete this.animation;
	}
	destroy() {
		this.dependents?.clear(), this.events.destroy?.notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
	}
};
function Er(e, t) {
	return new Tr(e, t);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/resolve-transition.mjs
function Dr(e, t) {
	if (e?.inherit && t) {
		let { inherit: n, ...r } = e;
		return {
			...t,
			...r
		};
	}
	return e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/get-value-transition.mjs
function Or(e, t) {
	let n = e?.[t] ?? e?.default ?? e;
	return n === e ? n : Dr(n, e);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/utils/default-transitions.mjs
var kr = {
	type: "spring",
	stiffness: 500,
	damping: 25,
	restSpeed: 10
}, Ar = (e) => ({
	type: "spring",
	stiffness: 550,
	damping: e === 0 ? 2 * Math.sqrt(550) : 30,
	restSpeed: 10
}), jr = {
	type: "keyframes",
	duration: .8
}, Mr = {
	type: "keyframes",
	ease: [
		.25,
		.1,
		.35,
		1
	],
	duration: .3
}, Nr = (e, { keyframes: t }) => t.length > 2 ? jr : Nn.has(e) ? e.startsWith("scale") ? Ar(t[1]) : kr : Mr, Pr = new Set([
	"when",
	"delay",
	"delayChildren",
	"staggerChildren",
	"staggerDirection",
	"repeat",
	"repeatType",
	"repeatDelay",
	"from",
	"elapsed"
]);
function Fr(e) {
	for (let t in e) if (!Pr.has(t)) return !0;
	return !1;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/motion-value.mjs
var Ir = (e, t, n, r = {}, i, a) => (o) => {
	let s = Or(r, e) || {}, c = s.delay || r.delay || 0, { elapsed: l = 0 } = r;
	l -= /* @__PURE__ */ O(c);
	let u = {
		keyframes: Array.isArray(n) ? n : [null, n],
		ease: "easeOut",
		velocity: t.getVelocity(),
		...s,
		delay: -l,
		onUpdate: (e) => {
			t.set(e), s.onUpdate && s.onUpdate(e);
		},
		onComplete: () => {
			o(), s.onComplete && s.onComplete();
		},
		name: e,
		motionValue: t,
		element: a ? void 0 : i
	};
	Fr(s) || Object.assign(u, Nr(e, u)), u.duration &&= /* @__PURE__ */ O(u.duration), u.repeatDelay &&= /* @__PURE__ */ O(u.repeatDelay), u.from !== void 0 && (u.keyframes[0] = u.from);
	let d = !1;
	if ((u.type === !1 || u.duration === 0 && !u.repeatDelay) && (fr(u), u.delay === 0 && (d = !0)), (E.instantAnimations || E.skipAnimations || i?.shouldSkipAnimations || s.skipAnimations) && (d = !0, fr(u), u.delay = 0), u.allowFlatten = !s.type && !s.ease, d && !a && t.get() !== void 0) {
		let e = mn(u.keyframes, s);
		if (e !== void 0) {
			A.update(() => {
				u.onUpdate(e), u.onComplete();
			});
			return;
		}
	}
	return s.isSync ? new yn(u) : new br(u);
}, Lr = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Rr(e) {
	let t = Lr.exec(e);
	if (!t) return [,];
	let [, n, r, i] = t;
	return [`--${n ?? r}`, i];
}
function zr(e, t, n = 1) {
	`${e}`;
	let [r, i] = Rr(e);
	if (!r) return;
	let a = window.getComputedStyle(t).getPropertyValue(r);
	if (a) {
		let e = a.trim();
		return te(e) ? parseFloat(e) : e;
	}
	return Ve(i) ? zr(i, t, n + 1) : i;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/resolve-variants.mjs
function Br(e) {
	let t = [{}, {}];
	return e?.values.forEach((e, n) => {
		t[0][n] = e.get(), t[1][n] = e.getVelocity();
	}), t;
}
function Vr(e, t, n, r) {
	if (typeof t == "function") {
		let [i, a] = Br(r);
		t = t(n === void 0 ? e.custom : n, i, a);
	}
	if (typeof t == "string" && (t = e.variants && e.variants[t]), typeof t == "function") {
		let [i, a] = Br(r);
		t = t(n === void 0 ? e.custom : n, i, a);
	}
	return t;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/resolve-dynamic-variants.mjs
function W(e, t, n) {
	let r = e.getProps();
	return Vr(r, t, n === void 0 ? r.custom : n, e);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/keys-position.mjs
var Hr = new Set([
	"width",
	"height",
	"top",
	"left",
	"right",
	"bottom",
	...Mn
]), Ur = (e) => Array.isArray(e);
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/setters.mjs
function Wr(e, t, n) {
	e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, Er(n));
}
function Gr(e) {
	return Ur(e) ? e[e.length - 1] || 0 : e;
}
function Kr(e, t) {
	let { transitionEnd: n = {}, transition: r = {}, ...i } = W(e, t) || {};
	i = {
		...i,
		...n
	};
	for (let t in i) Wr(e, t, Gr(i[t]));
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/utils/is-motion-value.mjs
var G = (e) => !!(e && e.getVelocity);
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/will-change/is.mjs
function qr(e) {
	return !!(G(e) && e.add);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/will-change/add-will-change.mjs
function Jr(e, t) {
	let n = e.getValue("willChange");
	if (qr(n)) return n.add(t);
	if (!n && E.WillChange) {
		let n = new E.WillChange("auto");
		e.addValue("willChange", n), n.add(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/dom/utils/camel-to-dash.mjs
function Yr(e) {
	return e.replace(/([A-Z])/g, (e) => `-${e.toLowerCase()}`);
}
var Xr = "data-" + Yr("framerAppearId");
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/optimized-appear/get-appear-id.mjs
function Zr(e) {
	return e.props[Xr];
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element-target.mjs
function Qr({ protectedKeys: e, needsAnimating: t }, n) {
	let r = e.hasOwnProperty(n) && t[n] !== !0;
	return t[n] = !1, r;
}
function $r(e, t, { delay: n = 0, transitionOverride: r, type: i } = {}) {
	let { transition: a, transitionEnd: o, ...s } = t, c = e.getDefaultTransition();
	a = a ? Dr(a, c) : c;
	let l = a?.reduceMotion, u = a?.skipAnimations;
	r && (a = r);
	let d = [], f = i && e.animationState && e.animationState.getState()[i], p = a?.path;
	p && p.animateVisualElement(e, s, a, n, d);
	for (let t in s) {
		let r = e.getValue(t, e.latestValues[t] ?? null), i = s[t];
		if (i === void 0 || f && Qr(f, t)) continue;
		let o = {
			delay: n,
			...Or(a || {}, t)
		};
		u && (o.skipAnimations = !0);
		let c = r.get();
		if (c !== void 0 && !r.isAnimating() && !Array.isArray(i) && i === c && !o.velocity) {
			A.update(() => r.set(i));
			continue;
		}
		let p = !1;
		if (window.MotionHandoffAnimation) {
			let n = Zr(e);
			if (n) {
				let e = window.MotionHandoffAnimation(n, t, A);
				e !== null && (o.startTime = e, p = !0);
			}
		}
		Jr(e, t);
		let m = l ?? e.shouldReduceMotion;
		r.start(Ir(t, r, i, m && Hr.has(t) ? { type: !1 } : o, e, p));
		let h = r.animation;
		h && d.push(h);
	}
	if (o) {
		let t = () => A.update(() => {
			o && Kr(e, o);
		});
		d.length ? Promise.all(d).then(t) : t();
	}
	return d;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element-variant.mjs
function ei(e, t, n = {}) {
	let r = W(e, t, n.type === "exit" ? e.presenceContext?.custom : void 0), { transition: i = e.getDefaultTransition() || {} } = r || {};
	n.transitionOverride && (i = n.transitionOverride);
	let a = r ? () => Promise.all($r(e, r, n)) : () => Promise.resolve(), o = e.variantChildren && e.variantChildren.size ? (r = 0) => {
		let { delayChildren: a = 0, staggerChildren: o, staggerDirection: s } = i;
		return ti(e, t, r, a, o, s, n);
	} : () => Promise.resolve(), { when: s } = i;
	if (s) {
		let [e, t] = s === "beforeChildren" ? [a, o] : [o, a];
		return e().then(() => t());
	} else return Promise.all([a(), o(n.delay)]);
}
function ti(e, t, n = 0, r = 0, i = 0, a = 1, o) {
	let s = [];
	for (let c of e.variantChildren) c.notify("AnimationStart", t), s.push(ei(c, t, {
		...o,
		delay: n + (typeof r == "function" ? 0 : r) + xr(e.variantChildren, c, r, i, a)
	}).then(() => c.notify("AnimationComplete", t)));
	return Promise.all(s);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/interfaces/visual-element.mjs
function ni(e, t, n = {}) {
	e.notify("AnimationStart", t);
	let r;
	if (Array.isArray(t)) {
		let i = t.map((t) => ei(e, t, n));
		r = Promise.all(i);
	} else if (typeof t == "string") r = ei(e, t, n);
	else {
		let i = typeof t == "function" ? W(e, t, n.custom) : t;
		r = Promise.all($r(e, i, n));
	}
	return r.then(() => {
		e.notify("AnimationComplete", t);
	});
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/auto.mjs
var ri = {
	test: (e) => e === "auto",
	parse: (e) => e
}, ii = (e) => (t) => t.test(e), ai = [
	We,
	I,
	F,
	P,
	ot,
	at,
	ri
], oi = (e) => ai.find(ii(e));
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/is-none.mjs
function si(e) {
	return typeof e == "number" ? e === 0 : e === null ? !0 : e === "none" || e === "0" || re(e);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/complex/filter.mjs
var ci = new Set([
	"brightness",
	"contrast",
	"saturate",
	"opacity"
]);
function li(e) {
	let [t, n] = e.slice(0, -1).split("(");
	if (t === "drop-shadow") return e;
	let [r] = n.match(Je) || [];
	if (!r) return e;
	let i = n.replace(r, ""), a = +!!ci.has(t);
	return r !== n && (a *= 100), t + "(" + a + i + ")";
}
var ui = /\b([a-z-]*)\(.*?\)/gu, di = {
	...R,
	getAnimatableNone: (e) => {
		let t = e.match(ui);
		return t ? t.map(li).join(" ") : e;
	}
}, fi = {
	...R,
	getAnimatableNone: (e) => {
		let t = R.parse(e);
		return R.createTransformer(e)(t.map((e) => typeof e == "number" ? 0 : typeof e == "object" ? {
			...e,
			alpha: 1
		} : e));
	}
}, pi = {
	...We,
	transform: Math.round
}, mi = {
	borderWidth: I,
	borderTopWidth: I,
	borderRightWidth: I,
	borderBottomWidth: I,
	borderLeftWidth: I,
	borderRadius: I,
	borderTopLeftRadius: I,
	borderTopRightRadius: I,
	borderBottomRightRadius: I,
	borderBottomLeftRadius: I,
	width: I,
	maxWidth: I,
	height: I,
	maxHeight: I,
	top: I,
	right: I,
	bottom: I,
	left: I,
	inset: I,
	insetBlock: I,
	insetBlockStart: I,
	insetBlockEnd: I,
	insetInline: I,
	insetInlineStart: I,
	insetInlineEnd: I,
	padding: I,
	paddingTop: I,
	paddingRight: I,
	paddingBottom: I,
	paddingLeft: I,
	paddingBlock: I,
	paddingBlockStart: I,
	paddingBlockEnd: I,
	paddingInline: I,
	paddingInlineStart: I,
	paddingInlineEnd: I,
	margin: I,
	marginTop: I,
	marginRight: I,
	marginBottom: I,
	marginLeft: I,
	marginBlock: I,
	marginBlockStart: I,
	marginBlockEnd: I,
	marginInline: I,
	marginInlineStart: I,
	marginInlineEnd: I,
	fontSize: I,
	backgroundPositionX: I,
	backgroundPositionY: I,
	rotate: P,
	pathRotation: P,
	rotateX: P,
	rotateY: P,
	rotateZ: P,
	scale: Ke,
	scaleX: Ke,
	scaleY: Ke,
	scaleZ: Ke,
	skew: P,
	skewX: P,
	skewY: P,
	distance: I,
	translateX: I,
	translateY: I,
	translateZ: I,
	x: I,
	y: I,
	z: I,
	perspective: I,
	transformPerspective: I,
	opacity: Ge,
	originX: st,
	originY: st,
	originZ: I,
	zIndex: pi,
	fillOpacity: Ge,
	strokeOpacity: Ge,
	numOctaves: pi
}, hi = {
	...mi,
	color: L,
	backgroundColor: L,
	outlineColor: L,
	fill: L,
	stroke: L,
	borderColor: L,
	borderTopColor: L,
	borderRightColor: L,
	borderBottomColor: L,
	borderLeftColor: L,
	filter: di,
	WebkitFilter: di,
	mask: fi,
	WebkitMask: fi
}, gi = (e) => hi[e], _i = /* @__PURE__ */ new Set([di, fi]);
function vi(e, t) {
	let n = gi(e);
	return _i.has(n) || (n = R), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/utils/make-none-animatable.mjs
var yi = new Set([
	"auto",
	"none",
	"0"
]);
function bi(e, t, n) {
	let r = 0, i;
	for (; r < e.length && !i;) {
		let t = e[r];
		typeof t == "string" && !yi.has(t) && _t(t).values.length && (i = e[r]), r++;
	}
	if (i && n) for (let r of t) e[r] = vi(n, i);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/keyframes/DOMKeyframesResolver.mjs
var xi = class extends Wn {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i, !0);
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, element: t, name: n } = this;
		if (!t || !t.current) return;
		super.readKeyframes();
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (typeof r == "string" && (r = r.trim(), Ve(r))) {
				let i = zr(r, t.current);
				i !== void 0 && (e[n] = i), n === e.length - 1 && (this.finalKeyframe = r);
			}
		}
		if (this.resolveNoneKeyframes(), !Hr.has(n) || e.length !== 2) return;
		let [r, i] = e, a = oi(r), o = oi(i);
		if (Ue(r) !== Ue(i) && H[n]) {
			this.needsMeasurement = !0;
			return;
		}
		if (a !== o) if (Pn(a) && Pn(o)) for (let t = 0; t < e.length; t++) {
			let n = e[t];
			typeof n == "string" && (e[t] = parseFloat(n));
		}
		else H[n] && (this.needsMeasurement = !0);
	}
	resolveNoneKeyframes() {
		let { unresolvedKeyframes: e, name: t } = this, n = [];
		for (let t = 0; t < e.length; t++) (e[t] === null || si(e[t])) && n.push(t);
		n.length && bi(e, n, t);
	}
	measureInitialState() {
		let { element: e, unresolvedKeyframes: t, name: n } = this;
		if (!e || !e.current) return;
		n === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = H[n](e.measureViewportBox(), window.getComputedStyle(e.current)), t[0] = this.measuredOrigin;
		let r = t[t.length - 1];
		r !== void 0 && e.getValue(n, r).jump(r, !1);
	}
	measureEndState() {
		let { element: e, name: t, unresolvedKeyframes: n } = this;
		if (!e || !e.current) return;
		let r = e.getValue(t);
		r && r.jump(this.measuredOrigin, !1);
		let i = n.length - 1, a = n[i];
		n[i] = H[t](e.measureViewportBox(), window.getComputedStyle(e.current)), a !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = a), this.removedTransforms?.length && this.removedTransforms.forEach(([t, n]) => {
			e.getValue(t).set(n);
		}), this.resolveNoneKeyframes();
	}
}, Si = [
	"borderTopLeftRadius",
	"borderTopRightRadius",
	"borderBottomRightRadius",
	"borderBottomLeftRadius"
];
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/resolve-elements.mjs
function Ci(e, t, n) {
	if (e == null) return [];
	if (e instanceof EventTarget) return [e];
	if (typeof e == "string") {
		let r = document;
		t && (r = t.current);
		let i = n?.[e] ?? r.querySelectorAll(e);
		return i ? Array.from(i) : [];
	}
	return Array.from(e).filter((e) => e != null);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/get-as-type.mjs
var wi = (e, t) => t && typeof e == "number" ? t.transform(e) : e;
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-html-element.mjs
function Ti(e) {
	return ne(e) && "offsetHeight" in e && !("ownerSVGElement" in e);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/frameloop/microtask.mjs
var { schedule: Ei, cancel: Di } = /* @__PURE__ */ Pe(queueMicrotask, !1), K = {
	x: !1,
	y: !1
};
function Oi() {
	return K.x || K.y;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/drag/state/set-active.mjs
function ki(e) {
	return e === "x" || e === "y" ? K[e] ? null : (K[e] = !0, () => {
		K[e] = !1;
	}) : K.x || K.y ? null : (K.x = K.y = !0, () => {
		K.x = K.y = !1;
	});
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/utils/setup.mjs
function Ai(e, t) {
	let n = Ci(e), r = new AbortController();
	return [
		n,
		{
			passive: !0,
			...t,
			signal: r.signal
		},
		() => r.abort()
	];
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/hover.mjs
function ji(e) {
	return !(e.pointerType === "touch" || Oi());
}
function Mi(e, t, n = {}) {
	let [r, i, a] = Ai(e, n);
	return r.forEach((e) => {
		let n = !1, r = !1, a, o = () => {
			e.removeEventListener("pointerleave", u);
		}, s = (e) => {
			a &&= (a(e), void 0), o();
		}, c = (e) => {
			n = !1, window.removeEventListener("pointerup", c), window.removeEventListener("pointercancel", c), r && (r = !1, s(e));
		}, l = () => {
			n = !0, window.addEventListener("pointerup", c, i), window.addEventListener("pointercancel", c, i);
		}, u = (e) => {
			if (e.pointerType !== "touch") {
				if (n) {
					r = !0;
					return;
				}
				s(e);
			}
		};
		e.addEventListener("pointerenter", (n) => {
			if (!ji(n)) return;
			r = !1;
			let o = t(e, n);
			typeof o == "function" && (a = o, e.addEventListener("pointerleave", u, i));
		}, i), e.addEventListener("pointerdown", l, i);
	}), a;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/utils/is-node-or-child.mjs
var Ni = (e, t) => t ? e === t ? !0 : Ni(e, t.parentElement) : !1, Pi = (e) => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1, Fi = new Set([
	"BUTTON",
	"INPUT",
	"SELECT",
	"TEXTAREA",
	"A"
]);
function Ii(e) {
	return Fi.has(e.tagName) || e.isContentEditable === !0;
}
var Li = new Set([
	"INPUT",
	"SELECT",
	"TEXTAREA"
]);
function Ri(e) {
	return Li.has(e.tagName) || e.isContentEditable === !0;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/utils/state.mjs
var zi = /* @__PURE__ */ new WeakSet();
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/utils/keyboard.mjs
function Bi(e) {
	return (t) => {
		t.key === "Enter" && e(t);
	};
}
function Vi(e, t) {
	e.dispatchEvent(new PointerEvent("pointer" + t, {
		isPrimary: !0,
		bubbles: !0
	}));
}
var Hi = (e, t) => {
	let n = e.currentTarget;
	if (!n) return;
	let r = Bi(() => {
		if (zi.has(n)) return;
		Vi(n, "down");
		let e = Bi(() => {
			Vi(n, "up");
		});
		n.addEventListener("keyup", e, t), n.addEventListener("blur", () => Vi(n, "cancel"), t);
	});
	n.addEventListener("keydown", r, t), n.addEventListener("blur", () => n.removeEventListener("keydown", r), t);
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/gestures/press/index.mjs
function Ui(e) {
	return Pi(e) && !Oi();
}
var Wi = /* @__PURE__ */ new WeakSet();
function Gi(e, t, n = {}) {
	let [r, i, a] = Ai(e, n), o = (e) => {
		let r = e.currentTarget;
		if (!Ui(e) || Wi.has(e)) return;
		zi.add(r), n.stopPropagation && Wi.add(e);
		let a = t(r, e), o = {
			...i,
			capture: !0
		}, s = (e, t) => {
			window.removeEventListener("pointerup", c, o), window.removeEventListener("pointercancel", l, o), zi.has(r) && zi.delete(r), Ui(e) && typeof a == "function" && a(e, { success: t });
		}, c = (e) => {
			s(e, r === window || r === document || n.useGlobalTarget || Ni(r, e.target));
		}, l = (e) => {
			s(e, !1);
		};
		window.addEventListener("pointerup", c, o), window.addEventListener("pointercancel", l, o);
	};
	return r.forEach((e) => {
		(n.useGlobalTarget ? window : e).addEventListener("pointerdown", o, i), Ti(e) && (e.addEventListener("focus", (e) => Hi(e, i)), !Ii(e) && !e.hasAttribute("tabindex") && (e.tabIndex = 0));
	}), a;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-svg-element.mjs
function Ki(e) {
	return ne(e) && "ownerSVGElement" in e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/handle-element.mjs
var qi = /* @__PURE__ */ new WeakMap(), Ji, Yi = (e, t, n) => (r, i) => i && i[0] ? i[0][e + "Size"] : Ki(r) && "getBBox" in r ? r.getBBox()[t] : r[n], Xi = /* @__PURE__ */ Yi("inline", "width", "offsetWidth"), Zi = /* @__PURE__ */ Yi("block", "height", "offsetHeight");
function Qi({ target: e, borderBoxSize: t }) {
	qi.get(e)?.forEach((n) => {
		n(e, {
			get width() {
				return Xi(e, t);
			},
			get height() {
				return Zi(e, t);
			}
		});
	});
}
function $i(e) {
	e.forEach(Qi);
}
function ea() {
	typeof ResizeObserver > "u" || (Ji = new ResizeObserver($i));
}
function ta(e, t) {
	Ji || ea();
	let n = Ci(e);
	return n.forEach((e) => {
		let n = qi.get(e);
		n || (n = /* @__PURE__ */ new Set(), qi.set(e, n)), n.add(t), Ji?.observe(e);
	}), () => {
		n.forEach((e) => {
			let n = qi.get(e);
			n?.delete(t), n?.size || Ji?.unobserve(e);
		});
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/handle-window.mjs
var na = /* @__PURE__ */ new Set(), ra;
function ia() {
	ra = () => {
		let e = {
			get width() {
				return window.innerWidth;
			},
			get height() {
				return window.innerHeight;
			}
		};
		na.forEach((t) => t(e));
	}, window.addEventListener("resize", ra);
}
function aa(e) {
	return na.add(e), ra || ia(), () => {
		na.delete(e), !na.size && typeof ra == "function" && (window.removeEventListener("resize", ra), ra = void 0);
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/resize/index.mjs
function oa(e, t) {
	return typeof e == "function" ? aa(e) : ta(e, t);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/stats/buffer.mjs
var sa = {
	value: null,
	addProjectionMetrics: null
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/is-svg-svg-element.mjs
function ca(e) {
	return Ki(e) && e.tagName === "svg";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/types/utils/find.mjs
var la = [
	...ai,
	L,
	R
], ua = (e) => la.find(ii(e)), da = () => ({
	translate: 0,
	scale: 1,
	origin: 0,
	originPoint: 0
}), fa = () => ({
	x: da(),
	y: da()
}), pa = () => ({
	min: 0,
	max: 0
}), q = () => ({
	x: pa(),
	y: pa()
}), ma = /* @__PURE__ */ new WeakMap();
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-animation-controls.mjs
function ha(e) {
	return typeof e == "object" && !!e && typeof e.start == "function";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-variant-label.mjs
function ga(e) {
	return typeof e == "string" || Array.isArray(e);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/variant-props.mjs
var _a = [
	"animate",
	"whileInView",
	"whileFocus",
	"whileHover",
	"whileTap",
	"whileDrag",
	"exit"
], va = ["initial", ..._a];
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-controlling-variants.mjs
function ya(e) {
	return ha(e.animate) || va.some((t) => ga(e[t]));
}
function ba(e) {
	return !!(ya(e) || e.variants);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/motion-values.mjs
function xa(e, t, n) {
	for (let r in t) {
		let i = t[r], a = n[r];
		if (G(i)) e.addValue(r, i);
		else if (G(a)) e.addValue(r, Er(i, { owner: e }));
		else if (a !== i) if (e.hasValue(r)) {
			let t = e.getValue(r);
			t.liveStyle === !0 ? t.jump(i) : t.hasAnimated || t.set(i);
		} else {
			let t = e.getStaticValue(r);
			e.addValue(r, Er(t === void 0 ? i : t, { owner: e }));
		}
	}
	for (let r in n) t[r] === void 0 && e.removeValue(r);
	return t;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/reduced-motion/state.mjs
var Sa = { current: null }, Ca = { current: !1 }, wa = typeof window < "u";
function Ta() {
	if (Ca.current = !0, wa) if (window.matchMedia) {
		let e = window.matchMedia("(prefers-reduced-motion)"), t = () => Sa.current = e.matches;
		e.addEventListener("change", t), t();
	} else Sa.current = !1;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/VisualElement.mjs
var Ea = [
	"AnimationStart",
	"AnimationComplete",
	"Update",
	"BeforeLayoutMeasure",
	"LayoutMeasure",
	"LayoutAnimationStart",
	"LayoutAnimationComplete"
], Da = {};
function Oa(e) {
	Da = e;
}
function ka() {
	return Da;
}
var Aa = class {
	scrapeMotionValuesFromProps(e, t, n) {
		return {};
	}
	constructor({ parent: e, props: t, presenceContext: n, reducedMotionConfig: r, skipAnimations: i, blockInitialAnimation: a, visualState: o }, s = {}) {
		this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = /* @__PURE__ */ new Map(), this.KeyframeResolver = Wn, this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
			this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
		}, this.renderScheduledAt = 0, this.scheduleRender = () => {
			let e = N.now();
			this.renderScheduledAt < e && (this.renderScheduledAt = e, A.render(this.render, !1, !0));
		};
		let { latestValues: c, renderState: l } = o;
		this.latestValues = c, this.baseTarget = { ...c }, this.initialValues = t.initial ? { ...c } : {}, this.renderState = l, this.parent = e, this.props = t, this.presenceContext = n, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = r, this.skipAnimationsConfig = i, this.options = s, this.blockInitialAnimation = !!a, this.isControllingVariants = ya(t), this.isVariantNode = ba(t), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(e && e.current);
		let { willChange: u, ...d } = this.scrapeMotionValuesFromProps(t, {}, this);
		for (let e in d) {
			let t = d[e];
			c[e] !== void 0 && G(t) && t.set(c[e]);
		}
	}
	mount(e) {
		if (this.hasBeenMounted) for (let e in this.initialValues) this.values.get(e)?.jump(this.initialValues[e]), this.latestValues[e] = this.initialValues[e];
		this.current = e, ma.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((e, t) => this.bindToMotionValue(t, e)), this.reducedMotionConfig === "never" ? this.shouldReduceMotion = !1 : this.reducedMotionConfig === "always" ? this.shouldReduceMotion = !0 : (Ca.current || Ta(), this.shouldReduceMotion = Sa.current), this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1, this.parent?.addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0;
	}
	unmount() {
		this.projection && this.projection.unmount(), j(this.notifyUpdate), j(this.render), this.valueSubscriptions.forEach((e) => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent?.removeChild(this);
		for (let e in this.events) this.events[e].clear();
		for (let e in this.features) {
			let t = this.features[e];
			t && (t.unmount(), t.isMounted = !1);
		}
		this.current = null;
	}
	addChild(e) {
		this.children.add(e), this.enteringChildren ??= /* @__PURE__ */ new Set(), this.enteringChildren.add(e);
	}
	removeChild(e) {
		this.children.delete(e), this.enteringChildren && this.enteringChildren.delete(e);
	}
	bindToMotionValue(e, t) {
		if (this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)(), t.accelerate && pr.has(e) && this.current instanceof HTMLElement) {
			let { factory: n, keyframes: r, times: i, ease: a, duration: o } = t.accelerate, s = new rr({
				element: this.current,
				name: e,
				keyframes: r,
				times: i,
				ease: a,
				duration: /* @__PURE__ */ O(o)
			}), c = n(s);
			this.valueSubscriptions.set(e, () => {
				c(), s.cancel();
			});
			return;
		}
		let n = Nn.has(e);
		n && this.onBindTransform && this.onBindTransform();
		let r = t.on("change", (t) => {
			this.latestValues[e] = t, this.props.onUpdate && A.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender();
		}), i;
		typeof window < "u" && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, () => {
			r(), i && i();
		});
	}
	sortNodePosition(e) {
		return !this.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current);
	}
	updateFeatures() {
		let e = "animation";
		for (e in Da) {
			let t = Da[e];
			if (!t) continue;
			let { isEnabled: n, Feature: r } = t;
			if (!this.features[e] && r && n(this.props) && (this.features[e] = new r(this)), this.features[e]) {
				let t = this.features[e];
				t.isMounted ? t.update() : (t.mount(), t.isMounted = !0);
			}
		}
	}
	triggerBuild() {
		this.build(this.renderState, this.latestValues, this.props);
	}
	measureViewportBox() {
		return this.current ? this.measureInstanceViewportBox(this.current, this.props) : q();
	}
	getStaticValue(e) {
		return this.latestValues[e];
	}
	setStaticValue(e, t) {
		this.latestValues[e] = t;
	}
	update(e, t) {
		(e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
		for (let t = 0; t < Ea.length; t++) {
			let n = Ea[t];
			this.propEventSubscriptions[n] && (this.propEventSubscriptions[n](), delete this.propEventSubscriptions[n]);
			let r = e["on" + n];
			r && (this.propEventSubscriptions[n] = this.on(n, r));
		}
		this.prevMotionValues = xa(this, this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue();
	}
	getProps() {
		return this.props;
	}
	getVariant(e) {
		return this.props.variants ? this.props.variants[e] : void 0;
	}
	getDefaultTransition() {
		return this.props.transition;
	}
	getTransformPagePoint() {
		return this.props.transformPagePoint;
	}
	getClosestVariantNode() {
		return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
	}
	addVariantChild(e) {
		let t = this.getClosestVariantNode();
		if (t) return t.variantChildren && t.variantChildren.add(e), () => t.variantChildren.delete(e);
	}
	addValue(e, t) {
		let n = this.values.get(e);
		t !== n && (n && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t), this.latestValues[e] = t.get());
	}
	removeValue(e) {
		this.values.delete(e);
		let t = this.valueSubscriptions.get(e);
		t && (t(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState);
	}
	hasValue(e) {
		return this.values.has(e);
	}
	getValue(e, t) {
		if (this.props.values && this.props.values[e]) return this.props.values[e];
		let n = this.values.get(e);
		return n === void 0 && t !== void 0 && (n = Er(t === null ? void 0 : t, { owner: this }), this.addValue(e, n)), n;
	}
	readValue(e, t) {
		let n = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : this.getBaseTargetFromProps(this.props, e) ?? this.readValueFromInstance(this.current, e, this.options);
		return n != null && (typeof n == "string" && (te(n) || re(n)) ? n = parseFloat(n) : !ua(n) && R.test(t) && (n = vi(e, t)), this.setBaseTarget(e, G(n) ? n.get() : n)), G(n) ? n.get() : n;
	}
	setBaseTarget(e, t) {
		this.baseTarget[e] = t;
	}
	getBaseTarget(e) {
		let { initial: t } = this.props, n;
		if (typeof t == "string" || typeof t == "object") {
			let r = Vr(this.props, t, this.presenceContext?.custom);
			r && (n = r[e]);
		}
		if (t && n !== void 0) return n;
		let r = this.getBaseTargetFromProps(this.props, e);
		return r !== void 0 && !G(r) ? r : this.initialValues[e] !== void 0 && n === void 0 ? void 0 : this.baseTarget[e];
	}
	on(e, t) {
		return this.events[e] || (this.events[e] = new se()), this.events[e].add(t);
	}
	notify(e, ...t) {
		this.events[e] && this.events[e].notify(...t);
	}
	scheduleRenderMicrotask() {
		Ei.render(this.render);
	}
}, ja = class extends Aa {
	constructor() {
		super(...arguments), this.KeyframeResolver = xi;
	}
	sortInstanceNodePosition(e, t) {
		return e.compareDocumentPosition(t) & 2 ? 1 : -1;
	}
	getBaseTargetFromProps(e, t) {
		let n = e.style;
		return n ? n[t] : void 0;
	}
	removeValueFromRenderState(e, { vars: t, style: n }) {
		delete t[e], delete n[e];
	}
	handleChildMotionValue() {
		this.childSubscription && (this.childSubscription(), delete this.childSubscription);
		let { children: e } = this.props;
		G(e) && (this.childSubscription = e.on("change", (e) => {
			this.current && (this.current.textContent = `${e}`);
		}));
	}
}, J = class {
	constructor(e) {
		this.isMounted = !1, this.node = e;
	}
	update() {}
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/conversion.mjs
function Ma({ top: e, left: t, right: n, bottom: r }) {
	return {
		x: {
			min: t,
			max: n
		},
		y: {
			min: e,
			max: r
		}
	};
}
function Na({ x: e, y: t }) {
	return {
		top: t.min,
		right: e.max,
		bottom: t.max,
		left: e.min
	};
}
function Pa(e, t) {
	if (!t) return e;
	let n = t({
		x: e.left,
		y: e.top
	}), r = t({
		x: e.right,
		y: e.bottom
	});
	return {
		top: n.y,
		left: n.x,
		bottom: r.y,
		right: r.x
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/has-transform.mjs
function Fa(e) {
	return e === void 0 || e === 1;
}
function Ia({ scale: e, scaleX: t, scaleY: n }) {
	return !Fa(e) || !Fa(t) || !Fa(n);
}
function La(e) {
	return Ia(e) || Ra(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY;
}
function Ra(e) {
	return za(e.x) || za(e.y);
}
function za(e) {
	return e && e !== "0%";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-apply.mjs
function Ba(e, t, n) {
	return n + t * (e - n);
}
function Va(e, t, n, r, i) {
	return i !== void 0 && (e = Ba(e, i, r)), Ba(e, n, r) + t;
}
function Ha(e, t = 0, n = 1, r, i) {
	e.min = Va(e.min, t, n, r, i), e.max = Va(e.max, t, n, r, i);
}
function Ua(e, { x: t, y: n }) {
	Ha(e.x, t.translate, t.scale, t.originPoint), Ha(e.y, n.translate, n.scale, n.originPoint);
}
var Wa = .999999999999, Ga = 1.0000000000001;
function Ka(e, t, n, r = !1) {
	let i = n.length;
	if (!i) return;
	t.x = t.y = 1;
	let a, o;
	for (let s = 0; s < i; s++) {
		a = n[s], o = a.projectionDelta;
		let { visualElement: i } = a.options;
		i && i.props.style && i.props.style.display === "contents" || (r && a.options.layoutScroll && a.scroll && a !== a.root && (Y(e.x, -a.scroll.offset.x), Y(e.y, -a.scroll.offset.y)), o && (t.x *= o.x.scale, t.y *= o.y.scale, Ua(e, o)), r && La(a.latestValues) && Ya(e, a.latestValues, a.layout?.layoutBox));
	}
	t.x < Ga && t.x > Wa && (t.x = 1), t.y < Ga && t.y > Wa && (t.y = 1);
}
function Y(e, t) {
	e.min += t, e.max += t;
}
function qa(e, t, n, r, i = .5) {
	Ha(e, t, n, z(e.min, e.max, i), r);
}
function Ja(e, t) {
	return typeof e == "string" ? parseFloat(e) / 100 * (t.max - t.min) : e;
}
function Ya(e, t, n) {
	let r = n ?? e;
	qa(e.x, Ja(t.x, r.x), t.scaleX, t.scale, t.originX), qa(e.y, Ja(t.y, r.y), t.scaleY, t.scale, t.originY);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/measure.mjs
function Xa(e, t) {
	return Ma(Pa(e.getBoundingClientRect(), t));
}
function Za(e, t, n) {
	let r = Xa(e, n), { scroll: i } = t;
	return i && (Y(r.x, i.offset.x), Y(r.y, i.offset.y)), r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/build-transform.mjs
var Qa = {
	x: "translateX",
	y: "translateY",
	z: "translateZ",
	transformPerspective: "perspective"
}, $a = Mn.length;
function eo(e, t, n) {
	let r = "", i = !0;
	for (let a = 0; a < $a; a++) {
		let o = Mn[a], s = e[o];
		if (s === void 0) continue;
		let c = !0;
		if (typeof s == "number") c = s === +!!o.startsWith("scale");
		else {
			let e = parseFloat(s);
			c = o.startsWith("scale") ? e === 1 : e === 0;
		}
		if (!c || n) {
			let e = wi(s, mi[o]);
			if (!c) {
				i = !1;
				let t = Qa[o] || o;
				r += `${t}(${e}) `;
			}
			n && (t[o] = e);
		}
	}
	let a = e.pathRotation;
	return a && (i = !1, r += `rotate(${wi(a, mi.pathRotation)}) `), r = r.trim(), n ? r = n(t, i ? "" : r) : i && (r = "none"), r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/build-styles.mjs
function to(e, t, n) {
	let { style: r, vars: i, transformOrigin: a } = e, o = !1, s = !1;
	for (let e in t) {
		let n = t[e];
		if (Nn.has(e)) {
			o = !0;
			continue;
		} else if (ze(e)) {
			i[e] = n;
			continue;
		} else {
			let t = wi(n, mi[e]);
			e.startsWith("origin") ? (s = !0, a[e] = t) : r[e] = t;
		}
	}
	if (t.transform || (o || n ? r.transform = eo(t, e.transform, n) : r.transform &&= "none"), s) {
		let { originX: e = "50%", originY: t = "50%", originZ: n = 0 } = a;
		r.transformOrigin = `${e} ${t} ${n}`;
	}
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/render.mjs
function no(e, { style: t, vars: n }, r, i) {
	let a = e.style, o;
	for (o in t) a[o] = t[o];
	for (o in i?.applyProjectionStyles(a, r), n) a.setProperty(o, n[o]);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/styles/scale-border-radius.mjs
function ro(e, t) {
	return t.max === t.min ? 0 : e / (t.max - t.min) * 100;
}
var io = { correct: (e, t) => {
	if (!t.target) return e;
	if (typeof e == "string") if (I.test(e)) e = parseFloat(e);
	else return e;
	return `${ro(e, t.target.x)}% ${ro(e, t.target.y)}%`;
} }, ao = { correct: (e, { treeScale: t, projectionDelta: n }) => {
	let r = e, i = R.parse(e);
	if (i.length > 5) return r;
	let a = R.createTransformer(e), o = typeof i[0] == "number" ? 0 : 1, s = n.x.scale * t.x, c = n.y.scale * t.y;
	i[0 + o] /= s, i[1 + o] /= c;
	let l = z(s, c, .5);
	return typeof i[2 + o] == "number" && (i[2 + o] /= l), typeof i[3 + o] == "number" && (i[3 + o] /= l), a(i);
} }, oo = {
	borderRadius: {
		...io,
		applyTo: [...Si]
	},
	borderTopLeftRadius: io,
	borderTopRightRadius: io,
	borderBottomLeftRadius: io,
	borderBottomRightRadius: io,
	boxShadow: ao
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/is-forced-motion-value.mjs
function so(e, { layout: t, layoutId: n }) {
	return Nn.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!oo[e] || e === "opacity");
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/utils/scrape-motion-values.mjs
function co(e, t, n) {
	let r = e.style, i = t?.style, a = {};
	if (!r) return a;
	for (let t in r) (G(r[t]) || i && G(i[t]) || so(t, e) || n?.getValue(t)?.liveStyle !== void 0) && (a[t] = r[t]);
	return a;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/html/HTMLVisualElement.mjs
function lo(e) {
	return window.getComputedStyle(e);
}
var uo = class extends ja {
	constructor() {
		super(...arguments), this.type = "html", this.renderInstance = no;
	}
	mount(e) {
		e.style, super.mount(e);
	}
	readValueFromInstance(e, t) {
		if (Nn.has(t)) return this.projection?.isProjecting ? On(t) : An(e, t);
		{
			let n = lo(e), r = (ze(t) ? n.getPropertyValue(t) : n[t]) || 0;
			return typeof r == "string" ? r.trim() : r;
		}
	}
	measureInstanceViewportBox(e, { transformPagePoint: t }) {
		return Xa(e, t);
	}
	build(e, t, n) {
		to(e, t, n.transformTemplate);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return co(e, t, n);
	}
}, fo = {
	offset: "stroke-dashoffset",
	array: "stroke-dasharray"
}, po = {
	offset: "strokeDashoffset",
	array: "strokeDasharray"
};
function mo(e, t, n = 1, r = 0, i = !0) {
	e.pathLength = 1;
	let a = i ? fo : po;
	e[a.offset] = `${-r}`, e[a.array] = `${t} ${n}`;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/build-attrs.mjs
var ho = [
	"offsetDistance",
	"offsetPath",
	"offsetRotate",
	"offsetAnchor"
];
function go(e, { attrX: t, attrY: n, attrScale: r, pathLength: i, pathSpacing: a = 1, pathOffset: o = 0, ...s }, c, l, u) {
	if (to(e, s, l), c) {
		e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
		return;
	}
	e.attrs = e.style, e.style = {};
	let { attrs: d, style: f } = e;
	d.transform && (f.transform = d.transform, delete d.transform), (f.transform || d.transformOrigin) && (f.transformOrigin = d.transformOrigin ?? "50% 50%", delete d.transformOrigin), f.transform && (f.transformBox = u?.transformBox ?? "fill-box", delete d.transformBox);
	for (let e of ho) d[e] !== void 0 && (f[e] = d[e], delete d[e]);
	t !== void 0 && (d.x = t), n !== void 0 && (d.y = n), r !== void 0 && (d.scale = r), i !== void 0 && mo(d, i, a, o, !1);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/camel-case-attrs.mjs
var _o = new Set([
	"baseFrequency",
	"diffuseConstant",
	"kernelMatrix",
	"kernelUnitLength",
	"keySplines",
	"keyTimes",
	"limitingConeAngle",
	"markerHeight",
	"markerWidth",
	"numOctaves",
	"targetX",
	"targetY",
	"surfaceScale",
	"specularConstant",
	"specularExponent",
	"stdDeviation",
	"tableValues",
	"viewBox",
	"gradientTransform",
	"pathLength",
	"startOffset",
	"textLength",
	"lengthAdjust"
]), vo = (e) => typeof e == "string" && e.toLowerCase() === "svg";
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/render.mjs
function yo(e, t, n, r) {
	no(e, t, void 0, r);
	for (let n in t.attrs) e.setAttribute(_o.has(n) ? n : Yr(n), t.attrs[n]);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/utils/scrape-motion-values.mjs
function bo(e, t, n) {
	let r = co(e, t, n);
	for (let n in e) if (G(e[n]) || G(t[n])) {
		let t = Mn.indexOf(n) === -1 ? n : "attr" + n.charAt(0).toUpperCase() + n.substring(1);
		r[t] = e[n];
	}
	return r;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/svg/SVGVisualElement.mjs
var xo = class extends ja {
	constructor() {
		super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = q;
	}
	getBaseTargetFromProps(e, t) {
		return e[t];
	}
	readValueFromInstance(e, t) {
		if (Nn.has(t)) {
			let e = gi(t);
			return e && e.default || 0;
		}
		return t = _o.has(t) ? t : Yr(t), e.getAttribute(t);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return bo(e, t, n);
	}
	build(e, t, n) {
		go(e, t, this.isSVGTag, n.transformTemplate, n.style);
	}
	renderInstance(e, t, n, r) {
		yo(e, t, n, r);
	}
	mount(e) {
		this.isSVGTag = vo(e.tagName), super.mount(e);
	}
}, So = va.length;
function Co(e) {
	if (!e) return;
	if (!e.isControllingVariants) {
		let t = e.parent && Co(e.parent) || {};
		return e.props.initial !== void 0 && (t.initial = e.props.initial), t;
	}
	let t = {};
	for (let n = 0; n < So; n++) {
		let r = va[n], i = e.props[r];
		(ga(i) || i === !1) && (t[r] = i);
	}
	return t;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/shallow-compare.mjs
function wo(e, t) {
	if (!Array.isArray(t)) return !1;
	let n = t.length;
	if (n !== e.length) return !1;
	for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
	return !0;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/render/utils/animation-state.mjs
var To = [..._a].reverse(), Eo = _a.length;
function Do(e) {
	return (t) => Promise.all(t.map(({ animation: t, options: n }) => ni(e, t, n)));
}
function Oo(e) {
	let t = Do(e), n = jo(), r = !0, i = !1, a = (t) => (n, r) => {
		let i = W(e, r, t === "exit" ? e.presenceContext?.custom : void 0);
		if (i) {
			let { transition: e, transitionEnd: t, ...r } = i;
			n = {
				...n,
				...r,
				...t
			};
		}
		return n;
	};
	function o(n) {
		t = n(e);
	}
	function s(o) {
		let { props: s } = e, c = Co(e.parent) || {}, l = [], u = /* @__PURE__ */ new Set(), d = {}, f = Infinity;
		for (let t = 0; t < Eo; t++) {
			let p = To[t], m = n[p], h = s[p] === void 0 ? c[p] : s[p], g = ga(h), _ = p === o ? m.isActive : null;
			_ === !1 && (f = t);
			let v = h === c[p] && h !== s[p] && g;
			if (v && (r || i) && e.manuallyAnimateOnMount && (v = !1), m.protectedKeys = { ...d }, !m.isActive && _ === null || !h && !m.prevProp || ha(h) || typeof h == "boolean") continue;
			if (p === "exit" && m.isActive && _ !== !0) {
				m.prevResolvedValues && (d = {
					...d,
					...m.prevResolvedValues
				});
				continue;
			}
			let y = ko(m.prevProp, h), b = y || p === o && m.isActive && !v && g || t > f && g, x = !1, S = Array.isArray(h) ? h : [h], C = S.reduce(a(p), {});
			_ === !1 && (C = {});
			let { prevResolvedValues: w = {} } = m, T = {
				...w,
				...C
			}, ee = (t) => {
				b = !0, u.has(t) && (x = !0, u.delete(t)), m.needsAnimating[t] = !0;
				let n = e.getValue(t);
				n && (n.liveStyle = !1);
			};
			for (let e in T) {
				let t = C[e], n = w[e];
				if (d.hasOwnProperty(e)) continue;
				let r = !1;
				r = Ur(t) && Ur(n) ? !wo(t, n) || y : t !== n, r ? t == null ? u.add(e) : ee(e) : t !== void 0 && u.has(e) ? ee(e) : m.protectedKeys[e] = !0;
			}
			m.prevProp = h, m.prevResolvedValues = C, m.isActive && (d = {
				...d,
				...C
			}), (r || i) && e.blockInitialAnimation && (b = !1);
			let E = v && y;
			b && (!E || x) && l.push(...S.map((t) => {
				let n = { type: p };
				if (typeof t == "string" && (r || i) && !E && e.manuallyAnimateOnMount && e.parent) {
					let { parent: r } = e, i = W(r, t);
					if (r.enteringChildren && i) {
						let { delayChildren: t } = i.transition || {};
						n.delay = xr(r.enteringChildren, e, t);
					}
				}
				return {
					animation: t,
					options: n
				};
			}));
		}
		if (u.size) {
			let t = {};
			if (typeof s.initial != "boolean") {
				let n = W(e, Array.isArray(s.initial) ? s.initial[0] : s.initial);
				n && n.transition && (t.transition = n.transition);
			}
			u.forEach((n) => {
				let r = e.getBaseTarget(n), i = e.getValue(n);
				i && (i.liveStyle = !0), t[n] = r ?? null;
			}), l.push({ animation: t });
		}
		let p = !!l.length;
		return r && (s.initial === !1 || s.initial === s.animate) && !e.manuallyAnimateOnMount && (p = !1), r = !1, i = !1, p ? t(l) : Promise.resolve();
	}
	function c(t, r) {
		if (n[t].isActive === r) return Promise.resolve();
		e.variantChildren?.forEach((e) => e.animationState?.setActive(t, r)), n[t].isActive = r;
		let i = s(t);
		for (let e in n) n[e].protectedKeys = {};
		return i;
	}
	return {
		animateChanges: s,
		setActive: c,
		setAnimateFunction: o,
		getState: () => n,
		reset: () => {
			n = jo(), i = !0;
		}
	};
}
function ko(e, t) {
	return typeof t == "string" ? t !== e : Array.isArray(t) ? !wo(t, e) : !1;
}
function Ao(e = !1) {
	return {
		isActive: e,
		protectedKeys: {},
		needsAnimating: {},
		prevResolvedValues: {}
	};
}
function jo() {
	return {
		animate: Ao(!0),
		whileInView: Ao(),
		whileHover: Ao(),
		whileTap: Ao(),
		whileDrag: Ao(),
		whileFocus: Ao(),
		exit: Ao()
	};
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/copy.mjs
function Mo(e, t) {
	e.min = t.min, e.max = t.max;
}
function X(e, t) {
	Mo(e.x, t.x), Mo(e.y, t.y);
}
function No(e, t) {
	e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-calc.mjs
var Po = 1e-4, Fo = 1 - Po, Io = 1 + Po, Lo = .01, Ro = 0 - Lo, zo = 0 + Lo;
function Z(e) {
	return e.max - e.min;
}
function Bo(e, t, n) {
	return Math.abs(e - t) <= n;
}
function Vo(e, t, n, r = .5) {
	e.origin = r, e.originPoint = z(t.min, t.max, e.origin), e.scale = Z(n) / Z(t), e.translate = z(n.min, n.max, e.origin) - e.originPoint, (e.scale >= Fo && e.scale <= Io || isNaN(e.scale)) && (e.scale = 1), (e.translate >= Ro && e.translate <= zo || isNaN(e.translate)) && (e.translate = 0);
}
function Ho(e, t, n, r) {
	Vo(e.x, t.x, n.x, r ? r.originX : void 0), Vo(e.y, t.y, n.y, r ? r.originY : void 0);
}
function Uo(e, t, n, r = 0) {
	e.min = (r ? z(n.min, n.max, r) : n.min) + t.min, e.max = e.min + Z(t);
}
function Wo(e, t, n, r) {
	Uo(e.x, t.x, n.x, r?.x), Uo(e.y, t.y, n.y, r?.y);
}
function Go(e, t, n, r = 0) {
	let i = r ? z(n.min, n.max, r) : n.min;
	e.min = t.min - i, e.max = e.min + Z(t);
}
function Ko(e, t, n, r) {
	Go(e.x, t.x, n.x, r?.x), Go(e.y, t.y, n.y, r?.y);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/delta-remove.mjs
function qo(e, t, n, r, i) {
	return e -= t, e = Ba(e, 1 / n, r), i !== void 0 && (e = Ba(e, 1 / i, r)), e;
}
function Jo(e, t = 0, n = 1, r = .5, i, a = e, o = e) {
	if (F.test(t) && (t = parseFloat(t), t = z(o.min, o.max, t / 100) - o.min), typeof t != "number") return;
	let s = z(a.min, a.max, r);
	e === a && (s -= t), e.min = qo(e.min, t, n, s, i), e.max = qo(e.max, t, n, s, i);
}
function Yo(e, t, [n, r, i], a, o) {
	Jo(e, t[n], t[r], t[i], t.scale, a, o);
}
var Xo = [
	"x",
	"scaleX",
	"originX"
], Zo = [
	"y",
	"scaleY",
	"originY"
];
function Qo(e, t, n, r) {
	Yo(e.x, t, Xo, n ? n.x : void 0, r ? r.x : void 0), Yo(e.y, t, Zo, n ? n.y : void 0, r ? r.y : void 0);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/geometry/utils.mjs
function $o(e) {
	return e.translate === 0 && e.scale === 1;
}
function es(e) {
	return $o(e.x) && $o(e.y);
}
function ts(e, t) {
	return e.min === t.min && e.max === t.max;
}
function ns(e, t) {
	return ts(e.x, t.x) && ts(e.y, t.y);
}
function rs(e, t) {
	return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max);
}
function is(e, t) {
	return rs(e.x, t.x) && rs(e.y, t.y);
}
function as(e) {
	return Z(e.x) / Z(e.y);
}
function os(e, t) {
	return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/each-axis.mjs
function Q(e) {
	return [e("x"), e("y")];
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/styles/transform.mjs
function ss(e, t, n) {
	let r = "", i = e.x.translate / t.x, a = e.y.translate / t.y, o = n?.z || 0;
	if ((i || a || o) && (r = `translate3d(${i}px, ${a}px, ${o}px) `), (t.x !== 1 || t.y !== 1) && (r += `scale(${1 / t.x}, ${1 / t.y}) `), n) {
		let { transformPerspective: e, rotate: t, pathRotation: i, rotateX: a, rotateY: o, skewX: s, skewY: c } = n;
		e && (r = `perspective(${e}px) ${r}`), t && (r += `rotate(${t}deg) `), i && (r += `rotate(${i}deg) `), a && (r += `rotateX(${a}deg) `), o && (r += `rotateY(${o}deg) `), s && (r += `skewX(${s}deg) `), c && (r += `skewY(${c}deg) `);
	}
	let s = e.x.scale * t.x, c = e.y.scale * t.y;
	return (s !== 1 || c !== 1) && (r += `scale(${s}, ${c})`), r || "none";
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/animation/mix-values.mjs
var cs = Si.length, ls = (e) => typeof e == "string" ? parseFloat(e) : e, us = (e) => typeof e == "number" || I.test(e);
function ds(e, t, n, r, i, a) {
	i ? (e.opacity = z(0, n.opacity ?? 1, ps(r)), e.opacityExit = z(t.opacity ?? 1, 0, ms(r))) : a && (e.opacity = z(t.opacity ?? 1, n.opacity ?? 1, r));
	for (let i = 0; i < cs; i++) {
		let a = Si[i], o = fs(t, a), s = fs(n, a);
		o === void 0 && s === void 0 || (o ||= 0, s ||= 0, o === 0 || s === 0 || us(o) === us(s) ? (e[a] = Math.max(z(ls(o), ls(s), r), 0), (F.test(s) || F.test(o)) && (e[a] += "%")) : e[a] = s);
	}
	(t.rotate || n.rotate) && (e.rotate = z(t.rotate || 0, n.rotate || 0, r));
}
function fs(e, t) {
	return e[t] === void 0 ? e.borderRadius : e[t];
}
var ps = /* @__PURE__ */ hs(0, .5, xe), ms = /* @__PURE__ */ hs(.5, .95, D);
function hs(e, t, n) {
	return (r) => r < e ? 0 : r > t ? 1 : n(/* @__PURE__ */ oe(e, t, r));
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/animation/animate/single-value.mjs
function gs(e, t, n) {
	let r = G(e) ? e : Er(e);
	return r.start(Ir("", r, t, n)), r.animation;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/events/add-dom-event.mjs
function _s(e, t, n, r = { passive: !0 }) {
	return e.addEventListener(t, n, r), () => e.removeEventListener(t, n, r);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/utils/compare-by-depth.mjs
var vs = (e, t) => e.depth - t.depth, ys = class {
	constructor() {
		this.children = [], this.isDirty = !1;
	}
	add(e) {
		C(this.children, e), this.isDirty = !0;
	}
	remove(e) {
		w(this.children, e), this.isDirty = !0;
	}
	forEach(e) {
		this.isDirty && this.children.sort(vs), this.isDirty = !1, this.children.forEach(e);
	}
};
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/utils/delay.mjs
function bs(e, t) {
	let n = N.now(), r = ({ timestamp: i }) => {
		let a = i - n;
		a >= t && (j(r), e(a - t));
	};
	return A.setup(r, !0), () => j(r);
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/value/utils/resolve-motion-value.mjs
function xs(e) {
	return G(e) ? e.get() : e;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/shared/stack.mjs
var Ss = class {
	constructor() {
		this.members = [];
	}
	add(e) {
		C(this.members, e);
		for (let t = this.members.length - 1; t >= 0; t--) {
			let n = this.members[t];
			if (n === e || n === this.lead || n === this.prevLead) continue;
			let r = n.instance;
			(!r || r.isConnected === !1) && !n.snapshot && (w(this.members, n), n.unmount());
		}
		e.scheduleRender();
	}
	remove(e) {
		if (w(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
			let e = this.members[this.members.length - 1];
			e && this.promote(e);
		}
	}
	relegate(e) {
		for (let t = this.members.indexOf(e) - 1; t >= 0; t--) {
			let e = this.members[t];
			if (e.isPresent !== !1 && e.instance?.isConnected !== !1) return this.promote(e), !0;
		}
		return !1;
	}
	promote(e, t) {
		let n = this.lead;
		if (e !== n && (this.prevLead = n, this.lead = e, e.show(), n)) {
			n.updateSnapshot(), e.scheduleRender();
			let { layoutDependency: r } = n.options, { layoutDependency: i } = e.options;
			(r === void 0 || r !== i) && (e.resumeFrom = n, t && (n.preserveOpacity = !0), n.snapshot && (e.snapshot = n.snapshot, e.snapshot.latestValues = n.animationValues || n.latestValues), e.root?.isUpdating && (e.isLayoutDirty = !0)), e.options.crossfade === !1 && n.hide();
		}
	}
	exitAnimationComplete() {
		this.members.forEach((e) => {
			e.options.onExitComplete?.(), e.resumingFrom?.options.onExitComplete?.();
		});
	}
	scheduleRender() {
		this.members.forEach((e) => e.instance && e.scheduleRender(!1));
	}
	removeLeadSnapshot() {
		this.lead?.snapshot && (this.lead.snapshot = void 0);
	}
}, Cs = {
	hasAnimatedSinceResize: !0,
	hasEverUpdated: !1
}, $ = {
	nodes: 0,
	calculatedTargetDeltas: 0,
	calculatedProjections: 0
}, ws = [
	"",
	"X",
	"Y",
	"Z"
], Ts = 1e3, Es = 0;
function Ds(e, t, n, r) {
	let { latestValues: i } = t;
	i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0));
}
function Os(e) {
	if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
	let { visualElement: t } = e.options;
	if (!t) return;
	let n = Zr(t);
	if (window.MotionHasOptimisedAnimation(n, "transform")) {
		let { layout: t, layoutId: r } = e.options;
		window.MotionCancelOptimisedAnimation(n, "transform", A, !(t || r));
	}
	let { parent: r } = e;
	r && !r.hasCheckedOptimisedAppear && Os(r);
}
function ks({ attachResizeListener: e, defaultParent: t, measureScroll: n, checkIsScrollRoot: r, resetTransform: i }) {
	return class {
		constructor(e = {}, n = t?.()) {
			this.id = Es++, this.animationId = 0, this.animationCommitId = 0, this.children = /* @__PURE__ */ new Set(), this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
				x: 1,
				y: 1
			}, this.eventHandlers = /* @__PURE__ */ new Map(), this.hasTreeAnimated = !1, this.layoutVersion = 0, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
				this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots());
			}, this.updateProjection = () => {
				this.projectionUpdateScheduled = !1, sa.value && ($.nodes = $.calculatedTargetDeltas = $.calculatedProjections = 0), this.nodes.forEach(Ms), this.nodes.forEach(Vs), this.nodes.forEach(Hs), this.nodes.forEach(Ns), sa.addProjectionMetrics && sa.addProjectionMetrics($);
			}, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = /* @__PURE__ */ new Map(), this.latestValues = e, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0;
			for (let e = 0; e < this.path.length; e++) this.path[e].shouldResetTransform = !0;
			this.root === this && (this.nodes = new ys());
		}
		addEventListener(e, t) {
			return this.eventHandlers.has(e) || this.eventHandlers.set(e, new se()), this.eventHandlers.get(e).add(t);
		}
		notifyListeners(e, ...t) {
			let n = this.eventHandlers.get(e);
			n && n.notify(...t);
		}
		hasListeners(e) {
			return this.eventHandlers.has(e);
		}
		mount(t) {
			if (this.instance) return;
			this.isSVG = Ki(t) && !ca(t), this.instance = t;
			let { layoutId: n, layout: r, visualElement: i } = this.options;
			if (i && !i.current && i.mount(t), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (r || n) && (this.isLayoutDirty = !0), e) {
				let n, r = 0, i = () => this.root.updateBlockedByResize = !1;
				A.read(() => {
					r = window.innerWidth;
				}), e(t, () => {
					let e = window.innerWidth;
					e !== r && (r = e, this.root.updateBlockedByResize = !0, n && n(), n = bs(i, 250), Cs.hasAnimatedSinceResize && (Cs.hasAnimatedSinceResize = !1, this.nodes.forEach(Bs)));
				});
			}
			n && this.root.registerSharedNode(n, this), this.options.animate !== !1 && i && (n || r) && this.addEventListener("didUpdate", ({ delta: e, hasLayoutChanged: t, hasRelativeLayoutChanged: n, layout: r }) => {
				if (this.isTreeAnimationBlocked()) {
					this.target = void 0, this.relativeTarget = void 0;
					return;
				}
				let a = this.options.transition || i.getDefaultTransition() || Ys, { onLayoutAnimationStart: o, onLayoutAnimationComplete: s } = i.getProps(), c = !this.targetLayout || !is(this.targetLayout, r), l = !t && n;
				if (this.options.layoutRoot || this.resumeFrom || l || t && (c || !this.currentAnimation)) {
					this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
					let t = {
						...Or(a, "layout"),
						onPlay: o,
						onComplete: s
					};
					(i.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t), this.setAnimationOrigin(e, l, t.path);
				} else t || Bs(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
				this.targetLayout = r;
			});
		}
		unmount() {
			this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
			let e = this.getStack();
			e && e.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), j(this.updateProjection);
		}
		blockUpdate() {
			this.updateManuallyBlocked = !0;
		}
		unblockUpdate() {
			this.updateManuallyBlocked = !1;
		}
		isUpdateBlocked() {
			return this.updateManuallyBlocked || this.updateBlockedByResize;
		}
		isTreeAnimationBlocked() {
			return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1;
		}
		startUpdate() {
			this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(Us), this.animationId++);
		}
		getTransformTemplate() {
			let { visualElement: e } = this.options;
			return e && e.getProps().transformTemplate;
		}
		willUpdate(e = !0) {
			if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
				this.options.onExitComplete && this.options.onExitComplete();
				return;
			}
			if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && Os(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
			this.isLayoutDirty = !0;
			for (let e = 0; e < this.path.length; e++) {
				let t = this.path[e];
				t.shouldResetTransform = !0, (typeof t.latestValues.x == "string" || typeof t.latestValues.y == "string") && (t.isLayoutDirty = !0), t.updateScroll("snapshot"), t.options.layoutRoot && t.willUpdate(!1);
			}
			let { layoutId: t, layout: n } = this.options;
			if (t === void 0 && !n) return;
			let r = this.getTransformTemplate();
			this.prevTransformTemplateValue = r ? r(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate");
		}
		update() {
			if (this.updateScheduled = !1, this.isUpdateBlocked()) {
				let e = this.updateBlockedByResize;
				this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), e && this.nodes.forEach(Is), this.nodes.forEach(Fs);
				return;
			}
			if (this.animationId <= this.animationCommitId) {
				this.nodes.forEach(Ls);
				return;
			}
			this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(Rs), this.nodes.forEach(zs), this.nodes.forEach(As), this.nodes.forEach(js)) : this.nodes.forEach(Ls), this.clearAllSnapshots();
			let e = N.now();
			M.delta = T(0, 1e3 / 60, e - M.timestamp), M.timestamp = e, M.isProcessing = !0, Fe.update.process(M), Fe.preRender.process(M), Fe.render.process(M), M.isProcessing = !1;
		}
		didUpdate() {
			this.updateScheduled || (this.updateScheduled = !0, Ei.read(this.scheduleUpdate));
		}
		clearAllSnapshots() {
			this.nodes.forEach(Ps), this.sharedNodes.forEach(Ws);
		}
		scheduleUpdateProjection() {
			this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, A.preRender(this.updateProjection, !1, !0));
		}
		scheduleCheckAfterUnmount() {
			A.postRender(() => {
				this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
			});
		}
		updateSnapshot() {
			this.snapshot || !this.instance || (this.snapshot = this.measure(), this.snapshot && !Z(this.snapshot.measuredBox.x) && !Z(this.snapshot.measuredBox.y) && (this.snapshot = void 0));
		}
		updateLayout() {
			if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
			if (this.resumeFrom && !this.resumeFrom.instance) for (let e = 0; e < this.path.length; e++) this.path[e].updateScroll();
			let e = this.layout;
			this.layout = this.measure(!1), this.layoutVersion++, this.layoutCorrected ||= q(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
			let { visualElement: t } = this.options;
			t && t.notify("LayoutMeasure", this.layout.layoutBox, e ? e.layoutBox : void 0);
		}
		updateScroll(e = "measure") {
			let t = !!(this.options.layoutScroll && this.instance);
			if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === e && (t = !1), t && this.instance) {
				let t = r(this.instance);
				this.scroll = {
					animationId: this.root.animationId,
					phase: e,
					isRoot: t,
					offset: n(this.instance),
					wasRoot: this.scroll ? this.scroll.isRoot : t
				};
			}
		}
		resetTransform() {
			if (!i) return;
			let e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout, t = this.projectionDelta && !es(this.projectionDelta), n = this.getTransformTemplate(), r = n ? n(this.latestValues, "") : void 0, a = r !== this.prevTransformTemplateValue;
			e && this.instance && (t || La(this.latestValues) || a) && (i(this.instance, r), this.shouldResetTransform = !1, this.scheduleRender());
		}
		measure(e = !0) {
			let t = this.measurePageBox(), n = this.removeElementScroll(t);
			return e && (n = this.removeTransform(n)), $s(n), {
				animationId: this.root.animationId,
				measuredBox: t,
				layoutBox: n,
				latestValues: {},
				source: this.id
			};
		}
		measurePageBox() {
			let { visualElement: e } = this.options;
			if (!e) return q();
			let t = e.measureViewportBox();
			if (!(this.scroll?.wasRoot || this.path.some(tc))) {
				let { scroll: e } = this.root;
				e && (Y(t.x, e.offset.x), Y(t.y, e.offset.y));
			}
			return t;
		}
		removeElementScroll(e) {
			let t = q();
			if (X(t, e), this.scroll?.wasRoot) return t;
			for (let n = 0; n < this.path.length; n++) {
				let r = this.path[n], { scroll: i, options: a } = r;
				r !== this.root && i && a.layoutScroll && (i.wasRoot && X(t, e), Y(t.x, i.offset.x), Y(t.y, i.offset.y));
			}
			return t;
		}
		applyTransform(e, t = !1, n) {
			let r = n || q();
			X(r, e);
			for (let e = 0; e < this.path.length; e++) {
				let n = this.path[e];
				!t && n.options.layoutScroll && n.scroll && n !== n.root && (Y(r.x, -n.scroll.offset.x), Y(r.y, -n.scroll.offset.y)), La(n.latestValues) && Ya(r, n.latestValues, n.layout?.layoutBox);
			}
			return La(this.latestValues) && Ya(r, this.latestValues, this.layout?.layoutBox), r;
		}
		removeTransform(e) {
			let t = q();
			X(t, e);
			for (let e = 0; e < this.path.length; e++) {
				let n = this.path[e];
				if (!La(n.latestValues)) continue;
				let r;
				n.instance && (Ia(n.latestValues) && n.updateSnapshot(), r = q(), X(r, n.measurePageBox())), Qo(t, n.latestValues, n.snapshot?.layoutBox, r);
			}
			return La(this.latestValues) && Qo(t, this.latestValues), t;
		}
		setTargetDelta(e) {
			this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0;
		}
		setOptions(e) {
			this.options = {
				...this.options,
				...e,
				crossfade: e.crossfade === void 0 ? !0 : e.crossfade
			};
		}
		clearMeasurements() {
			this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1;
		}
		forceRelativeParentToResolveTarget() {
			this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== M.timestamp && this.relativeParent.resolveTargetDelta(!0);
		}
		resolveTargetDelta(e = !1) {
			let t = this.getLead();
			this.isProjectionDirty ||= t.isProjectionDirty, this.isTransformDirty ||= t.isTransformDirty, this.isSharedProjectionDirty ||= t.isSharedProjectionDirty;
			let n = !!this.resumingFrom || this !== t;
			if (!(e || n && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent?.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
			let { layout: r, layoutId: i } = this.options;
			if (!this.layout || !(r || i)) return;
			this.resolvedRelativeTargetAt = M.timestamp;
			let a = this.getClosestProjectingParent();
			a && this.linkedParentVersion !== a.layoutVersion && !a.options.layoutRoot && this.removeRelativeTarget(), !this.targetDelta && !this.relativeTarget && (this.options.layoutAnchor !== !1 && a && a.layout ? this.createRelativeTarget(a, this.layout.layoutBox, a.layout.layoutBox) : this.removeRelativeTarget()), !(!this.relativeTarget && !this.targetDelta) && (this.target || (this.target = q(), this.targetWithTransforms = q()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), Wo(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target) : X(this.target, this.layout.layoutBox), Ua(this.target, this.targetDelta)) : X(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, this.options.layoutAnchor !== !1 && a && !!a.resumingFrom == !!this.resumingFrom && !a.options.layoutScroll && a.target && this.animationProgress !== 1 ? this.createRelativeTarget(a, this.target, a.target) : this.relativeParent = this.relativeTarget = void 0), sa.value && $.calculatedTargetDeltas++);
		}
		getClosestProjectingParent() {
			if (!(!this.parent || Ia(this.parent.latestValues) || Ra(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent();
		}
		isProjecting() {
			return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
		}
		createRelativeTarget(e, t, n) {
			this.relativeParent = e, this.linkedParentVersion = e.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = q(), this.relativeTargetOrigin = q(), Ko(this.relativeTargetOrigin, t, n, this.options.layoutAnchor || void 0), X(this.relativeTarget, this.relativeTargetOrigin);
		}
		removeRelativeTarget() {
			this.relativeParent = this.relativeTarget = void 0;
		}
		calcProjection() {
			let e = this.getLead(), t = !!this.resumingFrom || this !== e, n = !0;
			if ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (n = !1), t && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === M.timestamp && (n = !1), n) return;
			let { layout: r, layoutId: i } = this.options;
			if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || i)) return;
			X(this.layoutCorrected, this.layout.layoutBox);
			let a = this.treeScale.x, o = this.treeScale.y;
			Ka(this.layoutCorrected, this.treeScale, this.path, t), e.layout && !e.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (e.target = e.layout.layoutBox, e.targetWithTransforms = q());
			let { target: s } = e;
			if (!s) {
				this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
				return;
			}
			!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (No(this.prevProjectionDelta.x, this.projectionDelta.x), No(this.prevProjectionDelta.y, this.projectionDelta.y)), Ho(this.projectionDelta, this.layoutCorrected, s, this.latestValues), (this.treeScale.x !== a || this.treeScale.y !== o || !os(this.projectionDelta.x, this.prevProjectionDelta.x) || !os(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", s)), sa.value && $.calculatedProjections++;
		}
		hide() {
			this.isVisible = !1;
		}
		show() {
			this.isVisible = !0;
		}
		scheduleRender(e = !0) {
			if (this.options.visualElement?.scheduleRender(), e) {
				let e = this.getStack();
				e && e.scheduleRender();
			}
			this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
		}
		createProjectionDeltas() {
			this.prevProjectionDelta = fa(), this.projectionDelta = fa(), this.projectionDeltaWithTransform = fa();
		}
		setAnimationOrigin(e, t = !1, n) {
			let r = this.snapshot, i = r ? r.latestValues : {}, a = { ...this.latestValues }, o = fa();
			(!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
			let s = q(), c = (r ? r.source : void 0) !== (this.layout ? this.layout.source : void 0), l = this.getStack(), u = !l || l.members.length <= 1, d = !!(c && !u && this.options.crossfade === !0 && !this.path.some(Js));
			this.animationProgress = 0;
			let f, p = n?.interpolateProjection(e);
			this.mixTargetDelta = (t) => {
				let n = t / 1e3, r = p?.(n);
				r ? (o.x.translate = r.x, o.x.scale = z(e.x.scale, 1, n), o.x.origin = e.x.origin, o.x.originPoint = e.x.originPoint, o.y.translate = r.y, o.y.scale = z(e.y.scale, 1, n), o.y.origin = e.y.origin, o.y.originPoint = e.y.originPoint) : (Gs(o.x, e.x, n), Gs(o.y, e.y, n)), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (Ko(s, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), qs(this.relativeTarget, this.relativeTargetOrigin, s, n), f && ns(this.relativeTarget, f) && (this.isProjectionDirty = !1), f ||= q(), X(f, this.relativeTarget)), c && (this.animationValues = a, ds(a, i, this.latestValues, n, d, u)), r && r.rotate !== void 0 && (this.animationValues ||= a, this.animationValues.pathRotation = r.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n;
			}, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
		}
		startAnimation(e) {
			this.notifyListeners("animationStart"), this.currentAnimation?.stop(), this.resumingFrom?.currentAnimation?.stop(), this.pendingAnimation &&= (j(this.pendingAnimation), void 0), this.pendingAnimation = A.update(() => {
				Cs.hasAnimatedSinceResize = !0, this.motionValue ||= Er(0), this.motionValue.jump(0, !1), this.currentAnimation = gs(this.motionValue, [0, 1e3], {
					...e,
					velocity: 0,
					isSync: !0,
					onUpdate: (t) => {
						this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t);
					},
					onComplete: () => {
						e.onComplete && e.onComplete(), this.completeAnimation();
					}
				}), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0;
			});
		}
		completeAnimation() {
			this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
			let e = this.getStack();
			e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete");
		}
		finishAnimation() {
			this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(Ts), this.currentAnimation.stop()), this.completeAnimation();
		}
		applyTransformsToTarget() {
			let e = this.getLead(), { targetWithTransforms: t, target: n, layout: r, latestValues: i } = e;
			if (!(!t || !n || !r)) {
				if (this !== e && this.layout && r && ec(this.options.animationType, this.layout.layoutBox, r.layoutBox)) {
					n = this.target || q();
					let t = Z(this.layout.layoutBox.x);
					n.x.min = e.target.x.min, n.x.max = n.x.min + t;
					let r = Z(this.layout.layoutBox.y);
					n.y.min = e.target.y.min, n.y.max = n.y.min + r;
				}
				X(t, n), Ya(t, i), Ho(this.projectionDeltaWithTransform, this.layoutCorrected, t, i);
			}
		}
		registerSharedNode(e, t) {
			this.sharedNodes.has(e) || this.sharedNodes.set(e, new Ss()), this.sharedNodes.get(e).add(t);
			let n = t.options.initialPromotionConfig;
			t.promote({
				transition: n ? n.transition : void 0,
				preserveFollowOpacity: n && n.shouldPreserveFollowOpacity ? n.shouldPreserveFollowOpacity(t) : void 0
			});
		}
		isLead() {
			let e = this.getStack();
			return e ? e.lead === this : !0;
		}
		getLead() {
			let { layoutId: e } = this.options;
			return e && this.getStack()?.lead || this;
		}
		getPrevLead() {
			let { layoutId: e } = this.options;
			return e ? this.getStack()?.prevLead : void 0;
		}
		getStack() {
			let { layoutId: e } = this.options;
			if (e) return this.root.sharedNodes.get(e);
		}
		promote({ needsReset: e, transition: t, preserveFollowOpacity: n } = {}) {
			let r = this.getStack();
			r && r.promote(this, n), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({ transition: t });
		}
		relegate() {
			let e = this.getStack();
			return e ? e.relegate(this) : !1;
		}
		resetSkewAndRotation() {
			let { visualElement: e } = this.options;
			if (!e) return;
			let t = !1, { latestValues: n } = e;
			if ((n.z || n.rotate || n.rotateX || n.rotateY || n.rotateZ || n.skewX || n.skewY) && (t = !0), !t) return;
			let r = {};
			n.z && Ds("z", e, r, this.animationValues);
			for (let t = 0; t < ws.length; t++) Ds(`rotate${ws[t]}`, e, r, this.animationValues), Ds(`skew${ws[t]}`, e, r, this.animationValues);
			e.render();
			for (let t in r) e.setStaticValue(t, r[t]), this.animationValues && (this.animationValues[t] = r[t]);
			e.scheduleRender();
		}
		applyProjectionStyles(e, t) {
			if (!this.instance || this.isSVG) return;
			if (!this.isVisible) {
				e.visibility = "hidden";
				return;
			}
			let n = this.getTransformTemplate();
			if (this.needsReset) {
				this.needsReset = !1, e.visibility = "", e.opacity = "", e.pointerEvents = xs(t?.pointerEvents) || "", e.transform = n ? n(this.latestValues, "") : "none";
				return;
			}
			let r = this.getLead();
			if (!this.projectionDelta || !this.layout || !r.target) {
				this.options.layoutId && (e.opacity = this.latestValues.opacity === void 0 ? 1 : this.latestValues.opacity, e.pointerEvents = xs(t?.pointerEvents) || ""), this.hasProjected && !La(this.latestValues) && (e.transform = n ? n({}, "") : "none", this.hasProjected = !1);
				return;
			}
			e.visibility = "";
			let i = r.animationValues || r.latestValues;
			this.applyTransformsToTarget();
			let a = ss(this.projectionDeltaWithTransform, this.treeScale, i);
			n && (a = n(i, a)), e.transform = a;
			let { x: o, y: s } = this.projectionDelta;
			e.transformOrigin = `${o.origin * 100}% ${s.origin * 100}% 0`, r.animationValues ? e.opacity = r === this ? i.opacity ?? this.latestValues.opacity ?? 1 : this.preserveOpacity ? this.latestValues.opacity : i.opacityExit : e.opacity = r === this ? i.opacity === void 0 ? "" : i.opacity : i.opacityExit === void 0 ? 0 : i.opacityExit;
			for (let t in oo) {
				if (i[t] === void 0) continue;
				let { correct: n, applyTo: o, isCSSVariable: s } = oo[t], c = a === "none" ? i[t] : n(i[t], r);
				if (o) {
					let t = o.length;
					for (let n = 0; n < t; n++) e[o[n]] = c;
				} else s ? this.options.visualElement.renderState.vars[t] = c : e[t] = c;
			}
			this.options.layoutId && (e.pointerEvents = r === this ? xs(t?.pointerEvents) || "" : "none");
		}
		clearSnapshot() {
			this.resumeFrom = this.snapshot = void 0;
		}
		resetTree() {
			this.root.nodes.forEach((e) => e.currentAnimation?.stop()), this.root.nodes.forEach(Fs), this.root.sharedNodes.clear();
		}
	};
}
function As(e) {
	e.updateLayout();
}
function js(e) {
	let t = e.resumeFrom?.snapshot || e.snapshot;
	if (e.isLead() && e.layout && t && e.hasListeners("didUpdate")) {
		let { layoutBox: n, measuredBox: r } = e.layout, { animationType: i } = e.options, a = t.source !== e.layout.source;
		if (i === "size") Q((e) => {
			let r = a ? t.measuredBox[e] : t.layoutBox[e], i = Z(r);
			r.min = n[e].min, r.max = r.min + i;
		});
		else if (i === "x" || i === "y") {
			let e = i === "x" ? "y" : "x";
			Mo(a ? t.measuredBox[e] : t.layoutBox[e], n[e]);
		} else ec(i, t.layoutBox, n) && Q((r) => {
			let i = a ? t.measuredBox[r] : t.layoutBox[r], o = Z(n[r]);
			i.max = i.min + o, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[r].max = e.relativeTarget[r].min + o);
		});
		let o = fa();
		Ho(o, n, t.layoutBox);
		let s = fa();
		a ? Ho(s, e.applyTransform(r, !0), t.measuredBox) : Ho(s, n, t.layoutBox);
		let c = !es(o), l = !1;
		if (!e.resumeFrom) {
			let r = e.getClosestProjectingParent();
			if (r && !r.resumeFrom) {
				let { snapshot: i, layout: a } = r;
				if (i && a) {
					let o = e.options.layoutAnchor || void 0, s = q();
					Ko(s, t.layoutBox, i.layoutBox, o);
					let c = q();
					Ko(c, n, a.layoutBox, o), is(s, c) || (l = !0), r.options.layoutRoot && (e.relativeTarget = c, e.relativeTargetOrigin = s, e.relativeParent = r);
				}
			}
		}
		e.notifyListeners("didUpdate", {
			layout: n,
			snapshot: t,
			delta: s,
			layoutDelta: o,
			hasLayoutChanged: c,
			hasRelativeLayoutChanged: l
		});
	} else if (e.isLead()) {
		let { onExitComplete: t } = e.options;
		t && t();
	}
	e.options.transition = void 0;
}
function Ms(e) {
	sa.value && $.nodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty ||= !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty), e.isTransformDirty ||= e.parent.isTransformDirty);
}
function Ns(e) {
	e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function Ps(e) {
	e.clearSnapshot();
}
function Fs(e) {
	e.clearMeasurements();
}
function Is(e) {
	e.isLayoutDirty = !0, e.updateLayout();
}
function Ls(e) {
	e.isLayoutDirty = !1;
}
function Rs(e) {
	e.isAnimationBlocked && e.layout && !e.isLayoutDirty && (e.snapshot = e.layout, e.isLayoutDirty = !0);
}
function zs(e) {
	let { visualElement: t } = e.options;
	t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform();
}
function Bs(e) {
	e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0;
}
function Vs(e) {
	e.resolveTargetDelta();
}
function Hs(e) {
	e.calcProjection();
}
function Us(e) {
	e.resetSkewAndRotation();
}
function Ws(e) {
	e.removeLeadSnapshot();
}
function Gs(e, t, n) {
	e.translate = z(t.translate, 0, n), e.scale = z(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint;
}
function Ks(e, t, n, r) {
	e.min = z(t.min, n.min, r), e.max = z(t.max, n.max, r);
}
function qs(e, t, n, r) {
	Ks(e.x, t.x, n.x, r), Ks(e.y, t.y, n.y, r);
}
function Js(e) {
	return e.animationValues && e.animationValues.opacityExit !== void 0;
}
var Ys = {
	duration: .45,
	ease: [
		.4,
		0,
		.1,
		1
	]
}, Xs = (e) => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e), Zs = Xs("applewebkit/") && !Xs("chrome/") ? Math.round : D;
function Qs(e) {
	e.min = Zs(e.min), e.max = Zs(e.max);
}
function $s(e) {
	Qs(e.x), Qs(e.y);
}
function ec(e, t, n) {
	return e === "position" || e === "preserve-aspect" && !Bo(as(t), as(n), .2);
}
function tc(e) {
	return e !== e.root && e.scroll?.wasRoot;
}
//#endregion
//#region ../../node_modules/.bun/motion-dom@12.43.0/node_modules/motion-dom/dist/es/projection/node/DocumentProjectionNode.mjs
var nc = ks({
	attachResizeListener: (e, t) => _s(e, "resize", t),
	measureScroll: () => ({
		x: document.documentElement.scrollLeft || document.body?.scrollLeft || 0,
		y: document.documentElement.scrollTop || document.body?.scrollTop || 0
	}),
	checkIsScrollRoot: () => !0
}), rc = { current: void 0 }, ic = ks({
	measureScroll: (e) => ({
		x: e.scrollLeft,
		y: e.scrollTop
	}),
	defaultParent: () => {
		if (!rc.current) {
			let e = new nc({});
			e.mount(window), e.setOptions({ layoutScroll: !0 }), rc.current = e;
		}
		return rc.current;
	},
	resetTransform: (e, t) => {
		e.style.transform = t === void 0 ? "none" : t;
	},
	checkIsScrollRoot: (e) => window.getComputedStyle(e).position === "fixed"
}), ac = a({
	transformPagePoint: (e) => e,
	isStatic: !1,
	reducedMotion: "never"
});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/components/AnimatePresence/use-presence.mjs
function oc(e = !0) {
	let t = l(S);
	if (t === null) return [!0, null];
	let { isPresent: n, onExitComplete: r, register: i } = t, a = d();
	u(() => {
		if (e) return i(a);
	}, [e]);
	let o = c(() => e && r && r(a), [
		a,
		r,
		e
	]);
	return !n && r ? [!1, o] : [!0];
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/LazyContext.mjs
var sc = a({ strict: !1 }), cc = {
	animation: [
		"animate",
		"variants",
		"whileHover",
		"whileTap",
		"exit",
		"whileInView",
		"whileFocus",
		"whileDrag"
	],
	exit: ["exit"],
	drag: ["drag", "dragControls"],
	focus: ["whileFocus"],
	hover: [
		"whileHover",
		"onHoverStart",
		"onHoverEnd"
	],
	tap: [
		"whileTap",
		"onTap",
		"onTapStart",
		"onTapCancel"
	],
	pan: [
		"onPan",
		"onPanStart",
		"onPanSessionStart",
		"onPanEnd"
	],
	inView: [
		"whileInView",
		"onViewportEnter",
		"onViewportLeave"
	],
	layout: ["layout", "layoutId"]
}, lc = !1;
function uc() {
	if (lc) return;
	let e = {};
	for (let t in cc) e[t] = { isEnabled: (e) => cc[t].some((t) => !!e[t]) };
	Oa(e), lc = !0;
}
function dc() {
	return uc(), ka();
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/features/load-features.mjs
function fc(e) {
	let t = dc();
	for (let n in e) t[n] = {
		...t[n],
		...e[n]
	};
	Oa(t);
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/utils/valid-prop.mjs
var pc = new Set(/* @__PURE__ */ "animate.exit.variants.initial.style.values.variants.transition.transformTemplate.custom.inherit.onBeforeLayoutMeasure.onAnimationStart.onAnimationComplete.onUpdate.onDragStart.onDrag.onDragEnd.onMeasureDragConstraints.onDirectionLock.onDragTransitionEnd._dragX._dragY.onHoverStart.onHoverEnd.onViewportEnter.onViewportLeave.globalTapTarget.propagate.ignoreStrict.viewport".split("."));
function mc(e) {
	return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || pc.has(e);
}
//#endregion
//#region __vite-optional-peer-dep:@emotion/is-prop-valid:framer-motion
var hc = /* @__PURE__ */ n({ default: () => gc }), gc, _c = t((() => {
	throw gc = {}, Error("Could not resolve \"@emotion/is-prop-valid\" imported by \"framer-motion\". Is it installed?");
})), vc = (e) => !mc(e);
function yc(e) {
	typeof e == "function" && (vc = (t) => t.startsWith("on") ? !mc(t) : e(t));
}
try {
	yc((_c(), e(hc)).default);
} catch {}
function bc(e, t, n) {
	let r = {};
	for (let i in e) i === "values" && typeof e.values == "object" || G(e[i]) || (vc(i) || n === !0 && mc(i) || !t && !mc(i) || e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
	return r;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/MotionContext/index.mjs
var xc = /* @__PURE__ */ a({});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/MotionContext/utils.mjs
function Sc(e, t) {
	if (ya(e)) {
		let { initial: t, animate: n } = e;
		return {
			initial: t === !1 || ga(t) ? t : void 0,
			animate: ga(n) ? n : void 0
		};
	}
	return e.inherit === !1 ? {} : t;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/MotionContext/create.mjs
function Cc(e) {
	let { initial: t, animate: n } = Sc(e, l(xc));
	return m(() => ({
		initial: t,
		animate: n
	}), [wc(t), wc(n)]);
}
function wc(e) {
	return Array.isArray(e) ? e.join(" ") : e;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/html/utils/create-render-state.mjs
var Tc = () => ({
	style: {},
	transform: {},
	transformOrigin: {},
	vars: {}
});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/html/use-props.mjs
function Ec(e, t, n) {
	for (let r in t) !G(t[r]) && !so(r, n) && (e[r] = t[r]);
}
function Dc({ transformTemplate: e }, t) {
	return m(() => {
		let n = Tc();
		return to(n, t, e), Object.assign({}, n.vars, n.style);
	}, [t]);
}
function Oc(e, t) {
	let n = e.style || {}, r = {};
	return Ec(r, n, e), Object.assign(r, Dc(e, t)), r;
}
function kc(e, t) {
	let n = {}, r = Oc(e, t);
	return e.drag && e.dragListener !== !1 && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = e.drag === !0 ? "none" : `pan-${e.drag === "x" ? "y" : "x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/svg/utils/create-render-state.mjs
var Ac = () => ({
	...Tc(),
	attrs: {}
});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/svg/use-props.mjs
function jc(e, t, n, r) {
	let i = m(() => {
		let n = Ac();
		return go(n, t, vo(r), e.transformTemplate, e.style), {
			...n.attrs,
			style: { ...n.style }
		};
	}, [t]);
	if (e.style) {
		let t = {};
		Ec(t, e.style, e), i.style = {
			...t,
			...i.style
		};
	}
	return i;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/svg/lowercase-elements.mjs
var Mc = [
	"animate",
	"circle",
	"defs",
	"desc",
	"ellipse",
	"g",
	"image",
	"line",
	"filter",
	"marker",
	"mask",
	"metadata",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"rect",
	"stop",
	"switch",
	"symbol",
	"svg",
	"text",
	"tspan",
	"use",
	"view"
];
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/dom/utils/is-svg-component.mjs
function Nc(e) {
	return typeof e != "string" || e.includes("-") ? !1 : !!(Mc.indexOf(e) > -1 || /[A-Z]/u.test(e));
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/dom/use-render.mjs
function Pc(e, t, n, { latestValues: r }, a, s = !1, c) {
	let l = (c ?? Nc(e) ? jc : kc)(t, r, a, e), u = bc(t, typeof e == "string", s), d = e === i ? {} : {
		...u,
		...l,
		ref: n
	}, { children: f } = t, p = m(() => G(f) ? f.get() : f, [f]);
	return o(e, {
		...d,
		children: p
	});
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/utils/use-visual-state.mjs
function Fc({ scrapeMotionValuesFromProps: e, createRenderState: t }, n, r, i) {
	return {
		latestValues: Ic(n, r, i, e),
		renderState: t()
	};
}
function Ic(e, t, n, r) {
	let i = {}, a = r(e, {});
	for (let e in a) i[e] = xs(a[e]);
	let { initial: o, animate: s } = e, c = ya(e), l = ba(e);
	t && l && !c && e.inherit !== !1 && (o === void 0 && (o = t.initial), s === void 0 && (s = t.animate));
	let u = n ? n.initial === !1 : !1;
	u ||= o === !1;
	let d = u ? s : o;
	if (d && typeof d != "boolean" && !ha(d)) {
		let t = Array.isArray(d) ? d : [d];
		for (let n = 0; n < t.length; n++) {
			let r = Vr(e, t[n]);
			if (r) {
				let { transitionEnd: e, transition: t, ...n } = r;
				for (let e in n) {
					let t = n[e];
					if (Array.isArray(t)) {
						let e = u ? t.length - 1 : 0;
						t = t[e];
					}
					t !== null && (i[e] = t);
				}
				for (let t in e) i[t] = e[t];
			}
		}
	}
	return i;
}
var Lc = (e) => (t, n) => {
	let r = l(xc), i = l(S), a = () => Fc(e, t, r, i);
	return n ? a() : b(a);
}, Rc = /* @__PURE__ */ Lc({
	scrapeMotionValuesFromProps: co,
	createRenderState: Tc
}), zc = /* @__PURE__ */ Lc({
	scrapeMotionValuesFromProps: bo,
	createRenderState: Ac
}), Bc = Symbol.for("motionComponentSymbol");
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/utils/use-motion-ref.mjs
function Vc(e, t, n) {
	let r = h(n);
	f(() => {
		r.current = n;
	});
	let i = h(null);
	return c((n) => {
		n && e.onMount?.(n), t && (n ? t.mount(n) : t.unmount());
		let a = r.current;
		if (typeof a == "function") if (n) {
			let e = a(n);
			typeof e == "function" && (i.current = e);
		} else i.current ? (i.current(), i.current = null) : a(n);
		else a && (a.current = n);
	}, [t]);
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/context/SwitchLayoutGroupContext.mjs
var Hc = a({});
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/is-ref-object.mjs
function Uc(e) {
	return e && typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current");
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/utils/use-visual-element.mjs
function Wc(e, t, n, r, i, a) {
	let { visualElement: o } = l(xc), s = l(sc), c = l(S), d = l(ac), p = d.reducedMotion, m = d.skipAnimations, g = h(null), _ = h(!1);
	r ||= s.renderer, !g.current && r && (g.current = r(e, {
		visualState: t,
		parent: o,
		props: n,
		presenceContext: c,
		blockInitialAnimation: c ? c.initial === !1 : !1,
		reducedMotionConfig: p,
		skipAnimations: m,
		isSVG: a
	}), _.current && g.current && (g.current.manuallyAnimateOnMount = !0));
	let v = g.current, y = l(Hc);
	v && !v.projection && i && (v.type === "html" || v.type === "svg") && Gc(g.current, n, i, y);
	let b = h(!1);
	f(() => {
		v && b.current && v.update(n, c);
	});
	let C = n[Xr], w = h(!!C && typeof window < "u" && !window.MotionHandoffIsComplete?.(C) && window.MotionHasOptimisedAnimation?.(C));
	return x(() => {
		_.current = !0, v && (b.current = !0, window.MotionIsMounted = !0, v.updateFeatures(), v.scheduleRenderMicrotask(), w.current && v.animationState && v.animationState.animateChanges());
	}), u(() => {
		v && (!w.current && v.animationState && v.animationState.animateChanges(), w.current &&= (queueMicrotask(() => {
			window.MotionHandoffMarkAsComplete?.(C);
		}), !1), v.enteringChildren = void 0);
	}), v;
}
function Gc(e, t, n, r) {
	let { layoutId: i, layout: a, drag: o, dragConstraints: s, layoutScroll: c, layoutRoot: l, layoutAnchor: u, layoutCrossfade: d } = t;
	e.projection = new n(e.latestValues, t["data-framer-portal-id"] ? void 0 : Kc(e.parent)), e.projection.setOptions({
		layoutId: i,
		layout: a,
		alwaysMeasureLayout: !!o || s && Uc(s),
		visualElement: e,
		animationType: typeof a == "string" ? a : "both",
		initialPromotionConfig: r,
		crossfade: d,
		layoutScroll: c,
		layoutRoot: l,
		layoutAnchor: u
	});
}
function Kc(e) {
	if (e) return e.options.allowProjection === !1 ? Kc(e.parent) : e.projection;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/index.mjs
function qc(e, { forwardMotionProps: t = !1, type: n } = {}, r, i) {
	r && fc(r);
	let a = n ? n === "svg" : Nc(e), o = a ? zc : Rc;
	function c(n, s) {
		let c, u = {
			...l(ac),
			...n,
			layoutId: Jc(n)
		}, { isStatic: d } = u, f = Cc(n), p = o(n, d);
		if (!d && typeof window < "u") {
			Yc(u, r);
			let t = Xc(u);
			c = t.MeasureLayout, f.visualElement = Wc(e, p, u, i, t.ProjectionNode, a);
		}
		return _(xc.Provider, {
			value: f,
			children: [c && f.visualElement ? g(c, {
				visualElement: f.visualElement,
				...u
			}) : null, Pc(e, n, Vc(p, f.visualElement, s), p, d, t, a)]
		});
	}
	c.displayName = `motion.${typeof e == "string" ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
	let u = s(c);
	return u[Bc] = e, u;
}
function Jc({ layoutId: e }) {
	let t = l(y).id;
	return t && e !== void 0 ? t + "-" + e : e;
}
function Yc(e, t) {
	l(sc).strict;
}
function Xc(e) {
	let { drag: t, layout: n } = dc();
	if (!t && !n) return {};
	let r = {
		...t,
		...n
	};
	return {
		MeasureLayout: t?.isEnabled(e) || n?.isEnabled(e) ? r.MeasureLayout : void 0,
		ProjectionNode: r.ProjectionNode
	};
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/components/create-proxy.mjs
function Zc(e, t) {
	if (typeof Proxy > "u") return qc;
	let n = /* @__PURE__ */ new Map(), r = (n, r) => qc(n, r, e, t);
	return new Proxy((e, t) => r(e, t), { get: (i, a) => a === "create" ? r : (n.has(a) || n.set(a, qc(a, void 0, e, t)), n.get(a)) });
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/render/dom/create-visual-element.mjs
var Qc = (e, t) => t.isSVG ?? Nc(e) ? new xo(t) : new uo(t, { allowProjection: e !== i }), $c = class extends J {
	constructor(e) {
		super(e), e.animationState ||= Oo(e);
	}
	updateAnimationControlsSubscription() {
		let { animate: e } = this.node.getProps();
		ha(e) && (this.unmountControls = e.subscribe(this.node));
	}
	mount() {
		this.updateAnimationControlsSubscription();
	}
	update() {
		let { animate: e } = this.node.getProps(), { animate: t } = this.node.prevProps || {};
		e !== t && this.updateAnimationControlsSubscription();
	}
	unmount() {
		this.node.animationState.reset(), this.unmountControls?.();
	}
}, el = 0, tl = {
	animation: { Feature: $c },
	exit: { Feature: class extends J {
		constructor() {
			super(...arguments), this.id = el++, this.isExitComplete = !1;
		}
		update() {
			if (!this.node.presenceContext) return;
			let { isPresent: e, onExitComplete: t } = this.node.presenceContext, { isPresent: n } = this.node.prevPresenceContext || {};
			if (!this.node.animationState || e === n) return;
			if (e && n === !1) {
				if (this.isExitComplete) {
					let { initial: e, custom: t } = this.node.getProps();
					if (typeof e == "string" || typeof e == "object" && e && !Array.isArray(e)) {
						let n = W(this.node, e, t);
						if (n) {
							let { transition: e, transitionEnd: t, ...r } = n;
							for (let e in r) this.node.getValue(e)?.jump(r[e]);
						}
					}
					this.node.animationState.reset(), this.node.animationState.animateChanges();
				} else this.node.animationState.setActive("exit", !1);
				this.isExitComplete = !1;
				return;
			}
			let r = this.node.animationState.setActive("exit", !e);
			t && !e && r.then(() => {
				this.isExitComplete = !0, t(this.id);
			});
		}
		mount() {
			let { register: e, onExitComplete: t } = this.node.presenceContext || {};
			t && t(this.id), e && (this.unmount = e(this.id));
		}
		unmount() {}
	} }
};
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/events/event-info.mjs
function nl(e) {
	return { point: {
		x: e.pageX,
		y: e.pageY
	} };
}
var rl = (e) => (t) => Pi(t) && e(t, nl(t));
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/events/add-pointer-event.mjs
function il(e, t, n, r) {
	return _s(e, t, rl(n), r);
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/get-context-window.mjs
var al = ({ current: e }) => e ? e.ownerDocument.defaultView : null, ol = (e, t) => Math.abs(e - t);
function sl(e, t) {
	let n = ol(e.x, t.x), r = ol(e.y, t.y);
	return Math.sqrt(n ** 2 + r ** 2);
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/pan/PanSession.mjs
var cl = /* @__PURE__ */ new Set(["auto", "scroll"]), ll = class {
	constructor(e, t, { transformPagePoint: n, contextWindow: r = window, dragSnapToOrigin: i = !1, distanceThreshold: a = 3, element: o } = {}) {
		if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = /* @__PURE__ */ new Map(), this.removeScrollListeners = null, this.onElementScroll = (e) => {
			this.handleScroll(e.target);
		}, this.onWindowScroll = () => {
			this.handleScroll(window);
		}, this.updatePoint = () => {
			if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			this.lastRawMoveEventInfo && (this.lastMoveEventInfo = ul(this.lastRawMoveEventInfo, this.transformPagePoint));
			let e = fl(this.lastMoveEventInfo, this.history), t = this.startEvent !== null, n = sl(e.offset, {
				x: 0,
				y: 0
			}) >= this.distanceThreshold;
			if (!t && !n) return;
			let { point: r } = e, { timestamp: i } = M;
			this.history.push({
				...r,
				timestamp: i
			});
			let { onStart: a, onMove: o } = this.handlers;
			t || (a && a(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), o && o(this.lastMoveEvent, e);
		}, this.handlePointerMove = (e, t) => {
			this.lastMoveEvent = e, this.lastRawMoveEventInfo = t, this.lastMoveEventInfo = ul(t, this.transformPagePoint), A.update(this.updatePoint, !0);
		}, this.handlePointerUp = (e, t) => {
			this.end();
			let { onEnd: n, onSessionEnd: r, resumeAnimation: i } = this.handlers;
			if ((this.dragSnapToOrigin || !this.startEvent) && i && i(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			let a = fl(e.type === "pointercancel" ? this.lastMoveEventInfo : ul(t, this.transformPagePoint), this.history);
			this.startEvent && n && n(e, a), r && r(e, a);
		}, !Pi(e)) return;
		this.dragSnapToOrigin = i, this.handlers = t, this.transformPagePoint = n, this.distanceThreshold = a, this.contextWindow = r || window;
		let s = ul(nl(e), this.transformPagePoint), { point: c } = s, { timestamp: l } = M;
		this.history = [{
			...c,
			timestamp: l
		}];
		let { onSessionStart: u } = t;
		u && u(e, fl(s, this.history));
		let d = {
			passive: !0,
			capture: !0
		};
		this.removeListeners = ae(il(this.contextWindow, "pointermove", this.handlePointerMove, d), il(this.contextWindow, "pointerup", this.handlePointerUp, d), il(this.contextWindow, "pointercancel", this.handlePointerUp, d)), o && this.startScrollTracking(o);
	}
	startScrollTracking(e) {
		let t = e.parentElement;
		for (; t;) {
			let e = getComputedStyle(t);
			(cl.has(e.overflowX) || cl.has(e.overflowY)) && this.scrollPositions.set(t, {
				x: t.scrollLeft,
				y: t.scrollTop
			}), t = t.parentElement;
		}
		this.scrollPositions.set(window, {
			x: window.scrollX,
			y: window.scrollY
		}), window.addEventListener("scroll", this.onElementScroll, { capture: !0 }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
			window.removeEventListener("scroll", this.onElementScroll, { capture: !0 }), window.removeEventListener("scroll", this.onWindowScroll);
		};
	}
	handleScroll(e) {
		let t = this.scrollPositions.get(e);
		if (!t) return;
		let n = e === window, r = n ? {
			x: window.scrollX,
			y: window.scrollY
		} : {
			x: e.scrollLeft,
			y: e.scrollTop
		}, i = {
			x: r.x - t.x,
			y: r.y - t.y
		};
		i.x === 0 && i.y === 0 || (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += i.x, this.lastMoveEventInfo.point.y += i.y) : this.history.length > 0 && (this.history[0].x -= i.x, this.history[0].y -= i.y), this.scrollPositions.set(e, r), A.update(this.updatePoint, !0));
	}
	updateHandlers(e) {
		this.handlers = e;
	}
	end() {
		this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), j(this.updatePoint);
	}
};
function ul(e, t) {
	return t ? { point: t(e.point) } : e;
}
function dl(e, t) {
	return {
		x: e.x - t.x,
		y: e.y - t.y
	};
}
function fl({ point: e }, t) {
	return {
		point: e,
		delta: dl(e, ml(t)),
		offset: dl(e, pl(t)),
		velocity: hl(t, .1)
	};
}
function pl(e) {
	return e[0];
}
function ml(e) {
	return e[e.length - 1];
}
function hl(e, t) {
	if (e.length < 2) return {
		x: 0,
		y: 0
	};
	let n = e.length - 1, r = null, i = ml(e);
	for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > /* @__PURE__ */ O(t)));) n--;
	if (!r) return {
		x: 0,
		y: 0
	};
	r === e[0] && e.length > 2 && i.timestamp - r.timestamp > /* @__PURE__ */ O(t) * 2 && (r = e[1]);
	let a = /* @__PURE__ */ k(i.timestamp - r.timestamp);
	if (a === 0) return {
		x: 0,
		y: 0
	};
	let o = {
		x: (i.x - r.x) / a,
		y: (i.y - r.y) / a
	};
	return o.x === Infinity && (o.x = 0), o.y === Infinity && (o.y = 0), o;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/drag/utils/constraints.mjs
function gl(e, { min: t, max: n }, r) {
	return t !== void 0 && e < t ? e = r ? z(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? z(n, e, r.max) : Math.min(e, n)), e;
}
function _l(e, t, n) {
	return {
		min: t === void 0 ? void 0 : e.min + t,
		max: n === void 0 ? void 0 : e.max + n - (e.max - e.min)
	};
}
function vl(e, { top: t, left: n, bottom: r, right: i }) {
	return {
		x: _l(e.x, n, i),
		y: _l(e.y, t, r)
	};
}
function yl(e, t) {
	let n = t.min - e.min, r = t.max - e.max;
	return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
		min: n,
		max: r
	};
}
function bl(e, t) {
	return {
		x: yl(e.x, t.x),
		y: yl(e.y, t.y)
	};
}
function xl(e, t) {
	let n = .5, r = Z(e), i = Z(t);
	return i > r ? n = /* @__PURE__ */ oe(t.min, t.max - r, e.min) : r > i && (n = /* @__PURE__ */ oe(e.min, e.max - i, t.min)), T(0, 1, n);
}
function Sl(e, t) {
	let n = {};
	return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n;
}
var Cl = .35;
function wl(e = Cl) {
	return e === !1 ? e = 0 : e === !0 && (e = Cl), {
		x: Tl(e, "left", "right"),
		y: Tl(e, "top", "bottom")
	};
}
function Tl(e, t, n) {
	return {
		min: El(e, t),
		max: El(e, n)
	};
}
function El(e, t) {
	return typeof e == "number" ? e : e[t] || 0;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/drag/VisualElementDragControls.mjs
var Dl = /* @__PURE__ */ new WeakMap(), Ol = class {
	constructor(e) {
		this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
			x: 0,
			y: 0
		}, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = q(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e;
	}
	start(e, { snapToCursor: t = !1, distanceThreshold: n } = {}) {
		let { presenceContext: r } = this.visualElement;
		if (r && r.isPresent === !1) return;
		let i = (e) => {
			t && this.snapToCursor(nl(e).point), this.stopAnimation();
		}, a = (e, t) => {
			let { drag: n, dragPropagation: r, onDragStart: i } = this.getProps();
			if (n && !r && (this.openDragLock && this.openDragLock(), this.openDragLock = ki(n), !this.openDragLock)) return;
			this.latestPointerEvent = e, this.latestPanInfo = t, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), Q((e) => {
				let t = this.getAxisMotionValue(e).get() || 0;
				if (F.test(t)) {
					let { projection: n } = this.visualElement;
					if (n && n.layout) {
						let r = n.layout.layoutBox[e];
						r && (t = Z(r) * (parseFloat(t) / 100));
					}
				}
				this.originPoint[e] = t;
			}), i && A.update(() => i(e, t), !1, !0), Jr(this.visualElement, "transform");
			let { animationState: a } = this.visualElement;
			a && a.setActive("whileDrag", !0);
		}, o = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t;
			let { dragPropagation: n, dragDirectionLock: r, onDirectionLock: i, onDrag: a } = this.getProps();
			if (!n && !this.openDragLock) return;
			let { offset: o } = t;
			if (r && this.currentDirection === null) {
				this.currentDirection = Ml(o), this.currentDirection !== null && i && i(this.currentDirection);
				return;
			}
			this.updateAxis("x", t.point, o), this.updateAxis("y", t.point, o), this.visualElement.render(), a && A.update(() => a(e, t), !1, !0);
		}, s = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t, this.stop(e, t), this.latestPointerEvent = null, this.latestPanInfo = null;
		}, c = () => {
			let { dragSnapToOrigin: e } = this.getProps();
			(e || this.constraints) && this.startAnimation({
				x: 0,
				y: 0
			});
		}, { dragSnapToOrigin: l } = this.getProps();
		this.panSession = new ll(e, {
			onSessionStart: i,
			onStart: a,
			onMove: o,
			onSessionEnd: s,
			resumeAnimation: c
		}, {
			transformPagePoint: this.visualElement.getTransformPagePoint(),
			dragSnapToOrigin: l,
			distanceThreshold: n,
			contextWindow: al(this.visualElement),
			element: this.visualElement.current
		});
	}
	stop(e, t) {
		let n = e || this.latestPointerEvent, r = t || this.latestPanInfo, i = this.isDragging;
		if (this.cancel(), !i || !r || !n) return;
		let { velocity: a } = r;
		this.startAnimation(a);
		let { onDragEnd: o } = this.getProps();
		o && A.postRender(() => o(n, r));
	}
	cancel() {
		this.isDragging = !1;
		let { projection: e, animationState: t } = this.visualElement;
		e && (e.isAnimationBlocked = !1), this.endPanSession();
		let { dragPropagation: n } = this.getProps();
		!n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), t && t.setActive("whileDrag", !1);
	}
	endPanSession() {
		this.panSession && this.panSession.end(), this.panSession = void 0;
	}
	updateAxis(e, t, n) {
		let { drag: r } = this.getProps();
		if (!n || !jl(e, r, this.currentDirection)) return;
		let i = this.getAxisMotionValue(e), a = this.originPoint[e] + n[e];
		this.constraints && this.constraints[e] && (a = gl(a, this.constraints[e], this.elastic[e])), i.set(a);
	}
	resolveConstraints() {
		let { dragConstraints: e, dragElastic: t } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection?.layout, r = this.constraints;
		e && Uc(e) ? this.constraints ||= this.resolveRefConstraints() : e && n ? this.constraints = vl(n.layoutBox, e) : this.constraints = !1, this.elastic = wl(t), r !== this.constraints && !Uc(e) && n && this.constraints && !this.hasMutatedConstraints && Q((e) => {
			this.constraints !== !1 && this.getAxisMotionValue(e) && (this.constraints[e] = Sl(n.layoutBox[e], this.constraints[e]));
		});
	}
	resolveRefConstraints() {
		let { dragConstraints: e, onMeasureDragConstraints: t } = this.getProps();
		if (!e || !Uc(e)) return !1;
		let n = e.current, { projection: r } = this.visualElement;
		if (!r || !r.layout) return !1;
		r.root && (r.root.scroll = void 0, r.root.updateScroll());
		let i = Za(n, r.root, this.visualElement.getTransformPagePoint()), a = bl(r.layout.layoutBox, i);
		if (t) {
			let e = t(Na(a));
			this.hasMutatedConstraints = !!e, e && (a = Ma(e));
		}
		return a;
	}
	startAnimation(e) {
		let { drag: t, dragMomentum: n, dragElastic: r, dragTransition: i, dragSnapToOrigin: a, onDragTransitionEnd: o } = this.getProps(), s = this.constraints || {}, c = Q((o) => {
			if (!jl(o, t, this.currentDirection)) return;
			let c = s && s[o] || {};
			(a === !0 || a === o) && (c = {
				min: 0,
				max: 0
			});
			let l = r ? 200 : 1e6, u = r ? 40 : 1e7, d = {
				type: "inertia",
				velocity: n ? e[o] : 0,
				bounceStiffness: l,
				bounceDamping: u,
				timeConstant: 750,
				restDelta: 1,
				restSpeed: 10,
				...i,
				...c
			};
			return this.startAxisValueAnimation(o, d);
		});
		return Promise.all(c).then(o);
	}
	startAxisValueAnimation(e, t) {
		let n = this.getAxisMotionValue(e);
		return Jr(this.visualElement, e), n.start(Ir(e, n, 0, t, this.visualElement, !1));
	}
	stopAnimation() {
		Q((e) => this.getAxisMotionValue(e).stop());
	}
	getAxisMotionValue(e) {
		let t = `_drag${e.toUpperCase()}`;
		return this.visualElement.getProps()[t] || this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0);
	}
	snapToCursor(e) {
		Q((t) => {
			let { drag: n } = this.getProps();
			if (!jl(t, n, this.currentDirection)) return;
			let { projection: r } = this.visualElement, i = this.getAxisMotionValue(t);
			if (r && r.layout) {
				let { min: n, max: a } = r.layout.layoutBox[t], o = i.get() || 0;
				i.set(e[t] - z(n, a, .5) + o);
			}
		});
	}
	scalePositionWithinConstraints() {
		if (!this.visualElement.current) return;
		let { drag: e, dragConstraints: t } = this.getProps(), { projection: n } = this.visualElement;
		if (!Uc(t) || !n || !this.constraints) return;
		this.stopAnimation();
		let r = {
			x: 0,
			y: 0
		};
		Q((e) => {
			let t = this.getAxisMotionValue(e);
			if (t && this.constraints !== !1) {
				let n = t.get();
				r[e] = xl({
					min: n,
					max: n
				}, this.constraints[e]);
			}
		});
		let { transformTemplate: i } = this.visualElement.getProps();
		this.visualElement.current.style.transform = i ? i({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.constraints = !1, this.resolveConstraints(), Q((t) => {
			if (!jl(t, e, null)) return;
			let n = this.getAxisMotionValue(t), { min: i, max: a } = this.constraints[t];
			n.set(z(i, a, r[t]));
		}), this.visualElement.render();
	}
	addListeners() {
		if (!this.visualElement.current) return;
		Dl.set(this.visualElement, this);
		let e = this.visualElement.current, t = il(e, "pointerdown", (t) => {
			let { drag: n, dragListener: r = !0 } = this.getProps(), i = t.target, a = i !== e && Ri(i);
			n && r && !a && this.start(t);
		}), n, r = () => {
			let { dragConstraints: t } = this.getProps();
			Uc(t) && t.current && (this.constraints = this.resolveRefConstraints(), n ||= Al(e, t.current, () => this.scalePositionWithinConstraints()));
		}, { projection: i } = this.visualElement, a = i.addEventListener("measure", r);
		i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), A.read(r);
		let o = _s(window, "resize", () => this.scalePositionWithinConstraints()), s = i.addEventListener("didUpdate", (({ delta: e, hasLayoutChanged: t }) => {
			this.isDragging && t && (Q((t) => {
				let n = this.getAxisMotionValue(t);
				n && (this.originPoint[t] += e[t].translate, n.set(n.get() + e[t].translate));
			}), this.visualElement.render());
		}));
		return () => {
			o(), t(), a(), s && s(), n && n();
		};
	}
	getProps() {
		let e = this.visualElement.getProps(), { drag: t = !1, dragDirectionLock: n = !1, dragPropagation: r = !1, dragConstraints: i = !1, dragElastic: a = Cl, dragMomentum: o = !0 } = e;
		return {
			...e,
			drag: t,
			dragDirectionLock: n,
			dragPropagation: r,
			dragConstraints: i,
			dragElastic: a,
			dragMomentum: o
		};
	}
};
function kl(e) {
	let t = !0;
	return () => {
		if (t) {
			t = !1;
			return;
		}
		e();
	};
}
function Al(e, t, n) {
	let r = oa(e, kl(n)), i = oa(t, kl(n));
	return () => {
		r(), i();
	};
}
function jl(e, t, n) {
	return (t === !0 || t === e) && (n === null || n === e);
}
function Ml(e, t = 10) {
	let n = null;
	return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/drag/index.mjs
var Nl = class extends J {
	constructor(e) {
		super(e), this.removeGroupControls = D, this.removeListeners = D, this.controls = new Ol(e);
	}
	mount() {
		let { dragControls: e } = this.node.getProps();
		e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || D;
	}
	update() {
		let { dragControls: e } = this.node.getProps(), { dragControls: t } = this.node.prevProps || {};
		e !== t && (this.removeGroupControls(), e && (this.removeGroupControls = e.subscribe(this.controls)));
	}
	unmount() {
		this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession();
	}
}, Pl = (e) => (t, n) => {
	e && A.update(() => e(t, n), !1, !0);
}, Fl = class extends J {
	constructor() {
		super(...arguments), this.removePointerDownListener = D;
	}
	onPointerDown(e) {
		this.session = new ll(e, this.createPanHandlers(), {
			transformPagePoint: this.node.getTransformPagePoint(),
			contextWindow: al(this.node)
		});
	}
	createPanHandlers() {
		let { onPanSessionStart: e, onPanStart: t, onPan: n, onPanEnd: r } = this.node.getProps();
		return {
			onSessionStart: Pl(e),
			onStart: Pl(t),
			onMove: Pl(n),
			onEnd: (e, t) => {
				delete this.session, r && A.postRender(() => r(e, t));
			}
		};
	}
	mount() {
		this.removePointerDownListener = il(this.node.current, "pointerdown", (e) => this.onPointerDown(e));
	}
	update() {
		this.session && this.session.updateHandlers(this.createPanHandlers());
	}
	unmount() {
		this.removePointerDownListener(), this.session && this.session.end();
	}
}, Il = !1, Ll = class extends r {
	componentDidMount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n, layoutId: r } = this.props, { projection: i } = e;
		i && (t.group && t.group.add(i), n && n.register && r && n.register(i), Il && i.root.didUpdate(), i.addEventListener("animationComplete", () => {
			this.safeToRemove();
		}), i.setOptions({
			...i.options,
			layoutDependency: this.props.layoutDependency,
			onExitComplete: () => this.safeToRemove()
		})), Cs.hasEverUpdated = !0;
	}
	getSnapshotBeforeUpdate(e) {
		let { layoutDependency: t, visualElement: n, drag: r, isPresent: i } = this.props, { projection: a } = n;
		return a ? (a.isPresent = i, e.layoutDependency !== t && a.setOptions({
			...a.options,
			layoutDependency: t
		}), Il = !0, r || e.layoutDependency !== t || t === void 0 || e.isPresent !== i ? a.willUpdate() : this.safeToRemove(), e.isPresent !== i && (i ? a.promote() : a.relegate() || A.postRender(() => {
			let e = a.getStack();
			(!e || !e.members.length) && this.safeToRemove();
		})), null) : null;
	}
	componentDidUpdate() {
		let { visualElement: e, layoutAnchor: t } = this.props, { projection: n } = e;
		n && (n.options.layoutAnchor = t, n.root.didUpdate(), Ei.postRender(() => {
			!n.currentAnimation && n.isLead() && this.safeToRemove();
		}));
	}
	componentWillUnmount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n } = this.props, { projection: r } = e;
		Il = !0, r && (r.scheduleCheckAfterUnmount(), t && t.group && t.group.remove(r), n && n.deregister && n.deregister(r));
	}
	safeToRemove() {
		let { safeToRemove: e } = this.props;
		e && e();
	}
	render() {
		return null;
	}
};
function Rl(e) {
	let [t, n] = oc(), r = l(y);
	return g(Ll, {
		...e,
		layoutGroup: r,
		switchLayoutGroup: l(Hc),
		isPresent: t,
		safeToRemove: n
	});
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/features/drag.mjs
var zl = {
	pan: { Feature: Fl },
	drag: {
		Feature: Nl,
		ProjectionNode: ic,
		MeasureLayout: Rl
	}
};
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/hover.mjs
function Bl(e, t, n) {
	let { props: r } = e;
	e.animationState && r.whileHover && e.animationState.setActive("whileHover", n === "Start");
	let i = r["onHover" + n];
	i && A.postRender(() => i(t, nl(t)));
}
var Vl = class extends J {
	mount() {
		let { current: e } = this.node;
		e && (this.unmount = Mi(e, (e, t) => (Bl(this.node, t, "Start"), (e) => Bl(this.node, e, "End"))));
	}
	unmount() {}
}, Hl = class extends J {
	constructor() {
		super(...arguments), this.isActive = !1;
	}
	onFocus() {
		let e = !1;
		try {
			e = this.node.current.matches(":focus-visible");
		} catch {
			e = !0;
		}
		!e || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0);
	}
	onBlur() {
		!this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1);
	}
	mount() {
		this.unmount = ae(_s(this.node.current, "focus", () => this.onFocus()), _s(this.node.current, "blur", () => this.onBlur()));
	}
	unmount() {}
};
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/gestures/press.mjs
function Ul(e, t, n) {
	let { props: r } = e;
	if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
	e.animationState && r.whileTap && e.animationState.setActive("whileTap", n === "Start");
	let i = r["onTap" + (n === "End" ? "" : n)];
	i && A.postRender(() => i(t, nl(t)));
}
var Wl = class extends J {
	mount() {
		let { current: e } = this.node;
		if (!e) return;
		let { globalTapTarget: t, propagate: n } = this.node.props;
		this.unmount = Gi(e, (e, t) => (Ul(this.node, t, "Start"), (e, { success: t }) => Ul(this.node, e, t ? "End" : "Cancel")), {
			useGlobalTarget: t,
			stopPropagation: n?.tap === !1
		});
	}
	unmount() {}
}, Gl = /* @__PURE__ */ new WeakMap(), Kl = /* @__PURE__ */ new WeakMap(), ql = (e) => {
	let t = Gl.get(e.target);
	t && t(e);
}, Jl = (e) => {
	e.forEach(ql);
};
function Yl({ root: e, ...t }) {
	let n = e || document;
	Kl.has(n) || Kl.set(n, {});
	let r = Kl.get(n), i = JSON.stringify(t);
	return r[i] || (r[i] = new IntersectionObserver(Jl, {
		root: e,
		...t
	})), r[i];
}
function Xl(e, t, n) {
	let r = Yl(t);
	return Gl.set(e, n), r.observe(e), () => {
		Gl.delete(e), r.unobserve(e);
	};
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/features/viewport/index.mjs
var Zl = {
	some: 0,
	all: 1
}, Ql = class extends J {
	constructor() {
		super(...arguments), this.hasEnteredView = !1, this.isInView = !1;
	}
	startObserver() {
		this.stopObserver?.();
		let { viewport: e = {} } = this.node.getProps(), { root: t, margin: n, amount: r = "some", once: i } = e, a = {
			root: t ? t.current : void 0,
			rootMargin: n,
			threshold: typeof r == "number" ? r : Zl[r]
		}, o = (e) => {
			let { isIntersecting: t } = e;
			if (this.isInView === t || (this.isInView = t, i && !t && this.hasEnteredView)) return;
			t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
			let { onViewportEnter: n, onViewportLeave: r } = this.node.getProps(), a = t ? n : r;
			a && a(e);
		};
		this.stopObserver = Xl(this.node.current, a, o);
	}
	mount() {
		this.startObserver();
	}
	update() {
		if (typeof IntersectionObserver > "u") return;
		let { props: e, prevProps: t } = this.node;
		[
			"amount",
			"margin",
			"root"
		].some($l(e, t)) && this.startObserver();
	}
	unmount() {
		this.stopObserver?.(), this.hasEnteredView = !1, this.isInView = !1;
	}
};
function $l({ viewport: e = {} }, { viewport: t = {} } = {}) {
	return (n) => e[n] !== t[n];
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/motion/features/gestures.mjs
var eu = {
	inView: { Feature: Ql },
	tap: { Feature: Wl },
	focus: { Feature: Hl },
	hover: { Feature: Vl }
}, tu = { layout: {
	ProjectionNode: ic,
	MeasureLayout: Rl
} }, nu = /* @__PURE__ */ Zc({
	...tl,
	...eu,
	...zl,
	...tu
}, Qc);
//#endregion
export { Ca as a, ni as c, S as d, x as f, v as h, Ta as i, Kr as l, y as m, oc as n, Sa as o, b as p, ac as r, Ti as s, nu as t, ee as u };
