import { n as e } from "./request-Dbjf-LtL.js";
import { l as t, p as n, r } from "./schemas-D8_brjAQ.js";
//#region src/lib/cloud/organization.ts
var i = t({
	results: r(t({ id: n().min(1) })),
	next: n().nullable().optional()
}), a = "cadet_active_organization_id";
function o() {
	try {
		return sessionStorage.getItem(a);
	} catch {
		return null;
	}
}
async function s(t) {
	let n = [];
	for (let r = 0; r < 20; r++) {
		let r = await e(`/v1/organizations/?limit=100&offset=${n.length}`, i, { signal: t });
		if (!r.ok) return r;
		if (n.push(...r.data.results.map((e) => e.id)), !r.data.next || r.data.results.length === 0) {
			let e = o(), t = e && n.includes(e) ? e : n[0];
			return t ? {
				ok: !0,
				status: r.status,
				data: t
			} : {
				ok: !1,
				status: r.status,
				error: { detail: "No organization available for this account." }
			};
		}
	}
	return {
		ok: !1,
		status: 200,
		error: { detail: "Organization list exceeded the page cap." }
	};
}
//#endregion
export { s as t };
