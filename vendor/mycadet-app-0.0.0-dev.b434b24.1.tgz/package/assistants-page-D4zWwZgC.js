import { l as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n as t, t as n } from "./loader-circle-Ch7lYSrj.js";
import { t as r } from "./check-DPXe7vV_.js";
import { i, n as a } from "./src-DLa8cepg.js";
import { g as o, t as s, v as c } from "./confirm-dialog-DH3yi6Nk.js";
import { t as l } from "./rotate-ccw-B-fMJOWC.js";
import { i as u, l as d, p as f, r as p } from "./schemas-D8_brjAQ.js";
import { r as m } from "./i18n-BRf-wfgm.js";
import { t as h } from "./button-BrPHE1Q9.js";
import { t as g } from "./capture-error-DAZY091e.js";
import { n as _ } from "./account-form-hStE8dzU.js";
import { t as v } from "./account-shell-D0S9QH7J.js";
import { a as y, n as b, t as x } from "./copy-to-clipboard-_taVOi2S.js";
import { t as S } from "./use-assistant-choices-Dluxsq-7.js";
import { useCallback as C, useEffect as w, useMemo as T, useRef as E, useState as D } from "react";
import { Fragment as O, jsx as k, jsxs as A } from "react/jsx-runtime";
var ee = t("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), j = t("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), M = t("save", [
	["path", {
		d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
		key: "1c8476"
	}],
	["path", {
		d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",
		key: "1ydtos"
	}],
	["path", {
		d: "M7 3v4a1 1 0 0 0 1 1h7",
		key: "t51u73"
	}]
]), N = d({ backups: p(d({
	snapshot_name: f(),
	pvc: f().default(""),
	created_at: f(),
	ready_to_use: u(),
	backup_type: f().default("point_in_time")
})) }), P = d({ current_release_version: f().nullable() }), F = d({ url: f().url() }), I = (e, t = "") => `/v1/assistants/${encodeURIComponent(e)}${t}`;
async function L(e, t, n) {
	let { response: r, data: i, detail: a, networkError: o } = await b(e, n);
	return o ? {
		ok: !1,
		status: 0,
		error: y(o)
	} : r?.ok ? {
		ok: !0,
		status: r.status,
		data: i
	} : {
		ok: !1,
		status: r?.status ?? 0,
		error: y(a ?? `${t} (${r?.status ?? 0})`, r ?? void 0)
	};
}
async function te(e) {
	let t = await L(I(e, "/backups/"), "Failed to list assistant backups.");
	if (!t.ok) return t;
	let n = N.safeParse(t.data);
	return n.success ? {
		ok: !0,
		status: t.status,
		data: n.data.backups
	} : {
		ok: !1,
		status: t.status,
		error: y(n.error.message, void 0)
	};
}
async function R(e) {
	let t = await L(I(e, "/backups/"), "Failed to create assistant backup.", {
		method: "POST",
		headers: { "Content-Type": "application/json" }
	});
	return t.ok ? {
		ok: !0,
		status: t.status,
		data: t.data && typeof t.data == "object" && !Array.isArray(t.data) ? t.data : {}
	} : t;
}
async function ne(e, t) {
	let n = await L(I(e, `/backups/${encodeURIComponent(t.snapshot_name)}/restore/`), "Failed to restore assistant backup.", {
		method: "POST",
		headers: { "Content-Type": "application/json" }
	});
	return n.ok ? {
		ok: !0,
		status: n.status,
		data: n.data && typeof n.data == "object" && !Array.isArray(n.data) ? n.data : {}
	} : n;
}
async function z(e) {
	let t = await fetch(I(e, "/"));
	if (!t.ok) throw Error(`The assistant read failed (${t.status})`);
	return P.parse(await t.json()).current_release_version;
}
async function B() {
	let e = await fetch("/v1/releases/");
	if (!e.ok) throw Error(`The releases read failed (${e.status})`);
	return await e.json();
}
async function V(e, t) {
	let n = await fetch(I(e, "/upgrade/"), {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(t)
	});
	if (!n.ok) throw Error(`The upgrade dial failed (${n.status})`);
	return await n.json();
}
async function re(e, t, n, r) {
	let i = await fetch(I(e, "/migrations/signed-url/"), {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({
			operation: "download",
			bundle_key: t,
			download_filename: r
		})
	});
	if (!i.ok) {
		let e = await i.json().then((e) => e.detail).catch(() => null);
		throw Error(typeof e == "string" ? e : `The signed-url dial failed (${i.status})`);
	}
	return F.parse(await i.json()).url;
}
function ie(e, t) {
	return `${e.replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^[^A-Za-z0-9]+/, "").slice(0, 64) || "assistant"}-${t.toISOString().slice(0, 10)}.tar.gz`;
}
function H(e) {
	let [t, ...n] = e.replace(/^[vV]/, "").split("-"), r = n.length > 0 ? n.join("-") : null, i = (t ?? "").match(/^(\d+)\.(\d+)\.(\d+)$/);
	return i ? {
		major: Number(i[1]),
		minor: Number(i[2]),
		patch: Number(i[3]),
		pre: r
	} : null;
}
function U(e, t) {
	let n = e.split("."), r = t.split("."), i = Math.max(n.length, r.length);
	for (let e = 0; e < i; e++) {
		let t = n[e], i = r[e];
		if (t === void 0) return -1;
		if (i === void 0) return 1;
		let a = /^\d+$/.test(t), o = /^\d+$/.test(i);
		if (a && o) {
			let e = Number(t) - Number(i);
			if (e !== 0) return e;
		} else if (a !== o) return a ? -1 : 1;
		else if (t !== i) return t < i ? -1 : 1;
	}
	return 0;
}
function W(e, t) {
	for (let n of [
		"major",
		"minor",
		"patch"
	]) if (e[n] !== t[n]) return e[n] - t[n];
	return e.pre === null && t.pre === null ? 0 : e.pre === null ? 1 : t.pre === null ? -1 : U(e.pre, t.pre);
}
var G = d({ enabled: u() });
async function K(e, t) {
	let n = await L(I(e, "/admin-access/"), "Failed to update assistant admin access.", {
		method: "PATCH",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ enabled: t })
	});
	if (!n.ok) return n;
	let r = G.safeParse(n.data);
	return r.success ? {
		ok: !0,
		status: n.status,
		data: r.data.enabled
	} : {
		ok: !1,
		status: n.status,
		error: y(r.error.message, void 0)
	};
}
//#endregion
//#region src/domains/account/assistants/assistant-backups-table.tsx
var ae = 3, q = {
	point_in_time: "neutral",
	scheduled: "positive",
	preview_channel: "warning",
	doctor: "warning"
};
function J({ type: e }) {
	let { t } = m("account"), n = e;
	return e === "point_in_time" ? n = t("assistantBackups.typePointInTime") : e === "scheduled" ? n = t("assistantBackups.typeScheduled") : e === "preview_channel" ? n = t("assistantBackups.typePreview") : e === "doctor" && (n = t("assistantBackups.typeDoctor")), /* @__PURE__ */ k(a, {
		tone: q[e] ?? "neutral",
		children: n
	});
}
function Y(e) {
	if (e == null) return "—";
	let t = String(e);
	/Z|[+-]\d{2}:?\d{2}$/.test(t) || (t += "Z");
	let n = new Date(t);
	return Number.isNaN(n.getTime()) ? "—" : n.toLocaleString("en-US", {
		year: "numeric",
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
async function oe(e, t) {
	let n = await fetch(e).then((e) => {
		if (!e.ok) throw Error(`The backup download failed (${e.status})`);
		return e.blob();
	}), r = URL.createObjectURL(n);
	try {
		let e = document.createElement("a");
		e.href = r, e.download = t, document.body.appendChild(e), e.click(), e.remove();
	} finally {
		URL.revokeObjectURL(r);
	}
}
function X({ assistantId: e }) {
	let { t } = m("account"), [u, d] = D(null), [f, p] = D(null), [_, v] = D([]), [y, b] = D(0), [S, T] = D(null), [E, j] = D(null), [N, P] = D(!1), [F, I] = D(null), [L, z] = D(null), [B, V] = D(!1), H = C((e) => {
		x(e, {
			errorMessage: t("assistantBackups.copyFailed"),
			onCopied: () => {
				I(e), setTimeout(() => I(null), 2e3);
			}
		});
	}, [t]), U = u !== e;
	w(() => {
		let n = !1;
		return te(e).then((r) => {
			n || (r.ok ? (v(r.data), p(null)) : p(typeof r.error?.detail == "string" ? r.error.detail : t("assistantBackups.loadFailed")), d(e));
		}).catch(() => {
			n || (p(t("assistantBackups.loadFailed")), d(e));
		}), () => {
			n = !0;
		};
	}, [
		e,
		y,
		t
	]);
	let W = C(async () => {
		if (!E) return;
		let n = E;
		j(null), T(n.snapshot_name);
		try {
			let r = await ne(e, n);
			if (r.ok) o.success(t("assistantBackups.restoreSuccessToast")), b((e) => e + 1);
			else {
				let e = typeof r.error?.detail == "string" ? r.error.detail : t("assistantBackups.restoreFailedToast");
				o.error(e);
			}
		} catch {
			o.error(t("assistantBackups.restoreFailedToast"));
		} finally {
			T(null);
		}
	}, [
		e,
		E,
		t
	]), G = C(async () => {
		P(!0);
		try {
			let n = await R(e);
			if (n.ok) o.success(t("assistantBackups.createSuccessToast")), b((e) => e + 1);
			else {
				let e = typeof n.error?.detail == "string" ? n.error.detail : t("assistantBackups.createFailedToast");
				o.error(e);
			}
		} catch {
			o.error(t("assistantBackups.createFailedToast"));
		} finally {
			P(!1);
		}
	}, [e, t]), K = C(async () => {
		V(!1), z("preparing");
		try {
			z("exporting");
			let t = await R(e);
			if (!t.ok) throw Error("Cloud backup creation failed.");
			let n = t.data ?? {};
			if (typeof n.snapshot_name != "string" || !n.snapshot_name) throw Error("Cloud backup creation failed.");
			let r = n.snapshot_name;
			z("downloading");
			let i = ie(e, /* @__PURE__ */ new Date());
			await oe(await re(e, r, void 0, i), i);
		} catch (e) {
			g(e, { context: "assistant-backups-export" }), o.error(t("assistantBackups.exportFailedToast"), { description: e instanceof Error ? e.message : void 0 });
		} finally {
			z(null);
		}
	}, [e, t]);
	if (U) return /* @__PURE__ */ A("div", {
		className: "flex items-center gap-2 text-body-medium-lighter text-[var(--content-tertiary)]",
		children: [/* @__PURE__ */ k(n, { className: "h-4 w-4 animate-spin" }), t("assistantBackups.loading")]
	});
	if (f) return /* @__PURE__ */ A("div", {
		className: "flex items-center gap-2 text-body-medium-lighter text-[var(--system-negative-strong)]",
		children: [/* @__PURE__ */ k(c, { className: "h-4 w-4 shrink-0" }), f]
	});
	let q = _.filter((e) => e.backup_type === "point_in_time").length, X = L !== null, Z = t("assistantBackups.export");
	L === "preparing" ? Z = t("assistantBackups.exportPreparing") : L === "exporting" ? Z = t("assistantBackups.exportExporting") : L === "downloading" && (Z = t("assistantBackups.exportDownloading"));
	let Q = /* @__PURE__ */ A("div", {
		className: "flex flex-wrap items-center justify-end gap-3",
		children: [
			q >= ae && /* @__PURE__ */ k("p", {
				className: "text-body-small-default text-[var(--content-tertiary)]",
				children: t("assistantBackups.oldestRemovedNotice")
			}),
			/* @__PURE__ */ k(h, {
				variant: "outlined",
				loading: X,
				leftIcon: /* @__PURE__ */ k(ee, {}),
				onClick: () => V(!0),
				disabled: X || S !== null,
				className: "shrink-0",
				children: Z
			}),
			/* @__PURE__ */ k(h, {
				variant: "outlined",
				loading: N,
				leftIcon: /* @__PURE__ */ k(M, {}),
				onClick: G,
				disabled: N || S !== null,
				className: "shrink-0",
				children: t(N ? "assistantBackups.creating" : "assistantBackups.createBackup")
			})
		]
	}), $ = /* @__PURE__ */ k(s, {
		open: B,
		title: t("assistantBackups.exportTitle"),
		message: t("assistantBackups.exportMessage"),
		confirmLabel: t("assistantBackups.export"),
		onConfirm: K,
		onCancel: () => V(!1)
	});
	return _.length === 0 ? /* @__PURE__ */ A(O, { children: [/* @__PURE__ */ A("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ k("div", {
			className: "flex justify-end",
			children: Q
		}), /* @__PURE__ */ k("p", {
			className: "text-body-medium-lighter text-[var(--content-tertiary)]",
			children: t("assistantBackups.empty")
		})]
	}), $] }) : /* @__PURE__ */ A(O, { children: [
		/* @__PURE__ */ A("div", {
			className: "space-y-2",
			children: [
				Q,
				/* @__PURE__ */ k("div", {
					className: "hidden lg:block",
					children: /* @__PURE__ */ A("table", {
						className: "w-full table-fixed text-body-medium-lighter",
						children: [/* @__PURE__ */ k("thead", { children: /* @__PURE__ */ A("tr", {
							className: "border-b border-[var(--border-base)] text-left text-body-small-default text-[var(--content-secondary)]",
							children: [
								/* @__PURE__ */ k("th", {
									className: "w-[35%] pb-2 pr-4",
									children: t("assistantBackups.columnSnapshotName")
								}),
								/* @__PURE__ */ k("th", {
									className: "w-[13%] pb-2 pr-4",
									children: t("assistantBackups.columnType")
								}),
								/* @__PURE__ */ k("th", {
									className: "w-[12%] pb-2 pr-4",
									children: t("assistantBackups.columnReady")
								}),
								/* @__PURE__ */ k("th", {
									className: "w-[20%] pb-2 pr-4",
									children: t("assistantBackups.columnCreated")
								}),
								/* @__PURE__ */ k("th", { className: "w-[20%] pb-2" })
							]
						}) }), /* @__PURE__ */ k("tbody", { children: _.map((e) => /* @__PURE__ */ A("tr", {
							className: "border-b border-[var(--border-base)] last:border-0",
							children: [
								/* @__PURE__ */ k("td", {
									className: "py-2.5 pr-4",
									children: /* @__PURE__ */ A("div", {
										"data-reveal-row": "",
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ k("code", {
											className: "truncate text-body-small-default text-[var(--content-default)]",
											title: e.snapshot_name,
											children: e.snapshot_name
										}), /* @__PURE__ */ k(h, {
											variant: "ghost",
											size: "compact",
											iconOnly: F === e.snapshot_name ? /* @__PURE__ */ k(r, { className: "text-green-500" }) : /* @__PURE__ */ k(i, {}),
											expandOnMobile: !1,
											onClick: () => H(e.snapshot_name),
											"data-reveal": "",
											className: "shrink-0",
											tooltip: t("assistantBackups.copySnapshotName"),
											"aria-label": t("assistantBackups.copySnapshotName")
										})]
									})
								}),
								/* @__PURE__ */ k("td", {
									className: "overflow-hidden whitespace-nowrap py-2.5 pr-4",
									children: /* @__PURE__ */ k(J, { type: e.backup_type })
								}),
								/* @__PURE__ */ k("td", {
									className: "overflow-hidden whitespace-nowrap py-2.5 pr-4",
									children: /* @__PURE__ */ k(a, {
										tone: e.ready_to_use ? "positive" : "warning",
										children: e.ready_to_use ? t("assistantBackups.ready") : t("assistantBackups.pending")
									})
								}),
								/* @__PURE__ */ k("td", {
									className: "overflow-hidden whitespace-nowrap py-2.5 pr-4 text-body-medium-default text-[var(--content-default)]",
									children: Y(e.created_at)
								}),
								/* @__PURE__ */ k("td", {
									className: "py-2.5 text-right",
									children: /* @__PURE__ */ k(h, {
										variant: "ghost",
										loading: S === e.snapshot_name,
										leftIcon: /* @__PURE__ */ k(l, {}),
										onClick: () => j(e),
										disabled: S !== null || X || !e.ready_to_use,
										title: e.ready_to_use ? void 0 : t("assistantBackups.notReady"),
										children: t("assistantBackups.restore")
									})
								})
							]
						}, e.snapshot_name)) })]
					})
				}),
				/* @__PURE__ */ k("div", {
					className: "flex flex-col gap-3 lg:hidden",
					children: _.map((e) => /* @__PURE__ */ A("div", {
						className: "rounded-lg border border-[var(--border-base)] p-3",
						children: [
							/* @__PURE__ */ A("div", {
								className: "mb-2 flex items-center gap-1",
								children: [/* @__PURE__ */ k("code", {
									className: "truncate text-body-small-default text-[var(--content-default)]",
									title: e.snapshot_name,
									children: e.snapshot_name
								}), /* @__PURE__ */ k(h, {
									variant: "ghost",
									size: "compact",
									iconOnly: F === e.snapshot_name ? /* @__PURE__ */ k(r, { className: "text-green-500" }) : /* @__PURE__ */ k(i, {}),
									expandOnMobile: !1,
									onClick: () => H(e.snapshot_name),
									className: "shrink-0",
									tooltip: t("assistantBackups.copySnapshotName"),
									"aria-label": t("assistantBackups.copySnapshotName")
								})]
							}),
							/* @__PURE__ */ A("div", {
								className: "mb-2 flex flex-wrap items-center gap-2 text-body-medium-lighter",
								children: [
									/* @__PURE__ */ k(J, { type: e.backup_type }),
									/* @__PURE__ */ k(a, {
										tone: e.ready_to_use ? "positive" : "warning",
										children: e.ready_to_use ? t("assistantBackups.ready") : t("assistantBackups.pending")
									}),
									/* @__PURE__ */ k("span", {
										className: "text-body-small-default text-[var(--content-secondary)]",
										children: Y(e.created_at)
									})
								]
							}),
							/* @__PURE__ */ k(h, {
								variant: "ghost",
								loading: S === e.snapshot_name,
								leftIcon: /* @__PURE__ */ k(l, {}),
								onClick: () => j(e),
								disabled: S !== null || X || !e.ready_to_use,
								title: e.ready_to_use ? void 0 : t("assistantBackups.notReady"),
								children: t("assistantBackups.restore")
							})
						]
					}, e.snapshot_name))
				})
			]
		}),
		/* @__PURE__ */ k(s, {
			open: E !== null,
			title: t("assistantBackups.restoreTitle"),
			message: E ? t("assistantBackups.restoreMessage", { name: E.snapshot_name }) : "",
			confirmLabel: t("assistantBackups.restore"),
			destructive: !0,
			onConfirm: W,
			onCancel: () => j(null)
		}),
		$
	] });
}
//#endregion
//#region src/domains/account/assistants/assistant-admin-access-panel.tsx
function Z({ assistantId: e, adminAccessEnabled: t }) {
	let { t: n } = m("account"), [r, i] = D(t), [a, s] = D(!1);
	w(() => {
		i(t);
	}, [e, t]);
	async function c() {
		if (r == null) return;
		s(!0);
		let t = await K(e, !r);
		s(!1), t.ok ? (i(t.data), o.success(n("assistantsPage.adminAccess.updated"))) : o.error(n("assistantsPage.adminAccess.updateFailed"));
	}
	return r == null ? /* @__PURE__ */ k("p", {
		className: "text-body-medium-lighter text-[var(--content-tertiary)]",
		children: n("assistantsPage.adminAccess.notAvailable")
	}) : /* @__PURE__ */ A("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ k("span", {
			className: "text-body-medium-lighter text-[var(--content-default)]",
			children: n(r ? "assistantsPage.adminAccess.stateOn" : "assistantsPage.adminAccess.stateOff")
		}), /* @__PURE__ */ k(h, {
			variant: "outlined",
			disabled: a,
			onClick: () => {
				c();
			},
			children: n(a ? "assistantsPage.adminAccess.working" : r ? "assistantsPage.adminAccess.disable" : "assistantsPage.adminAccess.enable")
		})]
	});
}
//#endregion
//#region src/domains/account/assistants/assistant-upgrades-panel.tsx
var Q = 3e3;
function $({ version: e }) {
	return /* @__PURE__ */ k("div", {
		className: "min-w-0",
		children: /* @__PURE__ */ k("span", {
			className: "block min-w-0 break-all text-body-medium-lighter text-[var(--content-default)]",
			children: e ?? "—"
		})
	});
}
function se({ assistantId: e }) {
	let { t } = m("account"), [r, i] = D(void 0), [a, c] = D(null), [l, u] = D(!0), [d, f] = D(!1), [p, g] = D(!1), _ = E(null), [v, y] = D(!1), [b, x] = D(null);
	w(() => {
		let t = !1;
		return i(void 0), z(e).then((e) => {
			t || i(e);
		}).catch(() => {
			t || i(null);
		}), () => {
			t = !0;
		};
	}, [e]), w(() => {
		let e = !1;
		return c(null), u(!0), B().then((t) => {
			e || c(t);
		}).catch(() => {
			e || c([]);
		}).finally(() => {
			e || u(!1);
		}), () => {
			e = !0;
		};
	}, []), w(() => {
		if (!d) return;
		let n = setInterval(() => {
			z(e).then((n) => {
				n && _.current && n === _.current && (x(t("assistantUpgrades.successUpdated", { version: _.current })), f(!1), _.current = null, o.success(t("assistantUpgrades.toastUpdateComplete"), {
					id: "runtime-upgrade-complete",
					tone: "strong"
				}), z(e).then((e) => {
					i(e);
				}));
			}).catch(() => {});
		}, Q);
		return () => clearInterval(n);
	}, [
		e,
		d,
		t
	]);
	let S = a?.[0], C = S?.version ?? null, O = T(() => {
		if (!C) return !1;
		if (!r) return !0;
		let e = H(C), t = H(r);
		return !e || !t ? C !== r : W(e, t) > 0;
	}, [C, r]), ee = async () => {
		y(!1), x(null), g(!0);
		try {
			let n = await V(e, {}), r = n.detail;
			if (r?.includes("Already on the latest") && r !== void 0) {
				o.warning(r);
				return;
			}
			_.current = n.version ?? null, o.success(n.detail || t("assistantUpgrades.toastUpdateInitiated", { version: n.version ?? t("assistantUpgrades.latest") })), f(!0), z(e).then((e) => {
				i(e);
			});
		} catch {
			o.error(t("assistantUpgrades.toastUpdateFailed"));
		} finally {
			g(!1);
		}
	};
	function M(e, n) {
		let r = [e.version];
		return C && e.version === C && r.push(t("assistantUpgrades.latestSuffix")), n && e.version === n && r.push(t("assistantUpgrades.currentSuffix")), r.join(" ");
	}
	let N = t(O ? "assistantUpgrades.updateTo" : "assistantUpgrades.selected");
	return /* @__PURE__ */ A("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ A("div", {
				className: "flex flex-col gap-4 md:grid md:grid-cols-[auto_minmax(0,1fr)] md:items-center md:gap-x-8 md:gap-y-4",
				children: [/* @__PURE__ */ A("div", {
					className: "flex flex-col gap-1 md:contents",
					children: [/* @__PURE__ */ k("span", {
						className: "text-body-medium-default text-[var(--content-tertiary)]",
						children: t("assistantUpgrades.current")
					}), /* @__PURE__ */ k($, { version: r })]
				}), /* @__PURE__ */ A("div", {
					className: "flex flex-col gap-1 md:contents",
					children: [/* @__PURE__ */ k("span", {
						className: "text-body-medium-default text-[var(--content-tertiary)]",
						children: N
					}), /* @__PURE__ */ A("div", {
						className: "flex min-w-0 flex-col gap-3 md:flex-row md:items-center md:gap-4",
						children: [/* @__PURE__ */ k("span", {
							className: "block min-w-0 flex-1",
							children: l ? /* @__PURE__ */ A("span", {
								className: "flex items-center gap-1 text-body-medium-lighter text-[var(--content-tertiary)]",
								children: [/* @__PURE__ */ k(n, { className: "h-3 w-3 animate-spin" }), t("assistantUpgrades.loading")]
							}) : a && a.length > 0 ? /* @__PURE__ */ k("span", {
								className: "block min-w-0 break-all text-body-medium-lighter text-[var(--content-default)]",
								children: S ? M(S, r) : "—"
							}) : t("assistantUpgrades.noReleases")
						}), /* @__PURE__ */ k(h, {
							variant: "primary",
							className: "min-w-[160px] shrink-0",
							loading: p || d,
							leftIcon: /* @__PURE__ */ k(j, {}),
							onClick: () => y(!0),
							disabled: !O || p || d || l || !a?.length,
							children: t(d ? "assistantUpgrades.updating" : "assistantUpgrades.update")
						})]
					})]
				})]
			}),
			!O && r && !l && /* @__PURE__ */ k("p", {
				className: "text-body-medium-lighter text-[var(--system-positive-strong)]",
				children: b ?? t("assistantUpgrades.alreadyOnVersion")
			}),
			/* @__PURE__ */ k(s, {
				open: v,
				title: t("assistantUpgrades.confirmUpdateTitle"),
				message: t("assistantUpgrades.confirmUpdateMessage", { version: C ?? t("assistantUpgrades.latest") }),
				confirmLabel: t("assistantUpgrades.update"),
				onConfirm: () => void ee(),
				onCancel: () => y(!1)
			})
		]
	});
}
//#endregion
//#region src/domains/account/pages/assistants-page.tsx
function ce() {
	let { t } = m("account"), { state: r, retry: i } = S(), { assistantId: a } = e(), [o, s] = D(null), c = o ?? a ?? null;
	if (r.status === "loading" || r.status === "error") return /* @__PURE__ */ A(v, { children: [/* @__PURE__ */ k(_, { title: t("assistantsPage.title") }), r.status === "error" ? /* @__PURE__ */ A("div", {
		className: "flex flex-col items-center gap-3",
		children: [/* @__PURE__ */ k("p", {
			className: "text-body-medium-lighter text-[var(--content-tertiary)]",
			children: t("assistantsPage.loadFailed")
		}), /* @__PURE__ */ k(h, {
			variant: "outlined",
			onClick: i,
			children: t("assistantsPage.retry")
		})]
	}) : /* @__PURE__ */ A("div", {
		className: "flex items-center gap-2 text-body-medium-lighter text-[var(--content-tertiary)]",
		children: [/* @__PURE__ */ k(n, { className: "h-4 w-4 animate-spin" }), t("assistantsPage.loading")]
	})] });
	if (r.status === "unauthenticated") return /* @__PURE__ */ A(v, { children: [/* @__PURE__ */ k(_, { title: t("assistantsPage.title") }), /* @__PURE__ */ k("p", {
		className: "text-body-medium-lighter text-[var(--content-tertiary)]",
		children: t("assistantsPage.signInRequired")
	})] });
	let l = r.status === "selection" ? r.assistants : [], u = c == null ? l[0] ?? null : l.find((e) => e.id === c) ?? null;
	return /* @__PURE__ */ A(v, { children: [/* @__PURE__ */ k(_, {
		title: t("assistantsPage.title"),
		subtitle: t("assistantsPage.subtitle")
	}), l.length === 0 ? /* @__PURE__ */ k("p", {
		className: "text-body-medium-lighter text-[var(--content-tertiary)]",
		children: t("assistantsPage.empty")
	}) : /* @__PURE__ */ A("div", {
		className: "flex flex-col gap-6",
		children: [l.length > 1 && /* @__PURE__ */ k("div", {
			className: "flex flex-wrap gap-2",
			children: l.map((e) => /* @__PURE__ */ k("button", {
				type: "button",
				onClick: () => s(e.id),
				className: ["cursor-pointer rounded-lg border px-3 py-1.5 text-sm transition-colors", u?.id === e.id ? "border-[var(--primary-base)] bg-[var(--primary-base)] text-[var(--content-inset)]" : "border-[var(--border-base)] text-[var(--content-default)] hover:bg-[var(--surface-lift)]"].join(" "),
				children: e.name
			}, e.id))
		}), u && /* @__PURE__ */ A(O, { children: [
			/* @__PURE__ */ A("section", { children: [/* @__PURE__ */ k("h3", {
				className: "mb-3 text-body-large-default text-[var(--content-default)]",
				children: t("assistantsPage.upgradesSection")
			}), /* @__PURE__ */ k(se, { assistantId: u.id })] }),
			/* @__PURE__ */ A("section", { children: [/* @__PURE__ */ k("h3", {
				className: "mb-3 text-body-large-default text-[var(--content-default)]",
				children: t("assistantsPage.backupsSection")
			}), /* @__PURE__ */ k(X, { assistantId: u.id })] }),
			/* @__PURE__ */ A("section", { children: [/* @__PURE__ */ k("h3", {
				className: "mb-3 text-body-large-default text-[var(--content-default)]",
				children: t("assistantsPage.adminAccessSection")
			}), /* @__PURE__ */ k(Z, {
				assistantId: u.id,
				adminAccessEnabled: u.allow_admin_access
			})] })
		] })]
	})] });
}
//#endregion
export { ce as AssistantsPage };
