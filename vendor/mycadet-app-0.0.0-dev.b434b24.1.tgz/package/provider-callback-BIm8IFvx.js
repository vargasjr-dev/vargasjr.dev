import { t as e } from "./provider-DTIzxq2J.js";
//#region src/domains/account/provider-callback.ts
var t = "authIntent";
function n(n, r = {}) {
	let i = new URLSearchParams();
	n && i.set("returnTo", n), r.authIntent && i.set(t, r.authIntent);
	let a = i.toString();
	return a ? `${e}?${a}` : e;
}
function r(e) {
	return e.get(t) === "signup" ? "signup" : "login";
}
//#endregion
export { r as n, n as t };
