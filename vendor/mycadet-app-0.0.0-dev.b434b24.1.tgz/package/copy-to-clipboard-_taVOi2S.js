import { g as e } from "./confirm-dialog-DH3yi6Nk.js";
import { t } from "./capture-error-DAZY091e.js";
//#region src/utils/api-errors.ts
function n(e, t) {
	return e && typeof e == "object" && !Array.isArray(e) ? e : typeof e == "string" && !e.trimStart().startsWith("<") ? { detail: e.slice(0, 500) || t?.statusText || "Request failed." } : { detail: t?.statusText || "Request failed." };
}
function r(e, t, n) {
	if (e && typeof e == "object" && !Array.isArray(e)) {
		if ("detail" in e && typeof e.detail == "string") return e.detail;
		if ("error" in e) {
			if (typeof e.error == "string") return e.error;
			if (e.error && typeof e.error == "object" && "message" in e.error && typeof e.error.message == "string") return e.error.message;
		}
		if ("message" in e && typeof e.message == "string") return e.message;
	}
	return typeof e == "string" && e && !e.trimStart().startsWith("<") ? e : n ?? (t ? `HTTP ${t.status}` : "Request failed.");
}
var i = class extends Error {
	status;
	code;
	details;
	constructor(e, t, n = {}) {
		super(t), this.name = "ApiError", this.status = e, n.code !== void 0 && (this.code = n.code), n.details !== void 0 && (this.details = n.details);
	}
};
//#endregion
//#region src/lib/dial.ts
async function a(e, t) {
	let n;
	try {
		n = await fetch(e, t);
	} catch (e) {
		return {
			response: null,
			data: null,
			detail: null,
			networkError: e
		};
	}
	let r = await n.text().catch(() => null), i = null;
	if (r !== null) try {
		i = JSON.parse(r);
	} catch {
		i = null;
	}
	let a = null;
	if (!n.ok && typeof i == "object" && i) {
		let e = i.detail;
		a = typeof e == "string" ? e : null;
	}
	return {
		response: n,
		data: i,
		detail: a,
		networkError: null
	};
}
//#endregion
//#region src/lib/copy-to-clipboard.ts
function o(n, r) {
	if (!navigator.clipboard?.writeText) {
		t(/* @__PURE__ */ Error("Clipboard API unavailable"), { context: "copyToClipboard" }), e.error(r.errorMessage);
		return;
	}
	navigator.clipboard.writeText(n).then(() => {
		r.onCopied?.(), r.successMessage && e.success(r.successMessage);
	}, (n) => {
		t(n, { context: "copyToClipboard" }), e.error(r.errorMessage);
	});
}
//#endregion
export { n as a, r as i, a as n, i as r, o as t };
