//#region src/runtime/native-deep-link.ts
var e = {
	"www.mycadet.ai": "cadet",
	"mycadet.ai": "cadet",
	"staging.mycadet.ai": "cadet-staging",
	"dev.mycadet.ai": "cadet-dev"
};
function t(t) {
	return e[t] ?? null;
}
var n = "oauth-complete";
function r(e, t) {
	let r = new URLSearchParams();
	return r.set("requestId", t.requestId), t.oauthStatus !== null && r.set("oauth_status", t.oauthStatus), t.oauthProvider !== null && r.set("oauth_provider", t.oauthProvider), t.oauthCode !== null && r.set("oauth_code", t.oauthCode), `${e}://${n}?${r.toString()}`;
}
//#endregion
export { t as n, r as t };
