import { d as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { t as n } from "./oauth-popup-UrZVjT5L.js";
import { useEffect as r, useRef as i } from "react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/domains/account/pages/oauth-complete-page.tsx
function s() {
	return /* @__PURE__ */ o("svg", {
		className: "oauth-icon",
		viewBox: "0 0 56 56",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		children: [/* @__PURE__ */ a("circle", {
			cx: "28",
			cy: "28",
			r: "28",
			fill: "var(--oauth-positive-bg)"
		}), /* @__PURE__ */ a("path", {
			className: "oauth-check",
			d: "M17 28.5L24.5 36L39 21",
			stroke: "var(--oauth-positive-fg)",
			strokeWidth: "3.5",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			fill: "none"
		})]
	});
}
function c() {
	return /* @__PURE__ */ o("svg", {
		className: "oauth-icon",
		viewBox: "0 0 56 56",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		children: [
			/* @__PURE__ */ a("circle", {
				cx: "28",
				cy: "28",
				r: "28",
				fill: "var(--oauth-negative-bg)"
			}),
			/* @__PURE__ */ a("path", {
				className: "oauth-cross oauth-cross-1",
				d: "M20 20L36 36",
				stroke: "var(--oauth-negative-fg)",
				strokeWidth: "3.5",
				strokeLinecap: "round",
				fill: "none"
			}),
			/* @__PURE__ */ a("path", {
				className: "oauth-cross oauth-cross-2",
				d: "M36 20L20 36",
				stroke: "var(--oauth-negative-fg)",
				strokeWidth: "3.5",
				strokeLinecap: "round",
				fill: "none"
			})
		]
	});
}
var l = "\n  :root {\n    --oauth-surface: #F5F3EB;\n    --oauth-surface-card: #FFFFFF;\n    --oauth-card-border: #E8E6DA;\n    --oauth-text-primary: #2A2A28;\n    --oauth-text-secondary: #4A4A46;\n    --oauth-positive-bg: #D4DFD0;\n    --oauth-positive-fg: #516748;\n    --oauth-negative-bg: #F7DAC9;\n    --oauth-negative-fg: #DA491A;\n    --oauth-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06);\n    --oauth-font: -apple-system, BlinkMacSystemFont, \"SF Pro Text\", \"Helvetica Neue\", sans-serif;\n  }\n  @media (prefers-color-scheme: dark) {\n    :root:not(.light) {\n      --oauth-surface: #1A1A18;\n      --oauth-surface-card: #2A2A28;\n      --oauth-card-border: #3A3A37;\n      --oauth-text-primary: #F5F3EB;\n      --oauth-text-secondary: #BDB9A9;\n      --oauth-positive-bg: #1A2316;\n      --oauth-positive-fg: #7A8B6F;\n      --oauth-negative-bg: #4E281D;\n      --oauth-negative-fg: #E86B40;\n      --oauth-shadow: 0 1px 3px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.3);\n    }\n  }\n  :root[data-theme=\"dark\"] {\n    --oauth-surface: #1A1A18;\n    --oauth-surface-card: #2A2A28;\n    --oauth-card-border: #3A3A37;\n    --oauth-text-primary: #F5F3EB;\n    --oauth-text-secondary: #BDB9A9;\n    --oauth-positive-bg: #1A2316;\n    --oauth-positive-fg: #7A8B6F;\n    --oauth-negative-bg: #4E281D;\n    --oauth-negative-fg: #E86B40;\n    --oauth-shadow: 0 1px 3px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.3);\n  }\n  .oauth-page {\n    font-family: var(--oauth-font);\n    background: var(--oauth-surface);\n    color: var(--oauth-text-primary);\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    min-height: 100vh;\n    margin: 0;\n    padding: 0;\n    -webkit-font-smoothing: antialiased;\n  }\n  .oauth-card {\n    display: flex;\n    flex-direction: column;\n    align-items: center;\n    text-align: center;\n    padding: 48px 40px 40px;\n    background: var(--oauth-surface-card);\n    border: 1px solid var(--oauth-card-border);\n    border-radius: 16px;\n    box-shadow: var(--oauth-shadow);\n    max-width: 380px;\n    width: 100%;\n    opacity: 0;\n    transform: translateY(8px) scale(0.98);\n    animation: oauthCardIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) 0.1s forwards;\n  }\n  @keyframes oauthCardIn {\n    to { opacity: 1; transform: translateY(0) scale(1); }\n  }\n  .oauth-icon {\n    width: 56px;\n    height: 56px;\n    margin-bottom: 20px;\n    flex-shrink: 0;\n  }\n  .oauth-check {\n    stroke-dasharray: 32;\n    stroke-dashoffset: 32;\n    animation: oauthDraw 0.4s ease-out 0.45s forwards;\n  }\n  .oauth-cross {\n    stroke-dasharray: 22;\n    stroke-dashoffset: 22;\n  }\n  .oauth-cross-1 { animation: oauthDraw 0.3s ease-out 0.45s forwards; }\n  .oauth-cross-2 { animation: oauthDraw 0.3s ease-out 0.55s forwards; }\n  @keyframes oauthDraw {\n    to { stroke-dashoffset: 0; }\n  }\n  .oauth-card h1 {\n    font-size: 18px;\n    font-weight: 600;\n    letter-spacing: -0.2px;\n    color: var(--oauth-text-primary);\n    margin: 0 0 6px;\n  }\n  .oauth-card p {\n    font-size: 13px;\n    line-height: 1.5;\n    color: var(--oauth-text-secondary);\n    margin: 0;\n  }\n";
function u(e) {
	return e.split(/[-_]/).map((e) => e.charAt(0).toUpperCase() + e.slice(1)).join(" ");
}
function d(e, t) {
	if (t.opener && t.opener.postMessage(e, t.origin), e.requestId) try {
		t.storage.setItem(n(e.requestId), JSON.stringify(e));
	} catch {}
	t.close();
}
function f() {
	let { t: n } = t("account"), [f] = e(), p = f.get("requestId"), m = f.get("oauth_status"), h = f.get("oauth_provider"), g = f.get("oauth_code"), _ = h ? u(h) : "", v = m === "connected", y = v ? _ ? `Connected to ${_}` : "Authorization Successful" : "Authorization Failed", b = v ? "You can close this tab and return to your assistant." : `${_ || "Service"} connection failed. You can try again from the desktop app.`, x = i(!1);
	return r(() => {
		x.current || (x.current = !0, d({
			type: "cadet:oauth-complete",
			requestId: p,
			oauthStatus: m || null,
			oauthProvider: h || null,
			oauthCode: g || null
		}, {
			opener: window.opener,
			origin: window.location.origin,
			storage: window.localStorage,
			close: () => window.close()
		}));
	}, [
		p,
		m,
		h,
		g
	]), /* @__PURE__ */ o("div", {
		className: "oauth-page",
		children: [/* @__PURE__ */ a("style", { dangerouslySetInnerHTML: { __html: l } }), /* @__PURE__ */ o("div", {
			className: "oauth-card",
			children: [
				a(v ? s : c, {}),
				/* @__PURE__ */ a("h1", { children: y }),
				/* @__PURE__ */ a("p", { children: b }),
				!v && g && /* @__PURE__ */ a("p", {
					style: {
						marginTop: 8,
						fontSize: 11,
						color: "var(--oauth-text-secondary)",
						opacity: .7
					},
					children: n("oauthComplete.errorCode", { code: g })
				})
			]
		})]
	});
}
//#endregion
export { f as OAuthCompletePage };
