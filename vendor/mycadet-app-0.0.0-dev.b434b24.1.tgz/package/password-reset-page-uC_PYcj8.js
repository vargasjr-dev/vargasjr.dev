import { n as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n as t } from "./routes-DW44XTQk.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/domains/account/pages/password-reset-page.tsx
function r() {
	return /* @__PURE__ */ n(e, {
		to: t.account.login,
		replace: !0
	});
}
//#endregion
export { r as PasswordResetPage };
