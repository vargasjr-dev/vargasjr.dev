//#region src/i18n/locales/zh/common.json
var e = {
	build: "构建",
	taglineMacOS: "您的 Mac AI 助手",
	taglineWindows: "您的 Windows PC AI 助手",
	version: "版本"
}, t = {
	connecting: "正在连接到您的助手…",
	logIn: "登录",
	logOut: "注销",
	errorTitle: "无法连接到您的助手",
	retry: "重试"
}, n = {
	cancel: "取消",
	credentialSaved: "凭据已保存。",
	description: "添加 API 密钥或令牌，以便工具和集成可以使用它。",
	fieldLabel: "字段",
	fieldPlaceholder: "例如 api_token",
	labelOptional: "标签（可选）",
	labelPlaceholder: "例如 GitHub 个人访问令牌",
	save: "保存",
	saveFailed: "保存凭据失败",
	serviceLabel: "服务",
	servicePlaceholder: "例如 github",
	title: "添加凭据",
	valueLabel: "值",
	valuePlaceholder: "输入秘密值"
}, r = {
	amount: "金额",
	cancel: "取消",
	configureAutoReload: "配置自动充值",
	continue: "继续",
	description: "您将被重定向到 Stripe 完成支付。",
	title: "添加点数"
}, i = {
	openApp: "打开应用",
	pin: "置顶",
	previewTitle: "{name} 预览",
	unpin: "取消置顶"
}, a = {
	close: "关闭",
	copyLink: "复制链接",
	deploy: "部署",
	deployToVercel: "部署到 Vercel",
	deployToVercelSubtitle: "发布为静态页面",
	deployedCopyLinkAria: "已部署到 Vercel，复制链接",
	deployedCopyLinkTooltip: "已部署：复制链接",
	deployedToVercel: "已部署到 Vercel",
	deploying: "正在部署…",
	edit: "编辑",
	expandApp: "展开应用",
	fullscreen: "全屏",
	openApp: "打开应用",
	redeploy: "重新部署",
	redeploySubtitle: "发布当前版本",
	share: "分享",
	shareAndDeploy: "分享并部署",
	shareExportSubtitle: "导出为 .cadet 文件",
	sharing: "正在分享…"
}, o = { exitFullscreen: "退出全屏" }, s = { failed: "连接助手失败。" }, c = { setUp: "设置邮箱" }, l = { updateFailed: "无法更新“{label}”。您的更改已恢复。" }, u = {
	accent: "强调色",
	accentAutomatic: "自动",
	accentPickerLabel: "强调色",
	accentReset: "重置",
	body: "身体",
	color: "颜色",
	eyes: "眼睛",
	keepUploadedDescription: "保存角色会替换它",
	keepUploadedLabel: "保留您上传的图片",
	loadError: "无法加载头像组件。请确保您的助手正在运行。",
	name: "名称",
	next: "下一个 {label}",
	previous: "上一个 {label}",
	randomize: "随机化",
	save: "保存",
	saving: "正在保存…",
	title: "更新头像",
	uploadImage: "上传图片",
	uploadedAlt: "已上传头像",
	useCharacterDescription: "从我们内置的头像中选择",
	useCharacterLabel: "改用角色"
}, d = {
	bySigner: "由 {name}",
	cancel: "取消",
	capabilities: "功能",
	createdBy: "创建者",
	hideWarnings: "隐藏警告 ({count})",
	install: "安装",
	installAnyway: "仍然安装",
	loading: "正在加载...",
	showWarnings: "显示警告 ({count})",
	size: "大小"
}, f = { body: "您的助手通过您自己配置的提供商进行语音交互。请在<settingsLink>模型与服务</settingsLink>中设置其语音。" }, p = {
	verifyTitle: "最后一步：确认您的身份",
	verifyAction: "验证我",
	verifyBody: "您的助手还不知道哪个 {channel} 账号是您的，所以暂时不会回复您。在聊天中说“在 {channel} 上验证我”即可完成。",
	verifyActionBody: "您的助手还不知道哪个 {channel} 账号是您的，所以暂时不会回复您。它会在聊天中陪您完成。",
	verifiedTitle: "身份已验证",
	verifiedBody: "您的助手已识别您的 {channel} 账号，会回复您。一切就绪。"
}, m = {
	alt: "助手头像",
	fallbackLetter: "V"
}, h = { alt: "助手头像" }, g = { actionsTitle: "{title} 操作" }, _ = {
	ariaLabel: "命令面板",
	clear: "清除",
	clearSearch: "清除搜索",
	closeSearch: "关闭搜索",
	noResults: "无结果",
	placeholder: "搜索对话、记忆…",
	searchAriaLabel: "搜索",
	searching: "正在搜索…"
}, v = {
	announcement: {
		body: "现在，无论你在桌面上的哪个位置，我都能陪你一起工作。",
		cards: {
			context: {
				body: "让我看到你所看到的内容，结合情境为你提供帮助。",
				title: "展示并讲解"
			},
			flow: {
				body: "无需离开当前应用，随时都能找到我。",
				title: "保持专注和节奏"
			},
			together: {
				body: "和我交谈、指点，一起推进工作。",
				title: "并肩协作"
			}
		},
		close: "关闭",
		previewLabel: "你的桌面助手",
		previewAssistantName: "Quill",
		start: "出发吧",
		title: "在你工作的地方与我相遇"
	},
	ariaLabel: "介绍您的助手",
	back: "上一步",
	call: {
		click: "点击",
		line: "正在聆听",
		shortcut: "快捷键"
	},
	close: "关闭",
	done: "知道了",
	draw: {
		body: "指出屏幕上的任何内容",
		title: "标注"
	},
	idle: {
		body: "把光标移到我上面，我就出来。",
		title: "嘿，是我",
		titleNamed: "嘿，我是 {name}"
	},
	key: {
		scolded: "不是这个，是键盘上的那个键",
		title: "让我更方便地和你交谈"
	},
	meet: { body: "我会在您的桌面上，即使 Cadet 不可见。" },
	mute: {
		body: "点击麦克风把自己静音，点击喇叭把我静音",
		title: "静音"
	},
	next: "下一步",
	share: {
		body: "把标签页、窗口或整个屏幕分享给我",
		title: "分享您的屏幕"
	},
	talk: {
		body: "点击我就能开始对话。",
		gesture: "或者连按两次这个键：",
		greeted: "成功了！就这么简单。",
		title: "和我说话"
	},
	try: {
		body: "跟我打个招呼，我会说出声来回答。",
		how: "点击我，或连按两次这个键",
		title: "试一试"
	},
	permission: {
		microphoneAction: "启用麦克风",
		microphoneSettingsHint: "在系统设置中打开 Cadet 的麦克风开关，然后返回这里。",
		microphonePromptHint: "macOS 会请求你允许使用麦克风。",
		microphoneBody: "允许我使用你的麦克风进行语音对话。",
		shortcutBody: "允许我在你使用其他应用时识别快捷键。",
		screenAction: "启用屏幕共享",
		screenBody: "设置屏幕共享。使用时再选择要共享的内容。",
		openSettings: "打开设置",
		settingsHint: "在系统设置中允许访问，然后返回这里。",
		restricted: "你的 Mac 限制了此权限。你可以跳过此步骤。",
		error: "无法检查访问权限。请重试。",
		waiting: "正在检查访问权限…",
		skip: "暂时跳过"
	}
}, y = {
	allow: "允许",
	confirm: "确认",
	credentialLabel: "凭据",
	defaultSuffix: "（默认）",
	deny: "拒绝",
	dismiss: "关闭",
	enter: "输入",
	microphoneFallback: "麦克风 {index}",
	microphonePermissionHint: "允许访问麦克风后即可按名称查看每个麦克风。",
	microphoneTitle: "麦克风",
	needsCredentials: "需要凭据",
	needsCredentialsFor: "需要 {service} 的凭据",
	needsOkCount: "{count, plural, other {有 # 项需要你的同意}}",
	notNow: "暂不",
	openApp: "打开 Cadet",
	pendingBadge: "{count, plural, other {有 # 项需要你的同意}}",
	previewVoice: "试听 {voice}",
	review: "查看",
	savedMicrophone: "已保存的麦克风",
	savedMicrophoneNotConnected: "已保存的麦克风（未连接）",
	stopPreview: "停止试听",
	surfaceFallback: "有内容要给你看",
	systemDefault: "系统默认",
	voiceTitle: "声音"
}, b = {
	calling: "正在呼叫…",
	callingNamed: "正在呼叫 {name}…",
	captureKind: "来源类型",
	captureNothing: "没有可显示的内容",
	capturePicker: "教学来源",
	captureScreen: "屏幕 {n}",
	captureScreens: "屏幕",
	captureTabs: "Chrome 标签页",
	captureWindows: "窗口",
	draw: "绘制",
	clearMarks: "清除标记",
	drawTools: "绘图工具",
	drawFreehand: "自由绘制",
	drawLine: "直线",
	drawBox: "方框",
	drawCircle: "圆形",
	endSession: "结束会话",
	muteAssistant: "静音助手",
	muteAssistantNamed: "静音 {name}",
	muteMicrophone: "静音麦克风",
	notNow: "暂不",
	offerCopy: "复制",
	offerDiscard: "丢弃",
	offerHeard: "{app} 已粘贴了那段",
	offerNowhere: "没有地方可以放",
	offerPasteFailed: "无法粘贴这些内容",
	offerQuit: "退出 {app}",
	offerUse: "使用 Cadet 的版本",
	offerVersion: "Cadet 听到的是",
	openCadet: "打开 Cadet",
	share: "共享",
	sharePicker: "共享来源",
	showSummary: "显示摘要",
	stopTeaching: "停止教学",
	summarizing: "正在摘要",
	talk: "交谈",
	teach: "教学",
	unmuteAssistant: "取消助手静音",
	unmuteAssistantNamed: "取消 {name} 静音",
	unmuteMicrophone: "取消麦克风静音",
	dictating: "正在聆听",
	dictatingTranscribing: "正在思考",
	chooseMicrophone: "选择麦克风",
	workCount: "{count, plural, =0 {没有正在进行的任务} other {# 项任务进行中}}",
	workDone: "已完成",
	workStopped: "已停止",
	workMore: "还有 {count} 项",
	workWaiting: "{count, plural, other {# 项等待你的回复}}",
	workWaitingStep: "等待你的回复",
	captureScreenRecordingOff: "屏幕录制已关闭",
	captureTurnOnScreenRecording: "开启"
}, x = {
	sharingScreen: "正在分享你的屏幕",
	sharingScreenNamed: "正在与 {name} 分享你的屏幕",
	sharingWindow: "正在分享一个窗口",
	sharingWindowNamed: "正在与 {name} 分享一个窗口",
	teaching: "正在教学",
	teachingNamed: "正在教 {name}"
}, S = {
	copiedAria: "已复制",
	copyFailed: "无法复制文件内容。",
	copyFileContentsAria: "复制文件内容",
	downloadFileAria: "下载文件",
	editFileAria: "编辑文件"
}, C = { untitled: "无标题" }, w = {
	copied: "已复制",
	copyFailed: "无法复制到剪贴板。"
}, T = {
	cancel: "取消",
	create: "创建",
	description: "配置一个新助手。它将在后台启动。",
	namePlaceholder: "助手名称（可选）",
	title: "新助手",
	toastSuccess: "新助手已创建。"
}, E = {
	ariaLabel: "日期范围",
	lastDays: "{days, plural, other {过去 # 天}}"
}, D = {
	delete: "删除",
	deleting: "正在删除…",
	message: "\"{name}\" 将被永久删除。",
	title: "删除应用"
}, O = {
	confirmLabel: "让您的助手处理",
	confirmLabelNamed: "让 {assistantName} 处理",
	message: "\"{appName}\" 使用后端服务，这些服务无法在静态 Vercel 页面上运行。您的助手可以使用无服务器函数正确部署它。",
	messageNamed: "\"{appName}\" 使用后端服务，这些服务无法在静态 Vercel 页面上运行。{assistantName} 可以使用无服务器函数正确部署它。",
	title: "此应用需要完整部署"
}, k = {
	appExported: "应用已导出",
	deployFailed: "部署失败",
	deployedToVercel: "已部署到 Vercel",
	open: "打开",
	shareFailed: "分享应用失败"
}, A = { tooltip: "停止" }, j = {
	copy: "复制",
	expandedValue: "展开的值",
	showLess: "显示更少",
	showMore: "显示更多"
}, M = { stopRecording: "停止录音" }, N = {
	ariaLabel: "加入 Cadet Discord 社区",
	ctaLong: "加入 Discord",
	ctaShort: "加入",
	subtitleLong: "与团队交流 - 分享反馈、请求功能、更快获得答案",
	subtitleShort: "分享反馈、请求功能、更快获得答案",
	title: "加入我们的社区！"
}, P = {
	instructions: "粘贴您从“机器人”页面复制的机器人令牌。",
	verificationNoticeTitle: "请忽略“验证您的应用”页面",
	verificationNoticeBody: "Discord 对每个新应用都会显示它。只有超过 100 个服务器时才有意义。",
	botTokenLabel: "机器人令牌",
	save: "连接",
	saving: "正在连接...",
	saved: "已连接。接下来，将机器人添加到服务器。",
	botTokenPlaceholder: "MTk4NjIyNDgzNzAyNDU0..."
}, F = {
	inPortal: "在 Discord 开发者门户中：",
	stepCreateApp: "点击<strong>New Application</strong>，并用您助手的名字命名应用：",
	copyName: "复制名称",
	copied: "已复制！",
	stepAppIcon: "可选：下载头像，然后在<strong>一般信息</strong>页面上传为应用图标。",
	stepResetToken: "前往应用菜单中的<strong>机器人</strong>页面，点击<strong>重置令牌</strong>并立即复制令牌。Discord 只显示一次。",
	stepIntentsOff: "在同一页面，保持三个<strong>特权网关意图</strong>开关全部关闭。您的助手不需要它们：它只读取私信和提及它的消息。",
	openPortal: "打开 Discord 门户",
	continue: "我已拥有令牌"
}, I = {
	connectedTitle: "机器人已添加",
	connectedBody: "令牌已保存，机器人已加入您的服务器。Discord 这边已完成。"
}, L = {
	instructions: "机器人加入服务器前什么都看不到、也无法回复。打开链接，选择您的服务器并批准。",
	openInvite: "添加到服务器",
	confirmJoined: "我已添加机器人",
	noAppId: "请先连接机器人令牌，然后返回此处将其添加到服务器。"
}, R = {
	channelLabel: "Discord",
	stepCreate: "创建应用",
	stepConnect: "连接",
	stepInvite: "添加到服务器",
	stepFinish: "完成",
	copyError: "无法复制名称。请改为在 Discord 中输入。"
}, z = {
	acknowledge: "确认",
	acknowledging: "正在确认...",
	cleanupBody: "提示您的助手释放空间，以免空间耗尽并进入锁定状态。",
	cleanupTitle: "清理模式已激活",
	criticalBody: "如果存储空间耗尽，您的助手将进入锁定状态。",
	criticalModalDescription: "如果存储空间耗尽，您的助手将进入锁定状态。您应该提示您的助手释放空间或增加存储空间。",
	criticalTitle: "存储空间严重不足",
	dontShowAgain: "不再显示",
	manageStorage: "管理存储",
	review: "查看",
	upgrade: "升级",
	warningBody: "释放空间以避免中断。",
	warningBodyWithUpgrade: "释放空间或增加更多存储空间以避免中断。",
	warningTitle: "您的存储空间即将耗尽"
}, B = {
	failed: "下载失败",
	revealMac: "在访达中显示",
	revealWindows: "在文件资源管理器中显示",
	saved: "已保存到“下载”",
	started: "下载已开始",
	startedDescription: "请在浏览器的下载内容中查找 {filename}。"
}, V = {
	discard: "放弃",
	save: "保存",
	saving: "正在保存…"
}, H = { close: "关闭" }, U = {
	formatted: "格式化",
	modeAria: "如何显示此文件",
	source: "源码"
}, W = {
	copyAriaLabel: "复制邀请链接",
	createFailed: "创建邀请链接失败。请确保您的助手已启用 A2A。",
	creating: "正在创建邀请链接…",
	done: "完成",
	shareHint: "与另一位助手所有者分享此链接以建立连接。",
	title: "分享连接链接",
	tryAgain: "重试"
}, G = {
	ariaLabel: "Cadet 在 GitHub 上开源",
	ctaAriaLabel: "在 GitHub 上为 Cadet 点赞",
	ctaLabel: "为我们点赞",
	subtitle: "在 GitHub 上为我们点赞或贡献代码",
	title: "Cadet 是开源的"
}, K = { loadError: "此部分无法加载。请重新加载页面重试。" }, q = { goToConversation: "前往对话" }, J = {
	ariaLabelMacOS: "下载 macOS 应用",
	ariaLabelWindows: "下载 Windows 应用",
	ctaAriaLabelMacOS: "下载 macOS 应用",
	ctaAriaLabelWindows: "下载 Windows 应用",
	ctaLabel: "下载",
	subtitle: "电脑使用 · 终端访问 · 原生自动化",
	titleMacOS: "获取 macOS 应用",
	titleWindows: "获取 Windows 应用"
}, Y = {
	bannerAria: "下载 {appName} 应用",
	bannerAriaGeneric: "下载 Cadet 移动应用",
	download: "下载",
	downloadAppAria: "下载 {appName} 应用",
	downloadAppAriaGeneric: "下载 Cadet 移动应用",
	subtitle: "推送通知 · 生物识别登录 · 触觉反馈",
	title: "获取 {appName} 应用",
	titleGeneric: "获取 Cadet 应用"
}, X = { dismissAria: "关闭" }, Z = { back: "返回" }, Q = {
	cancel: "取消",
	logIn: "登录"
}, $ = {
	assistantHandleIdleEmpty: "您的助手尚未设置句柄，请设置一个以便提及。",
	assistantHandleLabel: "助手句柄",
	assistantHandleUpdated: "助手句柄已更新。",
	available: "可用",
	availableHelper: "可用。",
	checkAvailabilityFailed: "无法检查可用性。",
	checkingAvailability: "正在检查可用性…",
	chooseDifferentHandle: "请选择一个不同的句柄。",
	emailLabel: "电子邮件",
	handleHelper: "小写字母、数字、连字符和下划线。3–30个字符。",
	handleLocked: "您的助手句柄已锁定，因为它被用作其电子邮件子域名。要更改它，请先<releaseLink>释放子域名</releaseLink>。",
	loading: "正在加载您的个人资料…",
	notAvailable: "不可用",
	profileUpdated: "个人资料已更新。",
	save: "保存",
	saved: "已保存",
	saving: "正在保存…",
	subtitle: "管理您的账户详情和偏好设置。",
	title: "个人资料",
	userHandleIdleAutoGenerated: "您的句柄是在注册时自动生成的 - 请选择一个您喜欢的。",
	userHandleLabel: "用户句柄"
}, ee = { created: "个人资料“{name}”已创建" }, te = {
	logoAlt: "Cadet",
	placeholder: "向 Cadet 提问...",
	send: "发送消息"
}, ne = {
	confirm: "移除",
	messageOrigin: "这不会影响 {assistantName} 或让您在那里退出登录。它只会忘记此设备上的条目。您可以随时再次添加。",
	messagePaired: "这不会影响 {assistantName} 在其主机上的状态。它只会忘记此设备上的配对。您可以随时使用 cadet connect import 再次配对。",
	messagePlatform: "这不会删除 {assistantName}。它只会将其从此设备中移除。登录后它将再次可用。",
	title: "从该设备移除？",
	removeFailed: "从助手移除设备失败。"
}, re = {
	body: "您的助手正在努力工作，并已达到其当前资源限制。请升级以确保其平稳运行。",
	bodyNoUpgrade: "您的助手正在努力工作，并已达到其当前资源限制。",
	dontShowAgain: "不再显示",
	title: "您的助手需要更多算力",
	titleNamed: "{assistantName} 需要更多算力",
	upgrade: "升级"
}, ie = {
	confirmLabel: "停用",
	message: "这将永久停用此助手及其所有数据。您需要重新完成引导流程才能创建新助手。此操作无法撤销。",
	title: "停用助手"
}, ae = { loadingAria: "正在加载" }, oe = { loadingAria: "正在加载" }, se = { unnamedAssistant: "该助手" }, ce = {
	chunkFailBody: "此部分无法加载。可能是网络故障或版本过旧。请重新加载页面重试。",
	reload: "重新加载"
}, le = {
	confirmMessage: "更新到版本 {version}？更新期间助手将暂时不可用。",
	confirmTitle: "更新助手运行时",
	later: "稍后",
	title: "有新的助手版本可用：{version}",
	toastComplete: "更新完成。您的助手运行正常。",
	toastFailed: "未能触发更新。请重试。",
	update: "更新"
}, ue = { ariaLabel: "{name} 操作" }, de = {
	reset: "重置",
	save: "保存"
}, fe = { label: "分享连接链接" }, pe = {
	aboutDiagnosticsAria: "关于诊断信息",
	addFiles: "添加文件",
	adminOnlyHint: "仅限管理员 - 在本地构建诊断存档并下载，而不是提交反馈或通知 Slack。",
	attachments: "附件",
	bugTip: "提示：在我们的 <discordLink>Discord 社区</discordLink> 发布问题可获得更快的支持",
	cancel: "取消",
	category: "类别",
	closeAria: "关闭",
	diagnosticsTooltip: "诊断信息包括浏览器上下文、助手日志和时间戳，绝不包含密码或凭据。",
	downloadDiagnostics: "直接下载诊断信息",
	downloadDiagnosticsAria: "直接下载诊断信息",
	downloadDiagnosticsButton: "下载诊断信息",
	dropFiles: "拖放文件以附加…",
	email: "电子邮件",
	featureTip: "提示：在我们的 <roadmapLink>公开路线图</roadmapLink> 上为功能投票",
	includeConversation: "包含最近的对话",
	includeConversationAria: "包含最近的对话",
	includeDiagnostics: "包含诊断信息",
	includeDiagnosticsAria: "包含浏览器诊断信息",
	messageLabelBug: "哪里出错了？",
	messageLabelFeature: "描述您的想法",
	messageLabelOther: "您有什么想法？",
	messagePlaceholderBug: "您预期会发生什么，实际发生了什么？",
	messagePlaceholderFeature: "这将为您解决什么问题？",
	messagePlaceholderOther: "分享您的想法...",
	preparingDiagnostics: "正在准备诊断信息…",
	reasonBugReport: "错误报告",
	reasonFeatureRequest: "功能请求",
	reasonOther: "其他",
	removeAttachmentAria: "移除 {name}",
	sendingFeedback: "正在发送反馈…",
	submit: "提交",
	timeRange: "时间范围",
	timeRangeAllTime: "所有时间",
	timeRangeAria: "诊断信息时间范围",
	timeRangePast24Hours: "过去 24 小时",
	timeRangePastHour: "过去一小时",
	title: "分享反馈"
}, me = { loadingAria: "正在加载反馈表单" }, he = {
	close: "关闭",
	message: "无法加载反馈表单。",
	retry: "重试"
}, ge = {
	closeAria: "关闭",
	closeSidebarAria: "关闭侧边栏",
	openSidebarAria: "打开侧边栏"
}, _e = {
	backFrom: "从 {title} 返回",
	backToMenu: "返回 {title} 菜单",
	navigationAria: "{title} 导航"
}, ve = { ariaLabel: "侧边栏导航" }, ye = { label: "从本次对话中学习" }, be = {
	message: "从该助手移除“{name}”？",
	remove: "移除",
	title: "移除技能"
}, xe = {
	approvalNotice: "如果 Slack 显示“请求批准”而不是<strong>安装</strong>，则工作区管理员需要先批准该应用。",
	createdApp: "我已创建应用",
	inSlack: "在 Slack 中：",
	stepManifest: "在<strong>或以您自己的方式开始</strong>下，选择<strong>从清单</strong>，然后选择<strong>继续</strong>",
	stepPaste: "选择您的工作区并粘贴清单",
	stepReview: "审查权限，然后点击<strong>创建并安装</strong>"
}, Se = {
	appName: "应用名称",
	appNamePlaceholder: "我的助手",
	copied: "已复制！",
	copyManifest: "复制清单",
	description: "描述（可选）",
	descriptionHelper: "显示在应用的 Slack 个人资料中。",
	descriptionPlaceholder: "此助手提供哪些帮助",
	intro: "命名您的 Slack 应用并复制其清单。所有权限和设置均已预配置。",
	next: "下一步"
}, Ce = {
	body: "在新标签页中打开 Slack 以创建应用，然后返回此处查看后续步骤。",
	copied: "已复制！",
	copyManifest: "复制清单",
	manifestCopiedNotice: "您已在此处复制此应用的清单。如果您在此之后复制了其他内容，请在粘贴前再次复制。",
	manifestNotCopiedNotice: "您尚未复制此应用的清单。Slack 的创建应用模态框没有其他方式获取它，因此请在粘贴前复制它。",
	next: "下一步",
	openSlack: "打开 Slack"
}, we = {
	appTokenLabel: "应用令牌",
	botTokenLabel: "机器人令牌",
	connectSlack: "连接 Slack",
	connecting: "正在连接…",
	credentialsSaved: "凭据已保存",
	instructions: "在 Slack 的确认屏幕上，展开 <credentials>您的应用凭据</credentials> 并复制两个 Token。",
	skipNotice: "该屏幕还提供命令行演练和 <download>下载应用文件</download> 按钮。请跳过这两项。它们会设置一个独立的本地应用，而此助手只需要这两个 Token。",
	savedBody: "两个 Token都已保存。Slack 这边已完成。"
}, Te = {
	channelLabel: "Slack",
	copyError: "无法复制清单。请在继续之前重新复制。",
	stepConnect: "连接",
	stepCreate: "创建",
	stepName: "名称",
	stepOpen: "打开"
}, Ee = { total: "总计：{value}" }, De = { reloadApp: "重新加载应用" }, Oe = {
	reconnecting: "正在重新连接到你的助手…",
	dismiss: "忽略",
	goToDoctor: "前往诊断",
	resumeAssistant: "恢复助手",
	retryNow: "立即重试",
	wakeUp: "唤醒"
}, ke = {
	allLanguages: "所有语言",
	featured: "精选",
	languagesAriaLabel: "语言",
	noMatch: "无匹配语言。",
	searchAriaLabel: "搜索语言",
	searchPlaceholder: "搜索语言",
	suggested: "建议"
}, Ae = { description: "从您下次语音输入开始生效。" }, je = {
	apiKeyLabel: "API 密钥",
	apiKeyPlaceholderReplace: "•••••••• (输入新密钥以替换)",
	providerAriaLabel: "语音转文本提供商",
	providerLabel: "提供商",
	saveFailed: "保存语音转文本设置失败",
	saveSuccess: "语音转文本设置已保存",
	spokenLanguage: "口语语言",
	spokenLanguageApplies: "从您下次语音输入开始生效。",
	cadetTranscription: "转录通过您的 Cadet 账户运行。",
	windowsNativeDisplayName: "Windows 本机听写",
	windowsNativeSetupWarning: "需要为您的 Windows 显示语言启用基本语音识别：打开“设置”>“时间和语言”>“语言和区域”，选择显示语言旁边的三个点，选择“语言选项”，然后在“语言功能”下下载“基本语音识别”。",
	windowsNativeSubtitle: "Windows 设备上的语音识别，通过 Windows 助手在本地运行。可离线工作，无需 API 密钥。"
}, Me = { ariaLabel: "子代理 {subagentId}" }, Ne = {
	accessibilityDescription: "允许您的助手代表您点击、输入和控制应用程序。",
	accessibilityLabel: "辅助功能",
	checking: "正在检查权限...",
	dockIcon: "程序坞图标",
	microphoneDescription: "允许您的助手捕获音频用于语音输入和录音。",
	microphoneLabel: "麦克风",
	notificationBadgesDescription: "允许您的助手在 {surface} 上显示未读对话计数。",
	notificationBadgesLabel: "通知标记",
	notificationsDescription: "允许您的助手发送 macOS 提醒，用于审批、消息和任务更新。",
	notificationsLabel: "通知",
	notificationsWindowsDescription: "允许您的助手显示 Windows 通知，用于审批、消息和任务更新。",
	screenDescription: "允许您的助手在计算机使用任务期间捕获屏幕上下文。",
	screenLabel: "屏幕录制",
	speechRecognitionDescription: "允许您的助手在设备上将您的语音转录为文本。",
	speechRecognitionLabel: "语音识别",
	speechRecognitionWindowsDescription: "允许您的助手使用 Windows 语音识别将您的语音转录为文本。",
	taskbarIcon: "任务栏图标",
	title: "系统权限"
}, Pe = {
	botTokenLabel: "机器人令牌",
	connectTelegram: "连接 Telegram",
	instructions: "粘贴 BotFather 回复中的令牌。它是 <tokenLine>Use this token to access the HTTP API</tokenLine> 之后的整行内容。",
	saving: "正在保存…",
	savedTitle: "令牌已保存",
	savedBody: "机器人令牌已保存。Telegram 这边已完成。"
}, Fe = {
	copied: "已复制！",
	copyName: "复制名称",
	displayNameHint: "对于显示名称，<strong>{suggestedName}</strong> 可使此机器人与您的助手匹配。用户名是独立的，不必匹配。",
	chatScopeNotice: "支持私聊和群组。在群组中，助手会在被提及或有人回复它时作出回应。不支持广播频道。",
	inBotFather: "在 BotFather 中：",
	intro: "Telegram 机器人通过向 <strong>@BotFather</strong> 发送消息来创建。打开它，按照提示操作，然后带着它给您的令牌回来。",
	next: "下一步",
	openBotFather: "打开 BotFather",
	stepDisplayName: "给它一个显示名称，这是人们在聊天中看到的名称",
	stepSendNewBot: "发送 <strong>/newbot</strong>",
	stepTokenReply: "BotFather 会在 <strong>Use this token to access the HTTP API</strong> 之后回复一个 Token",
	stepUsername: "给它一个用户名，该用户名必须是唯一的，并以 <strong>bot</strong> 结尾"
}, Ie = {
	channelLabel: "Telegram",
	copyError: "无法复制名称。请改为在 BotFather 中输入。",
	stepConnect: "连接",
	stepCreate: "创建机器人"
}, Le = {
	shopifyLabel: "店铺域名",
	shopifyPlaceholder: "your-store.myshopify.com"
}, Re = { recoveryModeBanner: "恢复模式已激活：此会话已连接到调试终端。" }, ze = {
	accentFill: "强调色填充",
	activeBorder: "活动边框",
	activeSurface: "活动表面",
	assistantBubble: "助手回复，在页面表面全宽渲染。",
	buttonDisabled: "禁用",
	buttonPrimary: "主要",
	buttonSecondary: "次要",
	chatAssistant1: "完成。摘要已准备就绪。收入稳步增长，上季度标记的两个风险已解决，我已将值得展示的三张图表提取到单独的页面中。",
	chatAssistant2: "已安排在上午9点。我将包含图表和一个段落版本，供在手机上快速浏览的人查看。",
	chatUser1: "你能在明天的会议前总结一下季度报告吗？",
	chatUser2: "太好了。早上发给团队。",
	composerPlaceholder: "给你的助手发消息",
	faintText: "淡文本 - 斜坡上最后一个清晰可见的步骤。",
	inputFilled: "已输入到字段中的文本。",
	inputPlaceholder: "空字段中的占位符",
	newConversation: "新对话",
	overlaySurface: "叠加表面",
	primaryText: "主要文本 - 应用的主要阅读表面。",
	quietText: "安静文本 - 元数据和时间戳。",
	raisedCard: "凸起卡片",
	raisedCardBody: "凸起表面位于面板和页面背景之上。",
	samplerTitle: "主题样本",
	secondaryText: "次要文本 - 辅助文案和描述。",
	sectionAccent: "强调色",
	sectionButtons: "按钮",
	sectionInputs: "输入",
	sectionMessages: "消息",
	sectionSurfaces: "表面和边框",
	sectionText: "文本",
	send: "发送",
	subtleDivider: "此线上方的细分隔线。",
	tertiaryText: "三级文本 - 字幕、标签和占位符。",
	userBubble: "用户在其气泡中的消息。"
}, Be = {
	dark: "深色",
	label: "主题",
	light: "浅色",
	system: "系统"
}, Ve = {
	apiKey: "API 密钥",
	apiKeyRequired: "测试前请为此提供商保存 API 密钥。",
	chooseFromCatalog: "从目录中选择",
	customVoiceIdAriaLabel: "自定义语音 ID",
	noCloudVoices: "目前没有可用的托管语音。",
	provider: "提供商",
	providerAriaLabel: "TTS 提供商",
	saveFailed: "保存文本转语音设置失败",
	saved: "文本转语音设置已保存",
	test: "测试",
	testing: "正在测试…",
	voice: "语音",
	voiceId: "语音 ID",
	voiceIdPlaceholder: "输入语音 ID"
}, He = {
	available: "有可用更新。正在开始下载…",
	closeAriaLabel: "关闭",
	downloading: "正在下载更新…",
	ready: "Cadet {version} 已准备就绪。",
	restartToInstall: "重启以安装",
	versionFallback: "更新"
}, Ue = { deleteFailed: "删除应用失败" }, We = {
	copyFailed: "无法复制链接。请在 {url} 打开。",
	linkCopied: "链接已复制",
	open: "打开"
}, Ge = {
	setupPrompt: {
		slack: "我想在 Slack 上联系你。我们来设置一下。",
		telegram: "我想在 Telegram 上联系你。我们来设置一下。",
		discord: "我想在 Discord 上联系你。我们来设置一下。",
		email: "我想给你发邮件。我们来设置你的电子邮件地址。",
		phone: "我想能够给你打电话。我们来设置你的电话号码。"
	},
	finishPrompt: {
		slack: "Slack 已设置但无法工作。你能完成它吗？",
		telegram: "Telegram 已设置但无法工作。你能完成它吗？",
		discord: "Discord 已设置但无法工作。你能完成它吗？",
		email: "我的电子邮件地址已设置但无法工作。你能完成它吗？",
		phone: "我的电话号码已设置但无法工作。你能完成它吗？"
	}
}, Ke = {
	addFailed: "收藏消息失败。",
	removeFailed: "移除收藏失败。"
}, qe = {
	exchangeFailed: "请检查粘贴的密钥并重试。",
	failed: "连接 Claude 失败。请重试。",
	notStarted: "请先启动连接 Claude 流程。",
	pasteEmpty: "请粘贴 Claude 页面上显示的代码。",
	popupBlocked: "您的浏览器阻止了登录标签页。请允许此站点的弹窗，然后再次点击连接。",
	startFailed: "无法启动连接 Claude。请重试。",
	timedOut: "等待 Claude 连接超时。请重试。"
}, Je = {
	accountConnected: "{name} 账户已连接。",
	authorizationError: "{name} 错误：{code}",
	authorizationFailed: "{name} 授权失败",
	popupBlocked: "弹窗被阻止。请启用弹窗并重试。",
	startFailed: "启动 {name} 授权失败。",
	startFailedWithReason: "启动 {name} 授权失败：{reason}"
}, Ye = {
	blocked: "您的浏览器阻止了助手尝试打开的页面。",
	openPage: "打开页面"
}, Xe = { playFailed: "无法播放语音样本。" }, Ze = { updated: "主题已更新" }, Qe = {
	body: "输入您的 Vercel API 令牌，将应用程序部署为静态页面。",
	cancel: "取消",
	createToken: "在 Vercel 上创建令牌 →",
	save: "保存",
	saveFailed: "保存 Vercel 令牌失败。",
	saving: "正在保存…",
	title: "连接 Vercel",
	tokenLabel: "API 令牌",
	tokenPlaceholder: "Vercel API 令牌"
}, $e = {
	assistantVoiceAriaLabel: "助手语音",
	defaultSuffix: "（默认）",
	previewVoice: "预览 {description}",
	providerAriaLabel: "语音提供商",
	stopPreview: "停止预览"
}, et = {
	ariaLabel: "语音",
	selectVoice: "选择语音"
}, tt = {
	done: "完成",
	title: "语音"
}, nt = { body: "语音提供商、转录和 API 密钥位于<modelsLink>模型与服务</modelsLink>中。" }, rt = {
	recommendedOff: "建议关闭",
	userTranscriptLabel: "显示你说的话",
	userTranscriptDescription: "在你说话时实时转录文字。",
	assistantTranscriptLabel: "显示助手说的话",
	assistantTranscriptDescription: "在语音回复旁同步显示文本。"
}, it = {
	developer: "开发者",
	file: "文件",
	help: "帮助",
	view: "视图"
}, at = {
	checkingDomain: "正在检查域名…",
	domainVerified: "域名已验证",
	failedTitle: "域名验证失败。DNS 记录可能未正确传播。您可以尝试释放并重新注册该域名。",
	unknownStatus: "未知状态",
	unknownStatusTitle: "无法检索域名验证状态。",
	verificationFailed: "验证失败",
	verifiedTitle: "DNS 记录已验证。您的域名已准备好发送和接收电子邮件。",
	verifyingDomain: "正在验证域名…",
	verifyingTitle: "DNS 记录已配置。正在等待电子邮件提供商验证它们 - 这通常需要几分钟。",
	setupRequired: "需要设置域名",
	setupRequiredTitle: "此域名尚未在电子邮件提供商处完成配置。在完成设置前，它无法发送或接收电子邮件。"
}, ot = { body: "托管服务按量计费，并从您的 Cadet 账户余额中扣除。<link>查看定价</link>" }, st = {
	managedLabel: "托管",
	modeToggleAriaLabel: "服务模式",
	yourOwnLabel: "自托管"
}, ct = {
	previewAlt: "您的助手头像",
	download: "下载头像",
	prompt: {
		slack: "下载您的助手头像以上传为应用图标。",
		discord: "下载您的助手头像以上传为机器人图标。",
		telegram: "下载您的助手头像，然后使用 /setuserpic 发送给 BotFather。"
	}
}, lt = {
	strict: {
		label: "严格",
		description: "执行任何操作前均需确认。不自动批准任何操作。"
	},
	conservative: {
		label: "保守",
		description: "自动批准低风险操作，例如网络搜索以及在其自身工作区中读写文件。"
	},
	relaxed: {
		label: "宽松",
		description: "自动批准低风险与中等风险操作，例如修改其工作区之外的文件。"
	},
	fullAccess: {
		label: "完全访问",
		description: "自动批准所有操作，包括高风险和无法识别的命令。助手将绝不请求权限确认。"
	}
}, ut = {
	everyHours: "每 {count} 小时",
	everyMinutes: "每 {count} 分钟",
	retrospectiveSubtitle: "在对话活动后触发"
}, dt = {
	title: "助手用户名",
	description: "你的助手的公开名称，它的邮箱地址也基于这个名称。",
	helper: "小写字母、数字、连字符和下划线。"
}, ft = {
	close: "关闭",
	closePanel: "关闭面板",
	loading: "加载中…"
}, pt = {
	back: "返回引导",
	dragInstruction: "将 {app} 拖入列表以允许{permission}。",
	dragApp: "将 {app} 拖到系统设置，或点击以在访达中显示",
	dragError: "无法拖动。请尝试从访达中拖动。",
	showInFinder: "在访达中显示",
	inputLabel: "输入监控"
}, mt = {
	loopback: "这是一个其他设备无法访问的环回地址。请输入助手的公共 HTTPS URL。",
	nonHttps: "URL 必须使用 HTTPS，以便您的设备可以安全连接。",
	privateAddress: "此地址指向一个私有网络地址。请输入助手的公共 HTTPS URL，以便您的设备可以访问它。",
	serviceFallbackName: "隧道提供商",
	serviceWebsite: "这是 {service} 的网站，而不是您的助手地址。请在主机上启动隧道以获取一个；`cadet tunnel --help` 列出了提供商。",
	unparseable: "请输入有效的 URL，例如 https://your-assistant.ts.net。"
}, ht = {
	aboutPage: e,
	activeAssistantGate: t,
	addCredentialModal: n,
	addCreditsModal: r,
	appCard: i,
	appNavBar: a,
	appViewerContainer: o,
	assistantConnect: s,
	assistantEmailIntroModal: c,
	assistantFeatureFlagStore: l,
	avatarManagementModal: u,
	bundleConfirmPage: d,
	byoVoiceNote: f,
	channelSetupCompleteNotice: p,
	chatAvatar: m,
	chooserAvatarChip: h,
	collapsibleNavSection: g,
	commandPalette: _,
	companionIntro: v,
	companionPopover: y,
	companionSurface: b,
	companionWatchFramePage: x,
	contentActionBar: S,
	conversationTitle: C,
	copyButton: w,
	createAssistantDialog: T,
	dateRangeSelect: E,
	deleteAppDialog: D,
	deployDialogs: O,
	deployStore: k,
	detailPanelStopButton: A,
	detailPrimitives: j,
	dictationOverlayPage: M,
	discordNudgeBanner: N,
	discordSetupConnectStep: P,
	discordSetupCreateStep: F,
	discordSetupFinishStep: I,
	discordSetupInviteStep: L,
	discordSetupWizard: R,
	diskPressureBanner: z,
	downloadFeedback: B,
	editFooter: V,
	featureIntroModal: H,
	fileViewMode: U,
	generateInviteLinkDialog: W,
	githubNudgeBanner: G,
	lazyBoundary: K,
	localNotification: q,
	desktopAppBanner: J,
	nativeAppBanner: Y,
	nudgeChatBanner: X,
	onboardingBackButton: Z,
	platformLoginNotice: Q,
	profileCard: $,
	profileQuickAddProvider: ee,
	quickInputPage: te,
	removeFromDeviceDialog: ne,
	resourcePressureBanner: re,
	retireConfirmDialog: ie,
	rootHydrateFallback: ae,
	routePendingIndicator: oe,
	rootLayout: se,
	routeErrorBoundary: ce,
	runtimeUpgradeBanner: le,
	sectionActionsButton: ue,
	serviceFormControls: de,
	shareConnectionLinkButton: fe,
	shareFeedbackModal: pe,
	shareFeedbackModalFallback: me,
	shareFeedbackModalLoadError: he,
	sideListDrawer: ge,
	sidebarShell: _e,
	sidebarTree: ve,
	skillLineageLink: ye,
	skillRemovalDialog: be,
	slackSetupCreateStep: xe,
	slackSetupNameStep: Se,
	slackSetupOpenStep: Ce,
	slackSetupTokensStep: we,
	slackSetupWizard: Te,
	stackedBarTooltip: Ee,
	startupFailure: De,
	statusBanner: Oe,
	sttLanguagePicker: ke,
	sttLanguagePickerModal: Ae,
	sttProviderForm: je,
	subagentAvatarChip: Me,
	systemPermissionsCard: Ne,
	telegramSetupConnectStep: Pe,
	telegramSetupCreateStep: Fe,
	telegramSetupWizard: Ie,
	tenantHost: Le,
	terminalPanel: Re,
	themeStagePage: ze,
	themeToggle: Be,
	ttsProviderForm: Ve,
	updateToast: He,
	useAppDelete: Ue,
	useAppDeployment: We,
	useAssistantChannels: Ge,
	useBookmarks: Ke,
	useConnectClaude: qe,
	useOauthConnect: Je,
	useOpenUrlDirectives: Ye,
	useVoiceSamplePreview: Xe,
	useWorkspaceTheme: Ze,
	vercelTokenDialog: Qe,
	voiceList: $e,
	voicePickerField: et,
	voicePickerModal: tt,
	voiceProvidersNote: nt,
	voiceTranscriptToggles: rt,
	windowsMenuBar: it,
	domainVerificationChip: at,
	managedServicesBanner: ot,
	serviceCard: st,
	channelAvatarDownload: ct,
	thresholdPresets: lt,
	scheduleFormatters: ut,
	assistantHandleModal: dt,
	detailShell: ft,
	permissionGuide: pt,
	pairDeviceUrl: mt
};
//#endregion
export { e as aboutPage, t as activeAssistantGate, n as addCredentialModal, r as addCreditsModal, i as appCard, a as appNavBar, o as appViewerContainer, s as assistantConnect, c as assistantEmailIntroModal, l as assistantFeatureFlagStore, dt as assistantHandleModal, u as avatarManagementModal, d as bundleConfirmPage, f as byoVoiceNote, ct as channelAvatarDownload, p as channelSetupCompleteNotice, m as chatAvatar, h as chooserAvatarChip, g as collapsibleNavSection, _ as commandPalette, v as companionIntro, y as companionPopover, b as companionSurface, x as companionWatchFramePage, S as contentActionBar, C as conversationTitle, w as copyButton, T as createAssistantDialog, E as dateRangeSelect, ht as default, D as deleteAppDialog, O as deployDialogs, k as deployStore, J as desktopAppBanner, A as detailPanelStopButton, j as detailPrimitives, ft as detailShell, M as dictationOverlayPage, N as discordNudgeBanner, P as discordSetupConnectStep, F as discordSetupCreateStep, I as discordSetupFinishStep, L as discordSetupInviteStep, R as discordSetupWizard, z as diskPressureBanner, at as domainVerificationChip, B as downloadFeedback, V as editFooter, H as featureIntroModal, U as fileViewMode, W as generateInviteLinkDialog, G as githubNudgeBanner, K as lazyBoundary, q as localNotification, ot as managedServicesBanner, Y as nativeAppBanner, X as nudgeChatBanner, Z as onboardingBackButton, mt as pairDeviceUrl, pt as permissionGuide, Q as platformLoginNotice, $ as profileCard, ee as profileQuickAddProvider, te as quickInputPage, ne as removeFromDeviceDialog, re as resourcePressureBanner, ie as retireConfirmDialog, ae as rootHydrateFallback, se as rootLayout, ce as routeErrorBoundary, oe as routePendingIndicator, le as runtimeUpgradeBanner, ut as scheduleFormatters, ue as sectionActionsButton, st as serviceCard, de as serviceFormControls, fe as shareConnectionLinkButton, pe as shareFeedbackModal, me as shareFeedbackModalFallback, he as shareFeedbackModalLoadError, ge as sideListDrawer, _e as sidebarShell, ve as sidebarTree, ye as skillLineageLink, be as skillRemovalDialog, xe as slackSetupCreateStep, Se as slackSetupNameStep, Ce as slackSetupOpenStep, we as slackSetupTokensStep, Te as slackSetupWizard, Ee as stackedBarTooltip, De as startupFailure, Oe as statusBanner, ke as sttLanguagePicker, Ae as sttLanguagePickerModal, je as sttProviderForm, Me as subagentAvatarChip, Ne as systemPermissionsCard, Pe as telegramSetupConnectStep, Fe as telegramSetupCreateStep, Ie as telegramSetupWizard, Le as tenantHost, Re as terminalPanel, ze as themeStagePage, Be as themeToggle, lt as thresholdPresets, Ve as ttsProviderForm, He as updateToast, Ue as useAppDelete, We as useAppDeployment, Ge as useAssistantChannels, Ke as useBookmarks, qe as useConnectClaude, Je as useOauthConnect, Ye as useOpenUrlDirectives, Xe as useVoiceSamplePreview, Ze as useWorkspaceTheme, Qe as vercelTokenDialog, $e as voiceList, et as voicePickerField, tt as voicePickerModal, nt as voiceProvidersNote, rt as voiceTranscriptToggles, it as windowsMenuBar };
