//#region src/lib/auth/hard-navigate.ts
function e(e) {
	window.location.replace(e);
}
//#endregion
export { e as t };
