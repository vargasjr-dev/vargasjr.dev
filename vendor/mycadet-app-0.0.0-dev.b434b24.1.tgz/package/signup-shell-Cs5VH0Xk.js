import { h as e, t } from "./proxy-I7qEXaVt.js";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/domains/account/components/signup-shell.tsx
function i({ children: i }) {
	return /* @__PURE__ */ r(t.div, {
		"data-theme": "dark",
		className: "signup",
		initial: { opacity: 0 },
		animate: { opacity: 1 },
		transition: { duration: .5 },
		children: [/* @__PURE__ */ r("div", {
			className: "signup__left",
			children: [/* @__PURE__ */ n("div", {
				className: "signup__logo",
				children: /* @__PURE__ */ n("img", {
					src: e("/cadet-logo-white.svg"),
					alt: "Cadet",
					width: 82,
					height: 25
				})
			}), /* @__PURE__ */ n("div", {
				className: "signup__form",
				children: i
			})]
		}), /* @__PURE__ */ n(t.div, {
			className: "signup__right",
			initial: { opacity: 0 },
			animate: { opacity: 1 },
			transition: {
				duration: .6,
				delay: .15
			},
			"aria-hidden": !0,
			children: /* @__PURE__ */ n("video", {
				className: "signup__video",
				src: e("/cadet-scene-cut.mp4"),
				autoPlay: !0,
				loop: !0,
				muted: !0,
				playsInline: !0
			})
		})]
	});
}
//#endregion
export { i as t };
