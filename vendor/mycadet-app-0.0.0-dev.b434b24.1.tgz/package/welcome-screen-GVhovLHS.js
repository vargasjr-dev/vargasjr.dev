import { c as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { n } from "./api-DnMWUBLS.js";
import { n as r } from "./routes-DW44XTQk.js";
import { t as i } from "./auth-welcome-screen-GNygh2JH.js";
import { t as a } from "./onboarding-navigation-Bp-9lTqG.js";
import { jsx as o } from "react/jsx-runtime";
//#region src/domains/onboarding/pages/welcome-screen.tsx
function s() {
	let { t: s } = t("account"), c = e();
	return /* @__PURE__ */ o(i, {
		returnTo: null,
		secondary: {
			label: s("welcome.continueWithoutAccount"),
			onSelect: () => {
				n().then((e) => {
					e.ok && e.data.length > 0 ? c(r.assistant, a) : c(r.account.onboarding.hosting, a);
				});
			}
		}
	});
}
//#endregion
export { s as WelcomeScreen };
