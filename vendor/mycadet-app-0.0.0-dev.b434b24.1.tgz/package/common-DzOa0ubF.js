//#region src/i18n/locales/es/common.json
var e = {
	build: "Compilación",
	taglineMacOS: "Asistente de IA para tu Mac",
	taglineWindows: "Asistente de IA para tu PC",
	version: "Versión"
}, t = {
	connecting: "Conectando con tu asistente…",
	logIn: "Iniciar sesión",
	logOut: "Cerrar sesión",
	errorTitle: "No pudimos conectarnos con tu asistente",
	retry: "Reintentar"
}, n = {
	cancel: "Cancelar",
	credentialSaved: "Credencial guardada.",
	description: "Añade una clave API o un token para que las herramientas e integraciones lo usen.",
	fieldLabel: "Campo",
	fieldPlaceholder: "p. ej. api_token",
	labelOptional: "Etiqueta (opcional)",
	labelPlaceholder: "p. ej. token de acceso personal de GitHub",
	save: "Guardar",
	saveFailed: "No se pudo guardar la credencial",
	serviceLabel: "Servicio",
	servicePlaceholder: "p. ej. github",
	title: "Añadir credencial",
	valueLabel: "Valor",
	valuePlaceholder: "Introduce el valor secreto"
}, r = {
	amount: "Importe",
	cancel: "Cancelar",
	configureAutoReload: "Configurar la recarga automática",
	continue: "Continuar",
	description: "Se te redirigirá a Stripe para completar el pago.",
	title: "Añadir créditos"
}, i = {
	openApp: "Abrir app",
	pin: "Fijar",
	previewTitle: "Vista previa de {name}",
	unpin: "Desfijar"
}, a = {
	close: "Cerrar",
	copyLink: "Copiar enlace",
	deploy: "Desplegar",
	deployToVercel: "Desplegar en Vercel",
	deployToVercelSubtitle: "Publicar como página estática",
	deployedCopyLinkAria: "Desplegada en Vercel, copiar enlace",
	deployedCopyLinkTooltip: "Desplegada: copiar enlace",
	deployedToVercel: "Desplegada en Vercel",
	deploying: "Desplegando…",
	edit: "Editar",
	expandApp: "Expandir app",
	fullscreen: "Pantalla completa",
	openApp: "Abrir app",
	redeploy: "Volver a desplegar",
	redeploySubtitle: "Publicar la versión actual",
	share: "Compartir",
	shareAndDeploy: "Compartir y desplegar",
	shareExportSubtitle: "Exportar como archivo .cadet",
	sharing: "Compartiendo…"
}, o = { exitFullscreen: "Salir de pantalla completa" }, s = { failed: "No se pudo conectar con el asistente." }, c = { setUp: "Configurar el correo" }, l = { updateFailed: "No se pudo actualizar \"{label}\". Se revirtió el cambio." }, u = {
	accent: "Acento",
	accentAutomatic: "Automático",
	accentPickerLabel: "Color de acento",
	accentReset: "Restablecer",
	body: "Cuerpo",
	color: "Color",
	eyes: "Ojos",
	keepUploadedDescription: "Guardar el personaje la reemplaza",
	keepUploadedLabel: "Conservar tu imagen subida",
	loadError: "No se pudieron cargar los componentes del avatar. Asegúrate de que tu asistente esté en ejecución.",
	name: "Nombre",
	next: "Siguiente {label}",
	previous: "Anterior {label}",
	randomize: "Aleatorio",
	save: "Guardar",
	saving: "Guardando…",
	title: "Actualizar avatar",
	uploadImage: "Subir imagen",
	uploadedAlt: "Avatar subido",
	useCharacterDescription: "Elige entre nuestros avatares integrados",
	useCharacterLabel: "Usar un personaje en su lugar"
}, d = {
	bySigner: "por {name}",
	cancel: "Cancelar",
	capabilities: "Capacidades",
	createdBy: "Creado por",
	hideWarnings: "Ocultar advertencias ({count})",
	install: "Instalar",
	installAnyway: "Instalar de todos modos",
	loading: "Cargando...",
	showWarnings: "Mostrar advertencias ({count})",
	size: "Tamaño"
}, f = { body: "Tu asistente habla a través de un proveedor que configuraste tú. Define su voz en <settingsLink>Modelos y servicios</settingsLink>." }, p = {
	verifyTitle: "Último paso: confirma que eres tú",
	verifyAction: "Verificarme",
	verifyBody: "Tu asistente aún no sabe cuál cuenta de {channel} es la tuya, así que no te responderá. Di \"verifícame en {channel}\" en el chat para terminar.",
	verifyActionBody: "Tu asistente aún no sabe cuál cuenta de {channel} es la tuya, así que no te responderá. Lo termina contigo en el chat.",
	verifiedTitle: "Identidad verificada",
	verifiedBody: "Tu asistente conoce tu cuenta de {channel} y te responderá. Todo listo."
}, m = {
	alt: "Avatar del asistente",
	fallbackLetter: "V"
}, h = { alt: "Avatar del asistente" }, g = { actionsTitle: "Acciones de {title}" }, _ = {
	ariaLabel: "Paleta de comandos",
	clear: "Borrar",
	clearSearch: "Borrar búsqueda",
	closeSearch: "Cerrar búsqueda",
	noResults: "Sin resultados",
	placeholder: "Buscar conversaciones, recuerdos…",
	searchAriaLabel: "Buscar",
	searching: "Buscando…"
}, v = {
	announcement: {
		body: "Ahora puedo acompañarte en cualquier lugar de tu escritorio.",
		cards: {
			context: {
				body: "Déjame ver lo que ves para ayudarte con todo el contexto.",
				title: "Muestra y explica"
			},
			flow: {
				body: "Háblame sin salir de la app que estás usando.",
				title: "No pierdas el ritmo"
			},
			together: {
				body: "Habla, señala y avanza conmigo.",
				title: "Trabajemos juntos"
			}
		},
		close: "Cerrar",
		previewLabel: "Tu compañero de escritorio",
		previewAssistantName: "Quill",
		start: "Vamos",
		title: "Estoy donde tú trabajas"
	},
	ariaLabel: "Te presento a tu compañero",
	back: "Atrás",
	call: {
		click: "Clic",
		line: "Escuchando",
		shortcut: "Atajo"
	},
	close: "Cerrar",
	done: "Entendido",
	draw: {
		body: "Señala cualquier cosa de tu pantalla",
		title: "Dibuja"
	},
	idle: {
		body: "Pasa el cursor por encima y saldré.",
		title: "Hola, soy yo",
		titleNamed: "Hola, soy {name}"
	},
	key: {
		scolded: "No, la tecla de tu teclado",
		title: "Haz que sea fácil hablar conmigo"
	},
	meet: { body: "Me quedo en tu escritorio, aunque Cadet no esté a la vista." },
	mute: {
		body: "Toca el micrófono para silenciarte o el altavoz para silenciarme",
		title: "Silenciar"
	},
	next: "Siguiente",
	share: {
		body: "Muéstrame una pestaña, una ventana o toda la pantalla",
		title: "Comparte tu pantalla"
	},
	talk: {
		body: "Haz clic en mí para empezar una conversación.",
		gesture: "O pulsa dos veces esta tecla:",
		greeted: "¡Lo lograste! Así de simple.",
		title: "Habla conmigo"
	},
	try: {
		body: "Dime hola y te responderé en voz alta.",
		how: "Haz clic en mí, o pulsa dos veces la tecla",
		title: "Pruébalo"
	},
	permission: {
		microphoneAction: "Activar micrófono",
		microphoneSettingsHint: "Activa el interruptor del micrófono de Cadet en Ajustes del Sistema y vuelve aquí.",
		microphonePromptHint: "macOS te pedirá permiso para acceder al micrófono.",
		microphoneBody: "Permíteme usar tu micrófono para conversar por voz.",
		shortcutBody: "Permíteme detectar el atajo mientras usas otras apps.",
		screenAction: "Activar pantalla compartida",
		screenBody: "Activa esta opción. Tú eliges qué compartir al usarla.",
		openSettings: "Abrir Ajustes",
		settingsHint: "Permite el acceso en Ajustes del Sistema y vuelve aquí.",
		restricted: "Tu Mac restringe este permiso. Puedes omitir este paso.",
		error: "No se pudo comprobar el acceso. Inténtalo de nuevo.",
		waiting: "Comprobando acceso…",
		skip: "Omitir"
	}
}, y = {
	allow: "Permitir",
	confirm: "Confirmar",
	credentialLabel: "Credencial",
	defaultSuffix: "(predeterminada)",
	deny: "Denegar",
	dismiss: "Descartar",
	enter: "Introducir",
	microphoneFallback: "Micrófono {index}",
	microphonePermissionHint: "Permite el acceso al micrófono para ver cada micrófono por su nombre.",
	microphoneTitle: "Micrófono",
	needsCredentials: "Necesito una credencial",
	needsCredentialsFor: "Necesito credenciales para {service}",
	needsOkCount: "{count, plural, one {Necesito tu aprobación para # cosa} other {Necesito tu aprobación para # cosas}}",
	notNow: "Ahora no",
	openApp: "Abrir Cadet",
	pendingBadge: "{count, plural, one {# cosa necesita tu aprobación} other {# cosas necesitan tu aprobación}}",
	previewVoice: "Escuchar {voice}",
	review: "Revisar",
	savedMicrophone: "Micrófono guardado",
	savedMicrophoneNotConnected: "Micrófono guardado (no conectado)",
	stopPreview: "Detener",
	surfaceFallback: "Algo para ver",
	systemDefault: "Predeterminado del sistema",
	voiceTitle: "Voz"
}, b = {
	calling: "Llamando…",
	callingNamed: "Llamando a {name}…",
	captureKind: "Tipo de fuente",
	captureNothing: "Nada que mostrar",
	capturePicker: "Qué enseñar",
	captureScreen: "Pantalla {n}",
	captureScreenRecordingOff: "La grabación de pantalla está desactivada",
	captureScreens: "Pantallas",
	captureTabs: "Pestañas de Chrome",
	captureTurnOnScreenRecording: "Activar",
	captureWindows: "Ventanas",
	draw: "Dibujar",
	clearMarks: "Borrar marcas",
	drawTools: "Herramienta de dibujo",
	drawFreehand: "Mano alzada",
	drawLine: "Línea",
	drawBox: "Recuadro",
	drawCircle: "Círculo",
	endSession: "Finalizar sesión",
	muteAssistant: "Silenciar asistente",
	muteAssistantNamed: "Silenciar a {name}",
	muteMicrophone: "Silenciar micrófono",
	notNow: "Ahora no",
	offerCopy: "Copiar",
	offerDiscard: "Descartar",
	offerHeard: "{app} pegó eso",
	offerNowhere: "No hay dónde ponerlas",
	offerPasteFailed: "No se pudieron pegar",
	offerQuit: "Salir de {app}",
	offerUse: "Usar la de Cadet",
	offerVersion: "Cadet oyó",
	openCadet: "Abrir Cadet",
	share: "Compartir",
	sharePicker: "Qué compartir",
	showSummary: "Mostrar resumen",
	stopTeaching: "Dejar de enseñar",
	summarizing: "Resumiendo",
	talk: "Hablar",
	teach: "Enseñar",
	unmuteAssistant: "Activar sonido del asistente",
	unmuteAssistantNamed: "Activar sonido de {name}",
	unmuteMicrophone: "Activar micrófono",
	chooseMicrophone: "Elegir micrófono",
	workCount: "{count, plural, =0 {Nada en curso} one {# tarea en curso} other {# tareas en curso}}",
	workDone: "Hecho",
	workStopped: "Detenido",
	workMore: "{count} más",
	workWaiting: "{count, plural, one {# esperando tu respuesta} other {# esperando tu respuesta}}",
	workWaitingStep: "Esperando tu respuesta"
}, x = {
	sharingScreen: "Compartiendo tu pantalla",
	sharingScreenNamed: "Compartiendo tu pantalla con {name}",
	sharingWindow: "Compartiendo una ventana",
	sharingWindowNamed: "Compartiendo una ventana con {name}",
	teaching: "Enseñando",
	teachingNamed: "Enseñando a {name}"
}, S = {
	copiedAria: "Copiado",
	copyFailed: "No se pudo copiar el contenido del archivo.",
	copyFileContentsAria: "Copiar contenido del archivo",
	downloadFileAria: "Descargar archivo",
	editFileAria: "Editar archivo"
}, C = { untitled: "Sin título" }, w = {
	copied: "Copiado",
	copyFailed: "No se pudo copiar al portapapeles."
}, T = {
	cancel: "Cancelar",
	create: "Crear",
	description: "Provisiona un asistente nuevo. Se iniciará en segundo plano.",
	namePlaceholder: "Nombre del asistente (opcional)",
	title: "Nuevo asistente",
	toastSuccess: "Nuevo asistente creado."
}, E = {
	ariaLabel: "Rango de fechas",
	lastDays: "{days, plural, one {Último # día} other {Últimos # días}}"
}, D = {
	delete: "Eliminar",
	deleting: "Eliminando…",
	message: "\"{name}\" se eliminará de forma permanente.",
	title: "Eliminar app"
}, O = {
	confirmLabel: "Deja que tu asistente se encargue",
	confirmLabelNamed: "Deja que {assistantName} se encargue",
	message: "\"{appName}\" usa servicios de backend que no funcionarán en una página estática de Vercel. Tu asistente puede desplegarla correctamente con funciones serverless.",
	messageNamed: "\"{appName}\" usa servicios de backend que no funcionarán en una página estática de Vercel. {assistantName} puede desplegarla correctamente con funciones serverless.",
	title: "Esta app necesita un despliegue completo"
}, k = {
	appExported: "Aplicación exportada",
	deployFailed: "No se pudo desplegar",
	deployedToVercel: "Desplegada en Vercel",
	open: "Abrir",
	shareFailed: "No se pudo compartir la aplicación"
}, A = { tooltip: "Detener" }, j = {
	copy: "Copiar",
	expandedValue: "Valor expandido",
	showLess: "Mostrar menos",
	showMore: "Mostrar más"
}, M = { stopRecording: "Detener grabación" }, N = {
	ariaLabel: "Únete a la comunidad de Discord de Cadet",
	ctaLong: "Unirse a Discord",
	ctaShort: "Unirse",
	subtitleLong: "Habla con el equipo: comparte comentarios, solicita funciones y obtén respuestas más rápido",
	subtitleShort: "Comparte comentarios, solicita funciones y obtén respuestas más rápido",
	title: "¡Únete a nuestra comunidad!"
}, P = {
	instructions: "Pega el token del bot que copiaste de la página Bot.",
	verificationNoticeTitle: "Ignora la página \"Verify your App\"",
	verificationNoticeBody: "Discord la muestra a cada app nueva. Solo importa a partir de 100 servidores.",
	botTokenLabel: "Token del bot",
	save: "Conectar",
	saving: "Conectando...",
	saved: "Conectado. Ahora añade el bot a un servidor.",
	botTokenPlaceholder: "MTk4NjIyNDgzNzAyNDU0..."
}, F = {
	inPortal: "En el portal de desarrolladores de Discord:",
	stepCreateApp: "Pulsa <strong>New Application</strong> y ponle a la app el nombre de tu asistente:",
	copyName: "Copiar nombre",
	copied: "¡Copiado!",
	stepAppIcon: "Opcional: descarga el avatar y súbelo en <strong>General Information</strong> como icono de la app.",
	stepResetToken: "Ve a la página <strong>Bot</strong> en el menú de la app, pulsa <strong>Reset Token</strong> y copia el token de inmediato. Discord solo lo muestra una vez.",
	stepIntentsOff: "En la misma página, deja apagados los tres interruptores de <strong>Privileged Gateway Intents</strong>. Tu asistente no los necesita: solo lee mensajes directos y mensajes que lo mencionan.",
	openPortal: "Abrir el portal de Discord",
	continue: "Ya tengo mi token"
}, I = {
	connectedTitle: "Bot añadido",
	connectedBody: "El token está guardado y el bot ya está en tu servidor. La parte de Discord está lista."
}, L = {
	instructions: "Tu bot no puede ver ni responder nada hasta que entre en un servidor. Abre el enlace, elige tu servidor y aprueba.",
	openInvite: "Añadir a un servidor",
	confirmJoined: "Ya añadí el bot",
	noAppId: "Conecta primero un token del bot y vuelve para añadirlo a un servidor."
}, R = {
	channelLabel: "Discord",
	stepCreate: "Crear app",
	stepConnect: "Conectar",
	stepInvite: "Añadir al servidor",
	stepFinish: "Finalizar",
	copyError: "No se pudo copiar el nombre. Escríbelo en Discord en su lugar."
}, z = {
	acknowledge: "Reconocer",
	acknowledging: "Reconociendo...",
	cleanupBody: "Pide a tu asistente que libere espacio antes de que se agote y entre en un estado bloqueado.",
	cleanupTitle: "El modo de limpieza está activo",
	criticalBody: "Tu asistente entrará en un estado bloqueado si se queda sin almacenamiento.",
	criticalModalDescription: "Tu asistente entrará en un estado bloqueado si se queda sin almacenamiento. Debes pedir a tu asistente que libere espacio o aumentar tu almacenamiento.",
	criticalTitle: "El almacenamiento está críticamente bajo",
	dontShowAgain: "No mostrar de nuevo",
	manageStorage: "Gestionar almacenamiento",
	review: "Revisar",
	upgrade: "Mejorar plan",
	warningBody: "Libera espacio para evitar interrupciones.",
	warningBodyWithUpgrade: "Libera espacio o añade más almacenamiento para evitar interrupciones.",
	warningTitle: "Tu almacenamiento está casi lleno"
}, B = {
	failed: "No se pudo descargar el archivo",
	revealMac: "Mostrar en Finder",
	revealWindows: "Mostrar en el Explorador de archivos",
	saved: "Guardado en Descargas",
	started: "Descarga iniciada",
	startedDescription: "Busca {filename} en las descargas de tu navegador."
}, V = {
	discard: "Descartar",
	save: "Guardar",
	saving: "Guardando…"
}, H = { close: "Cerrar" }, U = {
	formatted: "Con formato",
	modeAria: "Cómo mostrar este archivo",
	source: "Fuente"
}, W = {
	copyAriaLabel: "Copiar enlace de invitación",
	createFailed: "No se pudo crear el enlace de invitación. Asegúrate de que A2A esté habilitado para tu asistente.",
	creating: "Creando enlace de invitación…",
	done: "Listo",
	shareHint: "Comparte este enlace con otro propietario de asistente para establecer una conexión.",
	title: "Compartir enlace de conexión",
	tryAgain: "Reintentar"
}, G = {
	ariaLabel: "Cadet es de código abierto en GitHub",
	ctaAriaLabel: "Dar una estrella a Cadet en GitHub",
	ctaLabel: "Danos una estrella",
	subtitle: "Danos una estrella en GitHub o contribuye",
	title: "Cadet es de código abierto"
}, K = { loadError: "Esta sección no se pudo cargar. Recarga la página para intentarlo de nuevo." }, q = { goToConversation: "Ir a la conversación" }, J = {
	ariaLabelMacOS: "Descargar la app de macOS",
	ariaLabelWindows: "Descargar la app de Windows",
	ctaAriaLabelMacOS: "Descargar la app de macOS",
	ctaAriaLabelWindows: "Descargar la app de Windows",
	ctaLabel: "Descargar",
	subtitle: "Uso del ordenador · acceso a terminal · automatización nativa",
	titleMacOS: "Consigue la app de macOS",
	titleWindows: "Consigue la app de Windows"
}, Y = {
	bannerAria: "Descargar la app de {appName}",
	bannerAriaGeneric: "Descargar la app móvil de Cadet",
	download: "Descargar",
	downloadAppAria: "Descargar la app de {appName}",
	downloadAppAriaGeneric: "Descargar la app móvil de Cadet",
	subtitle: "Notificaciones push · inicio biométrico · háptica",
	title: "Obtén la app de {appName}",
	titleGeneric: "Obtén la app de Cadet"
}, X = { dismissAria: "Descartar" }, Z = { back: "Atrás" }, Q = {
	cancel: "Cancelar",
	logIn: "Iniciar sesión"
}, $ = {
	assistantHandleIdleEmpty: "Tu asistente aún no tiene identificador; reclama uno para poder mencionarlo.",
	assistantHandleLabel: "Identificador del asistente",
	assistantHandleUpdated: "Identificador del asistente actualizado.",
	available: "Disponible",
	availableHelper: "Disponible.",
	checkAvailabilityFailed: "No se pudo comprobar la disponibilidad.",
	checkingAvailability: "Comprobando disponibilidad…",
	chooseDifferentHandle: "Elige un identificador diferente.",
	emailLabel: "Correo electrónico",
	handleHelper: "Letras minúsculas, dígitos, guiones y guiones bajos. De 3 a 30 caracteres.",
	handleLocked: "El identificador de tu asistente está bloqueado porque se usa como su subdominio de correo. Para cambiarlo, <releaseLink>libera el subdominio</releaseLink> primero.",
	loading: "Cargando tu perfil…",
	notAvailable: "No disponible",
	profileUpdated: "Perfil actualizado.",
	save: "Guardar",
	saved: "Guardado",
	saving: "Guardando…",
	subtitle: "Gestiona los detalles y las preferencias de tu cuenta.",
	title: "Perfil",
	userHandleIdleAutoGenerated: "Tu identificador se generó automáticamente al registrarte; elige uno que te guste.",
	userHandleLabel: "Identificador de usuario"
}, ee = { created: "Perfil \"{name}\" creado" }, te = {
	logoAlt: "Cadet",
	placeholder: "Pregunta lo que quieras a Cadet...",
	send: "Enviar mensaje"
}, ne = {
	confirm: "Eliminar",
	messageOrigin: "Esto no afectará a {assistantName} ni cerrará tu sesión allí. Solo olvida la entrada en este dispositivo. Puedes añadirla de nuevo cuando quieras.",
	messagePaired: "Esto no afectará a {assistantName} en su máquina anfitriona. Solo olvida el emparejamiento en este dispositivo. Puedes emparejarlo de nuevo cuando quieras con cadet connect import.",
	messagePlatform: "Esto no eliminará a {assistantName}. Solo lo quita de este dispositivo. Al iniciar sesión volverá a estar disponible.",
	title: "¿Eliminar de este dispositivo?",
	removeFailed: "No se pudo quitar el dispositivo del asistente"
}, re = {
	body: "Tu asistente está trabajando duro y está alcanzando sus límites de recursos actuales. Mejora tu plan para que siga funcionando sin problemas.",
	bodyNoUpgrade: "Tu asistente está trabajando duro y está alcanzando sus límites de recursos actuales.",
	dontShowAgain: "No mostrar de nuevo",
	title: "Tu asistente necesita más potencia",
	titleNamed: "{assistantName} necesita más potencia",
	upgrade: "Mejorar plan"
}, ie = {
	confirmLabel: "Retirar",
	message: "Esto retirará de forma permanente este asistente y todos sus datos. Tendrás que volver a completar el flujo de incorporación para crear uno nuevo. Esta acción no se puede deshacer.",
	title: "Retirar asistente"
}, ae = { loadingAria: "Cargando" }, oe = { loadingAria: "Cargando" }, se = { unnamedAssistant: "el asistente" }, ce = {
	chunkFailBody: "Esta sección no se pudo cargar. Probablemente un fallo de red o una versión antigua. Recarga la página para intentarlo de nuevo.",
	reload: "Recargar"
}, le = {
	confirmMessage: "¿Actualizar a la versión {version}? El asistente no estará disponible brevemente durante la actualización.",
	confirmTitle: "Actualizar el runtime del asistente",
	later: "Más tarde",
	title: "Nueva versión del asistente disponible: {version}",
	toastComplete: "Actualización completa. Tu asistente está en buen estado.",
	toastFailed: "No se pudo iniciar la actualización. Inténtalo de nuevo.",
	update: "Actualizar"
}, ue = { ariaLabel: "Acciones de {name}" }, de = {
	reset: "Restablecer",
	save: "Guardar"
}, fe = { label: "Compartir enlace de conexión" }, pe = {
	aboutDiagnosticsAria: "Acerca de los diagnósticos",
	addFiles: "Añadir archivos",
	adminOnlyHint: "Solo para administradores: crea el archivo de diagnósticos en local y lo descarga en lugar de enviar comentarios o notificar a Slack.",
	attachments: "Adjuntos",
	bugTip: "Consejo: obtén soporte más rápido publicando en nuestra <discordLink>comunidad de Discord</discordLink>",
	cancel: "Cancelar",
	category: "Categoría",
	closeAria: "Cerrar",
	diagnosticsTooltip: "Los diagnósticos incluyen el contexto del navegador, los registros del asistente y marcas de tiempo; nunca contraseñas ni credenciales.",
	downloadDiagnostics: "Descargar diagnósticos directamente",
	downloadDiagnosticsAria: "Descargar diagnósticos directamente",
	downloadDiagnosticsButton: "Descargar diagnósticos",
	dropFiles: "Suelta archivos para adjuntarlos…",
	email: "Correo electrónico",
	featureTip: "Consejo: vota funciones en nuestro <roadmapLink>roadmap público</roadmapLink>",
	includeConversation: "Incluir la conversación más reciente",
	includeConversationAria: "Incluir la conversación más reciente",
	includeDiagnostics: "Incluir diagnósticos",
	includeDiagnosticsAria: "Incluir diagnósticos del navegador",
	messageLabelBug: "¿Qué salió mal?",
	messageLabelFeature: "Describe tu idea",
	messageLabelOther: "¿Qué tienes en mente?",
	messagePlaceholderBug: "¿Qué esperabas que ocurriera y qué ocurrió en su lugar?",
	messagePlaceholderFeature: "¿Qué problema te resolvería esto?",
	messagePlaceholderOther: "Comparte tus pensamientos...",
	preparingDiagnostics: "Preparando diagnósticos…",
	reasonBugReport: "Informe de error",
	reasonFeatureRequest: "Solicitud de función",
	reasonOther: "Otro",
	removeAttachmentAria: "Eliminar {name}",
	sendingFeedback: "Enviando comentarios…",
	submit: "Enviar",
	timeRange: "Intervalo de tiempo",
	timeRangeAllTime: "Todo el tiempo",
	timeRangeAria: "Intervalo de tiempo de diagnósticos",
	timeRangePast24Hours: "Últimas 24 horas",
	timeRangePastHour: "Última hora",
	title: "Compartir comentarios"
}, me = { loadingAria: "Cargando el formulario de comentarios" }, he = {
	close: "Cerrar",
	message: "No se pudo cargar el formulario de comentarios.",
	retry: "Reintentar"
}, ge = {
	closeAria: "Cerrar",
	closeSidebarAria: "Cerrar barra lateral",
	openSidebarAria: "Abrir barra lateral"
}, _e = {
	backFrom: "Volver desde {title}",
	backToMenu: "Volver al menú de {title}",
	navigationAria: "Navegación de {title}"
}, ve = { ariaLabel: "Navegación de la barra lateral" }, ye = { label: "Aprendido de esta conversación" }, be = {
	message: "¿Quitar \"{name}\" de este asistente?",
	remove: "Quitar",
	title: "Quitar skill"
}, xe = {
	approvalNotice: "Si Slack muestra “Request approval” en lugar de <strong>Install</strong>, un administrador del espacio de trabajo debe aprobar la app primero.",
	createdApp: "He creado la app",
	inSlack: "En Slack:",
	stepManifest: "En <strong>Or start your own way</strong>, elige <strong>From a manifest</strong> y luego <strong>Continue</strong>",
	stepPaste: "Elige tu espacio de trabajo y pega el manifiesto",
	stepReview: "Revisa los permisos y haz clic en <strong>Create and Install</strong>"
}, Se = {
	appName: "Nombre de la app",
	appNamePlaceholder: "Mi asistente",
	copied: "¡Copiado!",
	copyManifest: "Copiar manifiesto",
	description: "Descripción (opcional)",
	descriptionHelper: "Se muestra en el perfil de Slack de la app.",
	descriptionPlaceholder: "En qué ayuda este asistente",
	intro: "Ponle nombre a tu app de Slack y copia su manifiesto. Todos los permisos y ajustes vienen preconfigurados.",
	next: "Siguiente"
}, Ce = {
	body: "Abre Slack en una pestaña nueva para crear la app y vuelve aquí para los pasos siguientes.",
	copied: "¡Copiado!",
	copyManifest: "Copiar manifiesto",
	manifestCopiedNotice: "Copiaste el manifiesto de esta app aquí. Si has copiado algo desde entonces, cópialo de nuevo antes de pegar.",
	manifestNotCopiedNotice: "Aún no has copiado el manifiesto de esta app. El modal de crear app de Slack no tiene otra forma de obtenerlo, así que cópialo antes de pegar.",
	next: "Siguiente",
	openSlack: "Abrir Slack"
}, we = {
	appTokenLabel: "Token de la app",
	botTokenLabel: "Token del bot",
	connectSlack: "Conectar Slack",
	connecting: "Conectando…",
	credentialsSaved: "Credenciales guardadas",
	instructions: "En la pantalla de confirmación de Slack, expande <credentials>Your app credentials</credentials> y copia ambos tokens.",
	skipNotice: "Esa pantalla también ofrece una guía por línea de comandos y un botón <download>Download app files</download>. Omite ambos. Configuran una app local aparte, y este asistente solo necesita los dos tokens.",
	savedBody: "Ambos tokens están guardados. La parte de Slack está lista."
}, Te = {
	channelLabel: "Slack",
	copyError: "No se pudo copiar el manifiesto. Cópialo de nuevo antes de continuar.",
	stepConnect: "Conectar",
	stepCreate: "Crear",
	stepName: "Nombre",
	stepOpen: "Abrir"
}, Ee = { total: "Total: {value}" }, De = { reloadApp: "Recargar app" }, Oe = {
	reconnecting: "Reconectando con tu asistente…",
	dismiss: "Descartar",
	goToDoctor: "Ir a Doctor",
	resumeAssistant: "Reanudar asistente",
	retryNow: "Reintentar ahora",
	wakeUp: "Despertar"
}, ke = {
	allLanguages: "Todos los idiomas",
	featured: "Destacados",
	languagesAriaLabel: "Idiomas",
	noMatch: "Ningún idioma coincide.",
	searchAriaLabel: "Buscar idiomas",
	searchPlaceholder: "Buscar idiomas",
	suggested: "Sugerido"
}, Ae = { description: "Se aplica desde tu próximo turno hablado." }, je = {
	apiKeyLabel: "Clave de API",
	apiKeyPlaceholderReplace: "••••••••  (Introduce una clave nueva para reemplazarla)",
	providerAriaLabel: "Proveedor de STT",
	providerLabel: "Proveedor",
	saveFailed: "No se pudieron guardar los ajustes de voz a texto",
	saveSuccess: "Ajustes de voz a texto guardados",
	spokenLanguage: "Idioma hablado",
	spokenLanguageApplies: "Se aplica a partir de tu próximo turno hablado.",
	cadetTranscription: "La transcripción se realiza a través de tu cuenta de Cadet.",
	windowsNativeDisplayName: "Dictado nativo de Windows",
	windowsNativeSetupWarning: "Requiere Reconocimiento de voz básico para el idioma de visualización de Windows: abre Configuración > Hora e idioma > Idioma y región, selecciona los tres puntos junto al idioma de visualización, elige Opciones de idioma y, en Características de idioma, descarga Reconocimiento de voz básico.",
	windowsNativeSubtitle: "Reconocimiento de voz integrado de Windows, ejecutado localmente mediante el asistente nativo de Windows. Funciona sin conexión y no necesita una clave de API."
}, Me = { ariaLabel: "Subagente {subagentId}" }, Ne = {
	accessibilityDescription: "Permite que tu asistente haga clic, escriba y controle apps en tu nombre.",
	accessibilityLabel: "Accesibilidad",
	checking: "Comprobando permisos...",
	dockIcon: "icono del Dock",
	microphoneDescription: "Permite que tu asistente capture audio para entrada de voz y grabaciones.",
	microphoneLabel: "Micrófono",
	notificationBadgesDescription: "Permite que tu asistente muestre el recuento de conversaciones no vistas en el {surface}.",
	notificationBadgesLabel: "Insignias de notificación",
	notificationsDescription: "Permite que tu asistente envíe alertas de macOS para aprobaciones, mensajes y actualizaciones de tareas.",
	notificationsLabel: "Notificaciones",
	notificationsWindowsDescription: "Permite que tu asistente muestre notificaciones de Windows para aprobaciones, mensajes y actualizaciones de tareas.",
	screenDescription: "Permite que tu asistente capture el contexto de la pantalla durante tareas de uso del ordenador.",
	screenLabel: "Grabación de pantalla",
	speechRecognitionDescription: "Permite que tu asistente transcriba tu voz a texto en el dispositivo.",
	speechRecognitionLabel: "Reconocimiento de voz",
	speechRecognitionWindowsDescription: "Permite que tu asistente transcriba tu voz a texto con el reconocimiento de voz de Windows.",
	taskbarIcon: "icono de la barra de tareas",
	title: "Permisos del sistema"
}, Pe = {
	botTokenLabel: "Token del bot",
	connectTelegram: "Conectar Telegram",
	instructions: "Pega el token de la respuesta de BotFather. Es la línea completa después de <tokenLine>Use this token to access the HTTP API</tokenLine>.",
	saving: "Guardando…",
	savedTitle: "Token guardado",
	savedBody: "El token del bot está guardado. La parte de Telegram está lista."
}, Fe = {
	copied: "¡Copiado!",
	copyName: "Copiar nombre",
	displayNameHint: "Para el nombre visible, <strong>{suggestedName}</strong> mantiene este bot alineado con tu asistente. El nombre de usuario es independiente y no tiene que coincidir.",
	chatScopeNotice: "Los chats privados y los grupos están admitidos. En un grupo, el asistente responde cuando lo mencionan o cuando alguien responde a uno de sus mensajes. Los canales de difusión no están admitidos.",
	inBotFather: "En BotFather:",
	intro: "Los bots de Telegram se crean enviando un mensaje a <strong>@BotFather</strong>. Ábrelo, sigue las indicaciones y vuelve con el token que te dé.",
	next: "Siguiente",
	openBotFather: "Abrir BotFather",
	stepDisplayName: "Dale un nombre visible, que es lo que la gente ve en el chat",
	stepSendNewBot: "Envía <strong>/newbot</strong>",
	stepTokenReply: "BotFather responde con un token después de <strong>Use this token to access the HTTP API</strong>",
	stepUsername: "Dale un nombre de usuario, que debe ser único y terminar en <strong>bot</strong>"
}, Ie = {
	channelLabel: "Telegram",
	copyError: "No se pudo copiar el nombre. Escríbelo en BotFather en su lugar.",
	stepConnect: "Conectar",
	stepCreate: "Crear bot"
}, Le = {
	shopifyLabel: "Dominio de la tienda",
	shopifyPlaceholder: "tu-tienda.myshopify.com"
}, Re = { recoveryModeBanner: "Modo de recuperación activo: esta sesión está conectada al terminal de depuración." }, ze = {
	accentFill: "Relleno de acento",
	activeBorder: "Borde activo",
	activeSurface: "Superficie activa",
	assistantBubble: "Una respuesta del asistente, a ancho completo sobre la superficie de la página.",
	buttonDisabled: "Deshabilitado",
	buttonPrimary: "Principal",
	buttonSecondary: "Secundario",
	chatAssistant1: "Listo. El resumen está preparado. Los ingresos crecieron de forma constante, los dos riesgos señalados del trimestre pasado están resueltos y reuní en una página aparte los tres gráficos que conviene mostrar.",
	chatAssistant2: "Programado para las 9:00. Incluiré los gráficos y una versión de un párrafo para quien lo revise en el teléfono.",
	chatUser1: "¿Puedes resumir el informe trimestral antes de la reunión de mañana?",
	chatUser2: "Perfecto. Envíalo al equipo por la mañana.",
	composerPlaceholder: "Escribe a tu asistente",
	faintText: "Texto tenue: el último escalón legible de la rampa.",
	inputFilled: "Texto que alguien ya ha escrito en un campo.",
	inputPlaceholder: "Un marcador de posición en un campo vacío",
	newConversation: "Nueva conversación",
	overlaySurface: "Superficie de superposición",
	primaryText: "Texto principal: la superficie de lectura principal de la app.",
	quietText: "Texto discreto: metadatos y marcas de tiempo.",
	raisedCard: "Tarjeta elevada",
	raisedCardBody: "Las superficies elevadas se sitúan por encima de los paneles y del fondo de la página.",
	samplerTitle: "Muestreador de tema",
	secondaryText: "Texto secundario: textos de apoyo y descripciones.",
	sectionAccent: "Acento",
	sectionButtons: "Botones",
	sectionInputs: "Campos",
	sectionMessages: "Mensajes",
	sectionSurfaces: "Superficies y bordes",
	sectionText: "Texto",
	send: "Enviar",
	subtleDivider: "Divisor sutil encima de esta línea.",
	tertiaryText: "Texto terciario: pies de foto, etiquetas y marcadores de posición.",
	userBubble: "Un mensaje del usuario, en su burbuja."
}, Be = {
	dark: "Oscuro",
	label: "Tema",
	light: "Claro",
	system: "Sistema"
}, Ve = {
	apiKey: "Clave de API",
	apiKeyRequired: "Guarda una clave de API para este proveedor antes de probar.",
	chooseFromCatalog: "Elegir del catálogo",
	customVoiceIdAriaLabel: "ID de voz personalizado",
	noCloudVoices: "No hay voces gestionadas disponibles en este momento.",
	provider: "Proveedor",
	providerAriaLabel: "Proveedor de TTS",
	saveFailed: "No se pudieron guardar los ajustes de texto a voz",
	saved: "Ajustes de texto a voz guardados",
	test: "Probar",
	testing: "Probando…",
	voice: "Voz",
	voiceId: "ID de voz",
	voiceIdPlaceholder: "Introduce un ID de voz"
}, He = {
	available: "Actualización disponible. Iniciando descarga…",
	closeAriaLabel: "Cerrar",
	downloading: "Descargando actualización…",
	ready: "Cadet {version} está listo.",
	restartToInstall: "Reiniciar para instalar",
	versionFallback: "actualización"
}, Ue = { deleteFailed: "No se pudo eliminar la app" }, We = {
	copyFailed: "No se pudo copiar el enlace. Ábrelo en {url}",
	linkCopied: "Enlace copiado",
	open: "Abrir"
}, Ge = {
	setupPrompt: {
		slack: "Quiero comunicarme contigo por Slack. Vamos a configurarlo.",
		telegram: "Quiero comunicarme contigo por Telegram. Vamos a configurarlo.",
		discord: "Quiero comunicarme contigo por Discord. Vamos a configurarlo.",
		email: "Quiero enviarte correos. Vamos a configurar tu dirección de correo.",
		phone: "Quiero poder llamarte. Vamos a conseguirte un número de teléfono."
	},
	finishPrompt: {
		slack: "Slack está configurado pero no funciona. ¿Puedes terminarlo?",
		telegram: "Telegram está configurado pero no funciona. ¿Puedes terminarlo?",
		discord: "Discord está configurado pero no funciona. ¿Puedes terminarlo?",
		email: "Mi dirección de correo está configurada pero no funciona. ¿Puedes terminarla?",
		phone: "Mi número de teléfono está configurado pero no funciona. ¿Puedes terminarlo?"
	}
}, Ke = {
	addFailed: "No se pudo marcar el mensaje.",
	removeFailed: "No se pudo quitar el marcador."
}, qe = {
	exchangeFailed: "Comprueba la clave pegada e inténtalo de nuevo.",
	failed: "No se pudo conectar Claude. Inténtalo de nuevo.",
	notStarted: "Primero inicia el flujo de Connect Claude.",
	pasteEmpty: "Pega el código que se muestra en la página de Claude.",
	popupBlocked: "Tu navegador bloqueó la pestaña de inicio de sesión. Permite las ventanas emergentes para este sitio y vuelve a hacer clic en Conectar.",
	startFailed: "No se pudo iniciar Connect Claude. Inténtalo de nuevo.",
	timedOut: "Se agotó el tiempo de espera para conectar Claude. Inténtalo de nuevo."
}, Je = {
	accountConnected: "Cuenta de {name} conectada.",
	authorizationError: "Error de {name}: {code}",
	authorizationFailed: "La autorización de {name} falló",
	popupBlocked: "Ventana emergente bloqueada. Permite las ventanas emergentes e inténtalo de nuevo.",
	startFailed: "No se pudo iniciar la autorización de {name}.",
	startFailedWithReason: "No se pudo iniciar la autorización de {name}: {reason}"
}, Ye = {
	blocked: "Tu navegador bloqueó una página que el asistente intentó abrir.",
	openPage: "Abrir página"
}, Xe = { playFailed: "No se pudo reproducir la muestra de voz." }, Ze = { updated: "Tema actualizado" }, Qe = {
	body: "Introduce tu token de API de Vercel para publicar apps como páginas estáticas.",
	cancel: "Cancelar",
	createToken: "Crear un token en Vercel →",
	save: "Guardar",
	saveFailed: "No se pudo guardar el token de Vercel.",
	saving: "Guardando…",
	title: "Conectar Vercel",
	tokenLabel: "Token de API",
	tokenPlaceholder: "Token de API de Vercel"
}, $e = {
	assistantVoiceAriaLabel: "Voz del asistente",
	defaultSuffix: "(predeterminada)",
	previewVoice: "Vista previa de {description}",
	providerAriaLabel: "Proveedor de voz",
	stopPreview: "Detener vista previa"
}, et = {
	ariaLabel: "Voz",
	selectVoice: "Selecciona una voz"
}, tt = {
	done: "Listo",
	title: "Voces"
}, nt = { body: "Los proveedores de voz, la transcripción y las claves de API están en <modelsLink>Modelos y servicios</modelsLink>." }, rt = { recommendedOff: "Recomendado desactivado" }, it = {
	developer: "Desarrollador",
	file: "Archivo",
	help: "Ayuda",
	view: "Ver"
}, at = {
	checkingDomain: "Comprobando dominio…",
	domainVerified: "Dominio verificado",
	failedTitle: "La verificación del dominio falló. Es posible que los registros DNS no se hayan propagado correctamente. Puedes intentar liberar y volver a registrar el dominio.",
	unknownStatus: "Estado desconocido",
	unknownStatusTitle: "No se pudo obtener el estado de verificación del dominio.",
	verificationFailed: "Verificación fallida",
	verifiedTitle: "Los registros DNS se han verificado. Tu dominio está listo para enviar y recibir correo.",
	verifyingDomain: "Verificando dominio…",
	verifyingTitle: "Los registros DNS se han aprovisionado. Esperando a que el proveedor de correo los verifique; esto suele tardar unos minutos.",
	setupRequired: "Configuración del dominio requerida",
	setupRequiredTitle: "Este dominio no se ha aprovisionado con el proveedor de correo. No puede enviar ni recibir correo hasta completar la configuración."
}, ot = { body: "Los servicios administrados se miden y se deducen del saldo de tu cuenta de Cadet. <link>Ver precios</link>" }, st = {
	managedLabel: "Administrado",
	modeToggleAriaLabel: "Modo de servicio",
	yourOwnLabel: "Propio"
}, ct = {
	title: "Identificador del asistente",
	description: "El nombre público de tu asistente. También es el nombre sobre el que se crea su dirección de correo.",
	helper: "Minúsculas, números, guiones y guiones bajos."
}, lt = {
	close: "Cerrar",
	closePanel: "Cerrar panel",
	loading: "Cargando…"
}, ut = {
	back: "Volver al recorrido",
	dragInstruction: "Arrastra {app} a la lista para permitir {permission}.",
	dragApp: "Arrastra {app} a Ajustes del Sistema o pulsa para mostrar en Finder",
	dragError: "No se puede arrastrar. Inténtalo desde Finder.",
	showInFinder: "Mostrar en Finder",
	inputLabel: "Monitorización de entrada"
}, dt = {
	loopback: "Esta es una dirección de loopback que otros dispositivos no pueden alcanzar. Introduce la URL https pública del asistente.",
	nonHttps: "La URL debe usar https para que tus dispositivos se conecten de forma segura.",
	privateAddress: "Esta dirección apunta a una dirección de red privada. Introduce la URL https pública del asistente para que tus dispositivos puedan alcanzarlo.",
	serviceFallbackName: "el proveedor del túnel",
	serviceWebsite: "Este es el sitio web de {service}, no la dirección de tu asistente. Inicia un túnel en el host para obtener una; `cadet tunnel --help` lista los proveedores.",
	unparseable: "Introduce una URL válida, p. ej. https://your-assistant.ts.net."
}, ft = {
	aboutPage: e,
	activeAssistantGate: t,
	addCredentialModal: n,
	addCreditsModal: r,
	appCard: i,
	appNavBar: a,
	appViewerContainer: o,
	assistantConnect: s,
	assistantEmailIntroModal: c,
	assistantFeatureFlagStore: l,
	avatarManagementModal: u,
	bundleConfirmPage: d,
	byoVoiceNote: f,
	channelSetupCompleteNotice: p,
	chatAvatar: m,
	chooserAvatarChip: h,
	collapsibleNavSection: g,
	commandPalette: _,
	companionIntro: v,
	companionPopover: y,
	companionSurface: b,
	companionWatchFramePage: x,
	contentActionBar: S,
	conversationTitle: C,
	copyButton: w,
	createAssistantDialog: T,
	dateRangeSelect: E,
	deleteAppDialog: D,
	deployDialogs: O,
	deployStore: k,
	detailPanelStopButton: A,
	detailPrimitives: j,
	dictationOverlayPage: M,
	discordNudgeBanner: N,
	discordSetupConnectStep: P,
	discordSetupCreateStep: F,
	discordSetupFinishStep: I,
	discordSetupInviteStep: L,
	discordSetupWizard: R,
	diskPressureBanner: z,
	downloadFeedback: B,
	editFooter: V,
	featureIntroModal: H,
	fileViewMode: U,
	generateInviteLinkDialog: W,
	githubNudgeBanner: G,
	lazyBoundary: K,
	localNotification: q,
	desktopAppBanner: J,
	nativeAppBanner: Y,
	nudgeChatBanner: X,
	onboardingBackButton: Z,
	platformLoginNotice: Q,
	profileCard: $,
	profileQuickAddProvider: ee,
	quickInputPage: te,
	removeFromDeviceDialog: ne,
	resourcePressureBanner: re,
	retireConfirmDialog: ie,
	rootHydrateFallback: ae,
	routePendingIndicator: oe,
	rootLayout: se,
	routeErrorBoundary: ce,
	runtimeUpgradeBanner: le,
	sectionActionsButton: ue,
	serviceFormControls: de,
	shareConnectionLinkButton: fe,
	shareFeedbackModal: pe,
	shareFeedbackModalFallback: me,
	shareFeedbackModalLoadError: he,
	sideListDrawer: ge,
	sidebarShell: _e,
	sidebarTree: ve,
	skillLineageLink: ye,
	skillRemovalDialog: be,
	slackSetupCreateStep: xe,
	slackSetupNameStep: Se,
	slackSetupOpenStep: Ce,
	slackSetupTokensStep: we,
	slackSetupWizard: Te,
	stackedBarTooltip: Ee,
	startupFailure: De,
	statusBanner: Oe,
	sttLanguagePicker: ke,
	sttLanguagePickerModal: Ae,
	sttProviderForm: je,
	subagentAvatarChip: Me,
	systemPermissionsCard: Ne,
	telegramSetupConnectStep: Pe,
	telegramSetupCreateStep: Fe,
	telegramSetupWizard: Ie,
	tenantHost: Le,
	terminalPanel: Re,
	themeStagePage: ze,
	themeToggle: Be,
	ttsProviderForm: Ve,
	updateToast: He,
	useAppDelete: Ue,
	useAppDeployment: We,
	useAssistantChannels: Ge,
	useBookmarks: Ke,
	useConnectClaude: qe,
	useOauthConnect: Je,
	useOpenUrlDirectives: Ye,
	useVoiceSamplePreview: Xe,
	useWorkspaceTheme: Ze,
	vercelTokenDialog: Qe,
	voiceList: $e,
	voicePickerField: et,
	voicePickerModal: tt,
	voiceProvidersNote: nt,
	voiceTranscriptToggles: rt,
	windowsMenuBar: it,
	domainVerificationChip: at,
	managedServicesBanner: ot,
	serviceCard: st,
	assistantHandleModal: ct,
	detailShell: lt,
	permissionGuide: ut,
	pairDeviceUrl: dt
};
//#endregion
export { e as aboutPage, t as activeAssistantGate, n as addCredentialModal, r as addCreditsModal, i as appCard, a as appNavBar, o as appViewerContainer, s as assistantConnect, c as assistantEmailIntroModal, l as assistantFeatureFlagStore, ct as assistantHandleModal, u as avatarManagementModal, d as bundleConfirmPage, f as byoVoiceNote, p as channelSetupCompleteNotice, m as chatAvatar, h as chooserAvatarChip, g as collapsibleNavSection, _ as commandPalette, v as companionIntro, y as companionPopover, b as companionSurface, x as companionWatchFramePage, S as contentActionBar, C as conversationTitle, w as copyButton, T as createAssistantDialog, E as dateRangeSelect, ft as default, D as deleteAppDialog, O as deployDialogs, k as deployStore, J as desktopAppBanner, A as detailPanelStopButton, j as detailPrimitives, lt as detailShell, M as dictationOverlayPage, N as discordNudgeBanner, P as discordSetupConnectStep, F as discordSetupCreateStep, I as discordSetupFinishStep, L as discordSetupInviteStep, R as discordSetupWizard, z as diskPressureBanner, at as domainVerificationChip, B as downloadFeedback, V as editFooter, H as featureIntroModal, U as fileViewMode, W as generateInviteLinkDialog, G as githubNudgeBanner, K as lazyBoundary, q as localNotification, ot as managedServicesBanner, Y as nativeAppBanner, X as nudgeChatBanner, Z as onboardingBackButton, dt as pairDeviceUrl, ut as permissionGuide, Q as platformLoginNotice, $ as profileCard, ee as profileQuickAddProvider, te as quickInputPage, ne as removeFromDeviceDialog, re as resourcePressureBanner, ie as retireConfirmDialog, ae as rootHydrateFallback, se as rootLayout, ce as routeErrorBoundary, oe as routePendingIndicator, le as runtimeUpgradeBanner, ue as sectionActionsButton, st as serviceCard, de as serviceFormControls, fe as shareConnectionLinkButton, pe as shareFeedbackModal, me as shareFeedbackModalFallback, he as shareFeedbackModalLoadError, ge as sideListDrawer, _e as sidebarShell, ve as sidebarTree, ye as skillLineageLink, be as skillRemovalDialog, xe as slackSetupCreateStep, Se as slackSetupNameStep, Ce as slackSetupOpenStep, we as slackSetupTokensStep, Te as slackSetupWizard, Ee as stackedBarTooltip, De as startupFailure, Oe as statusBanner, ke as sttLanguagePicker, Ae as sttLanguagePickerModal, je as sttProviderForm, Me as subagentAvatarChip, Ne as systemPermissionsCard, Pe as telegramSetupConnectStep, Fe as telegramSetupCreateStep, Ie as telegramSetupWizard, Le as tenantHost, Re as terminalPanel, ze as themeStagePage, Be as themeToggle, Ve as ttsProviderForm, He as updateToast, Ue as useAppDelete, We as useAppDeployment, Ge as useAssistantChannels, Ke as useBookmarks, qe as useConnectClaude, Je as useOauthConnect, Ye as useOpenUrlDirectives, Xe as useVoiceSamplePreview, Ze as useWorkspaceTheme, Qe as vercelTokenDialog, $e as voiceList, et as voicePickerField, tt as voicePickerModal, nt as voiceProvidersNote, rt as voiceTranscriptToggles, it as windowsMenuBar };
