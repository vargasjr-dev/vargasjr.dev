//#region src/i18n/locales/zh-TW/onboarding.json
var e = {
	continue: "繼續",
	back: "返回",
	forward: "前進",
	cancel: "取消",
	add: "新增",
	adding: "正在新增…",
	tryAgain: "再試一次",
	remove: "移除 {value}",
	downloadMacOSApp: "下載 macOS 應用程式",
	downloadWindowsApp: "下載 Windows 應用程式",
	claim: "認領"
}, t = {
	addOption: "新增「{value}」",
	enterHint: "↵ 輸入",
	freeTextHint: "輸入任何內容並按下 ↵ 以新增您自己的"
}, n = { ariaLabel: "第 {current} 步，共 {total} 步" }, r = {
	greetingNamed: "嗨，{name}！",
	greeting: "嗨！",
	introNamed: "我是 {name}，您的新 AI 助理。",
	intro: "我是您的新 AI 助理。"
}, i = {
	setupLine: "您可能用過只會回答問題的 AI。",
	helpLine: "我幫助得越多，",
	punchLine: "我與眾不同。",
	betterLine: "我就越好，",
	lessLine: "您需要做的就越少。"
}, a = {
	title: "建立我的個性",
	lockedBody: "個性已鎖定，請與您的助理聊天以進行更多更新",
	axisAriaLabel: "從 {left} 到 {right}",
	axes: {
		companionCoworker: {
			left: "夥伴",
			right: "同事"
		},
		genzBoomer: {
			left: "Z 世代",
			right: "嬰兒潮世代"
		},
		executeCollaborate: {
			left: "獨立",
			right: "協作"
		},
		playfulSerious: {
			left: "活潑",
			right: "嚴肅"
		},
		politeUnfiltered: {
			left: "有禮",
			right: "直率"
		}
	}
}, o = {
	title: "給我一個形象和名稱",
	previousCharacter: "上一個形象",
	nextCharacter: "下一個形象",
	namePlaceholder: "為您的助理命名",
	nameAriaLabel: "助理名稱",
	editName: "編輯名稱",
	shuffle: "隨機名稱和外觀",
	hearVoice: "聽我的聲音",
	stopVoice: "停止語音範例"
}, s = { title: "這裡有一些初始用法<br></br>供您開始。" }, c = {
	title: "我們從您開始。",
	firstNameLabel: "我該怎麼稱呼您？",
	firstNamePlaceholder: "您的名字",
	skip: "跳過初始設定"
}, l = {
	titleNamed: "{name} 已啟動並正在執行",
	title: "您的助理已啟動並正在執行",
	bodyNamed: "你們之間有歷史：個性、記憶和過去的對話。再次執行設定將會覆寫 {name} 現在的身份。",
	body: "你們之間有歷史：個性、記憶和過去的對話。再次執行設定將會覆寫您的助理現在的身份。",
	keepNamed: "保留 {name} 並開始聊天",
	keep: "保留您的助理並開始聊天",
	redoNamed: "重新開始並重建 {name} 的個性",
	redo: "重新開始並重建其個性"
}, u = {
	searching: "正在搜尋網路以了解您…",
	readingProfiles: "正在閱讀公開個人資料…",
	skimming: "正在瀏覽重點…",
	connectingDots: "正在連結點滴資訊…",
	piecing: "正在整合資訊…",
	almostThere: "快完成了…"
}, d = {
	updatingPersonality: "正在更新我的個性…",
	findingVoice: "正在尋找我的聲音…",
	gettingIntoCharacter: "正在進入角色…",
	almostThere: "快完成了…"
}, f = {
	title: "這是我找到關於您的資訊",
	bodyLoadingWithClaims: "仍在檢查其餘資訊。您可以在資訊出現時進行檢閱。",
	bodyReadyWithClaims: "我搜尋了網路。請隨意移除任何不實的資訊。",
	bodyLoadingEmpty: "仍在整理中…",
	removeClaim: "移除「{claim}」",
	notMe: "這不是我",
	stillSearching: "仍在搜尋…"
}, p = {
	title: "這是我們首先可以做的事情",
	pickOne: "選擇一個開始，或自行建立。<skip>跳至聊天</skip>",
	loading: "正在整理一些想法…",
	alreadySetUp: "已設定 <plugins></plugins> {count, plural, other {# 個}} 外掛程式以協助您完成工作",
	listAnd: " 和 ",
	listCommaAnd: "，和",
	listComma: "，",
	fallbacks: {
		brief: {
			suggestion: "我將為您整理一份關於您領域最新動態的簡報",
			prompt: "給我一份關於我領域最新動態的簡報。"
		},
		weekly: {
			suggestion: "我將每週發送一份關於您領域新聞的簡報",
			prompt: "設定每週發送一份關於我領域新聞的簡報。"
		},
		week: {
			suggestion: "我將協助您掌握您的一週",
			prompt: "協助我掌握我的一週。"
		},
		draft: {
			suggestion: "我將根據一些粗略的筆記起草內容",
			prompt: "根據我提供的一些粗略筆記起草內容。"
		}
	}
}, m = {
	genericFailure: "發生錯誤。請再試一次。",
	signupClosed: "很抱歉，Cadet 目前不接受新用戶註冊。歡迎稍後再試。",
	providerSignup: "該登入尚未連結 Cadet 帳號。請先註冊，然後登入。",
	loginIncomplete: "您的帳號需要額外步驟才能完成登入。請在網頁上登入，然後再試一次。",
	desktopUpdateRequired: "此版本的 Cadet 桌面應用程式無法登入。請更新應用程式，然後再試一次。"
}, h = {
	genericFailure: "發生了一些錯誤",
	localFallbackPitch: "立即開始使用本機助理"
}, g = {
	actions: e,
	onboardingAutocomplete: t,
	stepIndicator: n,
	introductionScreen: r,
	pitchStep: i,
	createPersonalityStep: a,
	giveMeAFaceScreen: o,
	integrationStep: s,
	researchOnboardingScreen: c,
	existingAssistantStep: l,
	lookingYouUpStep: u,
	finishingUpStep: d,
	researchResultsStep: f,
	suggestionsStep: p,
	authErrors: m,
	hatchingScreen: h
};
//#endregion
export { e as actions, m as authErrors, a as createPersonalityStep, g as default, l as existingAssistantStep, d as finishingUpStep, o as giveMeAFaceScreen, h as hatchingScreen, s as integrationStep, r as introductionScreen, u as lookingYouUpStep, t as onboardingAutocomplete, i as pitchStep, c as researchOnboardingScreen, f as researchResultsStep, n as stepIndicator, p as suggestionsStep };
