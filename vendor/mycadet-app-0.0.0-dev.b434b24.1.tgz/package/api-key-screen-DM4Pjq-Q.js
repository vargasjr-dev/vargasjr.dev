import { c as e, d as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { t as n } from "./select-B4GhYADp.js";
import { t as r } from "./external-anchor--Bf99ulE.js";
import { r as i } from "./i18n-BRf-wfgm.js";
import { t as a } from "./button-BrPHE1Q9.js";
import { r as o } from "./es2015-B_BDkut6.js";
import { n as s } from "./routes-DW44XTQk.js";
import { t as c } from "./account-shell-D0S9QH7J.js";
import { n as l, t as u } from "./onboarding-destination-BVBsT8nb.js";
import { t as d } from "./onboarding-navigation-Bp-9lTqG.js";
import { n as f, t as p } from "./provider-key-W64jwzTy.js";
import { useState as m } from "react";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
//#region src/domains/onboarding/provider-catalog.ts
var v = [
	{
		id: "fireworks",
		displayName: "Fireworks",
		apiKeyPlaceholder: "fw_...",
		docsUrl: "https://fireworks.ai/account/api-keys",
		requiresKey: !0,
		defaultModel: "accounts/fireworks/models/minimax-m3"
	},
	{
		id: "openrouter",
		displayName: "OpenRouter",
		apiKeyPlaceholder: "sk-or-v1-...",
		docsUrl: "https://openrouter.ai/keys",
		requiresKey: !0,
		defaultModel: "anthropic/claude-sonnet-4.6"
	},
	{
		id: "vercel-ai-gateway",
		displayName: "Vercel AI Gateway",
		apiKeyPlaceholder: "vck_...",
		docsUrl: "https://vercel.com/d?to=%2F%5Bteam%5D%2F%7E%2Fai-gateway%2Fapi-keys&title=AI+Gateway+API+Keys",
		requiresKey: !0,
		defaultModel: "anthropic/claude-sonnet-4.6"
	},
	{
		id: "openai",
		displayName: "OpenAI",
		apiKeyPlaceholder: "sk-proj-...",
		docsUrl: "https://platform.openai.com/api-keys",
		requiresKey: !0,
		defaultModel: "gpt-5.4-mini"
	},
	{
		id: "anthropic",
		displayName: "Anthropic",
		apiKeyPlaceholder: "sk-ant-api03-...",
		docsUrl: "https://console.anthropic.com/settings/keys",
		requiresKey: !0,
		defaultModel: "claude-sonnet-4-6"
	},
	{
		id: "gemini",
		displayName: "Google Gemini",
		apiKeyPlaceholder: "AIza...",
		docsUrl: "https://aistudio.google.com/apikey",
		requiresKey: !0,
		defaultModel: "gemini-3-flash-preview"
	},
	{
		id: "ollama",
		displayName: "Ollama",
		apiKeyPlaceholder: null,
		docsUrl: "https://ollama.com/download",
		requiresKey: !1,
		defaultModel: "llama3.2",
		models: [{
			id: "llama3.2",
			displayName: "Llama 3.2",
			contextWindowTokens: 128e3,
			maxOutputTokens: 4096
		}, {
			id: "mistral",
			displayName: "Mistral",
			contextWindowTokens: 32768,
			maxOutputTokens: 4096
		}]
	},
	{
		id: "openai-compatible",
		displayName: "OpenAI-compatible",
		apiKeyPlaceholder: "Your provider's API key (optional)",
		docsUrl: null,
		requiresKey: !0
	}
], y = v[0];
function b(e) {
	return v.find((t) => t.id === e);
}
function x(e) {
	let t = b(e);
	return t?.defaultModel ?? t?.models?.[0]?.id;
}
//#endregion
//#region src/domains/onboarding/pages/api-key-screen.tsx
var S = "touch-mobile:text-[16px]";
function C() {
	let { t: C } = i("account"), w = e(), [T] = t(), E = T.get("hosting"), D = p(), [O, k] = m(() => D?.provider ?? y.id), [A, j] = m(() => D?.key ?? ""), [M, N] = m(() => D?.model ?? x(D?.provider ?? y.id) ?? ""), [P, F] = m(() => D?.baseUrl ?? ""), [I, L] = m(() => D?.customModels ?? ""), R = b(O) ?? y, z = R.models ?? [], B = R.requiresKey, V = z.length > 0, H = O === "openai-compatible", U = (!(B && !H) || A.trim().length > 0) && (!V || M.trim().length > 0) && (!H || P.trim().length > 0 && I.trim().length > 0);
	return /* @__PURE__ */ g(c, { children: /* @__PURE__ */ _("div", {
		className: "flex w-full flex-col items-center text-center text-[var(--content-default)]",
		children: [
			/* @__PURE__ */ g("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: C("apiKeyScreen.title")
			}),
			/* @__PURE__ */ g("p", {
				className: "mt-3 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: C("apiKeyScreen.body")
			}),
			/* @__PURE__ */ _("div", {
				className: "mt-10 flex w-full flex-col gap-4 text-left",
				children: [
					/* @__PURE__ */ _("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ g("label", {
							className: "text-body-small-default text-[var(--content-tertiary)]",
							children: C("apiKeyScreen.providerLabel")
						}), /* @__PURE__ */ g(n, {
							"aria-label": C("apiKeyScreen.providerLabel"),
							value: O,
							onChange: (e) => {
								let t = b(e);
								t && (k(t.id), j(""), N(x(t.id) ?? ""));
							},
							options: v.map((e) => ({
								value: e.id,
								label: e.displayName
							}))
						})]
					}),
					z.length > 0 && /* @__PURE__ */ _("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ g("label", {
							className: "text-body-small-default text-[var(--content-tertiary)]",
							children: C("apiKeyScreen.modelLabel")
						}), /* @__PURE__ */ g(n, {
							"aria-label": C("apiKeyScreen.modelLabel"),
							value: M,
							onChange: N,
							options: z.map((e) => ({
								value: e.id,
								label: e.displayName
							}))
						})]
					}),
					H && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
						className: "flex flex-col gap-1",
						children: [/* @__PURE__ */ g("label", {
							className: "text-body-small-default text-[var(--content-tertiary)]",
							children: C("apiKeyScreen.baseUrlLabel")
						}), /* @__PURE__ */ g(o, {
							type: "text",
							placeholder: "http://localhost:1234/v1",
							value: P,
							onChange: (e) => F(e.target.value),
							fullWidth: !0
						})]
					}), /* @__PURE__ */ _("div", {
						className: "flex flex-col gap-1",
						children: [
							/* @__PURE__ */ g("label", {
								className: "text-body-small-default text-[var(--content-tertiary)]",
								children: C("apiKeyScreen.modelsLabel")
							}),
							/* @__PURE__ */ g(o, {
								type: "text",
								placeholder: C("apiKeyScreen.modelsPlaceholder"),
								value: I,
								onChange: (e) => L(e.target.value),
								fullWidth: !0
							}),
							/* @__PURE__ */ g("p", {
								className: "text-body-small-lighter text-[var(--content-tertiary)]",
								children: C("apiKeyScreen.modelsHelp")
							})
						]
					})] }),
					B && /* @__PURE__ */ _("div", {
						className: "flex flex-col gap-3",
						children: [/* @__PURE__ */ g(o, {
							type: "password",
							label: C("apiKeyScreen.apiKeyLabel", { provider: R.displayName }),
							placeholder: R.apiKeyPlaceholder ?? C("apiKeyScreen.apiKeyPlaceholder"),
							value: A,
							onChange: (e) => j(e.target.value),
							className: S,
							fullWidth: !0
						}), R.docsUrl && /* @__PURE__ */ _("p", {
							className: "self-start text-body-medium-lighter text-[var(--content-tertiary)]",
							children: [
								C("apiKeyScreen.noKeyPrompt"),
								" ",
								/* @__PURE__ */ g(r, {
									href: R.docsUrl,
									tone: "quiet",
									className: "text-[var(--content-default)]",
									glyph: !1,
									children: C("apiKeyScreen.getKeyLink")
								})
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ _("div", {
				className: "mt-8 flex w-full flex-col gap-2",
				children: [/* @__PURE__ */ g(a, {
					variant: "primary",
					size: "large",
					fullWidth: !0,
					disabled: !U,
					onClick: () => {
						if (!U) return;
						let e = M.trim() || x(O);
						f({
							provider: O,
							key: A.trim(),
							...e ? { model: e } : {},
							...H ? {
								baseUrl: P.trim(),
								customModels: I.trim()
							} : {}
						});
						let t = new URLSearchParams({ [u]: "1" });
						E && t.set("hosting", E);
						let n = t.toString();
						w(`${l({
							isLocalHatch: E !== null && E !== "cloud",
							newAssistant: !0
						})}${n ? `?${n}` : ""}`, d);
					},
					children: C("actions.continue")
				}), /* @__PURE__ */ g(a, {
					variant: "outlined",
					size: "large",
					fullWidth: !0,
					onClick: () => {
						w(s.account.onboarding.hosting, d);
					},
					children: C("actions.back")
				})]
			})
		]
	}) });
}
//#endregion
export { C as ApiKeyScreen };
