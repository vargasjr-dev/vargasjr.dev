import { n as e } from "./dist-BTjb3IwJ.js";
//#region ../../node_modules/.bun/@capacitor+browser@8.0.3+33da1c2fb16abc29/node_modules/@capacitor/browser/dist/esm/web.js
var t = class extends e {
	constructor() {
		super(), this._lastWindow = null;
	}
	async open(e) {
		this._lastWindow = window.open(e.url, e.windowName || "_blank");
	}
	async close() {
		return new Promise((e, t) => {
			this._lastWindow == null ? t("No active window to close!") : (this._lastWindow.close(), this._lastWindow = null, e());
		});
	}
};
new t();
//#endregion
export { t as BrowserWeb };
