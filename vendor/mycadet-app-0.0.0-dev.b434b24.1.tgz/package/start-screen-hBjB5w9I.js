import { c as e } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as t } from "./i18n-BRf-wfgm.js";
import { t as n } from "./button-BrPHE1Q9.js";
import { n as r } from "./routes-DW44XTQk.js";
import { t as i } from "./account-shell-D0S9QH7J.js";
import { t as a } from "./onboarding-destination-BVBsT8nb.js";
import { t as o } from "./onboarding-navigation-Bp-9lTqG.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/domains/onboarding/pages/start-screen.tsx
function l() {
	let { t: l } = t("account"), u = e();
	return /* @__PURE__ */ s(i, { children: /* @__PURE__ */ c("div", {
		className: "flex flex-col items-center text-center text-[var(--content-default)]",
		children: [
			/* @__PURE__ */ s("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: l("welcome.title")
			}),
			/* @__PURE__ */ s("p", {
				className: "mt-3 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: l("welcome.body")
			}),
			/* @__PURE__ */ s("div", {
				className: "mt-10 flex w-full max-w-sm flex-col",
				children: /* @__PURE__ */ s(n, {
					variant: "primary",
					size: "large",
					fullWidth: !0,
					onClick: () => void u(`${r.onboarding.hatching}?hosting=cloud&${a}=1`, o),
					children: l("startScreen.createAssistant")
				})
			})
		]
	}) });
}
//#endregion
export { l as StartScreen };
