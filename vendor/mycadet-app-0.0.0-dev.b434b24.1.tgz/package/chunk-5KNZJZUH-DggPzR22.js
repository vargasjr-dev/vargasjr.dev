import * as e from "react";
//#region ../../node_modules/.bun/react-router@7.15.0+d0e719b86e9808b5/node_modules/react-router/dist/development/chunk-5KNZJZUH.mjs
var t = (e) => {
	throw TypeError(e);
}, n = (e, n, r) => n.has(e) || t("Cannot " + r), r = (e, t, r) => (n(e, t, "read from private field"), r ? r.call(e) : t.get(e)), i = (e, n, r) => n.has(e) ? t("Cannot add the same private member more than once") : n instanceof WeakSet ? n.add(e) : n.set(e, r), a = (e, t, r, i) => (n(e, t, "write to private field"), i ? i.call(e, r) : t.set(e, r), r), o = "popstate";
function s(e) {
	return typeof e == "object" && !!e && "pathname" in e && "search" in e && "hash" in e && "state" in e && "key" in e;
}
function c(e = {}) {
	function t(e, t) {
		let n = t.state?.masked, { pathname: r, search: i, hash: a } = n || e.location;
		return p("", {
			pathname: r,
			search: i,
			hash: a
		}, t.state && t.state.usr || null, t.state && t.state.key || "default", n ? {
			pathname: e.location.pathname,
			search: e.location.search,
			hash: e.location.hash
		} : void 0);
	}
	function n(e, t) {
		return typeof t == "string" ? t : m(t);
	}
	return g(t, n, null, e);
}
function l(e, t) {
	if (e === !1 || e == null) throw Error(t);
}
function u(e, t) {
	if (!e) {
		typeof console < "u" && console.warn(t);
		try {
			throw Error(t);
		} catch {}
	}
}
function d() {
	return Math.random().toString(36).substring(2, 10);
}
function f(e, t) {
	return {
		usr: e.state,
		key: e.key,
		idx: t,
		masked: e.mask ? {
			pathname: e.pathname,
			search: e.search,
			hash: e.hash
		} : void 0
	};
}
function p(e, t, n = null, r, i) {
	return {
		pathname: typeof e == "string" ? e : e.pathname,
		search: "",
		hash: "",
		...typeof t == "string" ? h(t) : t,
		state: n,
		key: t && t.key || r || d(),
		mask: i
	};
}
function m({ pathname: e = "/", search: t = "", hash: n = "" }) {
	return t && t !== "?" && (e += t.charAt(0) === "?" ? t : "?" + t), n && n !== "#" && (e += n.charAt(0) === "#" ? n : "#" + n), e;
}
function h(e) {
	let t = {};
	if (e) {
		let n = e.indexOf("#");
		n >= 0 && (t.hash = e.substring(n), e = e.substring(0, n));
		let r = e.indexOf("?");
		r >= 0 && (t.search = e.substring(r), e = e.substring(0, r)), e && (t.pathname = e);
	}
	return t;
}
function g(e, t, n, r = {}) {
	let { window: i = document.defaultView, v5Compat: a = !1 } = r, c = i.history, l = "POP", u = null, d = m();
	d ?? (d = 0, c.replaceState({
		...c.state,
		idx: d
	}, ""));
	function m() {
		return (c.state || { idx: null }).idx;
	}
	function h() {
		l = "POP";
		let e = m(), t = e == null ? null : e - d;
		d = e, u && u({
			action: l,
			location: b.location,
			delta: t
		});
	}
	function g(e, t) {
		l = "PUSH";
		let r = s(e) ? e : p(b.location, e, t);
		n && n(r, e), d = m() + 1;
		let o = f(r, d), h = b.createHref(r.mask || r);
		try {
			c.pushState(o, "", h);
		} catch (e) {
			if (e instanceof DOMException && e.name === "DataCloneError") throw e;
			i.location.assign(h);
		}
		a && u && u({
			action: l,
			location: b.location,
			delta: 1
		});
	}
	function v(e, t) {
		l = "REPLACE";
		let r = s(e) ? e : p(b.location, e, t);
		n && n(r, e), d = m();
		let i = f(r, d), o = b.createHref(r.mask || r);
		c.replaceState(i, "", o), a && u && u({
			action: l,
			location: b.location,
			delta: 0
		});
	}
	function y(e) {
		return _(e);
	}
	let b = {
		get action() {
			return l;
		},
		get location() {
			return e(i, c);
		},
		listen(e) {
			if (u) throw Error("A history only accepts one active listener");
			return i.addEventListener(o, h), u = e, () => {
				i.removeEventListener(o, h), u = null;
			};
		},
		createHref(e) {
			return t(i, e);
		},
		createURL: y,
		encodeLocation(e) {
			let t = y(e);
			return {
				pathname: t.pathname,
				search: t.search,
				hash: t.hash
			};
		},
		push: g,
		replace: v,
		go(e) {
			return c.go(e);
		}
	};
	return b;
}
function _(e, t = !1) {
	let n = "http://localhost";
	typeof window < "u" && (n = window.location.origin === "null" ? window.location.href : window.location.origin), l(n, "No window.location.(origin|href) available to create URL");
	let r = typeof e == "string" ? e : m(e);
	return r = r.replace(/ $/, "%20"), !t && r.startsWith("//") && (r = n + r), new URL(r, n);
}
var v, y = class {
	constructor(e) {
		if (i(this, v, /* @__PURE__ */ new Map()), e) for (let [t, n] of e) this.set(t, n);
	}
	get(e) {
		if (r(this, v).has(e)) return r(this, v).get(e);
		if (e.defaultValue !== void 0) return e.defaultValue;
		throw Error("No value found for context");
	}
	set(e, t) {
		r(this, v).set(e, t);
	}
};
v = /* @__PURE__ */ new WeakMap();
var b = /* @__PURE__ */ new Set([
	"lazy",
	"caseSensitive",
	"path",
	"id",
	"index",
	"children"
]);
function x(e) {
	return b.has(e);
}
var S = /* @__PURE__ */ new Set([
	"lazy",
	"caseSensitive",
	"path",
	"id",
	"index",
	"middleware",
	"children"
]);
function C(e) {
	return S.has(e);
}
function w(e) {
	return e.index === !0;
}
function T(e, t, n = [], r = {}, i = !1) {
	return e.map((e, a) => {
		let o = [...n, String(a)], s = typeof e.id == "string" ? e.id : o.join("-");
		if (l(e.index !== !0 || !e.children, "Cannot specify children on an index route"), l(i || !r[s], `Found a route id collision on id "${s}".  Route id's must be globally unique within Data Router usages`), w(e)) {
			let n = {
				...e,
				id: s
			};
			return r[s] = E(n, t(n)), n;
		} else {
			let n = {
				...e,
				id: s,
				children: void 0
			};
			return r[s] = E(n, t(n)), e.children && (n.children = T(e.children, t, o, r, i)), n;
		}
	});
}
function E(e, t) {
	return Object.assign(e, {
		...t,
		...typeof t.lazy == "object" && t.lazy != null ? { lazy: {
			...e.lazy,
			...t.lazy
		} } : {}
	});
}
function D(e, t, n = "/") {
	return O(e, t, n, !1);
}
function O(e, t, n, r, i) {
	let a = R((typeof t == "string" ? h(t) : t).pathname || "/", n);
	if (a == null) return null;
	let o = i ?? A(e), s = null, c = ce(a);
	for (let e = 0; s == null && e < o.length; ++e) s = L(o[e], c, r);
	return s;
}
function k(e, t) {
	let { route: n, pathname: r, params: i } = e;
	return {
		id: n.id,
		pathname: r,
		params: i,
		data: t[n.id],
		loaderData: t[n.id],
		handle: n.handle
	};
}
function A(e) {
	let t = j(e);
	return N(t), t;
}
function j(e, t = [], n = [], r = "", i = !1) {
	let a = (e, a, o = i, s) => {
		let c = {
			relativePath: s === void 0 ? e.path || "" : s,
			caseSensitive: e.caseSensitive === !0,
			childrenIndex: a,
			route: e
		};
		if (c.relativePath.startsWith("/")) {
			if (!c.relativePath.startsWith(r) && o) return;
			l(c.relativePath.startsWith(r), `Absolute route path "${c.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`), c.relativePath = c.relativePath.slice(r.length);
		}
		let u = H([r, c.relativePath]), d = n.concat(c);
		e.children && e.children.length > 0 && (l(e.index !== !0, `Index routes must not have child routes. Please remove all child routes from route path "${u}".`), j(e.children, t, d, u, o)), !(e.path == null && !e.index) && t.push({
			path: u,
			score: ie(u, e.index),
			routesMeta: d
		});
	};
	return e.forEach((e, t) => {
		if (e.path === "" || !e.path?.includes("?")) a(e, t);
		else for (let n of M(e.path)) a(e, t, !0, n);
	}), t;
}
function M(e) {
	let t = e.split("/");
	if (t.length === 0) return [];
	let [n, ...r] = t, i = n.endsWith("?"), a = n.replace(/\?$/, "");
	if (r.length === 0) return i ? [a, ""] : [a];
	let o = M(r.join("/")), s = [];
	return s.push(...o.map((e) => e === "" ? a : [a, e].join("/"))), i && s.push(...o), s.map((t) => e.startsWith("/") && t === "" ? "/" : t);
}
function N(e) {
	e.sort((e, t) => e.score === t.score ? ae(e.routesMeta.map((e) => e.childrenIndex), t.routesMeta.map((e) => e.childrenIndex)) : t.score - e.score);
}
var P = /^:[\w-]+$/, ee = 3, F = 2, te = 1, ne = 10, I = -2, re = (e) => e === "*";
function ie(e, t) {
	let n = e.split("/"), r = n.length;
	return n.some(re) && (r += I), t && (r += F), n.filter((e) => !re(e)).reduce((e, t) => e + (P.test(t) ? ee : t === "" ? te : ne), r);
}
function ae(e, t) {
	return e.length === t.length && e.slice(0, -1).every((e, n) => e === t[n]) ? e[e.length - 1] - t[t.length - 1] : 0;
}
function L(e, t, n = !1) {
	let { routesMeta: r } = e, i = {}, a = "/", o = [];
	for (let e = 0; e < r.length; ++e) {
		let s = r[e], c = e === r.length - 1, l = a === "/" ? t : t.slice(a.length) || "/", u = oe({
			path: s.relativePath,
			caseSensitive: s.caseSensitive,
			end: c
		}, l), d = s.route;
		if (!u && c && n && !r[r.length - 1].route.index && (u = oe({
			path: s.relativePath,
			caseSensitive: s.caseSensitive,
			end: !1
		}, l)), !u) return null;
		Object.assign(i, u.params), o.push({
			params: i,
			pathname: H([a, u.pathname]),
			pathnameBase: ge(H([a, u.pathnameBase])),
			route: d
		}), u.pathnameBase !== "/" && (a = H([a, u.pathnameBase]));
	}
	return o;
}
function oe(e, t) {
	typeof e == "string" && (e = {
		path: e,
		caseSensitive: !1,
		end: !0
	});
	let [n, r] = se(e.path, e.caseSensitive, e.end), i = t.match(n);
	if (!i) return null;
	let a = i[0], o = a.replace(/(.)\/+$/, "$1"), s = i.slice(1);
	return {
		params: r.reduce((e, { paramName: t, isOptional: n }, r) => {
			if (t === "*") {
				let e = s[r] || "";
				o = a.slice(0, a.length - e.length).replace(/(.)\/+$/, "$1");
			}
			let i = s[r];
			return n && !i ? e[t] = void 0 : e[t] = (i || "").replace(/%2F/g, "/"), e;
		}, {}),
		pathname: a,
		pathnameBase: o,
		pattern: e
	};
}
function se(e, t = !1, n = !0) {
	u(e === "*" || !e.endsWith("*") || e.endsWith("/*"), `Route path "${e}" will be treated as if it were "${e.replace(/\*$/, "/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/, "/*")}".`);
	let r = [], i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (e, t, n, i, a) => {
		if (r.push({
			paramName: t,
			isOptional: n != null
		}), n) {
			let t = a.charAt(i + e.length);
			return t && t !== "/" ? "/([^\\/]*)" : "(?:/([^\\/]*))?";
		}
		return "/([^\\/]+)";
	}).replace(/\/([\w-]+)\?(\/|$)/g, "(/$1)?$2");
	return e.endsWith("*") ? (r.push({ paramName: "*" }), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r];
}
function ce(e) {
	try {
		return e.split("/").map((e) => decodeURIComponent(e).replace(/\//g, "%2F")).join("/");
	} catch (t) {
		return u(!1, `The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`), e;
	}
}
function R(e, t) {
	if (t === "/") return e;
	if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
	let n = t.endsWith("/") ? t.length - 1 : t.length, r = e.charAt(n);
	return r && r !== "/" ? null : e.slice(n) || "/";
}
function z({ basename: e, pathname: t }) {
	return t === "/" ? e : H([e, t]);
}
var le = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i, ue = (e) => le.test(e);
function de(e, t = "/") {
	let { pathname: n, search: r = "", hash: i = "" } = typeof e == "string" ? h(e) : e, a;
	return n ? (n = he(n), a = n.startsWith("/") ? B(n.substring(1), "/") : B(n, t)) : a = t, {
		pathname: a,
		search: _e(r),
		hash: ve(i)
	};
}
function B(e, t) {
	let n = U(t).split("/");
	return e.split("/").forEach((e) => {
		e === ".." ? n.length > 1 && n.pop() : e !== "." && n.push(e);
	}), n.length > 1 ? n.join("/") : "/";
}
function V(e, t, n, r) {
	return `Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`;
}
function fe(e) {
	return e.filter((e, t) => t === 0 || e.route.path && e.route.path.length > 0);
}
function pe(e) {
	let t = fe(e);
	return t.map((e, n) => n === t.length - 1 ? e.pathname : e.pathnameBase);
}
function me(e, t, n, r = !1) {
	let i;
	typeof e == "string" ? i = h(e) : (i = { ...e }, l(!i.pathname || !i.pathname.includes("?"), V("?", "pathname", "search", i)), l(!i.pathname || !i.pathname.includes("#"), V("#", "pathname", "hash", i)), l(!i.search || !i.search.includes("#"), V("#", "search", "hash", i)));
	let a = e === "" || i.pathname === "", o = a ? "/" : i.pathname, s;
	if (o == null) s = n;
	else {
		let e = t.length - 1;
		if (!r && o.startsWith("..")) {
			let t = o.split("/");
			for (; t[0] === "..";) t.shift(), --e;
			i.pathname = t.join("/");
		}
		s = e >= 0 ? t[e] : "/";
	}
	let c = de(i, s), u = o && o !== "/" && o.endsWith("/"), d = (a || o === ".") && n.endsWith("/");
	return !c.pathname.endsWith("/") && (u || d) && (c.pathname += "/"), c;
}
var he = (e) => e.replace(/\/\/+/g, "/"), H = (e) => he(e.join("/")), U = (e) => e.replace(/\/+$/, ""), ge = (e) => U(e).replace(/^\/*/, "/"), _e = (e) => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e, ve = (e) => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e, W = class {
	constructor(e, t, n, r = !1) {
		this.status = e, this.statusText = t || "", this.internal = r, n instanceof Error ? (this.data = n.toString(), this.error = n) : this.data = n;
	}
};
function ye(e) {
	return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e;
}
function be(e) {
	return H(e.map((e) => e.route.path).filter(Boolean)) || "/";
}
var xe = typeof window < "u" && window.document !== void 0 && window.document.createElement !== void 0;
function Se(e, t) {
	let n = e;
	if (typeof n != "string" || !le.test(n)) return {
		absoluteURL: void 0,
		isExternal: !1,
		to: n
	};
	let r = n, i = !1;
	if (xe) try {
		let e = new URL(window.location.href), r = n.startsWith("//") ? new URL(e.protocol + n) : new URL(n), a = R(r.pathname, t);
		r.origin === e.origin && a != null ? n = a + r.search + r.hash : i = !0;
	} catch {
		u(!1, `<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`);
	}
	return {
		absoluteURL: r,
		isExternal: i,
		to: n
	};
}
var Ce = Symbol("Uninstrumented");
function we(e, t) {
	let n = {
		lazy: [],
		"lazy.loader": [],
		"lazy.action": [],
		"lazy.middleware": [],
		middleware: [],
		loader: [],
		action: []
	};
	e.forEach((e) => e({
		id: t.id,
		index: t.index,
		path: t.path,
		instrument(e) {
			let t = Object.keys(n);
			for (let r of t) e[r] && n[r].push(e[r]);
		}
	}));
	let r = {};
	if (typeof t.lazy == "function" && n.lazy.length > 0) {
		let e = Ee(n.lazy, t.lazy, () => void 0);
		e && (r.lazy = e);
	}
	if (typeof t.lazy == "object") {
		let e = t.lazy;
		[
			"middleware",
			"loader",
			"action"
		].forEach((t) => {
			let i = e[t], a = n[`lazy.${t}`];
			if (typeof i == "function" && a.length > 0) {
				let e = Ee(a, i, () => void 0);
				e && (r.lazy = Object.assign(r.lazy || {}, { [t]: e }));
			}
		});
	}
	return ["loader", "action"].forEach((e) => {
		let i = t[e];
		if (typeof i == "function" && n[e].length > 0) {
			let t = i[Ce] ?? i, a = Ee(n[e], t, (...e) => Oe(e[0]));
			a && (e === "loader" && t.hydrate === !0 && (a.hydrate = !0), a[Ce] = t, r[e] = a);
		}
	}), t.middleware && t.middleware.length > 0 && n.middleware.length > 0 && (r.middleware = t.middleware.map((e) => {
		let t = e[Ce] ?? e, r = Ee(n.middleware, t, (...e) => Oe(e[0]));
		return r ? (r[Ce] = t, r) : e;
	})), r;
}
function Te(e, t) {
	let n = {
		navigate: [],
		fetch: []
	};
	if (t.forEach((e) => e({ instrument(e) {
		let t = Object.keys(e);
		for (let r of t) e[r] && n[r].push(e[r]);
	} })), n.navigate.length > 0) {
		let t = e.navigate[Ce] ?? e.navigate, r = Ee(n.navigate, t, (...t) => {
			let [n, r] = t;
			return {
				to: typeof n == "number" || typeof n == "string" ? n : n ? m(n) : ".",
				...ke(e, r ?? {})
			};
		});
		r && (r[Ce] = t, e.navigate = r);
	}
	if (n.fetch.length > 0) {
		let t = e.fetch[Ce] ?? e.fetch, r = Ee(n.fetch, t, (...t) => {
			let [n, , r, i] = t;
			return {
				href: r ?? ".",
				fetcherKey: n,
				...ke(e, i ?? {})
			};
		});
		r && (r[Ce] = t, e.fetch = r);
	}
	return e;
}
function Ee(e, t, n) {
	return e.length === 0 ? null : async (...r) => {
		let i = await De(e, n(...r), () => t(...r), e.length - 1);
		if (i.type === "error") throw i.value;
		return i.value;
	};
}
async function De(e, t, n, r) {
	let i = e[r], a;
	if (i) {
		let o, s = async () => (o ? console.error("You cannot call instrumented handlers more than once") : o = De(e, t, n, r - 1), a = await o, l(a, "Expected a result"), a.type === "error" && a.value instanceof Error ? {
			status: "error",
			error: a.value
		} : {
			status: "success",
			error: void 0
		});
		try {
			await i(s, t);
		} catch (e) {
			console.error("An instrumentation function threw an error:", e);
		}
		o || await s(), await o;
	} else try {
		a = {
			type: "success",
			value: await n()
		};
	} catch (e) {
		a = {
			type: "error",
			value: e
		};
	}
	return a || {
		type: "error",
		value: /* @__PURE__ */ Error("No result assigned in instrumentation chain.")
	};
}
function Oe(e) {
	let { request: t, context: n, params: r, pattern: i } = e;
	return {
		request: Ae(t),
		params: { ...r },
		pattern: i,
		context: je(n)
	};
}
function ke(e, t) {
	return {
		currentUrl: m(e.state.location),
		..."formMethod" in t ? { formMethod: t.formMethod } : {},
		..."formEncType" in t ? { formEncType: t.formEncType } : {},
		..."formData" in t ? { formData: t.formData } : {},
		..."body" in t ? { body: t.body } : {}
	};
}
function Ae(e) {
	return {
		method: e.method,
		url: e.url,
		headers: { get: (...t) => e.headers.get(...t) }
	};
}
function je(e) {
	if (G(e)) {
		let t = { ...e };
		return Object.freeze(t), t;
	} else return { get: (t) => e.get(t) };
}
var Me = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function G(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null || Object.getOwnPropertyNames(t).sort().join("\0") === Me;
}
var K = [
	"POST",
	"PUT",
	"PATCH",
	"DELETE"
], Ne = new Set(K), Pe = ["GET", ...K], Fe = new Set(Pe), Ie = /* @__PURE__ */ new Set([
	301,
	302,
	303,
	307,
	308
]), Le = /* @__PURE__ */ new Set([307, 308]), Re = {
	state: "idle",
	location: void 0,
	formMethod: void 0,
	formAction: void 0,
	formEncType: void 0,
	formData: void 0,
	json: void 0,
	text: void 0
}, ze = {
	state: "idle",
	data: void 0,
	formMethod: void 0,
	formAction: void 0,
	formEncType: void 0,
	formData: void 0,
	json: void 0,
	text: void 0
}, Be = {
	state: "unblocked",
	proceed: void 0,
	reset: void 0,
	location: void 0
}, Ve = (e) => ({ hasErrorBoundary: !!e.hasErrorBoundary }), q = "remix-router-transitions", He = Symbol("ResetLoaderData"), Ue, We, Ge, Ke, qe = class {
	constructor(e) {
		i(this, Ue), i(this, We), i(this, Ge), i(this, Ke), a(this, Ue, e), a(this, We, A(e));
	}
	get stableRoutes() {
		return r(this, Ue);
	}
	get activeRoutes() {
		return r(this, Ge) ?? r(this, Ue);
	}
	get branches() {
		return r(this, Ke) ?? r(this, We);
	}
	get hasHMRRoutes() {
		return r(this, Ge) != null;
	}
	setRoutes(e) {
		a(this, Ue, e), a(this, We, A(e));
	}
	setHmrRoutes(e) {
		a(this, Ge, e), a(this, Ke, A(e));
	}
	commitHmrRoutes() {
		r(this, Ge) && (a(this, Ue, r(this, Ge)), a(this, We, r(this, Ke)), a(this, Ge, void 0), a(this, Ke, void 0));
	}
};
Ue = /* @__PURE__ */ new WeakMap(), We = /* @__PURE__ */ new WeakMap(), Ge = /* @__PURE__ */ new WeakMap(), Ke = /* @__PURE__ */ new WeakMap();
function Je(e) {
	let t = e.window ? e.window : typeof window < "u" ? window : void 0, n = t !== void 0 && t.document !== void 0 && t.document.createElement !== void 0;
	l(e.routes.length > 0, "You must provide a non-empty routes array to createRouter");
	let r = e.hydrationRouteProperties || [], i = e.mapRouteProperties || Ve, a = i;
	if (e.instrumentations) {
		let t = e.instrumentations;
		a = (e) => ({
			...i(e),
			...we(t.map((e) => e.route).filter(Boolean), e)
		});
	}
	let o = {}, s = new qe(T(e.routes, a, void 0, o)), c = e.basename || "/";
	c.startsWith("/") || (c = `/${c}`);
	let d = e.dataStrategy || dt, f = { ...e.future }, m = null, g = /* @__PURE__ */ new Set(), v = null, b = null, x = null, S = e.hydrationData != null, C = O(s.activeRoutes, e.history.location, c, !1, s.branches), w = !1, E = null, D, A;
	if (C == null && !e.patchRoutesOnNavigation) {
		let t = J(404, { pathname: e.history.location.pathname }), { matches: n, route: r } = Pt(s.activeRoutes);
		D = !0, A = !D, C = n, E = { [r.id]: t };
	} else if (C && !e.hydrationData && st(C, s.activeRoutes, e.history.location.pathname).active && (C = null), !C) {
		D = !1, A = !D, C = [];
		let t = st(null, s.activeRoutes, e.history.location.pathname);
		t.active && t.matches && (w = !0, C = t.matches);
	} else if (C.some((e) => e.route.lazy)) D = !1, A = !D;
	else if (!C.some((e) => $e(e.route))) D = !0, A = !D;
	else {
		let t = e.hydrationData ? e.hydrationData.loaderData : null, n = e.hydrationData ? e.hydrationData.errors : null, r = C;
		if (n) {
			let e = C.findIndex((e) => n[e.route.id] !== void 0);
			r = r.slice(0, e + 1);
		}
		A = !1, D = !0, r.forEach((e) => {
			let r = et(e.route, t, n);
			A ||= r.renderFallback, D &&= !r.shouldLoad;
		});
	}
	let j, M = {
		historyAction: e.history.action,
		location: e.history.location,
		matches: C,
		initialized: D,
		renderFallback: A,
		navigation: Re,
		restoreScrollPosition: e.hydrationData == null ? null : !1,
		preventScrollReset: !1,
		revalidation: "idle",
		loaderData: e.hydrationData && e.hydrationData.loaderData || {},
		actionData: e.hydrationData && e.hydrationData.actionData || null,
		errors: e.hydrationData && e.hydrationData.errors || E,
		fetchers: /* @__PURE__ */ new Map(),
		blockers: /* @__PURE__ */ new Map()
	}, N = "POP", P = null, ee = !1, F, te = !1, ne = /* @__PURE__ */ new Map(), I = null, re = !1, ie = !1, ae = /* @__PURE__ */ new Set(), L = /* @__PURE__ */ new Map(), oe = 0, se = -1, ce = /* @__PURE__ */ new Map(), z = /* @__PURE__ */ new Set(), le = /* @__PURE__ */ new Map(), de = /* @__PURE__ */ new Map(), B = /* @__PURE__ */ new Set(), V = /* @__PURE__ */ new Map(), fe, pe = null;
	function me() {
		if (m = e.history.listen(({ action: t, location: n, delta: r }) => {
			if (fe) {
				fe(), fe = void 0;
				return;
			}
			u(V.size === 0 || r != null, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
			let i = Ye({
				currentLocation: M.location,
				nextLocation: n,
				historyAction: t
			});
			if (i && r != null) {
				let t = new Promise((e) => {
					fe = e;
				});
				e.history.go(r * -1), Je(i, {
					state: "blocked",
					location: n,
					proceed() {
						Je(i, {
							state: "proceeding",
							proceed: void 0,
							reset: void 0,
							location: n
						}), t.then(() => e.history.go(r));
					},
					reset() {
						let e = new Map(M.blockers);
						e.set(i, Be), U({ blockers: e });
					}
				}), P?.resolve(), P = null;
				return;
			}
			return W(t, n);
		}), n) {
			nn(t, ne);
			let e = () => rn(t, ne);
			t.addEventListener("pagehide", e), I = () => t.removeEventListener("pagehide", e);
		}
		return M.initialized || W("POP", M.location, { initialHydration: !0 }), j;
	}
	function he() {
		m && m(), I && I(), g.clear(), F && F.abort(), M.fetchers.forEach((e, t) => Fe(t)), M.blockers.forEach((e, t) => Ke(t));
	}
	function H(e) {
		return g.add(e), () => g.delete(e);
	}
	function U(e, t = {}) {
		e.matches &&= e.matches.map((e) => {
			let t = o[e.route.id], n = e.route;
			return n.element !== t.element || n.errorElement !== t.errorElement || n.hydrateFallbackElement !== t.hydrateFallbackElement ? {
				...e,
				route: t
			} : e;
		}), M = {
			...M,
			...e
		};
		let n = [], r = [];
		M.fetchers.forEach((e, t) => {
			e.state === "idle" && (B.has(t) ? n.push(t) : r.push(t));
		}), B.forEach((e) => {
			!M.fetchers.has(e) && !L.has(e) && n.push(e);
		}), [...g].forEach((r) => r(M, {
			deletedFetchers: n,
			newErrors: e.errors ?? null,
			viewTransitionOpts: t.viewTransitionOpts,
			flushSync: t.flushSync === !0
		})), n.forEach((e) => Fe(e)), r.forEach((e) => M.fetchers.delete(e));
	}
	function ge(t, n, { flushSync: r } = {}) {
		let i = M.actionData != null && M.navigation.formMethod != null && X(M.navigation.formMethod) && M.navigation.state === "loading" && t.state?._isRedirect !== !0, a;
		a = n.actionData ? Object.keys(n.actionData).length > 0 ? n.actionData : null : i ? M.actionData : null;
		let o = n.loaderData ? jt(M.loaderData, n.loaderData, n.matches || [], n.errors) : M.loaderData, c = M.blockers;
		c.size > 0 && (c = new Map(c), c.forEach((e, t) => c.set(t, Be)));
		let l = re ? !1 : ot(t, n.matches || M.matches), u = ee === !0 || M.navigation.formMethod != null && X(M.navigation.formMethod) && t.state?._isRedirect !== !0;
		s.commitHmrRoutes(), re || N === "POP" || (N === "PUSH" ? e.history.push(t, t.state) : N === "REPLACE" && e.history.replace(t, t.state));
		let d;
		if (N === "POP") {
			let e = ne.get(M.location.pathname);
			e && e.has(t.pathname) ? d = {
				currentLocation: M.location,
				nextLocation: t
			} : ne.has(t.pathname) && (d = {
				currentLocation: t,
				nextLocation: M.location
			});
		} else if (te) {
			let e = ne.get(M.location.pathname);
			e ? e.add(t.pathname) : (e = /* @__PURE__ */ new Set([t.pathname]), ne.set(M.location.pathname, e)), d = {
				currentLocation: M.location,
				nextLocation: t
			};
		}
		U({
			...n,
			actionData: a,
			loaderData: o,
			historyAction: N,
			location: t,
			initialized: !0,
			renderFallback: !1,
			navigation: Re,
			revalidation: "idle",
			restoreScrollPosition: l,
			preventScrollReset: u,
			blockers: c
		}, {
			viewTransitionOpts: d,
			flushSync: r === !0
		}), N = "POP", ee = !1, te = !1, re = !1, ie = !1, P?.resolve(), P = null, pe?.resolve(), pe = null;
	}
	async function _e(t, n) {
		if (P?.resolve(), P = null, typeof t == "number") {
			P ||= an();
			let n = P.promise;
			return e.history.go(t), n;
		}
		let { path: r, submission: i, error: a } = Ze(!1, Xe(M.location, M.matches, c, t, n?.fromRouteId, n?.relative), n), o;
		n?.mask && (o = {
			pathname: "",
			search: "",
			hash: "",
			...typeof n.mask == "string" ? h(n.mask) : {
				...M.location.mask,
				...n.mask
			}
		});
		let s = M.location, l = p(s, r, n && n.state, void 0, o);
		l = {
			...l,
			...e.history.encodeLocation(l)
		};
		let u = n && n.replace != null ? n.replace : void 0, d = "PUSH";
		u === !0 ? d = "REPLACE" : u === !1 || i != null && X(i.formMethod) && i.formAction === M.location.pathname + M.location.search && (d = "REPLACE");
		let f = n && "preventScrollReset" in n ? n.preventScrollReset === !0 : void 0, m = (n && n.flushSync) === !0, g = Ye({
			currentLocation: s,
			nextLocation: l,
			historyAction: d
		});
		if (g) {
			Je(g, {
				state: "blocked",
				location: l,
				proceed() {
					Je(g, {
						state: "proceeding",
						proceed: void 0,
						reset: void 0,
						location: l
					}), _e(t, n);
				},
				reset() {
					let e = new Map(M.blockers);
					e.set(g, Be), U({ blockers: e });
				}
			});
			return;
		}
		await W(d, l, {
			submission: i,
			pendingError: a,
			preventScrollReset: f,
			replace: n && n.replace,
			enableViewTransition: n && n.viewTransition,
			flushSync: m,
			callSiteDefaultShouldRevalidate: n && n.defaultShouldRevalidate
		});
	}
	function ve() {
		pe ||= an(), Me(), U({ revalidation: "loading" });
		let e = pe.promise;
		return M.navigation.state === "submitting" ? e : M.navigation.state === "idle" ? (W(M.historyAction, M.location, { startUninterruptedRevalidation: !0 }), e) : (W(N || M.historyAction, M.navigation.location, {
			overrideNavigation: M.navigation,
			enableViewTransition: te === !0
		}), e);
	}
	async function W(t, n, r) {
		F && F.abort(), F = null, N = t, re = (r && r.startUninterruptedRevalidation) === !0, at(M.location, M.matches), ee = (r && r.preventScrollReset) === !0, te = (r && r.enableViewTransition) === !0;
		let i = s.activeRoutes, a = r && r.overrideNavigation, o = r?.initialHydration && M.matches && M.matches.length > 0 && !w ? M.matches : O(i, n, c, !1, s.branches), l = (r && r.flushSync) === !0;
		if (o && M.initialized && !ie && Lt(M.location, n) && !(r && r.submission && X(r.submission.formMethod))) {
			ge(n, { matches: o }, { flushSync: l });
			return;
		}
		let u = st(o, i, n.pathname);
		if (u.active && u.matches && (o = u.matches), !o) {
			let { error: e, notFoundMatches: t, route: r } = tt(n.pathname);
			ge(n, {
				matches: t,
				loaderData: {},
				errors: { [r.id]: e }
			}, { flushSync: l });
			return;
		}
		F = new AbortController();
		let d = Tt(e.history, n, F.signal, r && r.submission), f = e.getContext ? await e.getContext() : new y(), p;
		if (r && r.pendingError) p = [Nt(o).route.id, {
			type: "error",
			error: r.pendingError
		}];
		else if (r && r.submission && X(r.submission.formMethod)) {
			let t = await be(d, n, r.submission, o, f, u.active, r && r.initialHydration === !0, {
				replace: r.replace,
				flushSync: l
			});
			if (t.shortCircuited) return;
			if (t.pendingActionResult) {
				let [e, r] = t.pendingActionResult;
				if (Y(r) && ye(r.error) && r.error.status === 404) {
					F = null, ge(n, {
						matches: t.matches,
						loaderData: {},
						errors: { [e]: r.error }
					});
					return;
				}
			}
			o = t.matches || o, p = t.pendingActionResult, a = Zt(n, r.submission), l = !1, u.active = !1, d = Tt(e.history, d.url, d.signal);
		}
		let { shortCircuited: m, matches: h, loaderData: g, errors: _ } = await xe(d, n, o, f, u.active, a, r && r.submission, r && r.fetcherSubmission, r && r.replace, r && r.initialHydration === !0, l, p, r && r.callSiteDefaultShouldRevalidate);
		m || (F = null, ge(n, {
			matches: h || o,
			...Mt(p),
			loaderData: g,
			errors: _
		}));
	}
	async function be(t, n, i, l, u, d, f, p = {}) {
		if (Me(), U({ navigation: Qt(n, i) }, { flushSync: p.flushSync === !0 }), d) {
			let e = await ct(l, n.pathname, t.signal);
			if (e.type === "aborted") return { shortCircuited: !0 };
			if (e.type === "error") {
				if (e.partialMatches.length === 0) {
					let { matches: t, route: n } = Pt(s.activeRoutes);
					return {
						matches: t,
						pendingActionResult: [n.id, {
							type: "error",
							error: e.error
						}]
					};
				}
				let t = Nt(e.partialMatches).route.id;
				return {
					matches: e.partialMatches,
					pendingActionResult: [t, {
						type: "error",
						error: e.error
					}]
				};
			} else if (e.matches) l = e.matches;
			else {
				let { notFoundMatches: e, error: t, route: r } = tt(n.pathname);
				return {
					matches: e,
					pendingActionResult: [r.id, {
						type: "error",
						error: t
					}]
				};
			}
		}
		let m, h = Yt(l, n);
		if (!h.route.action && !h.route.lazy) m = {
			type: "error",
			error: J(405, {
				method: t.method,
				pathname: n.pathname,
				routeId: h.route.id
			})
		};
		else {
			let e = await Ae(t, n, _t(a, o, t, n, l, h, f ? [] : r, u), u, null);
			if (m = e[h.route.id], !m) {
				for (let t of l) if (e[t.route.id]) {
					m = e[t.route.id];
					break;
				}
			}
			if (t.signal.aborted) return { shortCircuited: !0 };
		}
		if (Ht(m)) {
			let n;
			return n = p && p.replace != null ? p.replace : wt(m.response.headers.get("Location"), new URL(t.url), c, e.history) === M.location.pathname + M.location.search, await ke(t, m, !0, {
				submission: i,
				replace: n
			}), { shortCircuited: !0 };
		}
		if (Y(m)) {
			let e = Nt(l, h.route.id);
			return (p && p.replace) !== !0 && (N = "PUSH"), {
				matches: l,
				pendingActionResult: [
					e.route.id,
					m,
					h.route.id
				]
			};
		}
		return {
			matches: l,
			pendingActionResult: [h.route.id, m]
		};
	}
	async function xe(t, n, i, l, u, d, f, p, m, h, g, _, v) {
		let y = d || Zt(n, f), b = f || p || Xt(y), x = !re && !h;
		if (u) {
			if (x) {
				let e = Se(_);
				U({
					navigation: y,
					...e === void 0 ? {} : { actionData: e }
				}, { flushSync: g });
			}
			let e = await ct(i, n.pathname, t.signal);
			if (e.type === "aborted") return { shortCircuited: !0 };
			if (e.type === "error") {
				if (e.partialMatches.length === 0) {
					let { matches: t, route: n } = Pt(s.activeRoutes);
					return {
						matches: t,
						loaderData: {},
						errors: { [n.id]: e.error }
					};
				}
				let t = Nt(e.partialMatches).route.id;
				return {
					matches: e.partialMatches,
					loaderData: {},
					errors: { [t]: e.error }
				};
			} else if (e.matches) i = e.matches;
			else {
				let { error: e, notFoundMatches: t, route: r } = tt(n.pathname);
				return {
					matches: t,
					loaderData: {},
					errors: { [r.id]: e }
				};
			}
		}
		let S = s.activeRoutes, { dsMatches: C, revalidatingFetchers: w } = Qe(t, l, a, o, e.history, M, i, b, n, h ? [] : r, h === !0, ie, ae, B, le, z, S, c, e.patchRoutesOnNavigation != null, s.branches, _, v);
		if (se = ++oe, !e.dataStrategy && !C.some((e) => e.shouldLoad) && !C.some((e) => e.route.middleware && e.route.middleware.length > 0) && w.length === 0) {
			let e = Ue();
			return ge(n, {
				matches: i,
				loaderData: {},
				errors: _ && Y(_[1]) ? { [_[0]]: _[1].error } : null,
				...Mt(_),
				...e ? { fetchers: new Map(M.fetchers) } : {}
			}, { flushSync: g }), { shortCircuited: !0 };
		}
		if (x) {
			let e = {};
			if (!u) {
				e.navigation = y;
				let t = Se(_);
				t !== void 0 && (e.actionData = t);
			}
			w.length > 0 && (e.fetchers = Ce(w)), U(e, { flushSync: g });
		}
		w.forEach((e) => {
			q(e.key), e.controller && L.set(e.key, e.controller);
		});
		let T = () => w.forEach((e) => q(e.key));
		F && F.signal.addEventListener("abort", T);
		let { loaderResults: E, fetcherResults: D } = await je(C, w, t, n, l);
		if (t.signal.aborted) return { shortCircuited: !0 };
		F && F.signal.removeEventListener("abort", T), w.forEach((e) => L.delete(e.key));
		let O = Ft(E);
		if (O) return await ke(t, O.result, !0, { replace: m }), { shortCircuited: !0 };
		if (O = Ft(D), O) return z.add(O.key), await ke(t, O.result, !0, { replace: m }), { shortCircuited: !0 };
		let { loaderData: k, errors: A } = At(M, i, E, _, w, D);
		h && M.errors && (A = {
			...M.errors,
			...A
		});
		let j = Ue(), N = We(se), P = j || N || w.length > 0;
		return {
			matches: i,
			loaderData: k,
			errors: A,
			...P ? { fetchers: new Map(M.fetchers) } : {}
		};
	}
	function Se(e) {
		if (e && !Y(e[1])) return { [e[0]]: e[1].data };
		if (M.actionData) return Object.keys(M.actionData).length === 0 ? null : M.actionData;
	}
	function Ce(e) {
		return e.forEach((e) => {
			let t = M.fetchers.get(e.key), n = $t(void 0, t ? t.data : void 0);
			M.fetchers.set(e.key, n);
		}), new Map(M.fetchers);
	}
	async function Ee(t, n, r, i) {
		q(t);
		let a = (i && i.flushSync) === !0, o = s.activeRoutes, l = Xe(M.location, M.matches, c, r, n, i?.relative), u = O(o, l, c, !1, s.branches), d = st(u, o, l);
		if (d.active && d.matches && (u = d.matches), !u) {
			K(t, n, J(404, { pathname: l }), { flushSync: a });
			return;
		}
		let { path: f, submission: p, error: m } = Ze(!0, l, i);
		if (m) {
			K(t, n, m, { flushSync: a });
			return;
		}
		let h = e.getContext ? await e.getContext() : new y(), g = (i && i.preventScrollReset) === !0;
		if (p && X(p.formMethod)) {
			await De(t, n, f, u, h, d.active, a, g, p, i && i.defaultShouldRevalidate);
			return;
		}
		le.set(t, {
			routeId: n,
			path: f
		}), await Oe(t, n, f, u, h, d.active, a, g, p);
	}
	async function De(t, n, i, u, d, f, p, m, h, g) {
		Me(), le.delete(t), G(t, en(h, M.fetchers.get(t)), { flushSync: p });
		let _ = new AbortController(), v = Tt(e.history, i, _.signal, h);
		if (f) {
			let e = await ct(u, new URL(v.url).pathname, v.signal, t);
			if (e.type === "aborted") return;
			if (e.type === "error") {
				K(t, n, e.error, { flushSync: p });
				return;
			} else if (e.matches) u = e.matches;
			else {
				K(t, n, J(404, { pathname: i }), { flushSync: p });
				return;
			}
		}
		let y = Yt(u, i);
		if (!y.route.action && !y.route.lazy) {
			K(t, n, J(405, {
				method: h.formMethod,
				pathname: i,
				routeId: n
			}), { flushSync: p });
			return;
		}
		L.set(t, _);
		let b = oe, x = _t(a, o, v, i, u, y, r, d), S = await Ae(v, i, x, d, t), C = S[y.route.id];
		if (!C) {
			for (let e of x) if (S[e.route.id]) {
				C = S[e.route.id];
				break;
			}
		}
		if (v.signal.aborted) {
			L.get(t) === _ && L.delete(t);
			return;
		}
		if (B.has(t)) {
			if (Ht(C) || Y(C)) {
				G(t, tn(void 0));
				return;
			}
		} else {
			if (Ht(C)) if (L.delete(t), se > b) {
				G(t, tn(void 0));
				return;
			} else return z.add(t), G(t, $t(h)), ke(v, C, !1, {
				fetcherSubmission: h,
				preventScrollReset: m
			});
			if (Y(C)) {
				K(t, n, C.error);
				return;
			}
		}
		let w = M.navigation.location || M.location, T = Tt(e.history, w, _.signal), E = s.activeRoutes, D = M.navigation.state === "idle" ? M.matches : O(E, M.navigation.location, c, !1, s.branches);
		l(D, "Didn't find any matches after fetcher action");
		let k = ++oe;
		ce.set(t, k);
		let A = $t(h, C.data);
		M.fetchers.set(t, A);
		let { dsMatches: j, revalidatingFetchers: P } = Qe(T, d, a, o, e.history, M, D, h, w, r, !1, ie, ae, B, le, z, E, c, e.patchRoutesOnNavigation != null, s.branches, [y.route.id, C], g);
		P.filter((e) => e.key !== t).forEach((e) => {
			let t = e.key, n = M.fetchers.get(t), r = $t(void 0, n ? n.data : void 0);
			M.fetchers.set(t, r), q(t), e.controller && L.set(t, e.controller);
		}), U({ fetchers: new Map(M.fetchers) });
		let ee = () => P.forEach((e) => q(e.key));
		_.signal.addEventListener("abort", ee);
		let { loaderResults: te, fetcherResults: ne } = await je(j, P, T, w, d);
		if (_.signal.aborted) return;
		if (_.signal.removeEventListener("abort", ee), ce.delete(t), L.delete(t), P.forEach((e) => L.delete(e.key)), M.fetchers.has(t)) {
			let e = tn(C.data);
			M.fetchers.set(t, e);
		}
		let I = Ft(te);
		if (I) return ke(T, I.result, !1, { preventScrollReset: m });
		if (I = Ft(ne), I) return z.add(I.key), ke(T, I.result, !1, { preventScrollReset: m });
		let { loaderData: re, errors: R } = At(M, D, te, void 0, P, ne);
		We(k), M.navigation.state === "loading" && k > se ? (l(N, "Expected pending action"), F && F.abort(), ge(M.navigation.location, {
			matches: D,
			loaderData: re,
			errors: R,
			fetchers: new Map(M.fetchers)
		})) : (U({
			errors: R,
			loaderData: jt(M.loaderData, re, D, R),
			fetchers: new Map(M.fetchers)
		}), ie = !1);
	}
	async function Oe(t, n, i, s, c, l, u, d, f) {
		let p = M.fetchers.get(t);
		G(t, $t(f, p ? p.data : void 0), { flushSync: u });
		let m = new AbortController(), h = Tt(e.history, i, m.signal);
		if (l) {
			let e = await ct(s, new URL(h.url).pathname, h.signal, t);
			if (e.type === "aborted") return;
			if (e.type === "error") {
				K(t, n, e.error, { flushSync: u });
				return;
			} else if (e.matches) s = e.matches;
			else {
				K(t, n, J(404, { pathname: i }), { flushSync: u });
				return;
			}
		}
		let g = Yt(s, i);
		L.set(t, m);
		let _ = oe, v = await Ae(h, i, _t(a, o, h, i, s, g, r, c), c, t), y = v[g.route.id];
		if (!y) {
			for (let e of s) if (v[e.route.id]) {
				y = v[e.route.id];
				break;
			}
		}
		if (L.get(t) === m && L.delete(t), !h.signal.aborted) {
			if (B.has(t)) {
				G(t, tn(void 0));
				return;
			}
			if (Ht(y)) if (se > _) {
				G(t, tn(void 0));
				return;
			} else {
				z.add(t), await ke(h, y, !1, { preventScrollReset: d });
				return;
			}
			if (Y(y)) {
				K(t, n, y.error);
				return;
			}
			G(t, tn(y.data));
		}
	}
	async function ke(r, i, a, { submission: o, fetcherSubmission: s, preventScrollReset: u, replace: d } = {}) {
		a || (P?.resolve(), P = null), i.response.headers.has("X-Remix-Revalidate") && (ie = !0);
		let f = i.response.headers.get("Location");
		l(f, "Expected a Location header on the redirect Response"), f = wt(f, new URL(r.url), c, e.history);
		let m = p(M.location, f, { _isRedirect: !0 });
		if (n) {
			let e = !1;
			if (i.response.headers.has("X-Remix-Reload-Document")) e = !0;
			else if (ue(f)) {
				let n = _(f, !0);
				e = n.origin !== t.location.origin || R(n.pathname, c) == null;
			}
			if (e) {
				d ? t.location.replace(f) : t.location.assign(f);
				return;
			}
		}
		F = null;
		let h = d === !0 || i.response.headers.has("X-Remix-Replace") ? "REPLACE" : "PUSH", { formMethod: g, formAction: v, formEncType: y } = M.navigation;
		!o && !s && g && v && y && (o = Xt(M.navigation));
		let b = o || s;
		Le.has(i.response.status) && b && X(b.formMethod) ? await W(h, m, {
			submission: {
				...b,
				formAction: f
			},
			preventScrollReset: u || ee,
			enableViewTransition: a ? te : void 0
		}) : await W(h, m, {
			overrideNavigation: Zt(m, o),
			fetcherSubmission: s,
			preventScrollReset: u || ee,
			enableViewTransition: a ? te : void 0
		});
	}
	async function Ae(e, t, n, r, i) {
		let a, o = {};
		try {
			a = await vt(d, e, t, n, i, r, !1);
		} catch (e) {
			return n.filter((e) => e.shouldLoad).forEach((t) => {
				o[t.route.id] = {
					type: "error",
					error: e
				};
			}), o;
		}
		if (e.signal.aborted) return o;
		if (!X(e.method)) for (let e of n) {
			if (a[e.route.id]?.type === "error") break;
			!a.hasOwnProperty(e.route.id) && !M.loaderData.hasOwnProperty(e.route.id) && (!M.errors || !M.errors.hasOwnProperty(e.route.id)) && e.shouldCallHandler() && (a[e.route.id] = {
				type: "error",
				result: /* @__PURE__ */ Error(`No result returned from dataStrategy for route ${e.route.id}`)
			});
		}
		for (let [t, r] of Object.entries(a)) if (Vt(r)) {
			let i = r.result;
			o[t] = {
				type: "redirect",
				response: St(i, e, t, n, c)
			};
		} else o[t] = await xt(r);
		return o;
	}
	async function je(e, t, n, r, i) {
		let a = Ae(n, r, e, i, null), o = Promise.all(t.map(async (e) => {
			if (e.matches && e.match && e.request && e.controller) {
				let t = (await Ae(e.request, e.path, e.matches, i, e.key))[e.match.route.id];
				return { [e.key]: t };
			} else return Promise.resolve({ [e.key]: {
				type: "error",
				error: J(404, { pathname: e.path })
			} });
		}));
		return {
			loaderResults: await a,
			fetcherResults: (await o).reduce((e, t) => Object.assign(e, t), {})
		};
	}
	function Me() {
		ie = !0, le.forEach((e, t) => {
			L.has(t) && ae.add(t), q(t);
		});
	}
	function G(e, t, n = {}) {
		M.fetchers.set(e, t), U({ fetchers: new Map(M.fetchers) }, { flushSync: (n && n.flushSync) === !0 });
	}
	function K(e, t, n, r = {}) {
		let i = Nt(M.matches, t);
		Fe(e), U({
			errors: { [i.route.id]: n },
			fetchers: new Map(M.fetchers)
		}, { flushSync: (r && r.flushSync) === !0 });
	}
	function Ne(e) {
		return de.set(e, (de.get(e) || 0) + 1), B.has(e) && B.delete(e), M.fetchers.get(e) || ze;
	}
	function Pe(e, t) {
		q(e, t?.reason), G(e, tn(null));
	}
	function Fe(e) {
		let t = M.fetchers.get(e);
		L.has(e) && !(t && t.state === "loading" && ce.has(e)) && q(e), le.delete(e), ce.delete(e), z.delete(e), B.delete(e), ae.delete(e), M.fetchers.delete(e);
	}
	function Ie(e) {
		let t = (de.get(e) || 0) - 1;
		t <= 0 ? (de.delete(e), B.add(e)) : de.set(e, t), U({ fetchers: new Map(M.fetchers) });
	}
	function q(e, t) {
		let n = L.get(e);
		n && (n.abort(t), L.delete(e));
	}
	function He(e) {
		for (let t of e) {
			let e = tn(Ne(t).data);
			M.fetchers.set(t, e);
		}
	}
	function Ue() {
		let e = [], t = !1;
		for (let n of z) {
			let r = M.fetchers.get(n);
			l(r, `Expected fetcher: ${n}`), r.state === "loading" && (z.delete(n), e.push(n), t = !0);
		}
		return He(e), t;
	}
	function We(e) {
		let t = [];
		for (let [n, r] of ce) if (r < e) {
			let e = M.fetchers.get(n);
			l(e, `Expected fetcher: ${n}`), e.state === "loading" && (q(n), ce.delete(n), t.push(n));
		}
		return He(t), t.length > 0;
	}
	function Ge(e, t) {
		let n = M.blockers.get(e) || Be;
		return V.get(e) !== t && V.set(e, t), n;
	}
	function Ke(e) {
		M.blockers.delete(e), V.delete(e);
	}
	function Je(e, t) {
		let n = M.blockers.get(e) || Be;
		l(n.state === "unblocked" && t.state === "blocked" || n.state === "blocked" && t.state === "blocked" || n.state === "blocked" && t.state === "proceeding" || n.state === "blocked" && t.state === "unblocked" || n.state === "proceeding" && t.state === "unblocked", `Invalid blocker state transition: ${n.state} -> ${t.state}`);
		let r = new Map(M.blockers);
		r.set(e, t), U({ blockers: r });
	}
	function Ye({ currentLocation: e, nextLocation: t, historyAction: n }) {
		if (V.size === 0) return;
		V.size > 1 && u(!1, "A router only supports one blocker at a time");
		let r = Array.from(V.entries()), [i, a] = r[r.length - 1], o = M.blockers.get(i);
		if (!(o && o.state === "proceeding") && a({
			currentLocation: e,
			nextLocation: t,
			historyAction: n
		})) return i;
	}
	function tt(e) {
		let t = J(404, { pathname: e }), n = s.activeRoutes, { matches: r, route: i } = Pt(n);
		return {
			notFoundMatches: r,
			route: i,
			error: t
		};
	}
	function nt(e, t, n) {
		if (v = e, x = t, b = n || null, !S && M.navigation === Re) {
			S = !0;
			let e = ot(M.location, M.matches);
			e != null && U({ restoreScrollPosition: e });
		}
		return () => {
			v = null, x = null, b = null;
		};
	}
	function rt(e, t) {
		return b && b(e, t.map((e) => k(e, M.loaderData))) || e.key;
	}
	function at(e, t) {
		if (v && x) {
			let n = rt(e, t);
			v[n] = x();
		}
	}
	function ot(e, t) {
		if (v) {
			let n = rt(e, t), r = v[n];
			if (typeof r == "number") return r;
		}
		return null;
	}
	function st(t, n, r) {
		if (e.patchRoutesOnNavigation) {
			let e = s.branches;
			if (!t) return {
				active: !0,
				matches: O(n, r, c, !0, e) || []
			};
			if (Object.keys(t[0].params).length > 0) return {
				active: !0,
				matches: O(n, r, c, !0, e)
			};
		}
		return {
			active: !1,
			matches: null
		};
	}
	async function ct(t, n, r, i) {
		if (!e.patchRoutesOnNavigation) return {
			type: "success",
			matches: t
		};
		let l = t;
		for (;;) {
			let t = o;
			try {
				await e.patchRoutesOnNavigation({
					signal: r,
					path: n,
					matches: l,
					fetcherKey: i,
					patch: (e, n) => {
						r.aborted || it(e, n, s, t, a, !1);
					}
				});
			} catch (e) {
				return {
					type: "error",
					error: e,
					partialMatches: l
				};
			}
			if (r.aborted) return { type: "aborted" };
			let u = s.branches, d = O(s.activeRoutes, n, c, !1, u), f = null;
			if (d && (Object.keys(d[0].params).length === 0 || (f = O(s.activeRoutes, n, c, !0, u), !(f && l.length < f.length && lt(l, f.slice(0, l.length)))))) return {
				type: "success",
				matches: d
			};
			if (f ||= O(s.activeRoutes, n, c, !0, u), !f || lt(l, f)) return {
				type: "success",
				matches: null
			};
			l = f;
		}
	}
	function lt(e, t) {
		return e.length === t.length && e.every((e, n) => e.route.id === t[n].route.id);
	}
	function ut(e) {
		o = {}, s.setHmrRoutes(T(e, a, void 0, o));
	}
	function ft(e, t, n = !1) {
		it(e, t, s, o, a, n), s.hasHMRRoutes || U({});
	}
	return j = {
		get basename() {
			return c;
		},
		get future() {
			return f;
		},
		get state() {
			return M;
		},
		get routes() {
			return s.stableRoutes;
		},
		get branches() {
			return s.branches;
		},
		get manifest() {
			return o;
		},
		get window() {
			return t;
		},
		initialize: me,
		subscribe: H,
		enableScrollRestoration: nt,
		navigate: _e,
		fetch: Ee,
		revalidate: ve,
		createHref: (t) => e.history.createHref(t),
		encodeLocation: (t) => e.history.encodeLocation(t),
		getFetcher: Ne,
		resetFetcher: Pe,
		deleteFetcher: Ie,
		dispose: he,
		getBlocker: Ge,
		deleteBlocker: Ke,
		patchRoutes: ft,
		_internalFetchControllers: L,
		_internalSetRoutes: ut,
		_internalSetStateDoNotUseOrYouWillBreakYourApp(e) {
			U(e);
		}
	}, e.instrumentations && (j = Te(j, e.instrumentations.map((e) => e.router).filter(Boolean))), j;
}
function Ye(e) {
	return e != null && ("formData" in e && e.formData != null || "body" in e && e.body !== void 0);
}
function Xe(e, t, n, r, i, a) {
	let o, s;
	if (i) {
		o = [];
		for (let e of t) if (o.push(e), e.route.id === i) {
			s = e;
			break;
		}
	} else o = t, s = t[t.length - 1];
	let c = me(r || ".", pe(o), R(e.pathname, n) || e.pathname, a === "path");
	if (r ?? (c.search = e.search, c.hash = e.hash), (r == null || r === "" || r === ".") && s) {
		let e = Jt(c.search);
		if (s.route.index && !e) c.search = c.search ? c.search.replace(/^\?/, "?index&") : "?index";
		else if (!s.route.index && e) {
			let e = new URLSearchParams(c.search), t = e.getAll("index");
			e.delete("index"), t.filter((e) => e).forEach((t) => e.append("index", t));
			let n = e.toString();
			c.search = n ? `?${n}` : "";
		}
	}
	return n !== "/" && (c.pathname = z({
		basename: n,
		pathname: c.pathname
	})), m(c);
}
function Ze(e, t, n) {
	if (!n || !Ye(n)) return { path: t };
	if (n.formMethod && !qt(n.formMethod)) return {
		path: t,
		error: J(405, { method: n.formMethod })
	};
	let r = () => ({
		path: t,
		error: J(400, { type: "invalid-body" })
	}), i = (n.formMethod || "get").toUpperCase(), a = It(t);
	if (n.body !== void 0) {
		if (n.formEncType === "text/plain") {
			if (!X(i)) return r();
			let e = typeof n.body == "string" ? n.body : n.body instanceof FormData || n.body instanceof URLSearchParams ? Array.from(n.body.entries()).reduce((e, [t, n]) => `${e}${t}=${n}
`, "") : String(n.body);
			return {
				path: t,
				submission: {
					formMethod: i,
					formAction: a,
					formEncType: n.formEncType,
					formData: void 0,
					json: void 0,
					text: e
				}
			};
		} else if (n.formEncType === "application/json") {
			if (!X(i)) return r();
			try {
				let e = typeof n.body == "string" ? JSON.parse(n.body) : n.body;
				return {
					path: t,
					submission: {
						formMethod: i,
						formAction: a,
						formEncType: n.formEncType,
						formData: void 0,
						json: e,
						text: void 0
					}
				};
			} catch {
				return r();
			}
		}
	}
	l(typeof FormData == "function", "FormData is not available in this environment");
	let o, s;
	if (n.formData) o = Dt(n.formData), s = n.formData;
	else if (n.body instanceof FormData) o = Dt(n.body), s = n.body;
	else if (n.body instanceof URLSearchParams) o = n.body, s = Ot(o);
	else if (n.body == null) o = new URLSearchParams(), s = new FormData();
	else try {
		o = new URLSearchParams(n.body), s = Ot(o);
	} catch {
		return r();
	}
	let c = {
		formMethod: i,
		formAction: a,
		formEncType: n && n.formEncType || "application/x-www-form-urlencoded",
		formData: s,
		json: void 0,
		text: void 0
	};
	if (X(c.formMethod)) return {
		path: t,
		submission: c
	};
	let u = h(t);
	return e && u.search && Jt(u.search) && o.append("index", ""), u.search = `?${o}`, {
		path: m(u),
		submission: c
	};
}
function Qe(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x) {
	let S = b ? Y(b[1]) ? b[1].error : b[1].data : void 0, C = i.createURL(a.location), w = i.createURL(c), T;
	if (u && a.errors) {
		let e = Object.keys(a.errors)[0];
		T = o.findIndex((t) => t.route.id === e);
	} else if (b && Y(b[1])) {
		let e = b[0];
		T = o.findIndex((t) => t.route.id === e) - 1;
	}
	let E = b ? b[1].statusCode : void 0, D = E && E >= 400, k = {
		currentUrl: C,
		currentParams: a.matches[0]?.params || {},
		nextUrl: w,
		nextParams: o[0].params,
		...s,
		actionResult: S,
		actionStatus: E
	}, A = be(o), j = o.map((i, o) => {
		let { route: s } = i, f = null;
		if (T != null && o > T) f = !1;
		else if (s.lazy) f = !0;
		else if (!$e(s)) f = !1;
		else if (u) {
			let { shouldLoad: e } = et(s, a.loaderData, a.errors);
			f = e;
		} else tt(a.loaderData, a.matches[o], i) && (f = !0);
		if (f !== null) return gt(n, r, e, c, A, i, l, t, f);
		let p = !1;
		typeof x == "boolean" ? p = x : D ? p = !1 : d || C.pathname + C.search === w.pathname + w.search ? p = !0 : C.search === w.search ? nt(a.matches[o], i) && (p = !0) : p = !0;
		let m = {
			...k,
			defaultShouldRevalidate: p
		};
		return gt(n, r, e, c, A, i, l, t, rt(i, m), m, x);
	}), M = [];
	return m.forEach((e, s) => {
		if (u || !o.some((t) => t.route.id === e.routeId) || p.has(s)) return;
		let c = a.fetchers.get(s), m = c && c.state !== "idle" && c.data === void 0, b = O(g, e.path, _ ?? "/", !1, y);
		if (!b) {
			if (v && m) return;
			M.push({
				key: s,
				routeId: e.routeId,
				path: e.path,
				matches: null,
				match: null,
				request: null,
				controller: null
			});
			return;
		}
		if (h.has(s)) return;
		let S = Yt(b, e.path), C = new AbortController(), w = Tt(i, e.path, C.signal), T = null;
		if (f.has(s)) f.delete(s), T = _t(n, r, w, e.path, b, S, l, t);
		else if (m) d && (T = _t(n, r, w, e.path, b, S, l, t));
		else {
			let i;
			i = typeof x == "boolean" ? x : D ? !1 : d;
			let a = {
				...k,
				defaultShouldRevalidate: i
			};
			rt(S, a) && (T = _t(n, r, w, e.path, b, S, l, t, a));
		}
		T && M.push({
			key: s,
			routeId: e.routeId,
			path: e.path,
			matches: T,
			match: S,
			request: w,
			controller: C
		});
	}), {
		dsMatches: j,
		revalidatingFetchers: M
	};
}
function $e(e) {
	return e.loader != null || e.middleware != null && e.middleware.length > 0;
}
function et(e, t, n) {
	if (e.lazy) return {
		shouldLoad: !0,
		renderFallback: !0
	};
	if (!$e(e)) return {
		shouldLoad: !1,
		renderFallback: !1
	};
	let r = t != null && e.id in t, i = n != null && n[e.id] !== void 0;
	if (!r && i) return {
		shouldLoad: !1,
		renderFallback: !1
	};
	if (typeof e.loader == "function" && e.loader.hydrate === !0) return {
		shouldLoad: !0,
		renderFallback: !r
	};
	let a = !r && !i;
	return {
		shouldLoad: a,
		renderFallback: a
	};
}
function tt(e, t, n) {
	let r = !t || n.route.id !== t.route.id, i = !e.hasOwnProperty(n.route.id);
	return r || i;
}
function nt(e, t) {
	let n = e.route.path;
	return e.pathname !== t.pathname || n != null && n.endsWith("*") && e.params["*"] !== t.params["*"];
}
function rt(e, t) {
	if (e.route.shouldRevalidate) {
		let n = e.route.shouldRevalidate(t);
		if (typeof n == "boolean") return n;
	}
	return t.defaultShouldRevalidate;
}
function it(e, t, n, r, i, a) {
	let o;
	if (e) {
		let t = r[e];
		l(t, `No route found to patch children into: routeId = ${e}`), t.children ||= [], o = t.children;
	} else o = n.activeRoutes;
	let s = [], c = [];
	if (t.forEach((e) => {
		let t = o.find((t) => at(e, t));
		t ? c.push({
			existingRoute: t,
			newRoute: e
		}) : s.push(e);
	}), s.length > 0) {
		let t = T(s, i, [
			e || "_",
			"patch",
			String(o?.length || "0")
		], r);
		o.push(...t);
	}
	if (a && c.length > 0) for (let e = 0; e < c.length; e++) {
		let { existingRoute: t, newRoute: n } = c[e], r = t, [a] = T([n], i, [], {}, !0);
		Object.assign(r, {
			element: a.element ? a.element : r.element,
			errorElement: a.errorElement ? a.errorElement : r.errorElement,
			hydrateFallbackElement: a.hydrateFallbackElement ? a.hydrateFallbackElement : r.hydrateFallbackElement
		});
	}
	n.hasHMRRoutes || n.setRoutes([...n.activeRoutes]);
}
function at(e, t) {
	return "id" in e && "id" in t && e.id === t.id ? !0 : e.index === t.index && e.path === t.path && e.caseSensitive === t.caseSensitive ? (!e.children || e.children.length === 0) && (!t.children || t.children.length === 0) ? !0 : e.children?.every((e, n) => t.children?.some((t) => at(e, t))) ?? !1 : !1;
}
var ot = /* @__PURE__ */ new WeakMap(), st = ({ key: e, route: t, manifest: n, mapRouteProperties: r }) => {
	let i = n[t.id];
	if (l(i, "No route found in manifest"), !i.lazy || typeof i.lazy != "object") return;
	let a = i.lazy[e];
	if (!a) return;
	let o = ot.get(i);
	o || (o = {}, ot.set(i, o));
	let s = o[e];
	if (s) return s;
	let c = (async () => {
		let t = x(e), n = i[e] !== void 0 && e !== "hasErrorBoundary";
		if (t) u(!t, "Route property " + e + " is not a supported lazy route property. This property will be ignored."), o[e] = Promise.resolve();
		else if (n) u(!1, `Route "${i.id}" has a static property "${e}" defined. The lazy property will be ignored.`);
		else {
			let t = await a();
			t != null && (Object.assign(i, { [e]: t }), Object.assign(i, r(i)));
		}
		typeof i.lazy == "object" && (i.lazy[e] = void 0, Object.values(i.lazy).every((e) => e === void 0) && (i.lazy = void 0));
	})();
	return o[e] = c, c;
}, ct = /* @__PURE__ */ new WeakMap();
function lt(e, t, n, r, i) {
	let a = n[e.id];
	if (l(a, "No route found in manifest"), !e.lazy) return {
		lazyRoutePromise: void 0,
		lazyHandlerPromise: void 0
	};
	if (typeof e.lazy == "function") {
		let t = ct.get(a);
		if (t) return {
			lazyRoutePromise: t,
			lazyHandlerPromise: t
		};
		let n = (async () => {
			l(typeof e.lazy == "function", "No lazy route function found");
			let t = await e.lazy(), n = {};
			for (let e in t) {
				let r = t[e];
				if (r === void 0) continue;
				let i = C(e), o = a[e] !== void 0 && e !== "hasErrorBoundary";
				i ? u(!i, "Route property " + e + " is not a supported property to be returned from a lazy route function. This property will be ignored.") : o ? u(!o, `Route "${a.id}" has a static property "${e}" defined but its lazy function is also returning a value for this property. The lazy route property "${e}" will be ignored.`) : n[e] = r;
			}
			Object.assign(a, n), Object.assign(a, {
				...r(a),
				lazy: void 0
			});
		})();
		return ct.set(a, n), n.catch(() => {}), {
			lazyRoutePromise: n,
			lazyHandlerPromise: n
		};
	}
	let o = Object.keys(e.lazy), s = [], c;
	for (let a of o) {
		if (i && i.includes(a)) continue;
		let o = st({
			key: a,
			route: e,
			manifest: n,
			mapRouteProperties: r
		});
		o && (s.push(o), a === t && (c = o));
	}
	let d = s.length > 0 ? Promise.all(s).then(() => {}) : void 0;
	return d?.catch(() => {}), c?.catch(() => {}), {
		lazyRoutePromise: d,
		lazyHandlerPromise: c
	};
}
async function ut(e) {
	let t = e.matches.filter((e) => e.shouldLoad), n = {};
	return (await Promise.all(t.map((e) => e.resolve()))).forEach((e, r) => {
		n[t[r].route.id] = e;
	}), n;
}
async function dt(e) {
	return e.matches.some((e) => e.route.middleware) ? ft(e, () => ut(e)) : ut(e);
}
function ft(e, t) {
	return pt(e, t, (e) => {
		if (Kt(e)) throw e;
		return e;
	}, zt, n);
	function n(t, n, r) {
		if (r) return Promise.resolve(Object.assign(r.value, { [n]: {
			type: "error",
			result: t
		} }));
		{
			let { matches: r } = e, i = Nt(r, r[Math.min(Math.max(r.findIndex((e) => e.route.id === n), 0), Math.max(r.findIndex((e) => e.shouldCallHandler()), 0))].route.id).route.id;
			return Promise.resolve({ [i]: {
				type: "error",
				result: t
			} });
		}
	}
}
async function pt(e, t, n, r, i) {
	let { matches: a, ...o } = e;
	return await mt(o, a.flatMap((e) => e.route.middleware ? e.route.middleware.map((t) => [e.route.id, t]) : []), t, n, r, i);
}
async function mt(e, t, n, r, i, a, o = 0) {
	let { request: s } = e;
	if (s.signal.aborted) throw s.signal.reason ?? /* @__PURE__ */ Error(`Request aborted: ${s.method} ${s.url}`);
	let c = t[o];
	if (!c) return await n();
	let [l, u] = c, d, f = async () => {
		if (d) throw Error("You may only call `next()` once per middleware");
		try {
			return d = { value: await mt(e, t, n, r, i, a, o + 1) }, d.value;
		} catch (e) {
			return d = { value: await a(e, l, d) }, d.value;
		}
	};
	try {
		let t = await u(e, f), n = t == null ? void 0 : r(t);
		return i(n) ? n : d ? n ?? d.value : (d = { value: await f() }, d.value);
	} catch (e) {
		return await a(e, l, d);
	}
}
function ht(e, t, n, r, i) {
	let a = st({
		key: "middleware",
		route: r.route,
		manifest: t,
		mapRouteProperties: e
	}), o = lt(r.route, X(n.method) ? "action" : "loader", t, e, i);
	return {
		middleware: a,
		route: o.lazyRoutePromise,
		handler: o.lazyHandlerPromise
	};
}
function gt(e, t, n, r, i, a, o, s, c, l = null, u) {
	let d = !1, f = ht(e, t, n, a, o);
	return {
		...a,
		_lazyPromises: f,
		shouldLoad: c,
		shouldRevalidateArgs: l,
		shouldCallHandler(e) {
			return d = !0, l ? typeof u == "boolean" ? rt(a, {
				...l,
				defaultShouldRevalidate: u
			}) : typeof e == "boolean" ? rt(a, {
				...l,
				defaultShouldRevalidate: e
			}) : rt(a, l) : c;
		},
		resolve(e) {
			let { lazy: t, loader: o, middleware: l } = a.route, u = d || c || e && !X(n.method) && (t || o), p = l && l.length > 0 && !o && !t;
			return u && (X(n.method) || !p) ? yt({
				request: n,
				path: r,
				pattern: i,
				match: a,
				lazyHandlerPromise: f?.handler,
				lazyRoutePromise: f?.route,
				handlerOverride: e,
				scopedContext: s
			}) : Promise.resolve({
				type: "data",
				result: void 0
			});
		}
	};
}
function _t(e, t, n, r, i, a, o, s, c = null) {
	return i.map((l) => l.route.id === a.route.id ? gt(e, t, n, r, be(i), l, o, s, !0, c) : {
		...l,
		shouldLoad: !1,
		shouldRevalidateArgs: c,
		shouldCallHandler: () => !1,
		_lazyPromises: ht(e, t, n, l, o),
		resolve: () => Promise.resolve({
			type: "data",
			result: void 0
		})
	});
}
async function vt(e, t, n, r, i, a, o) {
	r.some((e) => e._lazyPromises?.middleware) && await Promise.all(r.map((e) => e._lazyPromises?.middleware));
	let s = {
		request: t,
		url: Et(t, n),
		pattern: be(r),
		params: r[0].params,
		context: a,
		matches: r
	}, c = o ? () => {
		throw Error("You cannot call `runClientMiddleware()` from a static handler `dataStrategy`. Middleware is run outside of `dataStrategy` during SSR in order to bubble up the Response.  You can enable middleware via the `respond` API in `query`/`queryRoute`");
	} : (e) => {
		let t = s;
		return ft(t, () => e({
			...t,
			fetcherKey: i,
			runClientMiddleware: () => {
				throw Error("Cannot call `runClientMiddleware()` from within an `runClientMiddleware` handler");
			}
		}));
	}, l = await e({
		...s,
		fetcherKey: i,
		runClientMiddleware: c
	});
	try {
		await Promise.all(r.flatMap((e) => [e._lazyPromises?.handler, e._lazyPromises?.route]));
	} catch {}
	return l;
}
async function yt({ request: e, path: t, pattern: n, match: r, lazyHandlerPromise: i, lazyRoutePromise: a, handlerOverride: o, scopedContext: s }) {
	let c, l, u = X(e.method), d = u ? "action" : "loader", f = (i) => {
		let a, c = new Promise((e, t) => a = t);
		l = () => a(), e.signal.addEventListener("abort", l);
		let u = (a) => typeof i == "function" ? i({
			request: e,
			url: Et(e, t),
			pattern: n,
			params: r.params,
			context: s
		}, ...a === void 0 ? [] : [a]) : Promise.reject(/* @__PURE__ */ Error(`You cannot call the handler for a route which defines a boolean "${d}" [routeId: ${r.route.id}]`)), f = (async () => {
			try {
				return {
					type: "data",
					result: await (o ? o((e) => u(e)) : u())
				};
			} catch (e) {
				return {
					type: "error",
					result: e
				};
			}
		})();
		return Promise.race([f, c]);
	};
	try {
		let t = u ? r.route.action : r.route.loader;
		if (i || a) if (t) {
			let e, [n] = await Promise.all([
				f(t).catch((t) => {
					e = t;
				}),
				i,
				a
			]);
			if (e !== void 0) throw e;
			c = n;
		} else {
			await i;
			let t = u ? r.route.action : r.route.loader;
			if (t) [c] = await Promise.all([f(t), a]);
			else if (d === "action") {
				let t = new URL(e.url), n = t.pathname + t.search;
				throw J(405, {
					method: e.method,
					pathname: n,
					routeId: r.route.id
				});
			} else return {
				type: "data",
				result: void 0
			};
		}
		else if (t) c = await f(t);
		else {
			let t = new URL(e.url);
			throw J(404, { pathname: t.pathname + t.search });
		}
	} catch (e) {
		return {
			type: "error",
			result: e
		};
	} finally {
		l && e.signal.removeEventListener("abort", l);
	}
	return c;
}
async function bt(e) {
	let t = e.headers.get("Content-Type");
	return t && /\bapplication\/json\b/.test(t) ? e.body == null ? null : e.json() : e.text();
}
async function xt(e) {
	let { result: t, type: n } = e;
	if (Wt(t)) {
		let e;
		try {
			e = await bt(t);
		} catch (e) {
			return {
				type: "error",
				error: e
			};
		}
		return n === "error" ? {
			type: "error",
			error: new W(t.status, t.statusText, e),
			statusCode: t.status,
			headers: t.headers
		} : {
			type: "data",
			data: e,
			statusCode: t.status,
			headers: t.headers
		};
	}
	return n === "error" ? Ut(t) ? t.data instanceof Error ? {
		type: "error",
		error: t.data,
		statusCode: t.init?.status,
		headers: t.init?.headers ? new Headers(t.init.headers) : void 0
	} : {
		type: "error",
		error: Rt(t),
		statusCode: ye(t) ? t.status : void 0,
		headers: t.init?.headers ? new Headers(t.init.headers) : void 0
	} : {
		type: "error",
		error: t,
		statusCode: ye(t) ? t.status : void 0
	} : Ut(t) ? {
		type: "data",
		data: t.data,
		statusCode: t.init?.status,
		headers: t.init?.headers ? new Headers(t.init.headers) : void 0
	} : {
		type: "data",
		data: t
	};
}
function St(e, t, n, r, i) {
	let a = e.headers.get("Location");
	if (l(a, "Redirects returned/thrown from loaders/actions must have a Location header"), !ue(a)) {
		let o = r.slice(0, r.findIndex((e) => e.route.id === n) + 1);
		a = Xe(new URL(t.url), o, i, a), e.headers.set("Location", a);
	}
	return e;
}
var Ct = [
	"about:",
	"blob:",
	"chrome:",
	"chrome-untrusted:",
	"content:",
	"data:",
	"devtools:",
	"file:",
	"filesystem:",
	"javascript:"
];
function wt(e, t, n, r) {
	if (ue(e)) {
		let r = e, i = r.startsWith("//") ? new URL(t.protocol + r) : new URL(r);
		if (Ct.includes(i.protocol)) throw Error("Invalid redirect location");
		let a = R(i.pathname, n) != null;
		if (i.origin === t.origin && a) return he(i.pathname) + i.search + i.hash;
	}
	try {
		let t = r.createURL(e);
		if (Ct.includes(t.protocol)) throw Error("Invalid redirect location");
	} catch {}
	return e;
}
function Tt(e, t, n, r) {
	let i = e.createURL(It(t)).toString(), a = { signal: n };
	if (r && X(r.formMethod)) {
		let { formMethod: e, formEncType: t } = r;
		a.method = e.toUpperCase(), t === "application/json" ? (a.headers = new Headers({ "Content-Type": t }), a.body = JSON.stringify(r.json)) : t === "text/plain" ? a.body = r.text : t === "application/x-www-form-urlencoded" && r.formData ? a.body = Dt(r.formData) : a.body = r.formData;
	}
	return new Request(i, a);
}
function Et(e, t) {
	let n = new URL(e.url), r = typeof t == "string" ? h(t) : t;
	if (n.pathname = r.pathname || "/", r.search) {
		let e = new URLSearchParams(r.search), t = e.getAll("index");
		e.delete("index");
		for (let n of t.filter(Boolean)) e.append("index", n);
		n.search = e.size ? `?${e.toString()}` : "";
	} else n.search = "";
	return n.hash = r.hash || "", n;
}
function Dt(e) {
	let t = new URLSearchParams();
	for (let [n, r] of e.entries()) t.append(n, typeof r == "string" ? r : r.name);
	return t;
}
function Ot(e) {
	let t = new FormData();
	for (let [n, r] of e.entries()) t.append(n, r);
	return t;
}
function kt(e, t, n, r = !1, i = !1) {
	let a = {}, o = null, s, c = !1, u = {}, d = n && Y(n[1]) ? n[1].error : void 0;
	return e.forEach((n) => {
		if (!(n.route.id in t)) return;
		let f = n.route.id, p = t[f];
		if (l(!Ht(p), "Cannot handle redirect results in processLoaderData"), Y(p)) {
			let t = p.error;
			if (d !== void 0 && (t = d, d = void 0), o ||= {}, i) o[f] = t;
			else {
				let n = Nt(e, f);
				o[n.route.id] ?? (o[n.route.id] = t);
			}
			r || (a[f] = He), c || (c = !0, s = ye(p.error) ? p.error.status : 500), p.headers && (u[f] = p.headers);
		} else a[f] = p.data, p.statusCode && p.statusCode !== 200 && !c && (s = p.statusCode), p.headers && (u[f] = p.headers);
	}), d !== void 0 && n && (o = { [n[0]]: d }, n[2] && (a[n[2]] = void 0)), {
		loaderData: a,
		errors: o,
		statusCode: s || 200,
		loaderHeaders: u
	};
}
function At(e, t, n, r, i, a) {
	let { loaderData: o, errors: s } = kt(t, n, r);
	return i.filter((e) => !e.matches || e.matches.some((e) => e.shouldLoad)).forEach((t) => {
		let { key: n, match: r, controller: i } = t;
		if (i && i.signal.aborted) return;
		let o = a[n];
		if (l(o, "Did not find corresponding fetcher result"), Y(o)) {
			let t = Nt(e.matches, r?.route.id);
			s && s[t.route.id] || (s = {
				...s,
				[t.route.id]: o.error
			}), e.fetchers.delete(n);
		} else if (Ht(o)) l(!1, "Unhandled fetcher revalidation redirect");
		else {
			let t = tn(o.data);
			e.fetchers.set(n, t);
		}
	}), {
		loaderData: o,
		errors: s
	};
}
function jt(e, t, n, r) {
	let i = Object.entries(t).filter(([, e]) => e !== He).reduce((e, [t, n]) => (e[t] = n, e), {});
	for (let a of n) {
		let n = a.route.id;
		if (!t.hasOwnProperty(n) && e.hasOwnProperty(n) && a.route.loader && (i[n] = e[n]), r && r.hasOwnProperty(n)) break;
	}
	return i;
}
function Mt(e) {
	return e ? Y(e[1]) ? { actionData: {} } : { actionData: { [e[0]]: e[1].data } } : {};
}
function Nt(e, t) {
	return (t ? e.slice(0, e.findIndex((e) => e.route.id === t) + 1) : [...e]).reverse().find((e) => e.route.hasErrorBoundary === !0) || e[0];
}
function Pt(e) {
	let t = e.length === 1 ? e[0] : e.find((e) => e.index || !e.path || e.path === "/") || { id: "__shim-error-route__" };
	return {
		matches: [{
			params: {},
			pathname: "",
			pathnameBase: "",
			route: t
		}],
		route: t
	};
}
function J(e, { pathname: t, routeId: n, method: r, type: i, message: a } = {}) {
	let o = "Unknown Server Error", s = "Unknown @remix-run/router error";
	return e === 400 ? (o = "Bad Request", r && t && n ? s = `You made a ${r} request to "${t}" but did not provide a \`loader\` for route "${n}", so there is no way to handle the request.` : i === "invalid-body" && (s = "Unable to encode submission body")) : e === 403 ? (o = "Forbidden", s = `Route "${n}" does not match URL "${t}"`) : e === 404 ? (o = "Not Found", s = `No route matches URL "${t}"`) : e === 405 && (o = "Method Not Allowed", r && t && n ? s = `You made a ${r.toUpperCase()} request to "${t}" but did not provide an \`action\` for route "${n}", so there is no way to handle the request.` : r && (s = `Invalid request method "${r.toUpperCase()}"`)), new W(e || 500, o, Error(s), !0);
}
function Ft(e) {
	let t = Object.entries(e);
	for (let e = t.length - 1; e >= 0; e--) {
		let [n, r] = t[e];
		if (Ht(r)) return {
			key: n,
			result: r
		};
	}
}
function It(e) {
	return m({
		...typeof e == "string" ? h(e) : e,
		hash: ""
	});
}
function Lt(e, t) {
	return e.pathname !== t.pathname || e.search !== t.search ? !1 : e.hash === "" ? t.hash !== "" : e.hash === t.hash ? !0 : t.hash !== "";
}
function Rt(e) {
	return new W(e.init?.status ?? 500, e.init?.statusText ?? "Internal Server Error", e.data);
}
function zt(e) {
	return typeof e == "object" && !!e && Object.entries(e).every(([e, t]) => typeof e == "string" && Bt(t));
}
function Bt(e) {
	return typeof e == "object" && !!e && "type" in e && "result" in e && (e.type === "data" || e.type === "error");
}
function Vt(e) {
	return Wt(e.result) && Ie.has(e.result.status);
}
function Y(e) {
	return e.type === "error";
}
function Ht(e) {
	return (e && e.type) === "redirect";
}
function Ut(e) {
	return typeof e == "object" && !!e && "type" in e && "data" in e && "init" in e && e.type === "DataWithResponseInit";
}
function Wt(e) {
	return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.headers == "object" && e.body !== void 0;
}
function Gt(e) {
	return Ie.has(e);
}
function Kt(e) {
	return Wt(e) && Gt(e.status) && e.headers.has("Location");
}
function qt(e) {
	return Fe.has(e.toUpperCase());
}
function X(e) {
	return Ne.has(e.toUpperCase());
}
function Jt(e) {
	return new URLSearchParams(e).getAll("index").some((e) => e === "");
}
function Yt(e, t) {
	let n = typeof t == "string" ? h(t).search : t.search;
	if (e[e.length - 1].route.index && Jt(n || "")) return e[e.length - 1];
	let r = fe(e);
	return r[r.length - 1];
}
function Xt(e) {
	let { formMethod: t, formAction: n, formEncType: r, text: i, formData: a, json: o } = e;
	if (!(!t || !n || !r)) {
		if (i != null) return {
			formMethod: t,
			formAction: n,
			formEncType: r,
			formData: void 0,
			json: void 0,
			text: i
		};
		if (a != null) return {
			formMethod: t,
			formAction: n,
			formEncType: r,
			formData: a,
			json: void 0,
			text: void 0
		};
		if (o !== void 0) return {
			formMethod: t,
			formAction: n,
			formEncType: r,
			formData: void 0,
			json: o,
			text: void 0
		};
	}
}
function Zt(e, t) {
	return t ? {
		state: "loading",
		location: e,
		formMethod: t.formMethod,
		formAction: t.formAction,
		formEncType: t.formEncType,
		formData: t.formData,
		json: t.json,
		text: t.text
	} : {
		state: "loading",
		location: e,
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0
	};
}
function Qt(e, t) {
	return {
		state: "submitting",
		location: e,
		formMethod: t.formMethod,
		formAction: t.formAction,
		formEncType: t.formEncType,
		formData: t.formData,
		json: t.json,
		text: t.text
	};
}
function $t(e, t) {
	return e ? {
		state: "loading",
		formMethod: e.formMethod,
		formAction: e.formAction,
		formEncType: e.formEncType,
		formData: e.formData,
		json: e.json,
		text: e.text,
		data: t
	} : {
		state: "loading",
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0,
		data: t
	};
}
function en(e, t) {
	return {
		state: "submitting",
		formMethod: e.formMethod,
		formAction: e.formAction,
		formEncType: e.formEncType,
		formData: e.formData,
		json: e.json,
		text: e.text,
		data: t ? t.data : void 0
	};
}
function tn(e) {
	return {
		state: "idle",
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0,
		data: e
	};
}
function nn(e, t) {
	try {
		let n = e.sessionStorage.getItem(q);
		if (n) {
			let e = JSON.parse(n);
			for (let [n, r] of Object.entries(e || {})) r && Array.isArray(r) && t.set(n, new Set(r || []));
		}
	} catch {}
}
function rn(e, t) {
	if (t.size > 0) {
		let n = {};
		for (let [e, r] of t) n[e] = [...r];
		try {
			e.sessionStorage.setItem(q, JSON.stringify(n));
		} catch (e) {
			u(!1, `Failed to save applied view transitions in sessionStorage (${e}).`);
		}
	}
}
function an() {
	let e, t, n = new Promise((r, i) => {
		e = async (e) => {
			r(e);
			try {
				await n;
			} catch {}
		}, t = async (e) => {
			i(e);
			try {
				await n;
			} catch {}
		};
	});
	return {
		promise: n,
		resolve: e,
		reject: t
	};
}
var on = e.createContext(null);
on.displayName = "DataRouter";
var sn = e.createContext(null);
sn.displayName = "DataRouterState";
var cn = e.createContext(!1);
function ln() {
	return e.useContext(cn);
}
var un = e.createContext({ isTransitioning: !1 });
un.displayName = "ViewTransition";
var dn = e.createContext(/* @__PURE__ */ new Map());
dn.displayName = "Fetchers";
var fn = e.createContext(null);
fn.displayName = "Await";
var Z = e.createContext(null);
Z.displayName = "Navigation";
var pn = e.createContext(null);
pn.displayName = "Location";
var Q = e.createContext({
	outlet: null,
	matches: [],
	isDataRoute: !1
});
Q.displayName = "Route";
var mn = e.createContext(null);
mn.displayName = "RouteError";
var hn = "REACT_ROUTER_ERROR", gn = "REDIRECT", _n = "ROUTE_ERROR_RESPONSE";
function vn(e) {
	if (e.startsWith(`${hn}:${gn}:{`)) try {
		let t = JSON.parse(e.slice(28));
		if (typeof t == "object" && t && typeof t.status == "number" && typeof t.statusText == "string" && typeof t.location == "string" && typeof t.reloadDocument == "boolean" && typeof t.replace == "boolean") return t;
	} catch {}
}
function yn(e) {
	if (e.startsWith(`${hn}:${_n}:{`)) try {
		let t = JSON.parse(e.slice(40));
		if (typeof t == "object" && t && typeof t.status == "number" && typeof t.statusText == "string") return new W(t.status, t.statusText, t.data);
	} catch {}
}
function bn(t, { relative: n } = {}) {
	l(xn(), "useHref() may be used only in the context of a <Router> component.");
	let { basename: r, navigator: i } = e.useContext(Z), { hash: a, pathname: o, search: s } = kn(t, { relative: n }), c = o;
	return r !== "/" && (c = o === "/" ? r : H([r, o])), i.createHref({
		pathname: c,
		search: s,
		hash: a
	});
}
function xn() {
	return e.useContext(pn) != null;
}
function $() {
	return l(xn(), "useLocation() may be used only in the context of a <Router> component."), e.useContext(pn).location;
}
var Sn = "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
function Cn(t) {
	e.useContext(Z).static || e.useLayoutEffect(t);
}
function wn() {
	let { isDataRoute: t } = e.useContext(Q);
	return t ? qn() : Tn();
}
function Tn() {
	l(xn(), "useNavigate() may be used only in the context of a <Router> component.");
	let t = e.useContext(on), { basename: n, navigator: r } = e.useContext(Z), { matches: i } = e.useContext(Q), { pathname: a } = $(), o = JSON.stringify(pe(i)), s = e.useRef(!1);
	return Cn(() => {
		s.current = !0;
	}), e.useCallback((e, i = {}) => {
		if (u(s.current, Sn), !s.current) return;
		if (typeof e == "number") {
			r.go(e);
			return;
		}
		let c = me(e, JSON.parse(o), a, i.relative === "path");
		t == null && n !== "/" && (c.pathname = c.pathname === "/" ? n : H([n, c.pathname])), (i.replace ? r.replace : r.push)(c, i.state, i);
	}, [
		n,
		r,
		o,
		a,
		t
	]);
}
var En = e.createContext(null);
function Dn(t) {
	let n = e.useContext(Q).outlet;
	return e.useMemo(() => n && /* @__PURE__ */ e.createElement(En.Provider, { value: t }, n), [n, t]);
}
function On() {
	let { matches: t } = e.useContext(Q);
	return t[t.length - 1]?.params ?? {};
}
function kn(t, { relative: n } = {}) {
	let { matches: r } = e.useContext(Q), { pathname: i } = $(), a = JSON.stringify(pe(r));
	return e.useMemo(() => me(t, JSON.parse(a), i, n === "path"), [
		t,
		a,
		i,
		n
	]);
}
function An(t, n, r) {
	l(xn(), "useRoutes() may be used only in the context of a <Router> component.");
	let { navigator: i } = e.useContext(Z), { matches: a } = e.useContext(Q), o = a[a.length - 1], s = o ? o.params : {}, c = o ? o.pathname : "/", d = o ? o.pathnameBase : "/", f = o && o.route;
	{
		let e = f && f.path || "";
		Yn(c, !f || e.endsWith("*") || e.endsWith("*?"), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${c}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${e}"> to <Route path="${e === "/" ? "*" : `${e}/*`}">.`);
	}
	let p = $(), m;
	if (n) {
		let e = typeof n == "string" ? h(n) : n;
		l(d === "/" || e.pathname?.startsWith(d), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${d}" but pathname "${e.pathname}" was given in the \`location\` prop.`), m = e;
	} else m = p;
	let g = m.pathname || "/", _ = g;
	if (d !== "/") {
		let e = d.replace(/^\//, "").split("/");
		_ = "/" + g.replace(/^\//, "").split("/").slice(e.length).join("/");
	}
	let v = r && r.state.matches.length ? r.state.matches.map((e) => Object.assign(e, { route: r.manifest[e.route.id] || e.route })) : D(t, { pathname: _ });
	u(f || v != null, `No routes matched location "${m.pathname}${m.search}${m.hash}" `), u(v == null || v[v.length - 1].route.element !== void 0 || v[v.length - 1].route.Component !== void 0 || v[v.length - 1].route.lazy !== void 0, `Matched leaf route at location "${m.pathname}${m.search}${m.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
	let y = Ln(v && v.map((e) => Object.assign({}, e, {
		params: Object.assign({}, s, e.params),
		pathname: H([d, i.encodeLocation ? i.encodeLocation(e.pathname.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : e.pathname]),
		pathnameBase: e.pathnameBase === "/" ? d : H([d, i.encodeLocation ? i.encodeLocation(e.pathnameBase.replace(/%/g, "%25").replace(/\?/g, "%3F").replace(/#/g, "%23")).pathname : e.pathnameBase])
	})), a, r);
	return n && y ? /* @__PURE__ */ e.createElement(pn.Provider, { value: {
		location: {
			pathname: "/",
			search: "",
			hash: "",
			state: null,
			key: "default",
			mask: void 0,
			...m
		},
		navigationType: "POP"
	} }, y) : y;
}
function jn() {
	let t = Kn(), n = ye(t) ? `${t.status} ${t.statusText}` : t instanceof Error ? t.message : JSON.stringify(t), r = t instanceof Error ? t.stack : null, i = "rgba(200,200,200, 0.5)", a = {
		padding: "0.5rem",
		backgroundColor: i
	}, o = {
		padding: "2px 4px",
		backgroundColor: i
	}, s = null;
	return console.error("Error handled by React Router default ErrorBoundary:", t), s = /* @__PURE__ */ e.createElement(e.Fragment, null, /* @__PURE__ */ e.createElement("p", null, "💿 Hey developer 👋"), /* @__PURE__ */ e.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", /* @__PURE__ */ e.createElement("code", { style: o }, "ErrorBoundary"), " or", " ", /* @__PURE__ */ e.createElement("code", { style: o }, "errorElement"), " prop on your route.")), /* @__PURE__ */ e.createElement(e.Fragment, null, /* @__PURE__ */ e.createElement("h2", null, "Unexpected Application Error!"), /* @__PURE__ */ e.createElement("h3", { style: { fontStyle: "italic" } }, n), r ? /* @__PURE__ */ e.createElement("pre", { style: a }, r) : null, s);
}
var Mn = /* @__PURE__ */ e.createElement(jn, null), Nn = class extends e.Component {
	constructor(e) {
		super(e), this.state = {
			location: e.location,
			revalidation: e.revalidation,
			error: e.error
		};
	}
	static getDerivedStateFromError(e) {
		return { error: e };
	}
	static getDerivedStateFromProps(e, t) {
		return t.location !== e.location || t.revalidation !== "idle" && e.revalidation === "idle" ? {
			error: e.error,
			location: e.location,
			revalidation: e.revalidation
		} : {
			error: e.error === void 0 ? t.error : e.error,
			location: t.location,
			revalidation: e.revalidation || t.revalidation
		};
	}
	componentDidCatch(e, t) {
		this.props.onError ? this.props.onError(e, t) : console.error("React Router caught the following error during render", e);
	}
	render() {
		let t = this.state.error;
		if (this.context && typeof t == "object" && t && "digest" in t && typeof t.digest == "string") {
			let e = yn(t.digest);
			e && (t = e);
		}
		let n = t === void 0 ? this.props.children : /* @__PURE__ */ e.createElement(Q.Provider, { value: this.props.routeContext }, /* @__PURE__ */ e.createElement(mn.Provider, {
			value: t,
			children: this.props.component
		}));
		return this.context ? /* @__PURE__ */ e.createElement(Fn, { error: t }, n) : n;
	}
};
Nn.contextType = cn;
var Pn = /* @__PURE__ */ new WeakMap();
function Fn({ children: t, error: n }) {
	let { basename: r } = e.useContext(Z);
	if (typeof n == "object" && n && "digest" in n && typeof n.digest == "string") {
		let t = vn(n.digest);
		if (t) {
			let i = Pn.get(n);
			if (i) throw i;
			let a = Se(t.location, r);
			if (xe && !Pn.get(n)) if (a.isExternal || t.reloadDocument) window.location.href = a.absoluteURL || a.to;
			else {
				let e = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(a.to, { replace: t.replace }));
				throw Pn.set(n, e), e;
			}
			return /* @__PURE__ */ e.createElement("meta", {
				httpEquiv: "refresh",
				content: `0;url=${a.absoluteURL || a.to}`
			});
		}
	}
	return t;
}
function In({ routeContext: t, match: n, children: r }) {
	let i = e.useContext(on);
	return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), /* @__PURE__ */ e.createElement(Q.Provider, { value: t }, r);
}
function Ln(t, n = [], r) {
	let i = r?.state;
	if (t == null) {
		if (!i) return null;
		if (i.errors) t = i.matches;
		else if (n.length === 0 && !i.initialized && i.matches.length > 0) t = i.matches;
		else return null;
	}
	let a = t, o = i?.errors;
	if (o != null) {
		let e = a.findIndex((e) => e.route.id && o?.[e.route.id] !== void 0);
		l(e >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(o).join(",")}`), a = a.slice(0, Math.min(a.length, e + 1));
	}
	let s = !1, c = -1;
	if (r && i) {
		s = i.renderFallback;
		for (let e = 0; e < a.length; e++) {
			let t = a[e];
			if ((t.route.HydrateFallback || t.route.hydrateFallbackElement) && (c = e), t.route.id) {
				let { loaderData: e, errors: n } = i, o = t.route.loader && !e.hasOwnProperty(t.route.id) && (!n || n[t.route.id] === void 0);
				if (t.route.lazy || o) {
					r.isStatic && (s = !0), a = c >= 0 ? a.slice(0, c + 1) : [a[0]];
					break;
				}
			}
		}
	}
	let u = r?.onError, d = i && u ? (e, t) => {
		u(e, {
			location: i.location,
			params: i.matches?.[0]?.params ?? {},
			pattern: be(i.matches),
			errorInfo: t
		});
	} : void 0;
	return a.reduceRight((t, r, l) => {
		let u, f = !1, p = null, m = null;
		i && (u = o && r.route.id ? o[r.route.id] : void 0, p = r.route.errorElement || Mn, s && (c < 0 && l === 0 ? (Yn("route-fallback", !1, "No `HydrateFallback` element provided to render during initial hydration"), f = !0, m = null) : c === l && (f = !0, m = r.route.hydrateFallbackElement || null)));
		let h = n.concat(a.slice(0, l + 1)), g = () => {
			let n;
			return n = u ? p : f ? m : r.route.Component ? /* @__PURE__ */ e.createElement(r.route.Component, null) : r.route.element ? r.route.element : t, /* @__PURE__ */ e.createElement(In, {
				match: r,
				routeContext: {
					outlet: t,
					matches: h,
					isDataRoute: i != null
				},
				children: n
			});
		};
		return i && (r.route.ErrorBoundary || r.route.errorElement || l === 0) ? /* @__PURE__ */ e.createElement(Nn, {
			location: i.location,
			revalidation: i.revalidation,
			component: p,
			error: u,
			children: g(),
			routeContext: {
				outlet: null,
				matches: h,
				isDataRoute: !0
			},
			onError: d
		}) : g();
	}, null);
}
function Rn(e) {
	return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function zn(t) {
	let n = e.useContext(on);
	return l(n, Rn(t)), n;
}
function Bn(t) {
	let n = e.useContext(sn);
	return l(n, Rn(t)), n;
}
function Vn(t) {
	let n = e.useContext(Q);
	return l(n, Rn(t)), n;
}
function Hn(e) {
	let t = Vn(e), n = t.matches[t.matches.length - 1];
	return l(n.route.id, `${e} can only be used on routes that contain a unique "id"`), n.route.id;
}
function Un() {
	return Hn("useRouteId");
}
function Wn() {
	return Bn("useNavigation").navigation;
}
function Gn() {
	let { matches: t, loaderData: n } = Bn("useMatches");
	return e.useMemo(() => t.map((e) => k(e, n)), [t, n]);
}
function Kn() {
	let t = e.useContext(mn), n = Bn("useRouteError"), r = Hn("useRouteError");
	return t === void 0 ? n.errors?.[r] : t;
}
function qn() {
	let { router: t } = zn("useNavigate"), n = Hn("useNavigate"), r = e.useRef(!1);
	return Cn(() => {
		r.current = !0;
	}), e.useCallback(async (e, i = {}) => {
		u(r.current, Sn), r.current && (typeof e == "number" ? await t.navigate(e) : await t.navigate(e, {
			fromRouteId: n,
			...i
		}));
	}, [t, n]);
}
var Jn = {};
function Yn(e, t, n) {
	!t && !Jn[e] && (Jn[e] = !0, u(!1, n));
}
var Xn = {};
function Zn(e, t) {
	!e && !Xn[t] && (Xn[t] = !0, console.warn(t));
}
var Qn = e.useOptimistic, $n = () => void 0;
function er(e) {
	return Qn ? Qn(e) : [e, $n];
}
function tr(t) {
	let n = { hasErrorBoundary: t.hasErrorBoundary || t.ErrorBoundary != null || t.errorElement != null };
	return t.Component && (t.element && u(!1, "You should not include both `Component` and `element` on your route - `Component` will be used."), Object.assign(n, {
		element: e.createElement(t.Component),
		Component: void 0
	})), t.HydrateFallback && (t.hydrateFallbackElement && u(!1, "You should not include both `HydrateFallback` and `hydrateFallbackElement` on your route - `HydrateFallback` will be used."), Object.assign(n, {
		hydrateFallbackElement: e.createElement(t.HydrateFallback),
		HydrateFallback: void 0
	})), t.ErrorBoundary && (t.errorElement && u(!1, "You should not include both `ErrorBoundary` and `errorElement` on your route - `ErrorBoundary` will be used."), Object.assign(n, {
		errorElement: e.createElement(t.ErrorBoundary),
		ErrorBoundary: void 0
	})), n;
}
var nr = ["HydrateFallback", "hydrateFallbackElement"], rr = class {
	constructor() {
		this.status = "pending", this.promise = new Promise((e, t) => {
			this.resolve = (t) => {
				this.status === "pending" && (this.status = "resolved", e(t));
			}, this.reject = (e) => {
				this.status === "pending" && (this.status = "rejected", t(e));
			};
		});
	}
};
function ir({ router: t, flushSync: n, onError: r, useTransitions: i }) {
	i = ln() || i;
	let [a, o] = e.useState(t.state), [s, c] = er(a), [l, u] = e.useState(), [d, f] = e.useState({ isTransitioning: !1 }), [p, m] = e.useState(), [h, g] = e.useState(), [_, v] = e.useState(), y = e.useRef(/* @__PURE__ */ new Map()), b = e.useCallback((a, { deletedFetchers: s, newErrors: l, flushSync: d, viewTransitionOpts: _ }) => {
		l && r && Object.values(l).forEach((e) => r(e, {
			location: a.location,
			params: a.matches[0]?.params ?? {},
			pattern: be(a.matches)
		})), a.fetchers.forEach((e, t) => {
			e.data !== void 0 && y.current.set(t, e.data);
		}), s.forEach((e) => y.current.delete(e)), Zn(d === !1 || n != null, "You provided the `flushSync` option to a router update, but you are not using the `<RouterProvider>` from `react-router/dom` so `ReactDOM.flushSync()` is unavailable.  Please update your app to `import { RouterProvider } from \"react-router/dom\"` and ensure you have `react-dom` installed as a dependency to use the `flushSync` option.");
		let b = t.window != null && t.window.document != null && typeof t.window.document.startViewTransition == "function";
		if (Zn(_ == null || b, "You provided the `viewTransition` option to a router update, but you do not appear to be running in a DOM environment as `window.startViewTransition` is not available."), !_ || !b) {
			n && d ? n(() => o(a)) : i === !1 ? o(a) : e.startTransition(() => {
				i === !0 && c((e) => ar(e, a)), o(a);
			});
			return;
		}
		if (n && d) {
			n(() => {
				h && (p?.resolve(), h.skipTransition()), f({
					isTransitioning: !0,
					flushSync: !0,
					currentLocation: _.currentLocation,
					nextLocation: _.nextLocation
				});
			});
			let e = t.window.document.startViewTransition(() => {
				n(() => o(a));
			});
			e.finished.finally(() => {
				n(() => {
					m(void 0), g(void 0), u(void 0), f({ isTransitioning: !1 });
				});
			}), n(() => g(e));
			return;
		}
		h ? (p?.resolve(), h.skipTransition(), v({
			state: a,
			currentLocation: _.currentLocation,
			nextLocation: _.nextLocation
		})) : (u(a), f({
			isTransitioning: !0,
			flushSync: !1,
			currentLocation: _.currentLocation,
			nextLocation: _.nextLocation
		}));
	}, [
		t.window,
		n,
		h,
		p,
		i,
		c,
		r
	]);
	e.useLayoutEffect(() => t.subscribe(b), [t, b]);
	let x = s.initialized;
	e.useLayoutEffect(() => {
		!x && t.state.initialized && b(t.state, {
			deletedFetchers: [],
			flushSync: !1,
			newErrors: null
		});
	}, [
		x,
		b,
		t.state
	]), e.useEffect(() => {
		d.isTransitioning && !d.flushSync && m(new rr());
	}, [d]), e.useEffect(() => {
		if (p && l && t.window) {
			let n = l, r = p.promise, a = t.window.document.startViewTransition(async () => {
				i === !1 ? o(n) : e.startTransition(() => {
					i === !0 && c((e) => ar(e, n)), o(n);
				}), await r;
			});
			a.finished.finally(() => {
				m(void 0), g(void 0), u(void 0), f({ isTransitioning: !1 });
			}), g(a);
		}
	}, [
		l,
		p,
		t.window,
		i,
		c
	]), e.useEffect(() => {
		p && l && s.location.key === l.location.key && p.resolve();
	}, [
		p,
		h,
		s.location,
		l
	]), e.useEffect(() => {
		!d.isTransitioning && _ && (u(_.state), f({
			isTransitioning: !0,
			flushSync: !1,
			currentLocation: _.currentLocation,
			nextLocation: _.nextLocation
		}), v(void 0));
	}, [d.isTransitioning, _]);
	let S = e.useMemo(() => ({
		createHref: t.createHref,
		encodeLocation: t.encodeLocation,
		go: (e) => t.navigate(e),
		push: (e, n, r) => t.navigate(e, {
			state: n,
			preventScrollReset: r?.preventScrollReset
		}),
		replace: (e, n, r) => t.navigate(e, {
			replace: !0,
			state: n,
			preventScrollReset: r?.preventScrollReset
		})
	}), [t]), C = t.basename || "/", w = e.useMemo(() => ({
		router: t,
		navigator: S,
		static: !1,
		basename: C,
		onError: r
	}), [
		t,
		S,
		C,
		r
	]);
	return /* @__PURE__ */ e.createElement(e.Fragment, null, /* @__PURE__ */ e.createElement(on.Provider, { value: w }, /* @__PURE__ */ e.createElement(sn.Provider, { value: s }, /* @__PURE__ */ e.createElement(dn.Provider, { value: y.current }, /* @__PURE__ */ e.createElement(un.Provider, { value: d }, /* @__PURE__ */ e.createElement(ur, {
		basename: C,
		location: s.location,
		navigationType: s.historyAction,
		navigator: S,
		useTransitions: i
	}, /* @__PURE__ */ e.createElement(or, {
		routes: t.routes,
		manifest: t.manifest,
		future: t.future,
		state: s,
		isStatic: !1,
		onError: r
	})))))), null);
}
function ar(e, t) {
	return {
		...e,
		navigation: t.navigation.state === "idle" ? e.navigation : t.navigation,
		revalidation: t.revalidation === "idle" ? e.revalidation : t.revalidation,
		actionData: t.navigation.state === "submitting" ? e.actionData : t.actionData,
		fetchers: t.fetchers
	};
}
var or = e.memo(sr);
function sr({ routes: e, manifest: t, future: n, state: r, isStatic: i, onError: a }) {
	return An(e, void 0, {
		manifest: t,
		state: r,
		isStatic: i,
		onError: a,
		future: n
	});
}
function cr({ to: t, replace: n, state: r, relative: i }) {
	l(xn(), "<Navigate> may be used only in the context of a <Router> component.");
	let { static: a } = e.useContext(Z);
	u(!a, "<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");
	let { matches: o } = e.useContext(Q), { pathname: s } = $(), c = wn(), d = me(t, pe(o), s, i === "path"), f = JSON.stringify(d);
	return e.useEffect(() => {
		c(JSON.parse(f), {
			replace: n,
			state: r,
			relative: i
		});
	}, [
		c,
		f,
		i,
		n,
		r
	]), null;
}
function lr(e) {
	return Dn(e.context);
}
function ur({ basename: t = "/", children: n = null, location: r, navigationType: i = "POP", navigator: a, static: o = !1, useTransitions: s }) {
	l(!xn(), "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");
	let c = t.replace(/^\/*/, "/"), d = e.useMemo(() => ({
		basename: c,
		navigator: a,
		static: o,
		useTransitions: s,
		future: {}
	}), [
		c,
		a,
		o,
		s
	]);
	typeof r == "string" && (r = h(r));
	let { pathname: f = "/", search: p = "", hash: m = "", state: g = null, key: _ = "default", mask: v } = r, y = e.useMemo(() => {
		let e = R(f, c);
		return e == null ? null : {
			location: {
				pathname: e,
				search: p,
				hash: m,
				state: g,
				key: _,
				mask: v
			},
			navigationType: i
		};
	}, [
		c,
		f,
		p,
		m,
		g,
		_,
		i,
		v
	]);
	return u(y != null, `<Router basename="${c}"> is not able to match the URL "${f}${p}${m}" because it does not start with the basename, so the <Router> won't render anything.`), y == null ? null : /* @__PURE__ */ e.createElement(Z.Provider, { value: d }, /* @__PURE__ */ e.createElement(pn.Provider, {
		children: n,
		value: y
	}));
}
e.Component;
var dr = "get", fr = "application/x-www-form-urlencoded";
function pr(e) {
	return typeof HTMLElement < "u" && e instanceof HTMLElement;
}
function mr(e) {
	return pr(e) && e.tagName.toLowerCase() === "button";
}
function hr(e) {
	return pr(e) && e.tagName.toLowerCase() === "form";
}
function gr(e) {
	return pr(e) && e.tagName.toLowerCase() === "input";
}
function _r(e) {
	return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
}
function vr(e, t) {
	return e.button === 0 && (!t || t === "_self") && !_r(e);
}
function yr(e = "") {
	return new URLSearchParams(typeof e == "string" || Array.isArray(e) || e instanceof URLSearchParams ? e : Object.keys(e).reduce((t, n) => {
		let r = e[n];
		return t.concat(Array.isArray(r) ? r.map((e) => [n, e]) : [[n, r]]);
	}, []));
}
function br(e, t) {
	let n = yr(e);
	return t && t.forEach((e, r) => {
		n.has(r) || t.getAll(r).forEach((e) => {
			n.append(r, e);
		});
	}), n;
}
var xr = null;
function Sr() {
	if (xr === null) try {
		new FormData(document.createElement("form"), 0), xr = !1;
	} catch {
		xr = !0;
	}
	return xr;
}
var Cr = /* @__PURE__ */ new Set([
	"application/x-www-form-urlencoded",
	"multipart/form-data",
	"text/plain"
]);
function wr(e) {
	return e != null && !Cr.has(e) ? (u(!1, `"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${fr}"`), null) : e;
}
function Tr(e, t) {
	let n, r, i, a, o;
	if (hr(e)) {
		let o = e.getAttribute("action");
		r = o ? R(o, t) : null, n = e.getAttribute("method") || dr, i = wr(e.getAttribute("enctype")) || fr, a = new FormData(e);
	} else if (mr(e) || gr(e) && (e.type === "submit" || e.type === "image")) {
		let o = e.form;
		if (o == null) throw Error("Cannot submit a <button> or <input type=\"submit\"> without a <form>");
		let s = e.getAttribute("formaction") || o.getAttribute("action");
		if (r = s ? R(s, t) : null, n = e.getAttribute("formmethod") || o.getAttribute("method") || dr, i = wr(e.getAttribute("formenctype")) || wr(o.getAttribute("enctype")) || fr, a = new FormData(o, e), !Sr()) {
			let { name: t, type: n, value: r } = e;
			if (n === "image") {
				let e = t ? `${t}.` : "";
				a.append(`${e}x`, "0"), a.append(`${e}y`, "0");
			} else t && a.append(t, r);
		}
	} else if (pr(e)) throw Error("Cannot submit element that is not <form>, <button>, or <input type=\"submit|image\">");
	else n = dr, r = null, i = fr, o = e;
	return a && i === "text/plain" && (o = a, a = void 0), {
		action: r,
		method: n.toLowerCase(),
		encType: i,
		formData: a,
		body: o
	};
}
Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
var Er = {
	"&": "\\u0026",
	">": "\\u003e",
	"<": "\\u003c",
	"\u2028": "\\u2028",
	"\u2029": "\\u2029"
}, Dr = /[&><\u2028\u2029]/g;
function Or(e) {
	return e.replace(Dr, (e) => Er[e]);
}
function kr(e, t) {
	if (e === !1 || e == null) throw Error(t);
}
function Ar(e, t, n, r) {
	let i = typeof e == "string" ? new URL(e, typeof window > "u" ? "server://singlefetch/" : window.location.origin) : e;
	return n ? i.pathname.endsWith("/") ? i.pathname = `${i.pathname}_.${r}` : i.pathname = `${i.pathname}.${r}` : i.pathname === "/" ? i.pathname = `_root.${r}` : t && R(i.pathname, t) === "/" ? i.pathname = `${U(t)}/_root.${r}` : i.pathname = `${U(i.pathname)}.${r}`, i;
}
async function jr(e, t) {
	if (e.id in t) return t[e.id];
	try {
		let n = await import(
			/* @vite-ignore */
			/* webpackIgnore: true */
			e.module
);
		return t[e.id] = n, n;
	} catch (t) {
		return console.error(`Error loading route module \`${e.module}\`, reloading page...`), console.error(t), window.__reactRouterContext && window.__reactRouterContext.isSpaMode, window.location.reload(), new Promise(() => {});
	}
}
function Mr(e) {
	return e != null && typeof e.page == "string";
}
function Nr(e) {
	return e == null ? !1 : e.href == null ? e.rel === "preload" && typeof e.imageSrcSet == "string" && typeof e.imageSizes == "string" : typeof e.rel == "string" && typeof e.href == "string";
}
async function Pr(e, t, n) {
	return zr((await Promise.all(e.map(async (e) => {
		let r = t.routes[e.route.id];
		if (r) {
			let e = await jr(r, n);
			return e.links ? e.links() : [];
		}
		return [];
	}))).flat(1).filter(Nr).filter((e) => e.rel === "stylesheet" || e.rel === "preload").map((e) => e.rel === "stylesheet" ? {
		...e,
		rel: "prefetch",
		as: "style"
	} : {
		...e,
		rel: "prefetch"
	}));
}
function Fr(e, t, n, r, i, a) {
	let o = (e, t) => n[t] ? e.route.id !== n[t].route.id : !0, s = (e, t) => n[t].pathname !== e.pathname || n[t].route.path?.endsWith("*") && n[t].params["*"] !== e.params["*"];
	return a === "assets" ? t.filter((e, t) => o(e, t) || s(e, t)) : a === "data" ? t.filter((t, a) => {
		let c = r.routes[t.route.id];
		if (!c || !c.hasLoader) return !1;
		if (o(t, a) || s(t, a)) return !0;
		if (t.route.shouldRevalidate) {
			let r = t.route.shouldRevalidate({
				currentUrl: new URL(i.pathname + i.search + i.hash, window.origin),
				currentParams: n[0]?.params || {},
				nextUrl: new URL(e, window.origin),
				nextParams: t.params,
				defaultShouldRevalidate: !0
			});
			if (typeof r == "boolean") return r;
		}
		return !0;
	}) : [];
}
function Ir(e, t, { includeHydrateFallback: n } = {}) {
	return Lr(e.map((e) => {
		let r = t.routes[e.route.id];
		if (!r) return [];
		let i = [r.module];
		return r.clientActionModule && (i = i.concat(r.clientActionModule)), r.clientLoaderModule && (i = i.concat(r.clientLoaderModule)), n && r.hydrateFallbackModule && (i = i.concat(r.hydrateFallbackModule)), r.imports && (i = i.concat(r.imports)), i;
	}).flat(1));
}
function Lr(e) {
	return [...new Set(e)];
}
function Rr(e) {
	let t = {}, n = Object.keys(e).sort();
	for (let r of n) t[r] = e[r];
	return t;
}
function zr(e, t) {
	let n = /* @__PURE__ */ new Set(), r = new Set(t);
	return e.reduce((e, i) => {
		if (t && !Mr(i) && i.as === "script" && i.href && r.has(i.href)) return e;
		let a = JSON.stringify(Rr(i));
		return n.has(a) || (n.add(a), e.push({
			key: a,
			link: i
		})), e;
	}, []);
}
function Br() {
	let t = e.useContext(on);
	return kr(t, "You must render this element inside a <DataRouterContext.Provider> element"), t;
}
function Vr() {
	let t = e.useContext(sn);
	return kr(t, "You must render this element inside a <DataRouterStateContext.Provider> element"), t;
}
var Hr = e.createContext(void 0);
Hr.displayName = "FrameworkContext";
function Ur() {
	let t = e.useContext(Hr);
	return kr(t, "You must render this element inside a <HydratedRouter> element"), t;
}
function Wr(t, n) {
	let r = e.useContext(Hr), [i, a] = e.useState(!1), [o, s] = e.useState(!1), { onFocus: c, onBlur: l, onMouseEnter: u, onMouseLeave: d, onTouchStart: f } = n, p = e.useRef(null);
	e.useEffect(() => {
		if (t === "render" && s(!0), t === "viewport") {
			let e = new IntersectionObserver((e) => {
				e.forEach((e) => {
					s(e.isIntersecting);
				});
			}, { threshold: .5 });
			return p.current && e.observe(p.current), () => {
				e.disconnect();
			};
		}
	}, [t]), e.useEffect(() => {
		if (i) {
			let e = setTimeout(() => {
				s(!0);
			}, 100);
			return () => {
				clearTimeout(e);
			};
		}
	}, [i]);
	let m = () => {
		a(!0);
	}, h = () => {
		a(!1), s(!1);
	};
	return r ? t === "intent" ? [
		o,
		p,
		{
			onFocus: Gr(c, m),
			onBlur: Gr(l, h),
			onMouseEnter: Gr(u, m),
			onMouseLeave: Gr(d, h),
			onTouchStart: Gr(f, m)
		}
	] : [
		o,
		p,
		{}
	] : [
		!1,
		p,
		{}
	];
}
function Gr(e, t) {
	return (n) => {
		e && e(n), n.defaultPrevented || t(n);
	};
}
function Kr({ page: t, ...n }) {
	let r = ln(), { router: i } = Br(), a = e.useMemo(() => D(i.routes, t, i.basename), [
		i.routes,
		t,
		i.basename
	]);
	return a ? r ? /* @__PURE__ */ e.createElement(Jr, {
		page: t,
		matches: a,
		...n
	}) : /* @__PURE__ */ e.createElement(Yr, {
		page: t,
		matches: a,
		...n
	}) : null;
}
function qr(t) {
	let { manifest: n, routeModules: r } = Ur(), [i, a] = e.useState([]);
	return e.useEffect(() => {
		let e = !1;
		return Pr(t, n, r).then((t) => {
			e || a(t);
		}), () => {
			e = !0;
		};
	}, [
		t,
		n,
		r
	]), i;
}
function Jr({ page: t, matches: n, ...r }) {
	let i = $(), { future: a } = Ur(), { basename: o } = Br(), s = e.useMemo(() => {
		if (t === i.pathname + i.search + i.hash) return [];
		let e = Ar(t, o, a.unstable_trailingSlashAwareDataRequests, "rsc"), r = !1, s = [];
		for (let e of n) typeof e.route.shouldRevalidate == "function" ? r = !0 : s.push(e.route.id);
		return r && s.length > 0 && e.searchParams.set("_routes", s.join(",")), [e.pathname + e.search];
	}, [
		o,
		a.unstable_trailingSlashAwareDataRequests,
		t,
		i,
		n
	]);
	return /* @__PURE__ */ e.createElement(e.Fragment, null, s.map((t) => /* @__PURE__ */ e.createElement("link", {
		key: t,
		rel: "prefetch",
		as: "fetch",
		href: t,
		...r
	})));
}
function Yr({ page: t, matches: n, ...r }) {
	let i = $(), { future: a, manifest: o, routeModules: s } = Ur(), { basename: c } = Br(), { loaderData: l, matches: u } = Vr(), d = e.useMemo(() => Fr(t, n, u, o, i, "data"), [
		t,
		n,
		u,
		o,
		i
	]), f = e.useMemo(() => Fr(t, n, u, o, i, "assets"), [
		t,
		n,
		u,
		o,
		i
	]), p = e.useMemo(() => {
		if (t === i.pathname + i.search + i.hash) return [];
		let e = /* @__PURE__ */ new Set(), r = !1;
		if (n.forEach((t) => {
			let n = o.routes[t.route.id];
			!n || !n.hasLoader || (!d.some((e) => e.route.id === t.route.id) && t.route.id in l && s[t.route.id]?.shouldRevalidate || n.hasClientLoader ? r = !0 : e.add(t.route.id));
		}), e.size === 0) return [];
		let u = Ar(t, c, a.unstable_trailingSlashAwareDataRequests, "data");
		return r && e.size > 0 && u.searchParams.set("_routes", n.filter((t) => e.has(t.route.id)).map((e) => e.route.id).join(",")), [u.pathname + u.search];
	}, [
		c,
		a.unstable_trailingSlashAwareDataRequests,
		l,
		i,
		o,
		d,
		n,
		t,
		s
	]), m = e.useMemo(() => Ir(f, o), [f, o]), h = qr(f);
	return /* @__PURE__ */ e.createElement(e.Fragment, null, p.map((t) => /* @__PURE__ */ e.createElement("link", {
		key: t,
		rel: "prefetch",
		as: "fetch",
		href: t,
		...r
	})), m.map((t) => /* @__PURE__ */ e.createElement("link", {
		key: t,
		rel: "modulepreload",
		href: t,
		...r
	})), h.map(({ key: t, link: n }) => /* @__PURE__ */ e.createElement("link", {
		key: t,
		nonce: r.nonce,
		...n,
		crossOrigin: n.crossOrigin ?? r.crossOrigin
	})));
}
function Xr(...e) {
	return (t) => {
		e.forEach((e) => {
			typeof e == "function" ? e(t) : e != null && (e.current = t);
		});
	};
}
e.Component;
var Zr = typeof window < "u" && window.document !== void 0 && window.document.createElement !== void 0;
try {
	Zr && (window.__reactRouterVersion = "7.15.0");
} catch {}
function Qr(e, t) {
	return Je({
		basename: t?.basename,
		getContext: t?.getContext,
		future: t?.future,
		history: c({ window: t?.window }),
		hydrationData: t?.hydrationData || $r(),
		routes: e,
		mapRouteProperties: tr,
		hydrationRouteProperties: nr,
		dataStrategy: t?.dataStrategy,
		patchRoutesOnNavigation: t?.patchRoutesOnNavigation,
		window: t?.window,
		instrumentations: t?.instrumentations
	}).initialize();
}
function $r() {
	let e = window?.__staticRouterHydrationData;
	return e && e.errors && (e = {
		...e,
		errors: ei(e.errors)
	}), e;
}
function ei(e) {
	if (!e) return null;
	let t = Object.entries(e), n = {};
	for (let [e, r] of t) if (r && r.__type === "RouteErrorResponse") n[e] = new W(r.status, r.statusText, r.data, r.internal === !0);
	else if (r && r.__type === "Error") {
		if (r.__subType) {
			let t = window[r.__subType];
			if (typeof t == "function") try {
				let i = new t(r.message);
				i.stack = "", n[e] = i;
			} catch {}
		}
		if (n[e] == null) {
			let t = Error(r.message);
			t.stack = "", n[e] = t;
		}
	} else n[e] = r;
	return n;
}
function ti({ basename: t, children: n, history: r, useTransitions: i }) {
	let [a, o] = e.useState({
		action: r.action,
		location: r.location
	}), s = e.useCallback((t) => {
		i === !1 ? o(t) : e.startTransition(() => o(t));
	}, [i]);
	return e.useLayoutEffect(() => r.listen(s), [r, s]), /* @__PURE__ */ e.createElement(ur, {
		basename: t,
		children: n,
		location: a.location,
		navigationType: a.action,
		navigator: r,
		useTransitions: i
	});
}
ti.displayName = "unstable_HistoryRouter";
var ni = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i, ri = e.forwardRef(function({ onClick: t, discover: n = "render", prefetch: r = "none", relative: i, reloadDocument: a, replace: o, mask: s, state: c, target: l, to: u, preventScrollReset: d, viewTransition: f, defaultShouldRevalidate: p, ...m }, h) {
	let { basename: g, navigator: _, useTransitions: v } = e.useContext(Z), y = typeof u == "string" && ni.test(u), b = Se(u, g);
	u = b.to;
	let x = bn(u, { relative: i }), S = $(), C = null;
	if (s) {
		let e = me(s, [], S.mask ? S.mask.pathname : "/", !0);
		g !== "/" && (e.pathname = e.pathname === "/" ? g : H([g, e.pathname])), C = _.createHref(e);
	}
	let [w, T, E] = Wr(r, m), D = ui(u, {
		replace: o,
		mask: s,
		state: c,
		target: l,
		preventScrollReset: d,
		relative: i,
		viewTransition: f,
		defaultShouldRevalidate: p,
		useTransitions: v
	});
	function O(e) {
		t && t(e), e.defaultPrevented || D(e);
	}
	let k = !(b.isExternal || a), A = /* @__PURE__ */ e.createElement("a", {
		...m,
		...E,
		href: (k ? C : void 0) || b.absoluteURL || x,
		onClick: k ? O : t,
		ref: Xr(h, T),
		target: l,
		"data-discover": !y && n === "render" ? "true" : void 0
	});
	return w && !y ? /* @__PURE__ */ e.createElement(e.Fragment, null, A, /* @__PURE__ */ e.createElement(Kr, { page: x })) : A;
});
ri.displayName = "Link";
var ii = e.forwardRef(function({ "aria-current": t = "page", caseSensitive: n = !1, className: r = "", end: i = !1, style: a, to: o, viewTransition: s, children: c, ...l }, u) {
	let d = kn(o, { relative: l.relative }), f = $(), p = e.useContext(sn), { navigator: m, basename: h } = e.useContext(Z), g = p != null && xi(d) && s === !0, _ = m.encodeLocation ? m.encodeLocation(d).pathname : d.pathname, v = f.pathname, y = p && p.navigation && p.navigation.location ? p.navigation.location.pathname : null;
	n || (v = v.toLowerCase(), y = y ? y.toLowerCase() : null, _ = _.toLowerCase()), y && h && (y = R(y, h) || y);
	let b = _ !== "/" && _.endsWith("/") ? _.length - 1 : _.length, x = v === _ || !i && v.startsWith(_) && v.charAt(b) === "/", S = y != null && (y === _ || !i && y.startsWith(_) && y.charAt(_.length) === "/"), C = {
		isActive: x,
		isPending: S,
		isTransitioning: g
	}, w = x ? t : void 0, T;
	T = typeof r == "function" ? r(C) : [
		r,
		x ? "active" : null,
		S ? "pending" : null,
		g ? "transitioning" : null
	].filter(Boolean).join(" ");
	let E = typeof a == "function" ? a(C) : a;
	return /* @__PURE__ */ e.createElement(ri, {
		...l,
		"aria-current": w,
		className: T,
		ref: u,
		style: E,
		to: o,
		viewTransition: s
	}, typeof c == "function" ? c(C) : c);
});
ii.displayName = "NavLink";
var ai = e.forwardRef(({ discover: t = "render", fetcherKey: n, navigate: r, reloadDocument: i, replace: a, state: o, method: s = dr, action: c, onSubmit: l, relative: u, preventScrollReset: d, viewTransition: f, defaultShouldRevalidate: p, ...m }, h) => {
	let { useTransitions: g } = e.useContext(Z), _ = mi(), v = hi(c, { relative: u }), y = s.toLowerCase() === "get" ? "get" : "post", b = typeof c == "string" && ni.test(c);
	return /* @__PURE__ */ e.createElement("form", {
		ref: h,
		method: y,
		action: v,
		onSubmit: i ? l : (t) => {
			if (l && l(t), t.defaultPrevented) return;
			t.preventDefault();
			let i = t.nativeEvent.submitter, c = i?.getAttribute("formmethod") || s, m = () => _(i || t.currentTarget, {
				fetcherKey: n,
				method: c,
				navigate: r,
				replace: a,
				state: o,
				relative: u,
				preventScrollReset: d,
				viewTransition: f,
				defaultShouldRevalidate: p
			});
			g && r !== !1 ? e.startTransition(() => m()) : m();
		},
		...m,
		"data-discover": !b && t === "render" ? "true" : void 0
	});
});
ai.displayName = "Form";
function oi({ getKey: t, storageKey: n, ...r }) {
	let i = e.useContext(Hr), { basename: a } = e.useContext(Z), o = $(), s = Gn();
	yi({
		getKey: t,
		storageKey: n
	});
	let c = e.useMemo(() => {
		if (!i || !t) return null;
		let e = vi(o, s, a, t);
		return e === o.key ? null : e;
	}, []);
	if (!i || i.isSpaMode) return null;
	let l = ((e, t) => {
		if (!window.history.state || !window.history.state.key) {
			let e = Math.random().toString(32).slice(2);
			window.history.replaceState({ key: e }, "");
		}
		try {
			let n = JSON.parse(sessionStorage.getItem(e) || "{}")[t || window.history.state.key];
			typeof n == "number" && window.scrollTo(0, n);
		} catch (t) {
			console.error(t), sessionStorage.removeItem(e);
		}
	}).toString();
	return /* @__PURE__ */ e.createElement("script", {
		...r,
		suppressHydrationWarning: !0,
		dangerouslySetInnerHTML: { __html: `(${l})(${Or(JSON.stringify(n || gi))}, ${Or(JSON.stringify(c))})` }
	});
}
oi.displayName = "ScrollRestoration";
function si(e) {
	return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`;
}
function ci(t) {
	let n = e.useContext(on);
	return l(n, si(t)), n;
}
function li(t) {
	let n = e.useContext(sn);
	return l(n, si(t)), n;
}
function ui(t, { target: n, replace: r, mask: i, state: a, preventScrollReset: o, relative: s, viewTransition: c, defaultShouldRevalidate: l, useTransitions: u } = {}) {
	let d = wn(), f = $(), p = kn(t, { relative: s });
	return e.useCallback((h) => {
		if (vr(h, n)) {
			h.preventDefault();
			let n = r === void 0 ? m(f) === m(p) : r, g = () => d(t, {
				replace: n,
				mask: i,
				state: a,
				preventScrollReset: o,
				relative: s,
				viewTransition: c,
				defaultShouldRevalidate: l
			});
			u ? e.startTransition(() => g()) : g();
		}
	}, [
		f,
		d,
		p,
		r,
		i,
		a,
		n,
		t,
		o,
		s,
		c,
		l,
		u
	]);
}
function di(t) {
	u(typeof URLSearchParams < "u", "You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.");
	let n = e.useRef(yr(t)), r = e.useRef(!1), i = $(), a = e.useMemo(() => br(i.search, r.current ? null : n.current), [i.search]), o = wn();
	return [a, e.useCallback((e, t) => {
		let n = yr(typeof e == "function" ? e(new URLSearchParams(a)) : e);
		r.current = !0, o("?" + n, t);
	}, [o, a])];
}
var fi = 0, pi = () => `__${String(++fi)}__`;
function mi() {
	let { router: t } = ci("useSubmit"), { basename: n } = e.useContext(Z), r = Un(), i = t.fetch, a = t.navigate;
	return e.useCallback(async (e, t = {}) => {
		let { action: o, method: s, encType: c, formData: l, body: u } = Tr(e, n);
		t.navigate === !1 ? await i(t.fetcherKey || pi(), r, t.action || o, {
			defaultShouldRevalidate: t.defaultShouldRevalidate,
			preventScrollReset: t.preventScrollReset,
			formData: l,
			body: u,
			formMethod: t.method || s,
			formEncType: t.encType || c,
			flushSync: t.flushSync
		}) : await a(t.action || o, {
			defaultShouldRevalidate: t.defaultShouldRevalidate,
			preventScrollReset: t.preventScrollReset,
			formData: l,
			body: u,
			formMethod: t.method || s,
			formEncType: t.encType || c,
			replace: t.replace,
			state: t.state,
			fromRouteId: r,
			flushSync: t.flushSync,
			viewTransition: t.viewTransition
		});
	}, [
		i,
		a,
		n,
		r
	]);
}
function hi(t, { relative: n } = {}) {
	let { basename: r } = e.useContext(Z), i = e.useContext(Q);
	l(i, "useFormAction must be used inside a RouteContext");
	let [a] = i.matches.slice(-1), o = { ...kn(t || ".", { relative: n }) }, s = $();
	if (t == null) {
		o.search = s.search;
		let e = new URLSearchParams(o.search), t = e.getAll("index");
		if (t.some((e) => e === "")) {
			e.delete("index"), t.filter((e) => e).forEach((t) => e.append("index", t));
			let n = e.toString();
			o.search = n ? `?${n}` : "";
		}
	}
	return (!t || t === ".") && a.route.index && (o.search = o.search ? o.search.replace(/^\?/, "?index&") : "?index"), r !== "/" && (o.pathname = o.pathname === "/" ? r : H([r, o.pathname])), m(o);
}
var gi = "react-router-scroll-positions", _i = {};
function vi(e, t, n, r) {
	let i = null;
	return r && (i = r(n === "/" ? e : {
		...e,
		pathname: R(e.pathname, n) || e.pathname
	}, t)), i ??= e.key, i;
}
function yi({ getKey: t, storageKey: n } = {}) {
	let { router: r } = ci("useScrollRestoration"), { restoreScrollPosition: i, preventScrollReset: a } = li("useScrollRestoration"), { basename: o } = e.useContext(Z), s = $(), c = Gn(), l = Wn();
	e.useEffect(() => (window.history.scrollRestoration = "manual", () => {
		window.history.scrollRestoration = "auto";
	}), []), bi(e.useCallback(() => {
		if (l.state === "idle") {
			let e = vi(s, c, o, t);
			_i[e] = window.scrollY;
		}
		try {
			sessionStorage.setItem(n || gi, JSON.stringify(_i));
		} catch (e) {
			u(!1, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${e}).`);
		}
		window.history.scrollRestoration = "auto";
	}, [
		l.state,
		t,
		o,
		s,
		c,
		n
	])), typeof document < "u" && (e.useLayoutEffect(() => {
		try {
			let e = sessionStorage.getItem(n || gi);
			e && (_i = JSON.parse(e));
		} catch {}
	}, [n]), e.useLayoutEffect(() => {
		let e = r?.enableScrollRestoration(_i, () => window.scrollY, t ? (e, n) => vi(e, n, o, t) : void 0);
		return () => e && e();
	}, [
		r,
		o,
		t
	]), e.useLayoutEffect(() => {
		if (i !== !1) {
			if (typeof i == "number") {
				window.scrollTo(0, i);
				return;
			}
			try {
				if (s.hash) {
					let e = document.getElementById(decodeURIComponent(s.hash.slice(1)));
					if (e) {
						e.scrollIntoView();
						return;
					}
				}
			} catch {
				u(!1, `"${s.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`);
			}
			a !== !0 && window.scrollTo(0, 0);
		}
	}, [
		s,
		i,
		a
	]));
}
function bi(t, n) {
	let { capture: r } = n || {};
	e.useEffect(() => {
		let e = r == null ? void 0 : { capture: r };
		return window.addEventListener("pagehide", t, e), () => {
			window.removeEventListener("pagehide", t, e);
		};
	}, [t, r]);
}
function xi(t, { relative: n } = {}) {
	let r = e.useContext(un);
	l(r != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
	let { basename: i } = ci("useViewTransitionState"), a = kn(t, { relative: n });
	if (!r.isTransitioning) return !1;
	let o = R(r.currentLocation.pathname, i) || r.currentLocation.pathname, s = R(r.nextLocation.pathname, i) || r.nextLocation.pathname;
	return oe(a.pathname, s) != null || oe(a.pathname, o) != null;
}
//#endregion
export { Qr as a, wn as c, di as d, ir as i, On as l, cr as n, ye as o, lr as r, $ as s, ri as t, Kn as u };
