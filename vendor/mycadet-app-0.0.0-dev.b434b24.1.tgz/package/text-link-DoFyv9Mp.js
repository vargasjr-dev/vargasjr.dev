import { t as e } from "./dist-CB0DYkRa.js";
import "react/jsx-runtime";
//#region ../../packages/design-library/src/components/text-link.tsx
var t = e(["cursor-pointer rounded-sm underline outline-none transition-colors", "keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0"].join(" "), {
	variants: { tone: {
		default: "text-[color:var(--content-link)] hover:text-[color:var(--content-link-hover)]",
		quiet: "text-[color:inherit] hover:text-[color:var(--content-default)]"
	} },
	defaultVariants: { tone: "default" }
});
//#endregion
export { t };
