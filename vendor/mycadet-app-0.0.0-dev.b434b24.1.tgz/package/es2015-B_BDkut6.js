import { o as e, t } from "./dist-CB0DYkRa.js";
import { t as n } from "./typography-DAhYh88V.js";
import * as r from "react";
import { useId as i, useState as a } from "react";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region ../../packages/design-library/src/components/field.tsx
function c(e, t, n) {
	return t ? `${e}-error` : n ? `${e}-helper` : void 0;
}
function l({ id: t, label: r, helperText: i, errorText: a, fullWidth: l, disabled: u, className: d, children: f }) {
	let p = c(t, !!a, !!i);
	return /* @__PURE__ */ s("div", {
		"data-slot": "field-wrapper",
		className: e("flex flex-col gap-1", l ? "w-full" : "w-fit", d),
		children: [
			r ? /* @__PURE__ */ o(n, {
				as: "label",
				id: `${t}-label`,
				variant: "label-medium-default",
				htmlFor: t,
				className: e("text-[var(--content-secondary)]", u && "opacity-60"),
				children: r
			}) : null,
			f,
			a ? /* @__PURE__ */ o("span", {
				id: p,
				role: "alert",
				"data-testid": "field-error",
				className: "text-body-small-default text-[var(--system-negative-strong)]",
				children: a
			}) : i ? /* @__PURE__ */ o("span", {
				id: p,
				className: "text-body-small-default text-[var(--content-tertiary)]",
				children: i
			}) : null
		]
	});
}
//#endregion
//#region ../../packages/design-library/src/components/input.tsx
var u = t([
	"block w-full rounded-md border bg-[var(--field-bg)]",
	"text-body-medium-lighter text-[var(--content-default)]",
	"placeholder:text-[var(--content-tertiary)]",
	"transition-[border-color,background-color] duration-150 ease-out",
	"outline-none",
	"disabled:cursor-not-allowed disabled:opacity-60"
].join(" "), {
	variants: {
		invalid: {
			true: ["border-[var(--system-negative-strong)]", "focus-visible:border-[var(--system-negative-strong)]"].join(" "),
			false: ["border-[var(--field-border)]", "focus-visible:border-[var(--border-active)]"].join(" ")
		},
		density: {
			input: "h-8 px-2 py-1.5",
			textarea: "min-h-[72px] px-3 py-2 resize-y"
		},
		hasLeftIcon: {
			true: "",
			false: ""
		},
		hasRightIcon: {
			true: "",
			false: ""
		}
	},
	compoundVariants: [{
		density: "input",
		hasLeftIcon: !0,
		class: "pl-8"
	}, {
		density: "input",
		hasRightIcon: !0,
		class: "pr-8"
	}],
	defaultVariants: {
		invalid: !1,
		density: "input",
		hasLeftIcon: !1,
		hasRightIcon: !1
	}
});
function d({ label: t, helperText: n, errorText: r, leftIcon: a, rightIcon: c, fullWidth: d = !1, wrapperClassName: f, className: p, id: m, disabled: h, ref: g, "aria-invalid": _, "aria-describedby": v, ...y }) {
	let b = i(), x = m ?? `input-${b}`, S = r != null || _ === !0, C = r ? `${x}-error` : n ? `${x}-helper` : void 0;
	return /* @__PURE__ */ o(l, {
		id: x,
		label: t,
		helperText: n,
		errorText: r,
		fullWidth: d,
		disabled: h === !0,
		className: f,
		children: /* @__PURE__ */ s("div", {
			className: "relative flex items-center",
			children: [
				a ? /* @__PURE__ */ o("span", {
					"aria-hidden": !0,
					"data-testid": "input-left-icon",
					className: "pointer-events-none absolute left-2 flex items-center text-[var(--content-tertiary)]",
					children: a
				}) : null,
				/* @__PURE__ */ o("input", {
					...y,
					ref: g,
					id: x,
					disabled: h,
					"aria-invalid": S || void 0,
					"aria-describedby": v ?? C,
					"data-slot": "input",
					className: e(u({
						invalid: S,
						density: "input",
						hasLeftIcon: a != null,
						hasRightIcon: c != null
					}), "[&[type=number]]:[appearance:textfield]", "[&[type=number]::-webkit-outer-spin-button]:[appearance:none]", "[&[type=number]::-webkit-inner-spin-button]:[appearance:none]", "[&[type=number]::-webkit-inner-spin-button]:m-0", p)
				}),
				c ? /* @__PURE__ */ o("span", {
					"aria-hidden": !0,
					"data-testid": "input-right-icon",
					className: "pointer-events-none absolute right-2 flex items-center text-[var(--content-tertiary)]",
					children: c
				}) : null
			]
		})
	});
}
//#endregion
//#region ../../node_modules/.bun/tslib@2.9.1/node_modules/tslib/tslib.es6.mjs
var f = function() {
	return f = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, f.apply(this, arguments);
};
function p(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function m(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
//#endregion
//#region ../../node_modules/.bun/react-remove-scroll-bar@2.3.8+bf264c7668a20073/node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var h = "right-scroll-bar-position", g = "width-before-scroll-bar", _ = "with-scroll-bars-hidden", v = "--removed-body-scroll-bar-size";
//#endregion
//#region ../../node_modules/.bun/use-callback-ref@1.3.3+bf264c7668a20073/node_modules/use-callback-ref/dist/es2015/assignRef.js
function y(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
//#endregion
//#region ../../node_modules/.bun/use-callback-ref@1.3.3+bf264c7668a20073/node_modules/use-callback-ref/dist/es2015/useRef.js
function b(e, t) {
	var n = a(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
//#endregion
//#region ../../node_modules/.bun/use-callback-ref@1.3.3+bf264c7668a20073/node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var x = typeof window < "u" ? r.useLayoutEffect : r.useEffect, S = /* @__PURE__ */ new WeakMap();
function C(e, t) {
	var n = b(t || null, function(t) {
		return e.forEach(function(e) {
			return y(e, t);
		});
	});
	return x(function() {
		var t = S.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || y(e, null);
			}), i.forEach(function(e) {
				r.has(e) || y(e, a);
			});
		}
		S.set(n, e);
	}, [e]), n;
}
//#endregion
//#region ../../node_modules/.bun/use-sidecar@1.1.3+bf264c7668a20073/node_modules/use-sidecar/dist/es2015/medium.js
function w(e) {
	return e;
}
function T(e, t) {
	t === void 0 && (t = w);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function E(e) {
	e === void 0 && (e = {});
	var t = T(null);
	return t.options = f({
		async: !0,
		ssr: !1
	}, e), t;
}
//#endregion
//#region ../../node_modules/.bun/use-sidecar@1.1.3+bf264c7668a20073/node_modules/use-sidecar/dist/es2015/exports.js
var D = function(e) {
	var t = e.sideCar, n = p(e, ["sideCar"]);
	if (!t) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var i = t.read();
	if (!i) throw Error("Sidecar medium not found");
	return r.createElement(i, f({}, n));
};
D.isSideCarExport = !0;
function ee(e, t) {
	return e.useMedium(t), D;
}
//#endregion
//#region ../../node_modules/.bun/react-remove-scroll@2.7.2+bf264c7668a20073/node_modules/react-remove-scroll/dist/es2015/medium.js
var O = E(), k = function() {}, A = r.forwardRef(function(e, t) {
	var n = r.useRef(null), i = r.useState({
		onScrollCapture: k,
		onWheelCapture: k,
		onTouchMoveCapture: k
	}), a = i[0], o = i[1], s = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, d = e.enabled, m = e.shards, h = e.sideCar, g = e.noRelative, _ = e.noIsolation, v = e.inert, y = e.allowPinchZoom, b = e.as, x = b === void 0 ? "div" : b, S = e.gapMode, w = p(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), T = h, E = C([n, t]), D = f(f({}, w), a);
	return r.createElement(r.Fragment, null, d && r.createElement(T, {
		sideCar: O,
		removeScrollBar: u,
		shards: m,
		noRelative: g,
		noIsolation: _,
		inert: v,
		setCallbacks: o,
		allowPinchZoom: !!y,
		lockRef: n,
		gapMode: S
	}), s ? r.cloneElement(r.Children.only(c), f(f({}, D), { ref: E })) : r.createElement(x, f({}, D, {
		className: l,
		ref: E
	}), c));
});
A.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, A.classNames = {
	fullWidth: g,
	zeroRight: h
};
//#endregion
//#region ../../node_modules/.bun/get-nonce@1.0.1/node_modules/get-nonce/dist/es2015/index.js
var j, te = function() {
	if (j) return j;
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
//#endregion
//#region ../../node_modules/.bun/react-style-singleton@2.2.3+bf264c7668a20073/node_modules/react-style-singleton/dist/es2015/singleton.js
function ne() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = te();
	return t && e.setAttribute("nonce", t), e;
}
function re(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function ie(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var ae = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = ne()) && (re(t, n), ie(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, oe = function() {
	var e = ae();
	return function(t, n) {
		r.useEffect(function() {
			return e.add(t), function() {
				e.remove();
			};
		}, [t && n]);
	};
}, M = function() {
	var e = oe();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, N = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, P = function(e) {
	return parseInt(e || "", 10) || 0;
}, se = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		P(n),
		P(r),
		P(i)
	];
}, ce = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return N;
	var t = se(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, le = M(), F = "data-scroll-locked", ue = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${_} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${F}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${h} {
    right: ${s}px ${r};
  }
  
  .${g} {
    margin-right: ${s}px ${r};
  }
  
  .${h} .${h} {
    right: 0 ${r};
  }
  
  .${g} .${g} {
    margin-right: 0 ${r};
  }
  
  body[${F}] {
    ${v}: ${s}px;
  }
`;
}, I = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, de = function() {
	r.useEffect(function() {
		return document.body.setAttribute(F, (I() + 1).toString()), function() {
			var e = I() - 1;
			e <= 0 ? document.body.removeAttribute(F) : document.body.setAttribute(F, e.toString());
		};
	}, []);
}, fe = function(e) {
	var t = e.noRelative, n = e.noImportant, i = e.gapMode, a = i === void 0 ? "margin" : i;
	de();
	var o = r.useMemo(function() {
		return ce(a);
	}, [a]);
	return r.createElement(le, { styles: ue(o, !t, a, n ? "" : "!important") });
}, L = !1;
if (typeof window < "u") try {
	var R = Object.defineProperty({}, "passive", { get: function() {
		return L = !0, !0;
	} });
	window.addEventListener("test", R, R), window.removeEventListener("test", R, R);
} catch {
	L = !1;
}
var z = L ? { passive: !1 } : !1, pe = function(e) {
	return e.tagName === "TEXTAREA";
}, B = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !pe(e) && n[t] === "visible");
}, me = function(e) {
	return B(e, "overflowY");
}, he = function(e) {
	return B(e, "overflowX");
}, V = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), H(e, r)) {
			var i = U(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, ge = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, _e = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, H = function(e, t) {
	return e === "v" ? me(t) : he(t);
}, U = function(e, t) {
	return e === "v" ? ge(t) : _e(t);
}, ve = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, ye = function(e, t, n, r, i) {
	var a = ve(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = U(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && H(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, W = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, G = function(e) {
	return [e.deltaX, e.deltaY];
}, K = function(e) {
	return e && "current" in e ? e.current : e;
}, be = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, xe = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, Se = 0, q = [];
function Ce(e) {
	var t = r.useRef([]), n = r.useRef([0, 0]), i = r.useRef(), a = r.useState(Se++)[0], o = r.useState(M)[0], s = r.useRef(e);
	r.useEffect(function() {
		s.current = e;
	}, [e]), r.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${a}`);
			var t = m([e.lockRef.current], (e.shards || []).map(K), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${a}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${a}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${a}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var c = r.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !s.current.allowPinchZoom;
		var r = W(e), a = n.current, o = "deltaX" in e ? e.deltaX : a[0] - r[0], c = "deltaY" in e ? e.deltaY : a[1] - r[1], l, u = e.target, d = Math.abs(o) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = V(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = V(d, u)), !m) return !1;
		if (!i.current && "changedTouches" in e && (o || c) && (i.current = l), !l) return !0;
		var h = i.current || l;
		return ye(h, t, e, h === "h" ? o : c, !0);
	}, []), l = r.useCallback(function(e) {
		var n = e;
		if (!(!q.length || q[q.length - 1] !== o)) {
			var r = "deltaY" in n ? G(n) : W(n), i = t.current.filter(function(e) {
				return e.name === n.type && (e.target === n.target || n.target === e.shadowParent) && be(e.delta, r);
			})[0];
			if (i && i.should) {
				n.cancelable && n.preventDefault();
				return;
			}
			if (!i) {
				var a = (s.current.shards || []).map(K).filter(Boolean).filter(function(e) {
					return e.contains(n.target);
				});
				(a.length > 0 ? c(n, a[0]) : !s.current.noIsolation) && n.cancelable && n.preventDefault();
			}
		}
	}, []), u = r.useCallback(function(e, n, r, i) {
		var a = {
			name: e,
			delta: n,
			target: r,
			should: i,
			shadowParent: we(r)
		};
		t.current.push(a), setTimeout(function() {
			t.current = t.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), d = r.useCallback(function(e) {
		n.current = W(e), i.current = void 0;
	}, []), f = r.useCallback(function(t) {
		u(t.type, G(t), t.target, c(t, e.lockRef.current));
	}, []), p = r.useCallback(function(t) {
		u(t.type, W(t), t.target, c(t, e.lockRef.current));
	}, []);
	r.useEffect(function() {
		return q.push(o), e.setCallbacks({
			onScrollCapture: f,
			onWheelCapture: f,
			onTouchMoveCapture: p
		}), document.addEventListener("wheel", l, z), document.addEventListener("touchmove", l, z), document.addEventListener("touchstart", d, z), function() {
			q = q.filter(function(e) {
				return e !== o;
			}), document.removeEventListener("wheel", l, z), document.removeEventListener("touchmove", l, z), document.removeEventListener("touchstart", d, z);
		};
	}, []);
	var h = e.removeScrollBar, g = e.inert;
	return r.createElement(r.Fragment, null, g ? r.createElement(o, { styles: xe(a) }) : null, h ? r.createElement(fe, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function we(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
//#endregion
//#region ../../node_modules/.bun/react-remove-scroll@2.7.2+bf264c7668a20073/node_modules/react-remove-scroll/dist/es2015/sidecar.js
var Te = ee(O, Ce), J = r.forwardRef(function(e, t) {
	return r.createElement(A, f({}, e, {
		ref: t,
		sideCar: Te
	}));
});
J.classNames = A.classNames;
//#endregion
//#region ../../node_modules/.bun/aria-hidden@1.2.6/node_modules/aria-hidden/dist/es2015/index.js
var Ee = function(e) {
	return typeof document > "u" ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body;
}, Y = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), Z = {}, Q = 0, $ = function(e) {
	return e && (e.host || $(e.parentNode));
}, De = function(e, t) {
	return t.map(function(t) {
		if (e.contains(t)) return t;
		var n = $(t);
		return n && e.contains(n) ? n : (console.error("aria-hidden", t, "in not contained inside", e, ". Doing nothing"), null);
	}).filter(function(e) {
		return !!e;
	});
}, Oe = function(e, t, n, r) {
	var i = De(t, Array.isArray(e) ? e : [e]);
	Z[n] || (Z[n] = /* @__PURE__ */ new WeakMap());
	var a = Z[n], o = [], s = /* @__PURE__ */ new Set(), c = new Set(i), l = function(e) {
		!e || s.has(e) || (s.add(e), l(e.parentNode));
	};
	i.forEach(l);
	var u = function(e) {
		!e || c.has(e) || Array.prototype.forEach.call(e.children, function(e) {
			if (s.has(e)) u(e);
			else try {
				var t = e.getAttribute(r), i = t !== null && t !== "false", c = (Y.get(e) || 0) + 1, l = (a.get(e) || 0) + 1;
				Y.set(e, c), a.set(e, l), o.push(e), c === 1 && i && X.set(e, !0), l === 1 && e.setAttribute(n, "true"), i || e.setAttribute(r, "true");
			} catch (t) {
				console.error("aria-hidden: cannot operate on ", e, t);
			}
		});
	};
	return u(t), s.clear(), Q++, function() {
		o.forEach(function(e) {
			var t = Y.get(e) - 1, i = a.get(e) - 1;
			Y.set(e, t), a.set(e, i), t || (X.has(e) || e.removeAttribute(r), X.delete(e)), i || e.removeAttribute(n);
		}), Q--, Q || (Y = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ new WeakMap(), X = /* @__PURE__ */ new WeakMap(), Z = {});
	};
}, ke = function(e, t, n) {
	n === void 0 && (n = "data-aria-hidden");
	var r = Array.from(Array.isArray(e) ? e : [e]), i = t || Ee(e);
	return i ? (r.push.apply(r, Array.from(i.querySelectorAll("[aria-live], script"))), Oe(r, i, n, "aria-hidden")) : function() {
		return null;
	};
};
//#endregion
export { c as a, l as i, J as n, d as r, ke as t };
