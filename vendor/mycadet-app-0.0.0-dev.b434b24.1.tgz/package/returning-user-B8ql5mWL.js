import { d as e, l as t, o as n, p as r, r as i } from "./schemas-D8_brjAQ.js";
import { m as a } from "./i18n-BRf-wfgm.js";
import { n as o } from "./api-DnMWUBLS.js";
//#region src/assistant/completion-record.ts
var s = "device:onboarded_assistants", c = e(r(), r()), l = t({
	key: n(s),
	value: r().nullable()
}), u;
typeof window < "u" && (window.addEventListener("cadet:pref-changed", (e) => {
	if (!(e instanceof CustomEvent)) return;
	let t = l.safeParse(e.detail);
	if (t.success) try {
		let e = c.safeParse(JSON.parse(t.data.value ?? "{}"));
		e.success && (u = e.data);
	} catch {}
}), window.addEventListener("storage", (e) => {
	(e.key === null || e.key === s) && (u = void 0);
}));
function d(e) {
	return u ? u[e] || void 0 : f()[e] || void 0;
}
function f() {
	try {
		let e = c.safeParse(JSON.parse(a(s, "{}")));
		return e.success ? e.data : {};
	} catch {
		return {};
	}
}
//#endregion
//#region src/assistant/returning-user.ts
var p = t({ assistants: i(t({
	assistantId: r().min(1),
	onboardedAt: r().optional(),
	hatchedAt: r().optional()
})) }), m = 10080 * 60 * 1e3;
function h(e) {
	if (e.onboardedAt || d(e.id)) return !0;
	let t = Date.parse(e.created ?? "");
	return Number.isFinite(t) && Date.now() - t >= m;
}
async function g(e = {}) {
	let t = e.signal ?? AbortSignal.timeout(5e3);
	if (t.aborted) return !1;
	let n, r = new Promise((e) => {
		n = () => e(!1), t.addEventListener("abort", n, { once: !0 });
	});
	try {
		return await Promise.race([_(t), r]);
	} catch {
		return !1;
	} finally {
		t.removeEventListener("abort", n);
	}
}
async function _(e) {
	try {
		let t = await fetch("/v1/assistants/", { signal: e }), n = t.ok ? await t.json() : null, r = p.safeParse(n);
		if (r.success && r.data.assistants.some((e) => h({
			id: e.assistantId,
			created: e.hatchedAt,
			onboardedAt: e.onboardedAt
		}))) return !0;
	} catch {}
	if (e.aborted) return !1;
	let t = await o({ signal: e });
	return t.ok && t.data.some(h);
}
//#endregion
export { g as t };
