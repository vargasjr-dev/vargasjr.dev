import { n as e } from "./routes-DW44XTQk.js";
//#region src/domains/onboarding/onboarding-destination.ts
var t = "new_assistant";
function n({ isLocalHatch: t, selectedAssistantOnboarded: n = !1, newAssistant: r = !1 }) {
	return n && !r && !t ? e.assistant : t ? e.onboarding.hatching : e.onboarding.research;
}
//#endregion
export { n, t };
