import { r as e } from "./chunk-C5e3QaDY.js";
//#region ../../node_modules/.bun/comma-separated-tokens@2.0.3/node_modules/comma-separated-tokens/index.js
function t(e) {
	let t = [], n = String(e || ""), r = n.indexOf(","), i = 0, a = !1;
	for (; !a;) {
		r === -1 && (r = n.length, a = !0);
		let e = n.slice(i, r).trim();
		(e || !a) && t.push(e), i = r + 1, r = n.indexOf(",", i);
	}
	return t;
}
function n(e, t) {
	let n = t || {};
	return (e[e.length - 1] === "" ? [...e, ""] : e).join((n.padRight ? " " : "") + "," + (n.padLeft === !1 ? "" : " ")).trim();
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/schema.js
var r = class {
	constructor(e, t, n) {
		this.normal = t, this.property = e, n && (this.space = n);
	}
};
r.prototype.normal = {}, r.prototype.property = {}, r.prototype.space = void 0;
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/merge.js
function i(e, t) {
	let n = {}, i = {};
	for (let t of e) Object.assign(n, t.property), Object.assign(i, t.normal);
	return new r(n, i, t);
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/normalize.js
function a(e) {
	return e.toLowerCase();
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/info.js
var o = class {
	constructor(e, t) {
		this.attribute = t, this.property = e;
	}
};
o.prototype.attribute = "", o.prototype.booleanish = !1, o.prototype.boolean = !1, o.prototype.commaOrSpaceSeparated = !1, o.prototype.commaSeparated = !1, o.prototype.defined = !1, o.prototype.mustUseProperty = !1, o.prototype.number = !1, o.prototype.overloadedBoolean = !1, o.prototype.property = "", o.prototype.spaceSeparated = !1, o.prototype.space = void 0;
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/types.js
var s = /* @__PURE__ */ e({
	boolean: () => l,
	booleanish: () => u,
	commaOrSpaceSeparated: () => h,
	commaSeparated: () => m,
	number: () => f,
	overloadedBoolean: () => d,
	spaceSeparated: () => p
}), c = 0, l = g(), u = g(), d = g(), f = g(), p = g(), m = g(), h = g();
function g() {
	return 2 ** ++c;
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/defined-info.js
var _ = Object.keys(s), v = class extends o {
	constructor(e, t, n, r) {
		let i = -1;
		if (super(e, t), y(this, "space", r), typeof n == "number") for (; ++i < _.length;) {
			let e = _[i];
			y(this, _[i], (n & s[e]) === s[e]);
		}
	}
};
v.prototype.defined = !0;
function y(e, t, n) {
	n && (e[t] = n);
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/create.js
function b(e) {
	let t = {}, n = {};
	for (let [r, i] of Object.entries(e.properties)) {
		let o = new v(r, e.transform(e.attributes || {}, r), i, e.space);
		e.mustUseProperty && e.mustUseProperty.includes(r) && (o.mustUseProperty = !0), t[r] = o, n[a(r)] = r, n[a(o.attribute)] = r;
	}
	return new r(t, n, e.space);
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/aria.js
var x = b({
	properties: {
		ariaActiveDescendant: null,
		ariaAtomic: u,
		ariaAutoComplete: null,
		ariaBusy: u,
		ariaChecked: u,
		ariaColCount: f,
		ariaColIndex: f,
		ariaColSpan: f,
		ariaControls: p,
		ariaCurrent: null,
		ariaDescribedBy: p,
		ariaDetails: null,
		ariaDisabled: u,
		ariaDropEffect: p,
		ariaErrorMessage: null,
		ariaExpanded: u,
		ariaFlowTo: p,
		ariaGrabbed: u,
		ariaHasPopup: null,
		ariaHidden: u,
		ariaInvalid: null,
		ariaKeyShortcuts: null,
		ariaLabel: null,
		ariaLabelledBy: p,
		ariaLevel: f,
		ariaLive: null,
		ariaModal: u,
		ariaMultiLine: u,
		ariaMultiSelectable: u,
		ariaOrientation: null,
		ariaOwns: p,
		ariaPlaceholder: null,
		ariaPosInSet: f,
		ariaPressed: u,
		ariaReadOnly: u,
		ariaRelevant: null,
		ariaRequired: u,
		ariaRoleDescription: p,
		ariaRowCount: f,
		ariaRowIndex: f,
		ariaRowSpan: f,
		ariaSelected: u,
		ariaSetSize: f,
		ariaSort: null,
		ariaValueMax: f,
		ariaValueMin: f,
		ariaValueNow: f,
		ariaValueText: null,
		role: null
	},
	transform(e, t) {
		return t === "role" ? t : "aria-" + t.slice(4).toLowerCase();
	}
});
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/case-sensitive-transform.js
function S(e, t) {
	return t in e ? e[t] : t;
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/util/case-insensitive-transform.js
function C(e, t) {
	return S(e, t.toLowerCase());
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/lib/html.js
var w = b({
	attributes: {
		acceptcharset: "accept-charset",
		classname: "class",
		htmlfor: "for",
		httpequiv: "http-equiv"
	},
	mustUseProperty: [
		"checked",
		"multiple",
		"muted",
		"selected"
	],
	properties: {
		abbr: null,
		accept: m,
		acceptCharset: p,
		accessKey: p,
		action: null,
		allow: null,
		allowFullScreen: l,
		allowPaymentRequest: l,
		allowUserMedia: l,
		alpha: l,
		alt: null,
		as: null,
		async: l,
		autoCapitalize: null,
		autoComplete: p,
		autoFocus: l,
		autoPlay: l,
		blocking: p,
		capture: null,
		charSet: null,
		checked: l,
		cite: null,
		className: p,
		closedBy: null,
		colorSpace: null,
		cols: f,
		colSpan: f,
		command: null,
		commandFor: null,
		content: null,
		contentEditable: u,
		controls: l,
		controlsList: p,
		coords: f | m,
		crossOrigin: null,
		data: null,
		dateTime: null,
		decoding: null,
		default: l,
		defer: l,
		dir: null,
		dirName: null,
		disabled: l,
		download: d,
		draggable: u,
		encType: null,
		enterKeyHint: null,
		fetchPriority: null,
		form: null,
		formAction: null,
		formEncType: null,
		formMethod: null,
		formNoValidate: l,
		formTarget: null,
		headers: p,
		height: f,
		hidden: d,
		high: f,
		href: null,
		hrefLang: null,
		htmlFor: p,
		httpEquiv: p,
		id: null,
		imageSizes: null,
		imageSrcSet: null,
		inert: l,
		inputMode: null,
		integrity: null,
		is: null,
		isMap: l,
		itemId: null,
		itemProp: p,
		itemRef: p,
		itemScope: l,
		itemType: p,
		kind: null,
		label: null,
		lang: null,
		language: null,
		list: null,
		loading: null,
		loop: l,
		low: f,
		manifest: null,
		max: null,
		maxLength: f,
		media: null,
		method: null,
		min: null,
		minLength: f,
		multiple: l,
		muted: l,
		name: null,
		nonce: null,
		noModule: l,
		noValidate: l,
		onAbort: null,
		onAfterPrint: null,
		onAuxClick: null,
		onBeforeMatch: null,
		onBeforePrint: null,
		onBeforeToggle: null,
		onBeforeUnload: null,
		onBlur: null,
		onCancel: null,
		onCanPlay: null,
		onCanPlayThrough: null,
		onChange: null,
		onClick: null,
		onClose: null,
		onContextLost: null,
		onContextMenu: null,
		onContextRestored: null,
		onCopy: null,
		onCueChange: null,
		onCut: null,
		onDblClick: null,
		onDrag: null,
		onDragEnd: null,
		onDragEnter: null,
		onDragExit: null,
		onDragLeave: null,
		onDragOver: null,
		onDragStart: null,
		onDrop: null,
		onDurationChange: null,
		onEmptied: null,
		onEnded: null,
		onError: null,
		onFocus: null,
		onFormData: null,
		onHashChange: null,
		onInput: null,
		onInvalid: null,
		onKeyDown: null,
		onKeyPress: null,
		onKeyUp: null,
		onLanguageChange: null,
		onLoad: null,
		onLoadedData: null,
		onLoadedMetadata: null,
		onLoadEnd: null,
		onLoadStart: null,
		onMessage: null,
		onMessageError: null,
		onMouseDown: null,
		onMouseEnter: null,
		onMouseLeave: null,
		onMouseMove: null,
		onMouseOut: null,
		onMouseOver: null,
		onMouseUp: null,
		onOffline: null,
		onOnline: null,
		onPageHide: null,
		onPageShow: null,
		onPaste: null,
		onPause: null,
		onPlay: null,
		onPlaying: null,
		onPopState: null,
		onProgress: null,
		onRateChange: null,
		onRejectionHandled: null,
		onReset: null,
		onResize: null,
		onScroll: null,
		onScrollEnd: null,
		onSecurityPolicyViolation: null,
		onSeeked: null,
		onSeeking: null,
		onSelect: null,
		onSlotChange: null,
		onStalled: null,
		onStorage: null,
		onSubmit: null,
		onSuspend: null,
		onTimeUpdate: null,
		onToggle: null,
		onUnhandledRejection: null,
		onUnload: null,
		onVolumeChange: null,
		onWaiting: null,
		onWheel: null,
		open: l,
		optimum: f,
		pattern: null,
		ping: p,
		placeholder: null,
		playsInline: l,
		popover: null,
		popoverTarget: null,
		popoverTargetAction: null,
		poster: null,
		preload: null,
		readOnly: l,
		referrerPolicy: null,
		rel: p,
		required: l,
		reversed: l,
		rows: f,
		rowSpan: f,
		sandbox: p,
		scope: null,
		scoped: l,
		seamless: l,
		selected: l,
		shadowRootClonable: l,
		shadowRootCustomElementRegistry: l,
		shadowRootDelegatesFocus: l,
		shadowRootMode: null,
		shadowRootSerializable: l,
		shape: null,
		size: f,
		sizes: null,
		slot: null,
		span: f,
		spellCheck: u,
		src: null,
		srcDoc: null,
		srcLang: null,
		srcSet: null,
		start: f,
		step: null,
		style: null,
		tabIndex: f,
		target: null,
		title: null,
		translate: null,
		type: null,
		typeMustMatch: l,
		useMap: null,
		value: u,
		width: f,
		wrap: null,
		writingSuggestions: null,
		align: null,
		aLink: null,
		archive: p,
		axis: null,
		background: null,
		bgColor: null,
		border: f,
		borderColor: null,
		bottomMargin: f,
		cellPadding: null,
		cellSpacing: null,
		char: null,
		charOff: null,
		classId: null,
		clear: null,
		code: null,
		codeBase: null,
		codeType: null,
		color: null,
		compact: l,
		declare: l,
		event: null,
		face: null,
		frame: null,
		frameBorder: null,
		hSpace: f,
		leftMargin: f,
		link: null,
		longDesc: null,
		lowSrc: null,
		marginHeight: f,
		marginWidth: f,
		noResize: l,
		noHref: l,
		noShade: l,
		noWrap: l,
		object: null,
		profile: null,
		prompt: null,
		rev: null,
		rightMargin: f,
		rules: null,
		scheme: null,
		scrolling: u,
		standby: null,
		summary: null,
		text: null,
		topMargin: f,
		valueType: null,
		version: null,
		vAlign: null,
		vLink: null,
		vSpace: f,
		allowTransparency: null,
		autoCorrect: null,
		autoSave: null,
		credentialless: l,
		disablePictureInPicture: l,
		disableRemotePlayback: l,
		exportParts: m,
		part: p,
		prefix: null,
		property: null,
		results: f,
		security: null,
		unselectable: null
	},
	space: "html",
	transform: C
}), ee = b({
	attributes: {
		accentHeight: "accent-height",
		alignmentBaseline: "alignment-baseline",
		arabicForm: "arabic-form",
		baselineShift: "baseline-shift",
		capHeight: "cap-height",
		className: "class",
		clipPath: "clip-path",
		clipRule: "clip-rule",
		colorInterpolation: "color-interpolation",
		colorInterpolationFilters: "color-interpolation-filters",
		colorProfile: "color-profile",
		colorRendering: "color-rendering",
		crossOrigin: "crossorigin",
		dataType: "datatype",
		dominantBaseline: "dominant-baseline",
		enableBackground: "enable-background",
		fillOpacity: "fill-opacity",
		fillRule: "fill-rule",
		floodColor: "flood-color",
		floodOpacity: "flood-opacity",
		fontFamily: "font-family",
		fontSize: "font-size",
		fontSizeAdjust: "font-size-adjust",
		fontStretch: "font-stretch",
		fontStyle: "font-style",
		fontVariant: "font-variant",
		fontWeight: "font-weight",
		glyphName: "glyph-name",
		glyphOrientationHorizontal: "glyph-orientation-horizontal",
		glyphOrientationVertical: "glyph-orientation-vertical",
		hrefLang: "hreflang",
		horizAdvX: "horiz-adv-x",
		horizOriginX: "horiz-origin-x",
		horizOriginY: "horiz-origin-y",
		imageRendering: "image-rendering",
		letterSpacing: "letter-spacing",
		lightingColor: "lighting-color",
		markerEnd: "marker-end",
		markerMid: "marker-mid",
		markerStart: "marker-start",
		maskType: "mask-type",
		navDown: "nav-down",
		navDownLeft: "nav-down-left",
		navDownRight: "nav-down-right",
		navLeft: "nav-left",
		navNext: "nav-next",
		navPrev: "nav-prev",
		navRight: "nav-right",
		navUp: "nav-up",
		navUpLeft: "nav-up-left",
		navUpRight: "nav-up-right",
		onAbort: "onabort",
		onActivate: "onactivate",
		onAfterPrint: "onafterprint",
		onBeforePrint: "onbeforeprint",
		onBegin: "onbegin",
		onCancel: "oncancel",
		onCanPlay: "oncanplay",
		onCanPlayThrough: "oncanplaythrough",
		onChange: "onchange",
		onClick: "onclick",
		onClose: "onclose",
		onCopy: "oncopy",
		onCueChange: "oncuechange",
		onCut: "oncut",
		onDblClick: "ondblclick",
		onDrag: "ondrag",
		onDragEnd: "ondragend",
		onDragEnter: "ondragenter",
		onDragExit: "ondragexit",
		onDragLeave: "ondragleave",
		onDragOver: "ondragover",
		onDragStart: "ondragstart",
		onDrop: "ondrop",
		onDurationChange: "ondurationchange",
		onEmptied: "onemptied",
		onEnd: "onend",
		onEnded: "onended",
		onError: "onerror",
		onFocus: "onfocus",
		onFocusIn: "onfocusin",
		onFocusOut: "onfocusout",
		onHashChange: "onhashchange",
		onInput: "oninput",
		onInvalid: "oninvalid",
		onKeyDown: "onkeydown",
		onKeyPress: "onkeypress",
		onKeyUp: "onkeyup",
		onLoad: "onload",
		onLoadedData: "onloadeddata",
		onLoadedMetadata: "onloadedmetadata",
		onLoadStart: "onloadstart",
		onMessage: "onmessage",
		onMouseDown: "onmousedown",
		onMouseEnter: "onmouseenter",
		onMouseLeave: "onmouseleave",
		onMouseMove: "onmousemove",
		onMouseOut: "onmouseout",
		onMouseOver: "onmouseover",
		onMouseUp: "onmouseup",
		onMouseWheel: "onmousewheel",
		onOffline: "onoffline",
		onOnline: "ononline",
		onPageHide: "onpagehide",
		onPageShow: "onpageshow",
		onPaste: "onpaste",
		onPause: "onpause",
		onPlay: "onplay",
		onPlaying: "onplaying",
		onPopState: "onpopstate",
		onProgress: "onprogress",
		onRateChange: "onratechange",
		onRepeat: "onrepeat",
		onReset: "onreset",
		onResize: "onresize",
		onScroll: "onscroll",
		onSeeked: "onseeked",
		onSeeking: "onseeking",
		onSelect: "onselect",
		onShow: "onshow",
		onStalled: "onstalled",
		onStorage: "onstorage",
		onSubmit: "onsubmit",
		onSuspend: "onsuspend",
		onTimeUpdate: "ontimeupdate",
		onToggle: "ontoggle",
		onUnload: "onunload",
		onVolumeChange: "onvolumechange",
		onWaiting: "onwaiting",
		onZoom: "onzoom",
		overlinePosition: "overline-position",
		overlineThickness: "overline-thickness",
		paintOrder: "paint-order",
		panose1: "panose-1",
		pointerEvents: "pointer-events",
		referrerPolicy: "referrerpolicy",
		renderingIntent: "rendering-intent",
		shapeRendering: "shape-rendering",
		stopColor: "stop-color",
		stopOpacity: "stop-opacity",
		strikethroughPosition: "strikethrough-position",
		strikethroughThickness: "strikethrough-thickness",
		strokeDashArray: "stroke-dasharray",
		strokeDashOffset: "stroke-dashoffset",
		strokeLineCap: "stroke-linecap",
		strokeLineJoin: "stroke-linejoin",
		strokeMiterLimit: "stroke-miterlimit",
		strokeOpacity: "stroke-opacity",
		strokeWidth: "stroke-width",
		tabIndex: "tabindex",
		textAnchor: "text-anchor",
		textDecoration: "text-decoration",
		textRendering: "text-rendering",
		transformOrigin: "transform-origin",
		typeOf: "typeof",
		underlinePosition: "underline-position",
		underlineThickness: "underline-thickness",
		unicodeBidi: "unicode-bidi",
		unicodeRange: "unicode-range",
		unitsPerEm: "units-per-em",
		vAlphabetic: "v-alphabetic",
		vHanging: "v-hanging",
		vIdeographic: "v-ideographic",
		vMathematical: "v-mathematical",
		vectorEffect: "vector-effect",
		vertAdvY: "vert-adv-y",
		vertOriginX: "vert-origin-x",
		vertOriginY: "vert-origin-y",
		wordSpacing: "word-spacing",
		writingMode: "writing-mode",
		xHeight: "x-height",
		playbackOrder: "playbackorder",
		timelineBegin: "timelinebegin"
	},
	properties: {
		about: h,
		accentHeight: f,
		accumulate: null,
		additive: null,
		alignmentBaseline: null,
		alphabetic: f,
		amplitude: f,
		arabicForm: null,
		ascent: f,
		attributeName: null,
		attributeType: null,
		azimuth: f,
		bandwidth: null,
		baselineShift: null,
		baseFrequency: null,
		baseProfile: null,
		bbox: null,
		begin: null,
		bias: f,
		by: null,
		calcMode: null,
		capHeight: f,
		className: p,
		clip: null,
		clipPath: null,
		clipPathUnits: null,
		clipRule: null,
		color: null,
		colorInterpolation: null,
		colorInterpolationFilters: null,
		colorProfile: null,
		colorRendering: null,
		content: null,
		contentScriptType: null,
		contentStyleType: null,
		crossOrigin: null,
		cursor: null,
		cx: null,
		cy: null,
		d: null,
		dataType: null,
		defaultAction: null,
		descent: f,
		diffuseConstant: f,
		direction: null,
		display: null,
		dur: null,
		divisor: f,
		dominantBaseline: null,
		download: l,
		dx: null,
		dy: null,
		edgeMode: null,
		editable: null,
		elevation: f,
		enableBackground: null,
		end: null,
		event: null,
		exponent: f,
		externalResourcesRequired: null,
		fill: null,
		fillOpacity: f,
		fillRule: null,
		filter: null,
		filterRes: null,
		filterUnits: null,
		floodColor: null,
		floodOpacity: null,
		focusable: null,
		focusHighlight: null,
		fontFamily: null,
		fontSize: null,
		fontSizeAdjust: null,
		fontStretch: null,
		fontStyle: null,
		fontVariant: null,
		fontWeight: null,
		format: null,
		fr: null,
		from: null,
		fx: null,
		fy: null,
		g1: m,
		g2: m,
		glyphName: m,
		glyphOrientationHorizontal: null,
		glyphOrientationVertical: null,
		glyphRef: null,
		gradientTransform: null,
		gradientUnits: null,
		handler: null,
		hanging: f,
		hatchContentUnits: null,
		hatchUnits: null,
		height: null,
		href: null,
		hrefLang: null,
		horizAdvX: f,
		horizOriginX: f,
		horizOriginY: f,
		id: null,
		ideographic: f,
		imageRendering: null,
		initialVisibility: null,
		in: null,
		in2: null,
		intercept: f,
		k: f,
		k1: f,
		k2: f,
		k3: f,
		k4: f,
		kernelMatrix: h,
		kernelUnitLength: null,
		keyPoints: null,
		keySplines: null,
		keyTimes: null,
		kerning: null,
		lang: null,
		lengthAdjust: null,
		letterSpacing: null,
		lightingColor: null,
		limitingConeAngle: f,
		local: null,
		markerEnd: null,
		markerMid: null,
		markerStart: null,
		markerHeight: null,
		markerUnits: null,
		markerWidth: null,
		mask: null,
		maskContentUnits: null,
		maskType: null,
		maskUnits: null,
		mathematical: null,
		max: null,
		media: null,
		mediaCharacterEncoding: null,
		mediaContentEncodings: null,
		mediaSize: f,
		mediaTime: null,
		method: null,
		min: null,
		mode: null,
		name: null,
		navDown: null,
		navDownLeft: null,
		navDownRight: null,
		navLeft: null,
		navNext: null,
		navPrev: null,
		navRight: null,
		navUp: null,
		navUpLeft: null,
		navUpRight: null,
		numOctaves: null,
		observer: null,
		offset: null,
		onAbort: null,
		onActivate: null,
		onAfterPrint: null,
		onBeforePrint: null,
		onBegin: null,
		onCancel: null,
		onCanPlay: null,
		onCanPlayThrough: null,
		onChange: null,
		onClick: null,
		onClose: null,
		onCopy: null,
		onCueChange: null,
		onCut: null,
		onDblClick: null,
		onDrag: null,
		onDragEnd: null,
		onDragEnter: null,
		onDragExit: null,
		onDragLeave: null,
		onDragOver: null,
		onDragStart: null,
		onDrop: null,
		onDurationChange: null,
		onEmptied: null,
		onEnd: null,
		onEnded: null,
		onError: null,
		onFocus: null,
		onFocusIn: null,
		onFocusOut: null,
		onHashChange: null,
		onInput: null,
		onInvalid: null,
		onKeyDown: null,
		onKeyPress: null,
		onKeyUp: null,
		onLoad: null,
		onLoadedData: null,
		onLoadedMetadata: null,
		onLoadStart: null,
		onMessage: null,
		onMouseDown: null,
		onMouseEnter: null,
		onMouseLeave: null,
		onMouseMove: null,
		onMouseOut: null,
		onMouseOver: null,
		onMouseUp: null,
		onMouseWheel: null,
		onOffline: null,
		onOnline: null,
		onPageHide: null,
		onPageShow: null,
		onPaste: null,
		onPause: null,
		onPlay: null,
		onPlaying: null,
		onPopState: null,
		onProgress: null,
		onRateChange: null,
		onRepeat: null,
		onReset: null,
		onResize: null,
		onScroll: null,
		onSeeked: null,
		onSeeking: null,
		onSelect: null,
		onShow: null,
		onStalled: null,
		onStorage: null,
		onSubmit: null,
		onSuspend: null,
		onTimeUpdate: null,
		onToggle: null,
		onUnload: null,
		onVolumeChange: null,
		onWaiting: null,
		onZoom: null,
		opacity: null,
		operator: null,
		order: null,
		orient: null,
		orientation: null,
		origin: null,
		overflow: null,
		overlay: null,
		overlinePosition: f,
		overlineThickness: f,
		paintOrder: null,
		panose1: null,
		path: null,
		pathLength: f,
		patternContentUnits: null,
		patternTransform: null,
		patternUnits: null,
		phase: null,
		ping: p,
		pitch: null,
		playbackOrder: null,
		pointerEvents: null,
		points: null,
		pointsAtX: f,
		pointsAtY: f,
		pointsAtZ: f,
		preserveAlpha: null,
		preserveAspectRatio: null,
		primitiveUnits: null,
		propagate: null,
		property: h,
		r: null,
		radius: null,
		referrerPolicy: null,
		refX: null,
		refY: null,
		rel: h,
		rev: h,
		renderingIntent: null,
		repeatCount: null,
		repeatDur: null,
		requiredExtensions: h,
		requiredFeatures: h,
		requiredFonts: h,
		requiredFormats: h,
		resource: null,
		restart: null,
		result: null,
		rotate: null,
		rx: null,
		ry: null,
		scale: null,
		seed: null,
		shapeRendering: null,
		side: null,
		slope: null,
		snapshotTime: null,
		specularConstant: f,
		specularExponent: f,
		spreadMethod: null,
		spacing: null,
		startOffset: null,
		stdDeviation: null,
		stemh: null,
		stemv: null,
		stitchTiles: null,
		stopColor: null,
		stopOpacity: null,
		strikethroughPosition: f,
		strikethroughThickness: f,
		string: null,
		stroke: null,
		strokeDashArray: h,
		strokeDashOffset: null,
		strokeLineCap: null,
		strokeLineJoin: null,
		strokeMiterLimit: f,
		strokeOpacity: f,
		strokeWidth: null,
		style: null,
		surfaceScale: f,
		syncBehavior: null,
		syncBehaviorDefault: null,
		syncMaster: null,
		syncTolerance: null,
		syncToleranceDefault: null,
		systemLanguage: h,
		tabIndex: f,
		tableValues: null,
		target: null,
		targetX: f,
		targetY: f,
		textAnchor: null,
		textDecoration: null,
		textRendering: null,
		textLength: null,
		timelineBegin: null,
		title: null,
		transformBehavior: null,
		type: null,
		typeOf: h,
		to: null,
		transform: null,
		transformOrigin: null,
		u1: null,
		u2: null,
		underlinePosition: f,
		underlineThickness: f,
		unicode: null,
		unicodeBidi: null,
		unicodeRange: null,
		unitsPerEm: f,
		values: null,
		vAlphabetic: f,
		vMathematical: f,
		vectorEffect: null,
		vHanging: f,
		vIdeographic: f,
		version: null,
		vertAdvY: f,
		vertOriginX: f,
		vertOriginY: f,
		viewBox: null,
		viewTarget: null,
		visibility: null,
		width: null,
		widths: null,
		wordSpacing: null,
		writingMode: null,
		x: null,
		x1: null,
		x2: null,
		xChannelSelector: null,
		xHeight: f,
		y: null,
		y1: null,
		y2: null,
		yChannelSelector: null,
		z: null,
		zoomAndPan: null
	},
	space: "svg",
	transform: S
}), T = b({
	properties: {
		xLinkActuate: null,
		xLinkArcRole: null,
		xLinkHref: null,
		xLinkRole: null,
		xLinkShow: null,
		xLinkTitle: null,
		xLinkType: null
	},
	space: "xlink",
	transform(e, t) {
		return "xlink:" + t.slice(5).toLowerCase();
	}
}), E = b({
	attributes: { xmlnsxlink: "xmlns:xlink" },
	properties: {
		xmlnsXLink: null,
		xmlns: null
	},
	space: "xmlns",
	transform: C
}), D = b({
	properties: {
		xmlBase: null,
		xmlLang: null,
		xmlSpace: null
	},
	space: "xml",
	transform(e, t) {
		return "xml:" + t.slice(3).toLowerCase();
	}
}), O = {
	classId: "classID",
	dataType: "datatype",
	itemId: "itemID",
	strokeDashArray: "strokeDasharray",
	strokeDashOffset: "strokeDashoffset",
	strokeLineCap: "strokeLinecap",
	strokeLineJoin: "strokeLinejoin",
	strokeMiterLimit: "strokeMiterlimit",
	typeOf: "typeof",
	xLinkActuate: "xlinkActuate",
	xLinkArcRole: "xlinkArcrole",
	xLinkHref: "xlinkHref",
	xLinkRole: "xlinkRole",
	xLinkShow: "xlinkShow",
	xLinkTitle: "xlinkTitle",
	xLinkType: "xlinkType",
	xmlnsXLink: "xmlnsXlink"
}, te = /[A-Z]/g, k = /-[a-z]/g, ne = /^data[-\w.:]+$/i;
function A(e, t) {
	let n = a(t), r = t, i = o;
	if (n in e.normal) return e.property[e.normal[n]];
	if (n.length > 4 && n.slice(0, 4) === "data" && ne.test(t)) {
		if (t.charAt(4) === "-") {
			let e = t.slice(5).replace(k, M);
			r = "data" + e.charAt(0).toUpperCase() + e.slice(1);
		} else {
			let e = t.slice(4);
			if (!k.test(e)) {
				let n = e.replace(te, j);
				n.charAt(0) !== "-" && (n = "-" + n), t = "data" + n;
			}
		}
		i = v;
	}
	return new i(r, t);
}
function j(e) {
	return "-" + e.toLowerCase();
}
function M(e) {
	return e.charAt(1).toUpperCase();
}
//#endregion
//#region ../../node_modules/.bun/property-information@7.2.0/node_modules/property-information/index.js
var N = i([
	x,
	w,
	T,
	E,
	D
], "html"), P = i([
	x,
	ee,
	T,
	E,
	D
], "svg");
//#endregion
//#region ../../node_modules/.bun/space-separated-tokens@2.0.2/node_modules/space-separated-tokens/index.js
function F(e) {
	let t = String(e || "").trim();
	return t ? t.split(/[ \t\n\r\f]+/g) : [];
}
function re(e) {
	return e.join(" ").trim();
}
//#endregion
//#region ../../node_modules/.bun/unist-util-is@6.0.1/node_modules/unist-util-is/lib/index.js
var I = (function(e) {
	if (e == null) return V;
	if (typeof e == "function") return B(e);
	if (typeof e == "object") return Array.isArray(e) ? L(e) : R(e);
	if (typeof e == "string") return z(e);
	throw Error("Expected function, string, or object as test");
});
function L(e) {
	let t = [], n = -1;
	for (; ++n < e.length;) t[n] = I(e[n]);
	return B(r);
	function r(...e) {
		let n = -1;
		for (; ++n < t.length;) if (t[n].apply(this, e)) return !0;
		return !1;
	}
}
function R(e) {
	let t = e;
	return B(n);
	function n(n) {
		let r = n, i;
		for (i in e) if (r[i] !== t[i]) return !1;
		return !0;
	}
}
function z(e) {
	return B(t);
	function t(t) {
		return t && t.type === e;
	}
}
function B(e) {
	return t;
	function t(t, n, r) {
		return !!(H(t) && e.call(this, t, typeof n == "number" ? n : void 0, r || void 0));
	}
}
function V() {
	return !0;
}
function H(e) {
	return typeof e == "object" && !!e && "type" in e;
}
//#endregion
//#region ../../node_modules/.bun/unist-util-visit-parents@6.1.0/node_modules/unist-util-visit-parents/lib/color.js
function U(e) {
	return e;
}
//#endregion
//#region ../../node_modules/.bun/unist-util-visit-parents@6.1.0/node_modules/unist-util-visit-parents/lib/index.js
var W = [], G = "skip";
function K(e, t, n, r) {
	if (!e || typeof e != "object") throw Error("Unexpected value `" + e + "` for `tree`, expected node");
	let i = !0, a, o, s, c;
	if (typeof n == "function" || n && typeof n == "object" ? (a = t, o = n, r && (i = !1)) : (o = t, n && (i = !1)), typeof o == "function") s = o;
	else if (o && typeof o == "object") {
		if (!(o.enter === null || o.enter === void 0)) if (typeof o.enter == "function") s = o.enter;
		else throw Error("Unexpected value `" + o.enter + "` for `visitors.enter`, expected optional visitor");
		if (typeof o.exit == "function") c = o.exit;
		else throw Error("Unexpected value `" + o.exit + "` for `visitors.exit`, expected visitor (pass a visitor directly if you only want an enter visitor)");
	} else throw Error("Unexpected value `" + o + "` for `enter` or `visitors`, expected visitor or object with visitors");
	let l = I(a), u = i ? 1 : -1;
	d(e, void 0, [])();
	function d(e, t, n) {
		let r = e && typeof e == "object" ? e : {};
		if (typeof r.type == "string") {
			let t = typeof r.tagName == "string" ? r.tagName : typeof r.name == "string" ? r.name : void 0;
			Object.defineProperty(o, "name", { value: "node (" + U(e.type + (t ? "<" + t + ">" : "")) + ")" });
		}
		return o;
		function o() {
			let r = !a || l(e, t, n[n.length - 1] || void 0), o = W;
			if (s && r && (o = q(s(e, n, t)), o[0] === !1)) return o;
			if ("children" in e && e.children) {
				let t = e;
				if (t.children && o[0] !== "skip") {
					let e = (i ? -1 : t.children.length) + u, r = [...n, t];
					for (; e > -1 && e < t.children.length;) {
						let n = t.children[e], i = d(n, e, r)();
						if (i[0] === !1) return i;
						e = typeof i[1] == "number" ? i[1] : e + u;
					}
				}
			}
			if (c && r) {
				let r = q(c(e, n, t));
				if (r[0] === "skip") throw Error("Unexpected value `" + r[0] + "` from `exit`, expected `CONTINUE`, `EXIT`, index, or nothing");
				if (r[0] === !1 || typeof r[1] == "number") return r;
			}
			return o;
		}
	}
}
function q(e) {
	return Array.isArray(e) ? e : typeof e == "number" ? [!0, e] : e == null ? W : [e];
}
//#endregion
//#region ../../node_modules/.bun/hast-util-parse-selector@4.0.0/node_modules/hast-util-parse-selector/lib/index.js
var J = /[#.]/g;
function Y(e, t) {
	let n = e || "", r = {}, i = 0, a, o;
	for (; i < n.length;) {
		J.lastIndex = i;
		let e = J.exec(n), t = n.slice(i, e ? e.index : n.length);
		t && (a ? a === "#" ? r.id = t : Array.isArray(r.className) ? r.className.push(t) : r.className = [t] : o = t, i += t.length), e && (a = e[0], i++);
	}
	return {
		type: "element",
		tagName: o || t || "div",
		properties: r,
		children: []
	};
}
//#endregion
//#region ../../node_modules/.bun/hastscript@9.0.3/node_modules/hastscript/lib/create-h.js
function X(e, t, n) {
	let r = n ? $(n) : void 0;
	function i(n, i, ...a) {
		let o;
		if (n == null) {
			o = {
				type: "root",
				children: []
			};
			let e = i;
			a.unshift(e);
		} else {
			o = Y(n, t);
			let s = o.tagName.toLowerCase(), c = r ? r.get(s) : void 0;
			if (o.tagName = c || s, ie(i)) a.unshift(i);
			else for (let [t, n] of Object.entries(i)) ae(e, o.properties, t, n);
		}
		for (let e of a) Z(o.children, e);
		return o.type === "element" && o.tagName === "template" && e.space === "html" && (o.content = {
			type: "root",
			children: o.children
		}, o.children = []), o;
	}
	return i;
}
function ie(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !0;
	if (typeof e.type != "string") return !1;
	let t = e, n = Object.keys(e);
	for (let e of n) {
		let n = t[e];
		if (n && typeof n == "object") {
			if (!Array.isArray(n)) return !0;
			let e = n;
			for (let t of e) if (typeof t != "number" && typeof t != "string") return !0;
		}
	}
	return !!("children" in e && Array.isArray(e.children));
}
function ae(e, n, r, i) {
	if (i == null) return;
	let a = A(e, r), o;
	if (typeof i == "number") {
		if (Number.isNaN(i)) return;
		o = i;
	} else o = typeof i == "boolean" ? i : typeof i == "string" ? a.spaceSeparated ? F(i) : a.commaSeparated ? t(i) : a.commaOrSpaceSeparated ? F(t(i).join(" ")) : Q(a, a.property, i) : Array.isArray(i) ? [...i] : a.property === "style" ? oe(i) : String(i);
	if (Array.isArray(o)) {
		let e = [];
		for (let t of o) e.push(Q(a, a.property, t));
		o = e;
	}
	if (a.property === "className" && Array.isArray(n.className)) {
		let e = o;
		o = [...n.className, ...Array.isArray(e) ? e : [e]];
	}
	n[a.property] = o;
}
function Z(e, t) {
	if (t != null) if (typeof t == "number" || typeof t == "string") e.push({
		type: "text",
		value: String(t)
	});
	else if (Array.isArray(t)) for (let n of t) Z(e, n);
	else if (typeof t == "object" && "type" in t) t.type === "root" ? Z(e, t.children) : e.push(t);
	else throw Error("Expected node, nodes, or string, got `" + t + "`");
}
function Q(e, t, n) {
	if (typeof n == "string") {
		if (e.number && n && !Number.isNaN(Number(n))) return Number(n);
		if ((e.boolean || e.overloadedBoolean) && (n === "" || a(n) === a(t))) return !0;
	}
	return n;
}
function oe(e) {
	let t = [];
	for (let [n, r] of Object.entries(e)) t.push([n, r].join(": "));
	return t.join("; ");
}
function $(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.toLowerCase(), n);
	return t;
}
//#endregion
//#region ../../node_modules/.bun/hastscript@9.0.3/node_modules/hastscript/lib/svg-case-sensitive-tag-names.js
var se = /* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feDropShadow.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.solidColor.textArea.textPath".split("."), ce = X(N, "div"), le = X(P, "g", se), ue = {
	html: "http://www.w3.org/1999/xhtml",
	mathml: "http://www.w3.org/1998/Math/MathML",
	svg: "http://www.w3.org/2000/svg",
	xlink: "http://www.w3.org/1999/xlink",
	xml: "http://www.w3.org/XML/1998/namespace",
	xmlns: "http://www.w3.org/2000/xmlns/"
};
//#endregion
export { K as a, N as c, O as d, n as f, G as i, P as l, ce as n, I as o, le as r, re as s, ue as t, A as u };
