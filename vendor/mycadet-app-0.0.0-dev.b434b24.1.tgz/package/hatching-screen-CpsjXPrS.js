import { c as e, d as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { r as n } from "./i18n-BRf-wfgm.js";
import { s as r, t as i } from "./assistant-selection-ZCXVlG5B.js";
import { t as a } from "./button-BrPHE1Q9.js";
import { n as o } from "./routes-DW44XTQk.js";
import { n as s, o as c, t as l } from "./avatar-random-De_AuTlf.js";
import { n as u, o as d } from "./resolve-assistant-g0zYJ1Fn.js";
import { t as f } from "./progress-bar-CfBUP_JA.js";
import { t as p } from "./account-shell-D0S9QH7J.js";
import { t as m } from "./onboarding-navigation-Bp-9lTqG.js";
import { BUNDLED_COMPONENTS as h } from "./avatar-bundled-components-CpiqHPhk.js";
import { useCallback as g, useEffect as _, useMemo as v, useRef as y, useState as b } from "react";
import { jsx as x, jsxs as S } from "react/jsx-runtime";
//#region src/assistant/operations.ts
var C = "Pairing failed. Please try again.", w = null, T;
function E() {
	w = null, T = void 0;
}
async function D(e) {
	return w && T !== e && E(), w ||= (T = e, O(e).then((e) => (e.ok || E(), e))), w;
}
async function O(e) {
	try {
		let t = await (await fetch("/v1/assistants/hatch", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ remote: e })
		})).json().catch(() => null);
		return t?.ok ? {
			ok: !0,
			assistantId: t.assistantId
		} : {
			ok: !1,
			error: t?.error ?? C
		};
	} catch {
		return {
			ok: !1,
			error: C
		};
	}
}
//#endregion
//#region src/domains/onboarding/pages/hatching-screen.tsx
var k = 800, A = 3e3, j = 3e5, M = null;
function N() {
	M = null;
}
var P = {
	initializing: 0,
	provisioning: .33,
	connecting: .66,
	ready: 1
}, F = 1500, I = {
	initializing: "hatchingScreen.phase.initializing",
	provisioning: "hatchingScreen.phase.provisioning",
	connecting: "hatchingScreen.phase.connecting",
	ready: "hatchingScreen.phase.ready"
};
function ee(e, t, n) {
	if (e >= t) return t;
	let r = 1 - (1 - Math.min(1, n / F)) ** 3;
	return e + (t - e) * r;
}
function L() {
	let { t: C } = n("account"), w = e(), [T] = t(), O = d.safeParse(T.get("hosting")).data, F = T.get("fail"), [L] = b(() => M ??= l(h)), R = v(() => {
		let e = s(h, L.bodyShape, L.eyeStyle, L.color, 320);
		return e ? `data:image/svg+xml;charset=utf-8,${encodeURIComponent(e)}` : "";
	}, [L]), [z, B] = b("initializing"), [V, H] = b(null), [U, W] = b(0), [G, K] = b(0), [q, J] = b(0), Y = y(z), X = y(0), Z = y(0), Q = y(0), $ = g((e) => {
		X.current = Q.current, Z.current = Date.now(), Y.current = e, B(e), J((e) => e + 1);
	}, []);
	return _(() => {
		if (F !== null) {
			H("Simulated hatch failure (developer menu → Replay Hatch Failure).");
			return;
		}
		let e = !1, t = null, n = null, a = Date.now(), s = (n) => {
			n && c(n, L), K(1), Q.current = 1, X.current = 1, B("ready"), Y.current = "ready", t = setTimeout(() => {
				if (!e) {
					if (E(), N(), n) {
						w(o.assistant, {
							...m,
							state: i(n)
						});
						return;
					}
					w(o.assistant, m);
				}
			}, k);
		};
		return (async () => {
			$("provisioning");
			try {
				let t = await D(O ?? "local");
				if (e) return;
				if (!t.ok) {
					N(), H(t.error ?? "Failed to hatch your assistant.");
					return;
				}
				if (t.assistantId && r(t.assistantId), $("connecting"), t.assistantId) {
					let t = !1;
					for (; !e && !t;) {
						let e = await u({ signal: AbortSignal.timeout(1e4) }).catch(() => null);
						if (e?.status === "ready") {
							t = !0;
							break;
						}
						if (e?.status === "unauthenticated") {
							E(), N(), H("We couldn't connect to your assistant. Please try again.");
							return;
						}
						if (Date.now() - a >= j) {
							E(), N(), H("Your assistant is taking longer than expected. Please try again.");
							return;
						}
						await new Promise((e) => {
							n = setTimeout(e, A);
						}), n = null;
					}
					if (e) return;
				}
				s(t.assistantId);
			} catch {
				if (N(), e) return;
				H("Failed to hatch your assistant. Please try again.");
			}
		})(), () => {
			e = !0, t && clearTimeout(t), n && clearTimeout(n);
		};
	}, [
		U,
		F,
		L,
		O,
		w,
		$
	]), _(() => {
		Z.current === 0 && (Z.current = Date.now());
		let e, t = () => {
			let n = Date.now() - Z.current, r = P[Y.current], i = ee(X.current, r, n);
			Q.current = i, K(i), r - i > 1e-6 && (e = requestAnimationFrame(t));
		};
		return e = requestAnimationFrame(t), () => cancelAnimationFrame(e);
	}, [q]), V ? /* @__PURE__ */ x(p, { children: /* @__PURE__ */ S("div", {
		role: "alert",
		className: "flex w-full flex-col items-center text-center text-[var(--content-default)]",
		children: [
			/* @__PURE__ */ x("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: C("hatchingScreen.genericFailure")
			}),
			/* @__PURE__ */ x("p", {
				className: "mt-3 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: V
			}),
			R ? /* @__PURE__ */ x("img", {
				src: R,
				alt: "",
				width: 160,
				height: 160,
				className: "my-10"
			}) : /* @__PURE__ */ x("div", {
				"aria-hidden": "true",
				className: "my-10 h-[160px] w-[160px] rounded-full bg-[var(--surface-raised)]"
			}),
			/* @__PURE__ */ S("div", {
				className: "flex w-full flex-col gap-2",
				children: [/* @__PURE__ */ x(a, {
					variant: "primary",
					size: "large",
					fullWidth: !0,
					onClick: () => {
						X.current = 0, Z.current = Date.now(), Y.current = "initializing", Q.current = 0, B("initializing"), K(0), J((e) => e + 1), H(null), W((e) => e + 1);
					},
					children: C("actions.tryAgain")
				}), /* @__PURE__ */ x(a, {
					variant: "outlined",
					size: "large",
					fullWidth: !0,
					onClick: () => {
						w(o.account.onboarding.hosting, m);
					},
					children: C("actions.back")
				})]
			})
		]
	}) }) : /* @__PURE__ */ x(p, { children: /* @__PURE__ */ S("div", {
		className: "flex w-full flex-col items-center text-center text-[var(--content-default)]",
		children: [
			/* @__PURE__ */ x("h1", {
				className: "text-3xl font-semibold tracking-tight",
				children: C(z === "ready" ? "hatchingScreen.ready" : "hatchingScreen.waking")
			}),
			z !== "ready" && /* @__PURE__ */ x("p", {
				className: "mt-3 text-body-medium-lighter text-[var(--content-tertiary)]",
				children: C("hatchingScreen.wakingBody")
			}),
			R ? /* @__PURE__ */ x("img", {
				src: R,
				alt: "",
				width: 160,
				height: 160,
				className: `my-10 ${z === "ready" ? "" : "animate-pulse"}`
			}) : /* @__PURE__ */ x("div", {
				"aria-hidden": "true",
				className: `my-10 h-[160px] w-[160px] rounded-full bg-[var(--surface-raised)] ${z === "ready" ? "" : "animate-pulse"}`
			}),
			/* @__PURE__ */ x(f, {
				value: G,
				height: 6,
				className: "w-full",
				"aria-label": C("hatchingScreen.progressAriaLabel")
			}),
			/* @__PURE__ */ x("p", {
				className: "mt-3 text-body-small-default text-[var(--content-tertiary)]",
				children: C(I[z])
			})
		]
	}) });
}
//#endregion
export { L as HatchingScreen };
