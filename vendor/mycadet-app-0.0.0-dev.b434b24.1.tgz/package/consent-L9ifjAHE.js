//#region src/i18n/locales/ru/consent.json
var e = {
	whatsChanged: "What's changed",
	agreements: "Agreements",
	agreeTo: "I agree to the <0>{policy}</0>"
}, t = {
	continue: "Continue",
	logOut: "Log out"
}, n = {
	consentControls: e,
	actions: t
};
//#endregion
export { t as actions, e as consentControls, n as default };
