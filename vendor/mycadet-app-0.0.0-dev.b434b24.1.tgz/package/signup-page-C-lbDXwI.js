import { s as e, t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { t as n } from "./external-anchor--Bf99ulE.js";
import { i as r, l as i } from "./schemas-D8_brjAQ.js";
import { n as a, r as o } from "./i18n-BRf-wfgm.js";
import { n as s, t as c } from "./routes-DW44XTQk.js";
import { d as l, f as u, m as d, n as f, p, r as m, s as h, t as g } from "./proxy-I7qEXaVt.js";
import { c as _ } from "./auth-store-Bx-RKZJ9.js";
import { n as v } from "./provider-DTIzxq2J.js";
import { r as y, t as b } from "./auth-flow-wtiOWtTR.js";
import { t as x } from "./provider-callback-BIm8IFvx.js";
import { n as S, t as C } from "./use-return-to-short-circuit-BXFgxgX8.js";
import { t as w } from "./signup-shell-Cs5VH0Xk.js";
import * as T from "react";
import { Children as E, isValidElement as D, useContext as O, useEffect as k, useId as A, useInsertionEffect as j, useMemo as M, useRef as N, useState as P } from "react";
import { Fragment as F, jsx as I, jsxs as L } from "react/jsx-runtime";
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/use-composed-ref.mjs
function R(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function z(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = R(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : R(e[t], null);
			}
		};
	};
}
function B(...e) {
	return T.useCallback(z(...e), e);
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
var V = class extends T.Component {
	getSnapshotBeforeUpdate(e) {
		let t = this.props.childRef.current;
		if (h(t) && e.isPresent && !this.props.isPresent && this.props.pop !== !1) {
			let e = t.offsetParent, n = h(e) && e.offsetWidth || 0, r = h(e) && e.offsetHeight || 0, i = getComputedStyle(t), a = this.props.sizeRef.current;
			a.height = parseFloat(i.height), a.width = parseFloat(i.width), a.top = t.offsetTop, a.left = t.offsetLeft, a.right = n - a.width - a.left, a.bottom = r - a.height - a.top, a.direction = i.direction;
		}
		return null;
	}
	componentDidUpdate() {}
	render() {
		return this.props.children;
	}
};
function H({ children: e, isPresent: t, anchorX: n, anchorY: r, root: i, pop: a }) {
	let o = A(), s = N(null), c = N({
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		direction: "ltr"
	}), { nonce: l } = O(m), u = B(s, a === !1 ? void 0 : e.props?.ref ?? e?.ref);
	return j(() => {
		let { width: e, height: u, top: d, left: f, right: p, bottom: m, direction: h } = c.current;
		if (t || a === !1 || !s.current || !e || !u) return;
		let g = h === "rtl", _ = n === "left" ? g ? `right: ${p}` : `left: ${f}` : g ? `left: ${f}` : `right: ${p}`, v = r === "bottom" ? `bottom: ${m}` : `top: ${d}`;
		s.current.dataset.motionPopId = o;
		let y = document.createElement("style");
		l && (y.nonce = l);
		let b = i ?? document.head;
		return b.appendChild(y), y.sheet && y.sheet.insertRule(`
          [data-motion-pop-id="${o}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${u}px !important;
            ${_}px !important;
            ${v}px !important;
          }
        `), () => {
			s.current?.removeAttribute("data-motion-pop-id"), b.contains(y) && b.removeChild(y);
		};
	}, [t]), I(V, {
		isPresent: t,
		childRef: s,
		sizeRef: c,
		pop: a,
		children: a === !1 ? e : T.cloneElement(e, { ref: u })
	});
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
var U = ({ children: e, initial: t, isPresent: n, onExitComplete: r, custom: i, presenceAffectsLayout: a, mode: o, anchorX: s, anchorY: c, root: d }) => {
	let f = p(W), m = A(), h = N(n), g = N(r);
	u(() => {
		h.current = n, g.current = r;
	});
	let _ = !0, v = M(() => (_ = !1, {
		id: m,
		initial: t,
		isPresent: n,
		custom: i,
		onExitComplete: (e) => {
			f.set(e, !0);
			for (let e of f.values()) if (!e) return;
			r && r();
		},
		register: (e) => (f.set(e, !1), () => {
			f.delete(e), !h.current && !f.size && g.current?.();
		})
	}), [
		n,
		f,
		r
	]);
	return a && _ && (v = { ...v }), M(() => {
		f.forEach((e, t) => f.set(t, !1));
	}, [n]), T.useEffect(() => {
		!n && !f.size && r && r();
	}, [n]), e = I(H, {
		pop: o === "popLayout",
		isPresent: n,
		anchorX: s,
		anchorY: c,
		root: d,
		children: e
	}), I(l.Provider, {
		value: v,
		children: e
	});
};
function W() {
	return /* @__PURE__ */ new Map();
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs
var G = (e) => e.key || "";
function K(e) {
	let t = [];
	return E.forEach(e, (e) => {
		D(e) && t.push(e);
	}), t;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
var q = ({ children: e, custom: t, initial: n = !0, onExitComplete: r, presenceAffectsLayout: i = !0, mode: a = "sync", propagate: o = !1, anchorX: s = "left", anchorY: c = "top", root: l }) => {
	let [m, h] = f(o), g = M(() => K(e), [e]), _ = o && !m ? [] : g.map(G), v = N(!0), y = N(g), b = p(() => /* @__PURE__ */ new Map()), x = N(/* @__PURE__ */ new Set()), [S, C] = P(g), [w, T] = P(g);
	u(() => {
		v.current = !1, y.current = g;
		for (let e = 0; e < w.length; e++) {
			let t = G(w[e]);
			_.includes(t) ? (b.delete(t), x.current.delete(t)) : b.get(t) !== !0 && b.set(t, !1);
		}
	}, [
		w,
		_.length,
		_.join("-")
	]);
	let E = [];
	if (g !== S) {
		let e = [...g];
		for (let t = 0; t < w.length; t++) {
			let n = w[t], r = G(n);
			_.includes(r) || (e.splice(t, 0, n), E.push(n));
		}
		return a === "wait" && E.length && (e = E), T(K(e)), C(g), null;
	}
	let { forceRender: D } = O(d);
	return I(F, { children: w.map((e) => {
		let u = G(e), d = o && !m ? !1 : g === w || _.includes(u);
		return I(U, {
			isPresent: d,
			initial: !v.current || n ? void 0 : !1,
			custom: t,
			presenceAffectsLayout: i,
			mode: a,
			root: l,
			onExitComplete: d ? void 0 : () => {
				if (x.current.has(u)) return;
				if (b.has(u)) x.current.add(u), b.set(u, !0);
				else return;
				let e = !0;
				b.forEach((t) => {
					t || (e = !1);
				}), e && (D?.(), T(y.current), o && h?.(), r && r());
			},
			anchorX: s,
			anchorY: c,
			children: e
		}, u);
	}) });
};
//#endregion
//#region src/domains/account/components/signup-closed-screen.tsx
function J({ returnTo: r }) {
	let { t: i } = o("account"), { search: l } = e(), u = y(r ? `${s.account.login}?returnTo=${encodeURIComponent(r)}` : s.account.login, l);
	return /* @__PURE__ */ L(w, { children: [
		/* @__PURE__ */ I("h1", {
			className: "signup__title",
			children: i("signupClosedScreen.title")
		}),
		/* @__PURE__ */ I("p", {
			className: "signup__subtitle",
			children: /* @__PURE__ */ I(a, {
				i18nKey: "signupClosedScreen.message",
				ns: "account",
				components: { selfHostingLink: /* @__PURE__ */ I(n, {
					href: c(s.docs.localHosting),
					tone: "default",
					glyph: !1
				}) }
			})
		}),
		/* @__PURE__ */ I("p", {
			className: "signup__footer",
			children: /* @__PURE__ */ I(a, {
				i18nKey: "signupClosedScreen.haveAccountPrompt",
				ns: "account",
				components: { signIn: /* @__PURE__ */ I(t, {
					className: "signup__link",
					to: u
				}) }
			})
		})
	] });
}
//#endregion
//#region src/components/icons/apple-logo.tsx
function Y({ size: e = 24, className: t, style: n }) {
	return /* @__PURE__ */ I("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		viewBox: "0 0 170 170",
		width: e,
		height: e,
		fill: "currentColor",
		className: t,
		style: n,
		"aria-hidden": !0,
		children: /* @__PURE__ */ I("path", { d: "M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.2-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.28 2.13-9.54 3.24-12.8 3.35-4.93.21-9.84-1.96-14.75-6.52-3.13-2.73-7.04-7.41-11.73-14.04-5.03-7.08-9.17-15.29-12.41-24.65-3.47-10.11-5.21-19.9-5.21-29.38 0-10.86 2.35-20.22 7.04-28.04 3.69-6.26 8.6-11.2 14.75-14.83 6.15-3.63 12.79-5.48 19.96-5.6 3.92 0 9.06 1.21 15.43 3.61 6.36 2.41 10.44 3.63 12.24 3.63 1.35 0 5.89-1.43 13.6-4.29 7.3-2.65 13.46-3.75 18.5-3.32 13.67 1.1 23.94 6.5 30.78 16.23-12.23 7.41-18.28 17.8-18.15 31.14.12 10.39 3.88 19.03 11.27 25.89 3.35 3.18 7.09 5.64 11.24 7.39-.9 2.61-1.85 5.11-2.86 7.51zM119.11 7.24c0 8.15-2.97 15.76-8.91 22.81-7.17 8.39-15.84 13.24-25.24 12.47a25.4 25.4 0 0 1-.19-3.09c0-7.82 3.4-16.18 9.44-23.02 3.01-3.47 6.84-6.35 11.49-8.66 4.64-2.27 9.03-3.53 13.16-3.75.12 1.1.25 2.19.25 3.24z" })
	});
}
//#endregion
//#region src/domains/account/components/rotating-word.tsx
function X({ words: e }) {
	let [t, n] = P(0), r = M(() => e.reduce((e, t) => e.length >= t.length ? e : t), [e]);
	return k(() => {
		let t = setInterval(() => {
			n((t) => (t + 1) % e.length);
		}, 2400);
		return () => clearInterval(t);
	}, [e.length]), /* @__PURE__ */ L("span", {
		className: "signup__rotating",
		children: [/* @__PURE__ */ L("span", {
			className: "signup__rotating-sizer",
			"aria-hidden": !0,
			children: [r, "."]
		}), /* @__PURE__ */ I(q, {
			mode: "wait",
			children: /* @__PURE__ */ L(g.em, {
				initial: {
					opacity: 0,
					y: 16
				},
				animate: {
					opacity: 1,
					y: 0
				},
				exit: {
					opacity: 0,
					y: -16
				},
				transition: {
					duration: .3,
					ease: "easeInOut"
				},
				children: [e[t], "."]
			}, e[t])
		})]
	});
}
//#endregion
//#region src/domains/account/components/signup-screen.tsx
var Z = [
	"signupScreen.headlineRoles.personalIntelligence",
	"signupScreen.headlineRoles.softwareEngineer",
	"signupScreen.headlineRoles.financeOps",
	"signupScreen.headlineRoles.householdManager",
	"signupScreen.headlineRoles.gtmEngineer",
	"signupScreen.headlineRoles.productLead"
];
function Q({ returnTo: e }) {
	let { t } = o("account"), n = M(() => Z.map((e) => t(e)), [t]), [r, i] = P(null), [s, c] = P(!1), l = (n, r) => {
		i(null), c(!0), b(v, x(e, { authIntent: n }), {
			returnTo: e,
			intent: n
		}).catch((e) => {
			console.error(r, e), i(t("authErrors.genericFailure"));
		}).finally(() => {
			c(!1);
		});
	};
	return /* @__PURE__ */ L(w, { children: [
		/* @__PURE__ */ L("h1", {
			className: "signup__title",
			children: [
				t("signupScreen.headlineLead"),
				/* @__PURE__ */ I("br", {}),
				/* @__PURE__ */ I(X, { words: n })
			]
		}),
		/* @__PURE__ */ I("p", {
			className: "signup__subtitle",
			children: t("signupScreen.subtitle")
		}),
		/* @__PURE__ */ I("div", {
			className: "signup__buttons",
			children: /* @__PURE__ */ I("button", {
				type: "button",
				className: "signup__btn",
				onClick: () => {
					l("signup", "[signup] auth flow failed:");
				},
				disabled: s,
				children: t("signupScreen.continue")
			})
		}),
		r && /* @__PURE__ */ I("p", {
			className: "signup__error",
			children: r
		}),
		/* @__PURE__ */ I("p", {
			className: "signup__footer",
			children: /* @__PURE__ */ I(a, {
				i18nKey: "signupScreen.haveAccountPrompt",
				ns: "account",
				components: { signIn: /* @__PURE__ */ I("button", {
					type: "button",
					className: "signup__link",
					onClick: () => {
						l(void 0, "[signup] sign-in flow failed:");
					},
					disabled: s
				}) }
			})
		}),
		/* @__PURE__ */ L("a", {
			className: "signup__download",
			href: "/downloads",
			children: [/* @__PURE__ */ I(Y, { size: 16 }), t("signupScreen.downloadMac")]
		})
	] });
}
//#endregion
//#region src/lib/auth/auth-config-schema.ts
var $ = i({ account: i({ is_open_for_signup: r() }) });
//#endregion
//#region src/lib/auth/auth-config-client.ts
function ee() {
	return _("config", $);
}
//#endregion
//#region src/domains/account/hooks/use-signup-availability.ts
var te = 5e3;
function ne({ enabled: e = !0, timeoutMs: t = te } = {}) {
	let [n, r] = P("pending");
	return k(() => {
		if (!e) return;
		let n = !1, i = (e) => {
			n || (n = !0, r(e));
		}, a = window.setTimeout(() => i("open"), t);
		return ee().then((e) => {
			i(e.ok && e.data.account.is_open_for_signup === !1 ? "closed" : "open");
		}, () => i("open")), () => {
			n = !0, window.clearTimeout(a);
		};
	}, [e, t]), n;
}
//#endregion
//#region src/domains/account/pages/signup-page.tsx
function re() {
	let e = C(), t = ne({ enabled: e.kind !== "redirect" });
	return e.kind === "redirect" ? e.node : e.kind === "wait" || t === "pending" ? /* @__PURE__ */ I(w, { children: /* @__PURE__ */ I(S, {}) }) : I(t === "closed" ? J : Q, { returnTo: e.returnTo });
}
//#endregion
export { re as SignupPage };
