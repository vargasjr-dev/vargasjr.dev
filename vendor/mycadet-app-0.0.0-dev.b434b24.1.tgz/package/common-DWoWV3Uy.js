//#region src/i18n/locales/ru/common.json
var e = {
	build: "Сборка",
	taglineMacOS: "ИИ-ассистент для вашего Mac",
	taglineWindows: "ИИ-ассистент для вашего ПК",
	version: "Версия"
}, t = {
	copied: "Скопировано",
	copyFailed: "Не удалось скопировать в буфер обмена."
}, n = { close: "Закрыть" }, r = {
	formatted: "Форматированный",
	modeAria: "Как показывать этот файл",
	source: "Исходный код"
}, i = { reconnecting: "Восстанавливаем соединение с вашим ассистентом…" }, a = { configureAutoReload: "Настроить автопополнение" }, o = { failed: "Не удалось подключиться к ассистенту." }, s = { setUp: "Настроить почту" }, c = { updateFailed: "Не удалось обновить «{label}». Изменение отменено." }, l = {
	verifyTitle: "Последний шаг: подтвердите, что это вы",
	verifyAction: "Подтвердить меня",
	verifyBody: "Ассистент ещё не знает, какой аккаунт {channel} ваш, поэтому не будет вам отвечать. Скажите в чате «подтверди меня в {channel}», чтобы закончить.",
	verifyActionBody: "Ассистент ещё не знает, какой аккаунт {channel} ваш, поэтому не будет вам отвечать. Он завершит это с вами в чате.",
	verifiedTitle: "Личность подтверждена",
	verifiedBody: "Ассистент знает ваш аккаунт {channel} и будет вам отвечать. Всё готово."
}, u = {
	announcement: {
		body: "Теперь я могу быть рядом в любом месте рабочего стола.",
		cards: {
			context: {
				body: "Покажите мне экран, чтобы я помог с учётом контекста.",
				title: "Покажите и объясните"
			},
			flow: {
				body: "Обращайтесь ко мне, не выходя из текущего приложения.",
				title: "Не отвлекайтесь от работы"
			},
			together: {
				body: "Говорите, указывайте и двигайтесь вперёд вместе со мной.",
				title: "Работайте вместе со мной"
			}
		},
		close: "Закрыть",
		previewLabel: "Ваш помощник на рабочем столе",
		previewAssistantName: "Quill",
		start: "Поехали",
		title: "Я рядом, пока вы работаете"
	},
	ariaLabel: "Знакомство с компаньоном",
	back: "Назад",
	call: {
		click: "Нажмите",
		line: "Слушаю",
		shortcut: "Сочетание"
	},
	close: "Закрыть",
	done: "Понятно",
	draw: {
		body: "Укажите на что угодно на экране",
		title: "Рисуйте"
	},
	idle: {
		body: "Наведите на меня курсор, и я появлюсь.",
		title: "Привет, это я",
		titleNamed: "Привет, это {name}"
	},
	key: {
		scolded: "Нет, клавишу на клавиатуре",
		title: "Сделайте общение со мной проще"
	},
	meet: { body: "Я остаюсь на рабочем столе, даже когда Cadet не видно." },
	mute: {
		body: "Нажмите микрофон, чтобы отключить себя, или динамик, чтобы отключить меня",
		title: "Без звука"
	},
	next: "Далее",
	share: {
		body: "Покажите мне вкладку, окно или весь экран",
		title: "Поделитесь экраном"
	},
	talk: {
		body: "Нажмите на меня, чтобы начать разговор.",
		gesture: "Или дважды нажмите эту клавишу:",
		greeted: "Получилось! Вот и всё.",
		title: "Поговорите со мной"
	},
	try: {
		body: "Скажите привет, и я отвечу вслух.",
		how: "Нажмите на меня или дважды нажмите клавишу",
		title: "Попробуйте"
	},
	permission: {
		microphoneAction: "Включить микрофон",
		microphoneSettingsHint: "Включите доступ Cadet к микрофону в Системных настройках, затем вернитесь сюда.",
		microphonePromptHint: "macOS попросит разрешить доступ к микрофону.",
		microphoneBody: "Разрешите использовать микрофон для голосовых разговоров.",
		shortcutBody: "Разрешите горячую клавишу в других приложениях.",
		screenAction: "Включить показ экрана",
		screenBody: "Настройте показ экрана. Что показать, вы выберете позже.",
		openSettings: "Открыть настройки",
		settingsHint: "Разрешите доступ в настройках и вернитесь сюда.",
		restricted: "Доступ ограничен. Шаг можно пропустить.",
		error: "Не удалось проверить доступ. Попробуйте ещё раз.",
		waiting: "Проверка доступа…",
		skip: "Пропустить"
	}
}, d = {
	sharingScreen: "Показываем ваш экран",
	sharingScreenNamed: "Показываем ваш экран {name}",
	sharingWindow: "Показываем окно",
	sharingWindowNamed: "Показываем окно {name}",
	teaching: "Обучаем",
	teachingNamed: "Обучаем {name}"
}, f = { untitled: "Без названия" }, p = {
	appExported: "Приложение экспортировано",
	deployFailed: "Не удалось опубликовать",
	deployedToVercel: "Опубликовано на Vercel",
	open: "Открыть",
	shareFailed: "Не удалось поделиться приложением"
}, m = { tooltip: "Стоп" }, h = {
	ariaLabelMacOS: "Скачать приложение для macOS",
	ariaLabelWindows: "Скачать приложение для Windows",
	ctaAriaLabelMacOS: "Скачать приложение для macOS",
	ctaAriaLabelWindows: "Скачать приложение для Windows",
	ctaLabel: "Скачать",
	subtitle: "Работа с компьютером · доступ к терминалу · нативная автоматизация",
	titleMacOS: "Установите приложение для macOS",
	titleWindows: "Установите приложение для Windows"
}, g = {
	instructions: "Вставьте токен бота, скопированный со страницы Bot.",
	verificationNoticeTitle: "Игнорируйте страницу «Verify your App»",
	verificationNoticeBody: "Discord показывает её каждому новому приложению. Она важна только после 100 серверов.",
	botTokenLabel: "Токен бота",
	save: "Подключить",
	saving: "Подключение...",
	saved: "Подключено. Теперь добавьте бота на сервер.",
	botTokenPlaceholder: "MTk4NjIyNDgzNzAyNDU0..."
}, _ = {
	inPortal: "На портале разработчиков Discord:",
	stepCreateApp: "Нажмите <strong>New Application</strong> и назовите приложение именем ассистента:",
	copyName: "Скопировать имя",
	copied: "Скопировано!",
	stepAppIcon: "Необязательно: скачайте аватар и загрузите его на странице <strong>General Information</strong> как значок приложения.",
	stepResetToken: "Перейдите на страницу <strong>Bot</strong> в меню приложения, нажмите <strong>Reset Token</strong> и сразу скопируйте токен. Discord показывает его только один раз.",
	stepIntentsOff: "На той же странице оставьте все три переключателя <strong>Privileged Gateway Intents</strong> выключенными. Ассистенту они не нужны: он читает только личные сообщения и сообщения с упоминанием.",
	openPortal: "Открыть портал Discord",
	continue: "Токен у меня есть"
}, v = {
	connectedTitle: "Бот добавлен",
	connectedBody: "Токен сохранён, бот на вашем сервере. Со стороны Discord всё готово."
}, y = {
	instructions: "Бот ничего не видит и не отвечает, пока не войдёт на сервер. Откройте ссылку, выберите свой сервер и подтвердите.",
	openInvite: "Добавить на сервер",
	confirmJoined: "Бот уже на сервере",
	noAppId: "Сначала подключите токен бота, затем вернитесь, чтобы добавить его на сервер."
}, b = {
	channelLabel: "Discord",
	stepCreate: "Создать приложение",
	stepConnect: "Подключить",
	stepInvite: "Добавить на сервер",
	stepFinish: "Завершение",
	copyError: "Не удалось скопировать имя. Введите его в Discord вручную."
}, x = {
	checkingDomain: "Проверка домена…",
	domainVerified: "Домен подтверждён",
	failedTitle: "Не удалось подтвердить домен. Записи DNS могли ещё не распространиться. Освободите домен и зарегистрируйте его снова.",
	unknownStatus: "Неизвестный статус",
	unknownStatusTitle: "Не удалось получить статус проверки домена.",
	verificationFailed: "Проверка не прошла",
	verifiedTitle: "Записи DNS подтверждены. Домен готов отправлять и получать почту.",
	verifyingDomain: "Проверка домена…",
	verifyingTitle: "Записи DNS подготовлены. Ждём, пока почтовый провайдер их подтвердит: обычно это несколько минут.",
	setupRequired: "Требуется настройка домена",
	setupRequiredTitle: "Этот домен не подготовлен у почтового провайдера. Он не может отправлять или получать почту, пока настройка не будет завершена."
}, S = {
	failed: "Не удалось скачать файл",
	revealMac: "Показать в Finder",
	revealWindows: "Показать в проводнике",
	saved: "Сохранено в папку «Загрузки»",
	started: "Скачивание началось",
	startedDescription: "Файл {filename} появится в загрузках браузера."
}, C = { goToConversation: "Перейти к диалогу" }, w = { body: "Управляемые сервисы тарифицируются и списываются с баланса аккаунта Cadet. <link>Смотреть цены</link>" }, T = {
	bannerAria: "Скачать приложение {appName}",
	bannerAriaGeneric: "Скачать приложение Cadet",
	download: "Скачать",
	downloadAppAria: "Скачать приложение {appName}",
	downloadAppAriaGeneric: "Скачать приложение Cadet",
	subtitle: "Push-уведомления · биометрический вход · тактильная отдача",
	title: "Приложение {appName}",
	titleGeneric: "Приложение Cadet"
}, E = {
	title: "Ассистенту нужно больше мощности",
	titleNamed: "{assistantName} нуждается в большей мощности",
	body: "Ассистент усердно работает и приближается к пределу доступных ресурсов. Обновите план, чтобы он продолжал работать без сбоев.",
	bodyNoUpgrade: "Ассистент усердно работает и приближается к пределу доступных ресурсов.",
	upgrade: "Обновить план",
	dontShowAgain: "Больше не показывать"
}, D = { unnamedAssistant: "ассистент" }, O = { ariaLabel: "Действия: {name}" }, k = {
	managedLabel: "Управляемые",
	modeToggleAriaLabel: "Режим сервиса",
	yourOwnLabel: "Свои"
}, A = {
	windowsNativeDisplayName: "Windows Native Dictation",
	windowsNativeSubtitle: "Распознавание речи Windows на устройстве, локально через вспомогательную программу Windows. Работает без сети и не требует API-ключа.",
	windowsNativeSetupWarning: "Нужно базовое распознавание речи для языка интерфейса Windows: Параметры > Время и язык > Язык и регион, три точки рядом с языком интерфейса, Параметры языка, в разделе Возможности языка: Базовое распознавание речи."
}, j = { deleteFailed: "Не удалось удалить приложение" }, M = {
	copyFailed: "Не удалось скопировать ссылку. Откройте её: {url}",
	linkCopied: "Ссылка скопирована",
	open: "Открыть"
}, N = {
	setupPrompt: {
		slack: "Я хочу связываться с тобой в Slack. Давай настроим.",
		telegram: "Я хочу связываться с тобой в Telegram. Давай настроим.",
		discord: "Я хочу связываться с тобой в Discord. Давай настроим.",
		email: "Я хочу писать тебе по электронной почте. Давай настроим твой адрес.",
		phone: "Я хочу иметь возможность звонить тебе. Давай настроим тебе номер телефона."
	},
	finishPrompt: {
		slack: "Slack настроен, но не работает. Можешь доделать?",
		telegram: "Telegram настроен, но не работает. Можешь доделать?",
		discord: "Discord настроен, но не работает. Можешь доделать?",
		email: "Мой адрес электронной почты настроен, но не работает. Можешь доделать?",
		phone: "Мой номер телефона настроен, но не работает. Можешь доделать?"
	}
}, P = {
	addFailed: "Не удалось добавить закладку.",
	removeFailed: "Не удалось удалить закладку."
}, F = {
	exchangeFailed: "Проверьте вставленный ключ и повторите попытку.",
	failed: "Не удалось подключить Claude. Повторите попытку.",
	notStarted: "Сначала запуск сценария Connect Claude.",
	pasteEmpty: "Вставка кода со страницы Claude.",
	popupBlocked: "Браузер заблокировал вкладку входа. Разрешение всплывающих окон для этого сайта, затем снова Подключить.",
	startFailed: "Не удалось запустить Connect Claude. Повторите попытку.",
	timedOut: "Время ожидания подключения Claude истекло. Повторите попытку."
}, I = {
	accountConnected: "Аккаунт {name} подключён.",
	authorizationError: "Ошибка {name}: {code}",
	authorizationFailed: "Авторизация {name} не удалась",
	popupBlocked: "Всплывающее окно заблокировано. Разрешите всплывающие окна и повторите попытку.",
	startFailed: "Не удалось начать авторизацию {name}.",
	startFailedWithReason: "Не удалось начать авторизацию {name}: {reason}"
}, L = {
	blocked: "Браузер заблокировал страницу, которую ассистент пытался открыть.",
	openPage: "Открыть страницу"
}, R = { updated: "Тема обновлена" }, z = {
	file: "Файл",
	view: "Вид",
	developer: "Разработчик",
	help: "Справка"
}, B = {
	expandedValue: "Развёрнутое значение",
	showLess: "Показать меньше",
	showMore: "Показать больше"
}, V = {
	title: "Имя ассистента",
	description: "Публичное имя вашего ассистента. На нём же строится его адрес электронной почты.",
	helper: "Строчные буквы, цифры, дефисы, подчёркивания."
}, H = { send: "Отправить сообщение" }, U = {
	confirm: "Удалить",
	messageOrigin: "Это не повлияет на {assistantName} и не выведет вас из аккаунта там. Устройство просто забудет эту запись. Добавить её можно в любой момент.",
	messagePaired: "Это не повлияет на {assistantName} на его хост-машине. Устройство просто забудет сопряжение. Сопрячь снова можно в любой момент через cadet connect import.",
	messagePlatform: "Это не удалит {assistantName}. Он просто исчезнет с этого устройства. Вход в аккаунт вернёт его.",
	title: "Удалить с этого устройства?",
	removeFailed: "Не удалось удалить устройство из ассистента"
}, W = {
	close: "Закрыть",
	closePanel: "Закрыть панель",
	loading: "Загрузка…"
}, G = {
	back: "Вернуться к обучению",
	dragInstruction: "Перетащите {app} в список, чтобы разрешить «{permission}».",
	dragApp: "Перетащите {app} в Системные настройки или нажмите, чтобы показать в Finder",
	dragError: "Перетаскивание недоступно. Попробуйте из Finder.",
	showInFinder: "Показать в Finder",
	inputLabel: "Мониторинг ввода"
}, K = {
	loopback: "Это loopback-адрес, до которого другие устройства не достучатся. Нужен публичный https URL ассистента.",
	nonHttps: "URL должен использовать https, чтобы устройства подключались безопасно.",
	privateAddress: "Этот адрес указывает на адрес частной сети. Введите публичный https URL ассистента, чтобы устройства могли до него достучаться.",
	serviceFallbackName: "провайдер туннеля",
	serviceWebsite: "Это сайт {service}, а не адрес ассистента. Запустите туннель на хосте, чтобы получить адрес; список провайдеров: `cadet tunnel --help`.",
	unparseable: "Нужен корректный URL, например https://your-assistant.ts.net."
}, q = {
	aboutPage: e,
	copyButton: t,
	featureIntroModal: n,
	fileViewMode: r,
	statusBanner: i,
	addCreditsModal: a,
	assistantConnect: o,
	assistantEmailIntroModal: s,
	assistantFeatureFlagStore: c,
	channelSetupCompleteNotice: l,
	companionIntro: u,
	companionWatchFramePage: d,
	conversationTitle: f,
	deployStore: p,
	detailPanelStopButton: m,
	desktopAppBanner: h,
	discordSetupConnectStep: g,
	discordSetupCreateStep: _,
	discordSetupFinishStep: v,
	discordSetupInviteStep: y,
	discordSetupWizard: b,
	domainVerificationChip: x,
	downloadFeedback: S,
	localNotification: C,
	managedServicesBanner: w,
	nativeAppBanner: T,
	resourcePressureBanner: E,
	rootLayout: D,
	sectionActionsButton: O,
	serviceCard: k,
	sttProviderForm: A,
	useAppDelete: j,
	useAppDeployment: M,
	useAssistantChannels: N,
	useBookmarks: P,
	useConnectClaude: F,
	useOauthConnect: I,
	useOpenUrlDirectives: L,
	useWorkspaceTheme: R,
	windowsMenuBar: z,
	detailPrimitives: B,
	assistantHandleModal: V,
	quickInputPage: H,
	removeFromDeviceDialog: U,
	detailShell: W,
	permissionGuide: G,
	pairDeviceUrl: K
};
//#endregion
export { e as aboutPage, a as addCreditsModal, o as assistantConnect, s as assistantEmailIntroModal, c as assistantFeatureFlagStore, V as assistantHandleModal, l as channelSetupCompleteNotice, u as companionIntro, d as companionWatchFramePage, f as conversationTitle, t as copyButton, q as default, p as deployStore, h as desktopAppBanner, m as detailPanelStopButton, B as detailPrimitives, W as detailShell, g as discordSetupConnectStep, _ as discordSetupCreateStep, v as discordSetupFinishStep, y as discordSetupInviteStep, b as discordSetupWizard, x as domainVerificationChip, S as downloadFeedback, n as featureIntroModal, r as fileViewMode, C as localNotification, w as managedServicesBanner, T as nativeAppBanner, K as pairDeviceUrl, G as permissionGuide, H as quickInputPage, U as removeFromDeviceDialog, E as resourcePressureBanner, D as rootLayout, O as sectionActionsButton, k as serviceCard, i as statusBanner, A as sttProviderForm, j as useAppDelete, M as useAppDeployment, N as useAssistantChannels, P as useBookmarks, F as useConnectClaude, I as useOauthConnect, L as useOpenUrlDirectives, R as useWorkspaceTheme, z as windowsMenuBar };
