//#region ../../node_modules/.bun/@capacitor+core@8.3.4/node_modules/@capacitor/core/dist/index.js
var e;
(function(e) {
	e.Unimplemented = "UNIMPLEMENTED", e.Unavailable = "UNAVAILABLE";
})(e ||= {});
var t = class extends Error {
	constructor(e, t, n) {
		super(e), this.message = e, this.code = t, this.data = n;
	}
}, n = (e) => e?.androidBridge ? "android" : e?.webkit?.messageHandlers?.bridge ? "ios" : "web", r = (r) => {
	let i = r.CapacitorCustomPlatform || null, a = r.Capacitor || {}, o = a.Plugins = a.Plugins || {}, s = () => i === null ? n(r) : i.name, c = () => s() !== "web", l = (e) => !!(f.get(e)?.platforms.has(s()) || u(e)), u = (e) => a.PluginHeaders?.find((t) => t.name === e), d = (e) => r.console.error(e), f = /* @__PURE__ */ new Map();
	return a.convertFileSrc ||= (e) => e, a.getPlatform = s, a.handleError = d, a.isNativePlatform = c, a.isPluginAvailable = l, a.registerPlugin = (n, r = {}) => {
		let c = f.get(n);
		if (c) return console.warn(`Capacitor plugin "${n}" already registered. Cannot register plugins twice.`), c.proxy;
		let l = s(), d = u(n), p, m = async () => (!p && l in r ? p = p = typeof r[l] == "function" ? await r[l]() : r[l] : i !== null && !p && "web" in r && (p = p = typeof r.web == "function" ? await r.web() : r.web), p), h = (r, i) => {
			if (d) {
				let e = d?.methods.find((e) => i === e.name);
				if (e) return e.rtype === "promise" ? (e) => a.nativePromise(n, i.toString(), e) : (e, t) => a.nativeCallback(n, i.toString(), e, t);
				if (r) return r[i]?.bind(r);
			} else if (r) return r[i]?.bind(r);
			else throw new t(`"${n}" plugin is not implemented on ${l}`, e.Unimplemented);
		}, g = (r) => {
			let i, a = (...a) => {
				let o = m().then((o) => {
					let s = h(o, r);
					if (s) {
						let e = s(...a);
						return i = e?.remove, e;
					} else throw new t(`"${n}.${r}()" is not implemented on ${l}`, e.Unimplemented);
				});
				return r === "addListener" && (o.remove = async () => i()), o;
			};
			return a.toString = () => `${r.toString()}() { [capacitor code] }`, Object.defineProperty(a, "name", {
				value: r,
				writable: !1,
				configurable: !1
			}), a;
		}, _ = g("addListener"), v = g("removeListener"), y = (e, t) => {
			let n = _({ eventName: e }, t), r = async () => {
				v({
					eventName: e,
					callbackId: await n
				}, t);
			}, i = new Promise((e) => n.then(() => e({ remove: r })));
			return i.remove = async () => {
				console.warn("Using addListener() without 'await' is deprecated."), await r();
			}, i;
		}, b = new Proxy({}, { get(e, t) {
			switch (t) {
				case "$$typeof": return;
				case "toJSON": return () => ({});
				case "addListener": return d ? y : _;
				case "removeListener": return v;
				default: return g(t);
			}
		} });
		return o[n] = b, f.set(n, {
			name: n,
			proxy: b,
			platforms: new Set([...Object.keys(r), ...d ? [l] : []])
		}), b;
	}, a.Exception = t, a.DEBUG = !!a.DEBUG, a.isLoggingEnabled = !!a.isLoggingEnabled, a;
}, i = /* @__PURE__ */ ((e) => e.Capacitor = r(e))(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {}), a = i.registerPlugin, o = class {
	constructor() {
		this.listeners = {}, this.retainedEventArguments = {}, this.windowListeners = {};
	}
	addListener(e, t) {
		let n = !1;
		this.listeners[e] || (this.listeners[e] = [], n = !0), this.listeners[e].push(t);
		let r = this.windowListeners[e];
		return r && !r.registered && this.addWindowListener(r), n && this.sendRetainedArgumentsForEvent(e), Promise.resolve({ remove: async () => this.removeListener(e, t) });
	}
	async removeAllListeners() {
		this.listeners = {};
		for (let e in this.windowListeners) this.removeWindowListener(this.windowListeners[e]);
		this.windowListeners = {};
	}
	notifyListeners(e, t, n) {
		let r = this.listeners[e];
		if (!r) {
			if (n) {
				let n = this.retainedEventArguments[e];
				n ||= [], n.push(t), this.retainedEventArguments[e] = n;
			}
			return;
		}
		r.forEach((e) => e(t));
	}
	hasListeners(e) {
		return !!this.listeners[e]?.length;
	}
	registerWindowListener(e, t) {
		this.windowListeners[t] = {
			registered: !1,
			windowEventName: e,
			pluginEventName: t,
			handler: (e) => {
				this.notifyListeners(t, e);
			}
		};
	}
	unimplemented(t = "not implemented") {
		return new i.Exception(t, e.Unimplemented);
	}
	unavailable(t = "not available") {
		return new i.Exception(t, e.Unavailable);
	}
	async removeListener(e, t) {
		let n = this.listeners[e];
		if (!n) return;
		let r = n.indexOf(t);
		this.listeners[e].splice(r, 1), this.listeners[e].length || this.removeWindowListener(this.windowListeners[e]);
	}
	addWindowListener(e) {
		window.addEventListener(e.windowEventName, e.handler), e.registered = !0;
	}
	removeWindowListener(e) {
		e && (window.removeEventListener(e.windowEventName, e.handler), e.registered = !1);
	}
	sendRetainedArgumentsForEvent(e) {
		let t = this.retainedEventArguments[e];
		t && (delete this.retainedEventArguments[e], t.forEach((t) => {
			this.notifyListeners(e, t);
		}));
	}
}, s = (e) => encodeURIComponent(e).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape), c = (e) => e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent), l = class extends o {
	async getCookies() {
		let e = document.cookie, t = {};
		return e.split(";").forEach((e) => {
			if (e.length <= 0) return;
			let [n, r] = e.replace(/=/, "CAP_COOKIE").split("CAP_COOKIE");
			n = c(n).trim(), r = c(r).trim(), t[n] = r;
		}), t;
	}
	async setCookie(e) {
		try {
			let t = s(e.key), n = s(e.value), r = e.expires ? `; expires=${e.expires.replace("expires=", "")}` : "", i = (e.path || "/").replace("path=", ""), a = e.url != null && e.url.length > 0 ? `domain=${e.url}` : "";
			document.cookie = `${t}=${n || ""}${r}; path=${i}; ${a};`;
		} catch (e) {
			return Promise.reject(e);
		}
	}
	async deleteCookie(e) {
		try {
			document.cookie = `${e.key}=; Max-Age=0`;
		} catch (e) {
			return Promise.reject(e);
		}
	}
	async clearCookies() {
		try {
			let e = document.cookie.split(";") || [];
			for (let t of e) document.cookie = t.replace(/^ +/, "").replace(/=.*/, `=;expires=${(/* @__PURE__ */ new Date()).toUTCString()};path=/`);
		} catch (e) {
			return Promise.reject(e);
		}
	}
	async clearAllCookies() {
		try {
			await this.clearCookies();
		} catch (e) {
			return Promise.reject(e);
		}
	}
};
a("CapacitorCookies", { web: () => new l() });
var u = async (e) => new Promise((t, n) => {
	let r = new FileReader();
	r.onload = () => {
		let e = r.result;
		t(e.indexOf(",") >= 0 ? e.split(",")[1] : e);
	}, r.onerror = (e) => n(e), r.readAsDataURL(e);
}), d = (e = {}) => {
	let t = Object.keys(e);
	return Object.keys(e).map((e) => e.toLocaleLowerCase()).reduce((n, r, i) => (n[r] = e[t[i]], n), {});
}, f = (e, t = !0) => e ? Object.entries(e).reduce((e, n) => {
	let [r, i] = n, a, o;
	return Array.isArray(i) ? (o = "", i.forEach((e) => {
		a = t ? encodeURIComponent(e) : e, o += `${r}=${a}&`;
	}), o.slice(0, -1)) : (a = t ? encodeURIComponent(i) : i, o = `${r}=${a}`), `${e}&${o}`;
}, "").substr(1) : null, p = (e, t = {}) => {
	let n = Object.assign({
		method: e.method || "GET",
		headers: e.headers
	}, t), r = d(e.headers)["content-type"] || "";
	if (typeof e.data == "string") n.body = e.data;
	else if (r.includes("application/x-www-form-urlencoded")) {
		let t = new URLSearchParams();
		for (let [n, r] of Object.entries(e.data || {})) t.set(n, r);
		n.body = t.toString();
	} else if (r.includes("multipart/form-data") || e.data instanceof FormData) {
		let t = new FormData();
		if (e.data instanceof FormData) e.data.forEach((e, n) => {
			t.append(n, e);
		});
		else for (let n of Object.keys(e.data)) t.append(n, e.data[n]);
		n.body = t;
		let r = new Headers(n.headers);
		r.delete("content-type"), n.headers = r;
	} else (r.includes("application/json") || typeof e.data == "object") && (n.body = JSON.stringify(e.data));
	return n;
}, m = class extends o {
	async request(e) {
		let t = p(e, e.webFetchExtra), n = f(e.params, e.shouldEncodeUrlParams), r = n ? `${e.url}?${n}` : e.url, i = await fetch(r, t), a = i.headers.get("content-type") || "", { responseType: o = "text" } = i.ok ? e : {};
		a.includes("application/json") && (o = "json");
		let s, c;
		switch (o) {
			case "arraybuffer":
			case "blob":
				c = await i.blob(), s = await u(c);
				break;
			case "json":
				s = await i.json();
				break;
			default: s = await i.text();
		}
		let l = {};
		return i.headers.forEach((e, t) => {
			l[t] = e;
		}), {
			data: s,
			headers: l,
			status: i.status,
			url: i.url
		};
	}
	async get(e) {
		return this.request(Object.assign(Object.assign({}, e), { method: "GET" }));
	}
	async post(e) {
		return this.request(Object.assign(Object.assign({}, e), { method: "POST" }));
	}
	async put(e) {
		return this.request(Object.assign(Object.assign({}, e), { method: "PUT" }));
	}
	async patch(e) {
		return this.request(Object.assign(Object.assign({}, e), { method: "PATCH" }));
	}
	async delete(e) {
		return this.request(Object.assign(Object.assign({}, e), { method: "DELETE" }));
	}
};
a("CapacitorHttp", { web: () => new m() });
var h;
(function(e) {
	e.Dark = "DARK", e.Light = "LIGHT", e.Default = "DEFAULT";
})(h ||= {});
var g;
(function(e) {
	e.StatusBar = "StatusBar", e.NavigationBar = "NavigationBar";
})(g ||= {});
var _ = class extends o {
	async setStyle() {
		this.unavailable("not available for web");
	}
	async setAnimation() {
		this.unavailable("not available for web");
	}
	async show() {
		this.unavailable("not available for web");
	}
	async hide() {
		this.unavailable("not available for web");
	}
};
a("SystemBars", { web: () => new _() });
//#endregion
export { o as n, a as r, i as t };
