import { n as e } from "./loader-circle-Ch7lYSrj.js";
var t = e("check", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]);
//#endregion
export { t };
