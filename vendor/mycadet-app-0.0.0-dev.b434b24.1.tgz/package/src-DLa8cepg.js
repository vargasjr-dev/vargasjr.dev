import { a as e, r as t, t as n } from "./chunk-C5e3QaDY.js";
import { n as r } from "./loader-circle-Ch7lYSrj.js";
import { t as i } from "./check-DPXe7vV_.js";
import "./select-B4GhYADp.js";
import { _ as a, a as o, c as s, d as c, f as l, i as u, l as d, m as f, o as p, p as m, s as h, u as g } from "./confirm-dialog-DH3yi6Nk.js";
import "./checkbox-r-BQDIah.js";
import { n as _, o as v, t as y } from "./dist-CB0DYkRa.js";
import { A as b, C as x, D as S, E as C, O as w, S as T, T as E, a as D, c as O, d as k, f as A, i as j, j as M, k as N, l as ee, n as te, o as ne, s as re, u as ie } from "./button-BrPHE1Q9.js";
import { t as ae } from "./typography-DAhYh88V.js";
import { n as oe, t as se } from "./es2015-B_BDkut6.js";
import { t as ce } from "./text-link-DoFyv9Mp.js";
import "./progress-bar-CfBUP_JA.js";
import { a as le, c as ue, d as de, f as fe, i as pe, l as me, n as he, o as ge, r as _e, s as ve, t as ye, u as be } from "./web-namespaces-CN13pIWg.js";
import * as P from "react";
import { Children as xe, createContext as Se, isValidElement as Ce, memo as we, useCallback as Te, useContext as Ee, useEffect as De, useId as Oe, useLayoutEffect as ke, useMemo as Ae, useRef as je, useState as Me, useSyncExternalStore as Ne } from "react";
import { Fragment as Pe, jsx as F, jsxs as I } from "react/jsx-runtime";
var Fe = r("chevron-right", [["path", {
	d: "m9 18 6-6-6-6",
	key: "mthhwq"
}]]), Ie = r("circle", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}]]), Le = r("copy", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]), Re = "(width < 48rem) and (pointer: coarse)";
function ze() {
	return Ne(Te((e) => {
		let t = window.matchMedia(Re);
		return t.addEventListener("change", e), () => t.removeEventListener("change", e);
	}, []), Te(() => window.matchMedia(Re).matches, []), () => !1);
}
//#endregion
//#region ../../packages/design-library/src/components/bottom-sheet.tsx
var Be = Se({});
function Ve({ open: e, defaultOpen: t = !1, modal: n = !0, onOpenChange: r, ...i }) {
	let [a, s] = Me(t), c = e ?? a, l = (t) => {
		t !== c && (e === void 0 && s(t), r?.(t));
	};
	return /* @__PURE__ */ F(Be, {
		value: {
			open: c,
			modal: n,
			onOpenChange: l
		},
		children: /* @__PURE__ */ F(o, {
			open: c,
			modal: n,
			onOpenChange: l,
			...i
		})
	});
}
function He(e) {
	return /* @__PURE__ */ F(l, {
		"data-slot": "bottom-sheet-trigger",
		...e
	});
}
function Ue({ variant: e = "default", dragHandleLabel: t, overlayClassName: n, className: r, padded: i = !0, children: a, onInteractOutside: o, ref: s, style: c, ...l }) {
	let f = j(), { open: p, modal: m, onOpenChange: _ } = Ee(Be), y = u({ onDismiss: () => _?.(!1) });
	return /* @__PURE__ */ I(g, {
		container: f ?? void 0,
		children: [/* @__PURE__ */ F(d, {
			"data-slot": "bottom-sheet-overlay",
			"data-variant": e,
			className: v("fixed inset-0 z-50 bg-black/50", n),
			...y
		}), /* @__PURE__ */ F(h, {
			ref: s,
			"data-slot": "bottom-sheet-content",
			"data-variant": e,
			onInteractOutside: (e) => {
				o?.(e), m && e.preventDefault();
			},
			inert: e === "detail" && !p ? !0 : void 0,
			style: e === "detail" ? {
				pointerEvents: "none",
				...c
			} : c,
			className: v("fixed inset-x-0 bottom-0 z-50 flex w-full flex-col focus:outline-none", e === "detail" ? "pointer-events-none h-[100dvh] justify-end" : "min-h-[min(280px,45dvh)] max-h-[50dvh] rounded-t-[24px] border-t bg-[var(--surface-lift)] border-[var(--border-base)] shadow-xl data-[state=open]:animate-[bottomSheetIn_180ms_ease-out]", r),
			...l,
			children: /* @__PURE__ */ I("div", {
				"data-slot": "bottom-sheet-content-inner",
				className: v("flex min-h-0 flex-col", e === "detail" ? "pointer-events-auto mb-[calc(-1*var(--bottom-sheet-bottom-inset,0px))] h-[calc(90%+var(--bottom-sheet-bottom-inset,0px))] pb-[var(--bottom-sheet-bottom-inset,0px)] overflow-hidden rounded-t-[24px] border-t border-[var(--border-base)] bg-[var(--surface-lift)] shadow-xl" : "flex-1", i && "px-4 pt-4 pb-[calc(16px+var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px)))]"),
				children: [e === "detail" && /* @__PURE__ */ F(Ge, {
					label: t,
					onDismiss: () => _?.(!1)
				}), a]
			})
		})]
	});
}
var We = 100;
function Ge({ onDismiss: e, label: t }) {
	let n = je(null), r = (r, i = !1) => {
		let a = n.current;
		!a || a.pointerId !== r.pointerId || (n.current = null, delete a.sheet.dataset.dragging, !i && (a.offset >= We || t && !a.moved) ? e() : (a.sheet.dataset.snapping = "true", a.sheet.style.setProperty("--bottom-sheet-drag-offset", "0px")), r.currentTarget.hasPointerCapture(r.pointerId) && r.currentTarget.releasePointerCapture(r.pointerId));
	};
	return /* @__PURE__ */ F(t ? "button" : "div", {
		"data-slot": "bottom-sheet-drag-handle",
		type: t ? "button" : void 0,
		"aria-label": t,
		"aria-hidden": t ? void 0 : !0,
		onClick: t ? (t) => {
			t.detail === 0 && e();
		} : void 0,
		className: "flex h-8 shrink-0 cursor-grab touch-none select-none items-center justify-center outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)] active:cursor-grabbing",
		onPointerDown: (e) => {
			if (!e.isPrimary || e.button !== 0) return;
			let t = e.currentTarget.closest("[data-slot=\"bottom-sheet-content\"]");
			t && (e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), delete t.dataset.snapping, t.dataset.dragging = "true", n.current = {
				pointerId: e.pointerId,
				startY: e.clientY,
				startX: e.clientX,
				offset: 0,
				moved: !1,
				sheet: t
			});
		},
		onPointerMove: (e) => {
			let t = n.current;
			!t || t.pointerId !== e.pointerId || (t.offset = Math.max(0, e.clientY - t.startY), t.moved ||= Math.hypot(e.clientY - t.startY, e.clientX - t.startX) > 5, t.sheet.style.setProperty("--bottom-sheet-drag-offset", `${t.offset}px`));
		},
		onPointerUp: (e) => r(e),
		onPointerCancel: (e) => r(e, !0),
		onLostPointerCapture: (e) => r(e, !0),
		children: /* @__PURE__ */ F("div", { className: "h-1 w-14 rounded-full bg-[var(--border-element)]" })
	});
}
function Ke({ icon: e, className: t, children: n, ref: r, ...i }) {
	return /* @__PURE__ */ I(c, {
		ref: r,
		"data-slot": "bottom-sheet-title",
		className: v("flex items-center gap-3 text-title-medium text-[var(--content-default)]", t),
		...i,
		children: [e ? /* @__PURE__ */ F("span", {
			"aria-hidden": "true",
			className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
			style: { backgroundColor: "color-mix(in oklab, var(--primary-base) 16%, transparent)" },
			children: /* @__PURE__ */ F(e, { className: "h-5 w-5 text-[var(--primary-base)]" })
		}) : null, /* @__PURE__ */ F("span", {
			className: "min-w-0 truncate leading-snug",
			children: n
		})]
	});
}
function qe({ className: e, children: t, ref: n, ...r }) {
	return /* @__PURE__ */ F(s, {
		ref: n,
		"data-slot": "bottom-sheet-description",
		className: v("mt-1 whitespace-pre-line text-body-medium-lighter text-[var(--content-secondary)]", e),
		...r,
		children: t
	});
}
function Je(e) {
	return /* @__PURE__ */ F(p, {
		"data-slot": "bottom-sheet-close",
		...e
	});
}
function Ye({ className: e, ...t }) {
	return /* @__PURE__ */ F("div", {
		"data-slot": "bottom-sheet-grabber",
		"aria-hidden": "true",
		className: v("mx-auto h-1 w-14 shrink-0 rounded-full bg-[var(--border-element)]", e),
		...t
	});
}
function Xe({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ F("div", {
		"data-slot": "bottom-sheet-header",
		className: v("flex flex-col gap-1", e),
		...n,
		children: t
	});
}
function Ze({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ F("div", {
		"data-slot": "bottom-sheet-body",
		className: v("flex-1 overflow-y-auto pt-4 text-[var(--content-default)]", e),
		...n,
		children: t
	});
}
function Qe({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ F("div", {
		"data-slot": "bottom-sheet-footer",
		className: v("flex justify-end gap-2 pt-4", e),
		...n,
		children: t
	});
}
var $e = {
	Root: Ve,
	Trigger: He,
	Content: Ue,
	Title: Ke,
	Description: qe,
	Close: Je,
	Grabber: Ye,
	Header: Xe,
	Body: Ze,
	Footer: Qe
};
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-collection@1.1.11+07ecf1aa3bcbed22/node_modules/@radix-ui/react-collection/dist/index.mjs
function et(e) {
	let t = e + "CollectionProvider", [n, r] = N(t), [i, a] = n(t, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	}), o = (e) => {
		let { scope: t, children: n } = e, r = P.useRef(null), a = P.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ F(i, {
			scope: t,
			itemMap: a,
			collectionRef: r,
			children: n
		});
	};
	o.displayName = t;
	let s = e + "CollectionSlot", c = w(s), l = P.forwardRef((e, t) => {
		let { scope: n, children: r } = e;
		return /* @__PURE__ */ F(c, {
			ref: b(t, a(s, n).collectionRef),
			children: r
		});
	});
	l.displayName = s;
	let u = e + "CollectionItemSlot", d = "data-radix-collection-item", f = w(u), p = P.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = P.useRef(null), s = b(t, o), c = a(u, n);
		return P.useEffect(() => (c.itemMap.set(o, {
			ref: o,
			...i
		}), () => void c.itemMap.delete(o))), /* @__PURE__ */ F(f, {
			[d]: "",
			ref: s,
			children: r
		});
	});
	p.displayName = u;
	function m(t) {
		let n = a(e + "CollectionConsumer", t);
		return P.useCallback(() => {
			let e = n.collectionRef.current;
			if (!e) return [];
			let t = Array.from(e.querySelectorAll(`[${d}]`));
			return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
		}, [n.collectionRef, n.itemMap]);
	}
	return [
		{
			Provider: o,
			Slot: l,
			ItemSlot: p
		},
		m,
		r
	];
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-direction@1.1.2+bf264c7668a20073/node_modules/@radix-ui/react-direction/dist/index.mjs
var tt = P.createContext(void 0);
function nt(e) {
	let t = P.useContext(tt);
	return e || t || "ltr";
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-roving-focus@1.1.14+07ecf1aa3bcbed22/node_modules/@radix-ui/react-roving-focus/dist/index.mjs
var rt = "rovingFocusGroup.onEntryFocus", it = {
	bubbles: !1,
	cancelable: !0
}, at = "RovingFocusGroup", [ot, st, ct] = et(at), [lt, ut] = N(at, [ct]), [dt, ft] = lt(at), pt = P.forwardRef((e, t) => /* @__PURE__ */ F(ot.Provider, {
	scope: e.__scopeRovingFocusGroup,
	children: /* @__PURE__ */ F(ot.Slot, {
		scope: e.__scopeRovingFocusGroup,
		children: /* @__PURE__ */ F(mt, {
			...e,
			ref: t
		})
	})
}));
pt.displayName = at;
var mt = P.forwardRef((e, t) => {
	let { __scopeRovingFocusGroup: n, orientation: r, loop: i = !1, dir: a, currentTabStopId: o, defaultCurrentTabStopId: s, onCurrentTabStopIdChange: c, onEntryFocus: l, preventScrollOnEntryFocus: u = !1, ...d } = e, f = P.useRef(null), p = b(t, f), m = nt(a), [h, g] = D({
		prop: o,
		defaultProp: s ?? null,
		onChange: c,
		caller: at
	}), [_, v] = P.useState(!1), y = E(l), x = st(n), S = P.useRef(!1), [w, T] = P.useState(0);
	return P.useEffect(() => {
		let e = f.current;
		if (e) return e.addEventListener(rt, y), () => e.removeEventListener(rt, y);
	}, [y]), /* @__PURE__ */ F(dt, {
		scope: n,
		orientation: r,
		dir: m,
		loop: i,
		currentTabStopId: h,
		onItemFocus: P.useCallback((e) => g(e), [g]),
		onItemShiftTab: P.useCallback(() => v(!0), []),
		onFocusableItemAdd: P.useCallback(() => T((e) => e + 1), []),
		onFocusableItemRemove: P.useCallback(() => T((e) => e - 1), []),
		children: /* @__PURE__ */ F(C.div, {
			tabIndex: _ || w === 0 ? -1 : 0,
			"data-orientation": r,
			...d,
			ref: p,
			style: {
				outline: "none",
				...e.style
			},
			onMouseDown: M(e.onMouseDown, () => {
				S.current = !0;
			}),
			onFocus: M(e.onFocus, (e) => {
				let t = !S.current;
				if (e.target === e.currentTarget && t && !_) {
					let t = new CustomEvent(rt, it);
					if (e.currentTarget.dispatchEvent(t), !t.defaultPrevented) {
						let e = x().filter((e) => e.focusable);
						bt([
							e.find((e) => e.active),
							e.find((e) => e.id === h),
							...e
						].filter(Boolean).map((e) => e.ref.current), u);
					}
				}
				S.current = !1;
			}),
			onBlur: M(e.onBlur, () => v(!1))
		})
	});
}), ht = "RovingFocusGroupItem", gt = P.forwardRef((e, t) => {
	let { __scopeRovingFocusGroup: n, focusable: r = !0, active: i = !1, tabStopId: a, children: o, ...s } = e, c = T(), l = a || c, u = ft(ht, n), d = u.currentTabStopId === l, f = st(n), { onFocusableItemAdd: p, onFocusableItemRemove: m, currentTabStopId: h } = u;
	return P.useEffect(() => {
		if (r) return p(), () => m();
	}, [
		r,
		p,
		m
	]), /* @__PURE__ */ F(ot.ItemSlot, {
		scope: n,
		id: l,
		focusable: r,
		active: i,
		children: /* @__PURE__ */ F(C.span, {
			tabIndex: d ? 0 : -1,
			"data-orientation": u.orientation,
			...s,
			ref: t,
			onMouseDown: M(e.onMouseDown, (e) => {
				r ? u.onItemFocus(l) : e.preventDefault();
			}),
			onFocus: M(e.onFocus, () => u.onItemFocus(l)),
			onKeyDown: M(e.onKeyDown, (e) => {
				if (e.key === "Tab" && e.shiftKey) {
					u.onItemShiftTab();
					return;
				}
				if (e.target !== e.currentTarget) return;
				let t = yt(e, u.orientation, u.dir);
				if (t !== void 0) {
					if (e.metaKey || e.ctrlKey || e.altKey || e.shiftKey) return;
					e.preventDefault();
					let n = f().filter((e) => e.focusable).map((e) => e.ref.current);
					if (t === "last") n.reverse();
					else if (t === "prev" || t === "next") {
						t === "prev" && n.reverse();
						let r = n.indexOf(e.currentTarget);
						n = u.loop ? xt(n, r + 1) : n.slice(r + 1);
					}
					setTimeout(() => bt(n));
				}
			}),
			children: typeof o == "function" ? o({
				isCurrentTabStop: d,
				hasTabStop: h != null
			}) : o
		})
	});
});
gt.displayName = ht;
var _t = {
	ArrowLeft: "prev",
	ArrowUp: "prev",
	ArrowRight: "next",
	ArrowDown: "next",
	PageUp: "first",
	Home: "first",
	PageDown: "last",
	End: "last"
};
function vt(e, t) {
	return t === "rtl" ? e === "ArrowLeft" ? "ArrowRight" : e === "ArrowRight" ? "ArrowLeft" : e : e;
}
function yt(e, t, n) {
	let r = vt(e.key, n);
	if (!(t === "vertical" && ["ArrowLeft", "ArrowRight"].includes(r)) && !(t === "horizontal" && ["ArrowUp", "ArrowDown"].includes(r))) return _t[r];
}
function bt(e, t = !1) {
	let n = document.activeElement;
	for (let r of e) if (r === n || (r.focus({ preventScroll: t }), document.activeElement !== n)) return;
}
function xt(e, t) {
	return e.map((n, r) => e[(t + r) % e.length]);
}
var St = pt, Ct = gt, wt = ["Enter", " "], Tt = [
	"ArrowDown",
	"PageUp",
	"Home"
], Et = [
	"ArrowUp",
	"PageDown",
	"End"
], Dt = [...Tt, ...Et], Ot = {
	ltr: [...wt, "ArrowRight"],
	rtl: [...wt, "ArrowLeft"]
}, kt = {
	ltr: ["ArrowLeft"],
	rtl: ["ArrowRight"]
}, At = "Menu", [jt, Mt, Nt] = et(At), [Pt, Ft] = N(At, [
	Nt,
	A,
	ut
]), It = A(), Lt = ut(), [Rt, zt] = Pt(At), [Bt, Vt] = Pt(At), Ht = (e) => {
	let { __scopeMenu: t, open: n = !1, children: r, dir: i, onOpenChange: a, modal: o = !0 } = e, s = It(t), [c, l] = P.useState(null), u = P.useRef(!1), d = E(a), f = nt(i);
	return P.useEffect(() => {
		let e = () => {
			u.current = !0, document.addEventListener("pointerdown", t, {
				capture: !0,
				once: !0
			}), document.addEventListener("pointermove", t, {
				capture: !0,
				once: !0
			});
		}, t = () => u.current = !1;
		return document.addEventListener("keydown", e, { capture: !0 }), () => {
			document.removeEventListener("keydown", e, { capture: !0 }), document.removeEventListener("pointerdown", t, { capture: !0 }), document.removeEventListener("pointermove", t, { capture: !0 });
		};
	}, []), P.useEffect(() => {
		if (!n) return;
		let e = () => d(!1);
		return window.addEventListener("blur", e), () => window.removeEventListener("blur", e);
	}, [n, d]), /* @__PURE__ */ F(k, {
		...s,
		children: /* @__PURE__ */ F(Rt, {
			scope: t,
			open: n,
			onOpenChange: d,
			content: c,
			onContentChange: l,
			children: /* @__PURE__ */ F(Bt, {
				scope: t,
				onClose: P.useCallback(() => d(!1), [d]),
				isUsingKeyboardRef: u,
				dir: f,
				modal: o,
				children: r
			})
		})
	});
};
Ht.displayName = At;
var Ut = "MenuAnchor", Wt = P.forwardRef((e, t) => {
	let { __scopeMenu: n, ...r } = e;
	return /* @__PURE__ */ F(O, {
		...It(n),
		...r,
		ref: t
	});
});
Wt.displayName = Ut;
var Gt = "MenuPortal", [Kt, qt] = Pt(Gt, { forceMount: void 0 }), Jt = (e) => {
	let { __scopeMenu: t, forceMount: n, children: r, container: i } = e, a = zt(Gt, t);
	return /* @__PURE__ */ F(Kt, {
		scope: t,
		forceMount: n,
		children: /* @__PURE__ */ F(ne, {
			present: n || a.open,
			children: /* @__PURE__ */ F(re, {
				asChild: !0,
				container: i,
				children: r
			})
		})
	});
};
Jt.displayName = Gt;
var Yt = "MenuContent", [Xt, Zt] = Pt(Yt), Qt = P.forwardRef((e, t) => {
	let n = qt(Yt, e.__scopeMenu), { forceMount: r = n.forceMount, ...i } = e, a = zt(Yt, e.__scopeMenu), o = Vt(Yt, e.__scopeMenu);
	return /* @__PURE__ */ F(jt.Provider, {
		scope: e.__scopeMenu,
		children: /* @__PURE__ */ F(ne, {
			present: r || a.open,
			children: /* @__PURE__ */ F(jt.Slot, {
				scope: e.__scopeMenu,
				children: o.modal ? /* @__PURE__ */ F($t, {
					...i,
					ref: t
				}) : /* @__PURE__ */ F(en, {
					...i,
					ref: t
				})
			})
		})
	});
}), $t = P.forwardRef((e, t) => {
	let n = zt(Yt, e.__scopeMenu), r = P.useRef(null), i = b(t, r);
	return P.useEffect(() => {
		let e = r.current;
		if (e) return se(e);
	}, []), /* @__PURE__ */ F(nn, {
		...e,
		ref: i,
		trapFocus: n.open,
		disableOutsidePointerEvents: n.open,
		disableOutsideScroll: !0,
		onFocusOutside: M(e.onFocusOutside, (e) => e.preventDefault(), { checkForDefaultPrevented: !1 }),
		onDismiss: () => n.onOpenChange(!1)
	});
}), en = P.forwardRef((e, t) => {
	let n = zt(Yt, e.__scopeMenu);
	return /* @__PURE__ */ F(nn, {
		...e,
		ref: t,
		trapFocus: !1,
		disableOutsidePointerEvents: !1,
		disableOutsideScroll: !1,
		onDismiss: () => n.onOpenChange(!1)
	});
}), tn = w("MenuContent.ScrollLock"), nn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, loop: r = !1, trapFocus: i, onOpenAutoFocus: a, onCloseAutoFocus: o, disableOutsidePointerEvents: s, onEntryFocus: c, onEscapeKeyDown: l, onPointerDownOutside: u, onFocusOutside: d, onInteractOutside: p, onDismiss: h, disableOutsideScroll: g, ..._ } = e, v = zt(Yt, n), y = Vt(Yt, n), S = It(n), C = Lt(n), w = Mt(n), [T, E] = P.useState(null), D = P.useRef(null), O = b(t, D, v.onContentChange), k = P.useRef(0), A = P.useRef(""), j = P.useRef(0), N = P.useRef(null), ee = P.useRef("right"), te = P.useRef(0), ne = g ? oe : P.Fragment, re = g ? {
		as: tn,
		allowPinchZoom: !0
	} : void 0, ae = (e) => {
		let t = A.current + e, n = w().filter((e) => !e.disabled), r = document.activeElement, i = n.find((e) => e.ref.current === r)?.textValue, a = Vn(n.map((e) => e.textValue), t, i), o = n.find((e) => e.textValue === a)?.ref.current;
		(function e(t) {
			A.current = t, window.clearTimeout(k.current), t !== "" && (k.current = window.setTimeout(() => e(""), 1e3));
		})(t), o && setTimeout(() => o.focus());
	};
	P.useEffect(() => () => window.clearTimeout(k.current), []), m();
	let se = P.useCallback((e) => ee.current === N.current?.side && Un(e, N.current?.area), []);
	return /* @__PURE__ */ F(Xt, {
		scope: n,
		searchRef: A,
		onItemEnter: P.useCallback((e) => {
			se(e) && e.preventDefault();
		}, [se]),
		onItemLeave: P.useCallback((e) => {
			se(e) || (D.current?.focus(), E(null));
		}, [se]),
		onTriggerLeave: P.useCallback((e) => {
			se(e) && e.preventDefault();
		}, [se]),
		pointerGraceTimerRef: j,
		onPointerGraceIntentChange: P.useCallback((e) => {
			N.current = e;
		}, []),
		children: /* @__PURE__ */ F(ne, {
			...re,
			children: /* @__PURE__ */ F(f, {
				asChild: !0,
				trapped: i,
				onMountAutoFocus: M(a, (e) => {
					e.preventDefault(), D.current?.focus({ preventScroll: !0 });
				}),
				onUnmountAutoFocus: o,
				children: /* @__PURE__ */ F(x, {
					asChild: !0,
					disableOutsidePointerEvents: s,
					onEscapeKeyDown: l,
					onPointerDownOutside: u,
					onFocusOutside: d,
					onInteractOutside: p,
					onDismiss: h,
					children: /* @__PURE__ */ F(St, {
						asChild: !0,
						...C,
						dir: y.dir,
						orientation: "vertical",
						loop: r,
						currentTabStopId: T,
						onCurrentTabStopIdChange: E,
						onEntryFocus: M(c, (e) => {
							y.isUsingKeyboardRef.current || e.preventDefault();
						}),
						preventScrollOnEntryFocus: !0,
						children: /* @__PURE__ */ F(ie, {
							role: "menu",
							"aria-orientation": "vertical",
							"data-state": In(v.open),
							"data-radix-menu-content": "",
							dir: y.dir,
							...S,
							..._,
							ref: O,
							style: {
								outline: "none",
								..._.style
							},
							onKeyDown: M(_.onKeyDown, (e) => {
								let t = e.target.closest("[data-radix-menu-content]") === e.currentTarget, n = e.ctrlKey || e.altKey || e.metaKey, r = e.key.length === 1;
								t && (e.key === "Tab" && e.preventDefault(), !n && r && ae(e.key));
								let i = D.current;
								if (e.target !== i || !Dt.includes(e.key)) return;
								e.preventDefault();
								let a = w().filter((e) => !e.disabled).map((e) => e.ref.current);
								Et.includes(e.key) && a.reverse(), zn(a);
							}),
							onBlur: M(e.onBlur, (e) => {
								e.currentTarget.contains(e.target) || (window.clearTimeout(k.current), A.current = "");
							}),
							onPointerMove: M(e.onPointerMove, Wn((e) => {
								let t = e.target, n = te.current !== e.clientX;
								e.currentTarget.contains(t) && n && (ee.current = e.clientX > te.current ? "right" : "left", te.current = e.clientX);
							}))
						})
					})
				})
			})
		})
	});
});
Qt.displayName = Yt;
var rn = "MenuGroup", an = P.forwardRef((e, t) => {
	let { __scopeMenu: n, ...r } = e;
	return /* @__PURE__ */ F(C.div, {
		role: "group",
		...r,
		ref: t
	});
});
an.displayName = rn;
var on = "MenuLabel", sn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, ...r } = e;
	return /* @__PURE__ */ F(C.div, {
		...r,
		ref: t
	});
});
sn.displayName = on;
var cn = "MenuItem", ln = "menu.itemSelect", un = P.forwardRef((e, t) => {
	let { disabled: n = !1, onSelect: r, ...i } = e, a = P.useRef(null), o = Vt(cn, e.__scopeMenu), s = Zt(cn, e.__scopeMenu), c = b(t, a), l = P.useRef(!1), u = () => {
		let e = a.current;
		if (!n && e) {
			let t = new CustomEvent(ln, {
				bubbles: !0,
				cancelable: !0
			});
			e.addEventListener(ln, (e) => r?.(e), { once: !0 }), S(e, t), t.defaultPrevented ? l.current = !1 : o.onClose();
		}
	};
	return /* @__PURE__ */ F(dn, {
		...i,
		ref: c,
		disabled: n,
		onClick: M(e.onClick, u),
		onPointerDown: (t) => {
			e.onPointerDown?.(t), l.current = !0;
		},
		onPointerUp: M(e.onPointerUp, (e) => {
			l.current || e.currentTarget?.click();
		}),
		onKeyDown: M(e.onKeyDown, (e) => {
			let t = s.searchRef.current !== "";
			n || t && e.key === " " || wt.includes(e.key) && (e.currentTarget.click(), e.preventDefault());
		})
	});
});
un.displayName = cn;
var dn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, disabled: r = !1, textValue: i, ...a } = e, o = Zt(cn, n), s = Lt(n), c = P.useRef(null), l = b(t, c), [u, d] = P.useState(!1), [f, p] = P.useState("");
	return P.useEffect(() => {
		let e = c.current;
		e && p((e.textContent ?? "").trim());
	}, [a.children]), /* @__PURE__ */ F(jt.ItemSlot, {
		scope: n,
		disabled: r,
		textValue: i ?? f,
		children: /* @__PURE__ */ F(Ct, {
			asChild: !0,
			...s,
			focusable: !r,
			children: /* @__PURE__ */ F(C.div, {
				role: "menuitem",
				"data-highlighted": u ? "" : void 0,
				"aria-disabled": r || void 0,
				"data-disabled": r ? "" : void 0,
				...a,
				ref: l,
				onPointerMove: M(e.onPointerMove, Wn((e) => {
					r ? o.onItemLeave(e) : (o.onItemEnter(e), e.defaultPrevented || e.currentTarget.focus({ preventScroll: !0 }));
				})),
				onPointerLeave: M(e.onPointerLeave, Wn((e) => o.onItemLeave(e))),
				onFocus: M(e.onFocus, () => d(!0)),
				onBlur: M(e.onBlur, () => d(!1))
			})
		})
	});
}), fn = "MenuCheckboxItem", pn = P.forwardRef((e, t) => {
	let { checked: n = !1, onCheckedChange: r, ...i } = e;
	return /* @__PURE__ */ F(xn, {
		scope: e.__scopeMenu,
		checked: n,
		children: /* @__PURE__ */ F(un, {
			role: "menuitemcheckbox",
			"aria-checked": Ln(n) ? "mixed" : n,
			...i,
			ref: t,
			"data-state": Rn(n),
			onSelect: M(i.onSelect, () => r?.(Ln(n) ? !0 : !n), { checkForDefaultPrevented: !1 })
		})
	});
});
pn.displayName = fn;
var mn = "MenuRadioGroup", [hn, gn] = Pt(mn, {
	value: void 0,
	onValueChange: () => {}
}), _n = P.forwardRef((e, t) => {
	let { value: n, onValueChange: r, ...i } = e, a = E(r);
	return /* @__PURE__ */ F(hn, {
		scope: e.__scopeMenu,
		value: n,
		onValueChange: a,
		children: /* @__PURE__ */ F(an, {
			...i,
			ref: t
		})
	});
});
_n.displayName = mn;
var vn = "MenuRadioItem", yn = P.forwardRef((e, t) => {
	let { value: n, ...r } = e, i = gn(vn, e.__scopeMenu), a = n === i.value;
	return /* @__PURE__ */ F(xn, {
		scope: e.__scopeMenu,
		checked: a,
		children: /* @__PURE__ */ F(un, {
			role: "menuitemradio",
			"aria-checked": a,
			...r,
			ref: t,
			"data-state": Rn(a),
			onSelect: M(r.onSelect, () => i.onValueChange?.(n), { checkForDefaultPrevented: !1 })
		})
	});
});
yn.displayName = vn;
var bn = "MenuItemIndicator", [xn, Sn] = Pt(bn, { checked: !1 }), Cn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, forceMount: r, ...i } = e, a = Sn(bn, n);
	return /* @__PURE__ */ F(ne, {
		present: r || Ln(a.checked) || a.checked === !0,
		children: /* @__PURE__ */ F(C.span, {
			...i,
			ref: t,
			"data-state": Rn(a.checked)
		})
	});
});
Cn.displayName = bn;
var wn = "MenuSeparator", Tn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, ...r } = e;
	return /* @__PURE__ */ F(C.div, {
		role: "separator",
		"aria-orientation": "horizontal",
		...r,
		ref: t
	});
});
Tn.displayName = wn;
var En = "MenuArrow", Dn = P.forwardRef((e, t) => {
	let { __scopeMenu: n, ...r } = e;
	return /* @__PURE__ */ F(ee, {
		...It(n),
		...r,
		ref: t
	});
});
Dn.displayName = En;
var On = "MenuSub", [kn, An] = Pt(On), jn = (e) => {
	let { __scopeMenu: t, children: n, open: r = !1, onOpenChange: i } = e, a = zt(On, t), o = It(t), [s, c] = P.useState(null), [l, u] = P.useState(null), d = E(i);
	return P.useEffect(() => (a.open === !1 && d(!1), () => d(!1)), [a.open, d]), /* @__PURE__ */ F(k, {
		...o,
		children: /* @__PURE__ */ F(Rt, {
			scope: t,
			open: r,
			onOpenChange: d,
			content: l,
			onContentChange: u,
			children: /* @__PURE__ */ F(kn, {
				scope: t,
				contentId: T(),
				triggerId: T(),
				trigger: s,
				onTriggerChange: c,
				children: n
			})
		})
	});
};
jn.displayName = On;
var Mn = "MenuSubTrigger", Nn = P.forwardRef((e, t) => {
	let n = zt(Mn, e.__scopeMenu), r = Vt(Mn, e.__scopeMenu), i = An(Mn, e.__scopeMenu), a = Zt(Mn, e.__scopeMenu), o = P.useRef(null), { pointerGraceTimerRef: s, onPointerGraceIntentChange: c } = a, l = { __scopeMenu: e.__scopeMenu }, u = P.useCallback(() => {
		o.current && window.clearTimeout(o.current), o.current = null;
	}, []);
	P.useEffect(() => u, [u]), P.useEffect(() => {
		let e = s.current;
		return () => {
			window.clearTimeout(e), c(null);
		};
	}, [s, c]);
	let d = b(t, i.onTriggerChange);
	return /* @__PURE__ */ F(Wt, {
		asChild: !0,
		...l,
		children: /* @__PURE__ */ F(dn, {
			id: i.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": n.open,
			"aria-controls": n.open ? i.contentId : void 0,
			"data-state": In(n.open),
			...e,
			ref: d,
			onClick: (t) => {
				e.onClick?.(t), !(e.disabled || t.defaultPrevented) && (t.currentTarget.focus(), n.open || n.onOpenChange(!0));
			},
			onPointerMove: M(e.onPointerMove, Wn((t) => {
				a.onItemEnter(t), !t.defaultPrevented && !e.disabled && !n.open && !o.current && (a.onPointerGraceIntentChange(null), o.current = window.setTimeout(() => {
					n.onOpenChange(!0), u();
				}, 100));
			})),
			onPointerLeave: M(e.onPointerLeave, Wn((e) => {
				u();
				let t = n.content?.getBoundingClientRect();
				if (t) {
					let r = n.content?.dataset.side, i = r === "right", o = i ? -5 : 5, c = t[i ? "left" : "right"], l = t[i ? "right" : "left"];
					a.onPointerGraceIntentChange({
						area: [
							{
								x: e.clientX + o,
								y: e.clientY
							},
							{
								x: c,
								y: t.top
							},
							{
								x: l,
								y: t.top
							},
							{
								x: l,
								y: t.bottom
							},
							{
								x: c,
								y: t.bottom
							}
						],
						side: r
					}), window.clearTimeout(s.current), s.current = window.setTimeout(() => a.onPointerGraceIntentChange(null), 300);
				} else {
					if (a.onTriggerLeave(e), e.defaultPrevented) return;
					a.onPointerGraceIntentChange(null);
				}
			})),
			onKeyDown: M(e.onKeyDown, (t) => {
				let i = a.searchRef.current !== "";
				e.disabled || i && t.key === " " || Ot[r.dir].includes(t.key) && (n.onOpenChange(!0), n.content?.focus(), t.preventDefault());
			})
		})
	});
});
Nn.displayName = Mn;
var Pn = "MenuSubContent", Fn = P.forwardRef((e, t) => {
	let n = qt(Yt, e.__scopeMenu), { forceMount: r = n.forceMount, align: i = "start", ...a } = e, o = zt(Yt, e.__scopeMenu), s = Vt(Yt, e.__scopeMenu), c = An(Pn, e.__scopeMenu), l = P.useRef(null), u = b(t, l);
	return /* @__PURE__ */ F(jt.Provider, {
		scope: e.__scopeMenu,
		children: /* @__PURE__ */ F(ne, {
			present: r || o.open,
			children: /* @__PURE__ */ F(jt.Slot, {
				scope: e.__scopeMenu,
				children: /* @__PURE__ */ F(nn, {
					id: c.contentId,
					"aria-labelledby": c.triggerId,
					...a,
					ref: u,
					align: i,
					side: s.dir === "rtl" ? "left" : "right",
					disableOutsidePointerEvents: !1,
					disableOutsideScroll: !1,
					trapFocus: !1,
					onOpenAutoFocus: (e) => {
						s.isUsingKeyboardRef.current && l.current?.focus(), e.preventDefault();
					},
					onCloseAutoFocus: (e) => e.preventDefault(),
					onFocusOutside: M(e.onFocusOutside, (e) => {
						e.target !== c.trigger && o.onOpenChange(!1);
					}),
					onEscapeKeyDown: M(e.onEscapeKeyDown, (e) => {
						s.onClose(), e.preventDefault();
					}),
					onKeyDown: M(e.onKeyDown, (e) => {
						let t = e.currentTarget.contains(e.target), n = kt[s.dir].includes(e.key);
						t && n && (o.onOpenChange(!1), c.trigger?.focus(), e.preventDefault());
					})
				})
			})
		})
	});
});
Fn.displayName = Pn;
function In(e) {
	return e ? "open" : "closed";
}
function Ln(e) {
	return e === "indeterminate";
}
function Rn(e) {
	return Ln(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
function zn(e) {
	let t = document.activeElement;
	for (let n of e) if (n === t || (n.focus(), document.activeElement !== t)) return;
}
function Bn(e, t) {
	return e.map((n, r) => e[(t + r) % e.length]);
}
function Vn(e, t, n) {
	let r = t.length > 1 && Array.from(t).every((e) => e === t[0]) ? t[0] : t, i = n ? e.indexOf(n) : -1, a = Bn(e, Math.max(i, 0));
	r.length === 1 && (a = a.filter((e) => e !== n));
	let o = a.find((e) => e.toLowerCase().startsWith(r.toLowerCase()));
	return o === n ? void 0 : o;
}
function Hn(e, t) {
	let { x: n, y: r } = e, i = !1;
	for (let e = 0, a = t.length - 1; e < t.length; a = e++) {
		let o = t[e], s = t[a], c = o.x, l = o.y, u = s.x, d = s.y;
		l > r != d > r && n < (u - c) * (r - l) / (d - l) + c && (i = !i);
	}
	return i;
}
function Un(e, t) {
	return t ? Hn({
		x: e.clientX,
		y: e.clientY
	}, t) : !1;
}
function Wn(e) {
	return (t) => t.pointerType === "mouse" ? e(t) : void 0;
}
var Gn = Ht, Kn = Wt, qn = Jt, Jn = Qt, Yn = an, Xn = sn, Zn = un, Qn = pn, $n = _n, er = yn, tr = Cn, nr = Tn, rr = Dn, ir = jn, ar = Nn, or = Fn, sr = "DropdownMenu", [cr, lr] = N(sr, [Ft]), L = Ft(), [ur, dr] = cr(sr), fr = (e) => {
	let { __scopeDropdownMenu: t, children: n, dir: r, open: i, defaultOpen: a, onOpenChange: o, modal: s = !0 } = e, c = L(t), l = P.useRef(null), [u, d] = D({
		prop: i,
		defaultProp: a ?? !1,
		onChange: o,
		caller: sr
	});
	return /* @__PURE__ */ F(ur, {
		scope: t,
		triggerId: T(),
		triggerRef: l,
		contentId: T(),
		open: u,
		onOpenChange: d,
		onOpenToggle: P.useCallback(() => d((e) => !e), [d]),
		modal: s,
		children: /* @__PURE__ */ F(Gn, {
			...c,
			open: u,
			onOpenChange: d,
			dir: r,
			modal: s,
			children: n
		})
	});
};
fr.displayName = sr;
var pr = "DropdownMenuTrigger", mr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, disabled: r = !1, ...i } = e, a = dr(pr, n), o = L(n), s = b(t, a.triggerRef);
	return /* @__PURE__ */ F(Kn, {
		asChild: !0,
		...o,
		children: /* @__PURE__ */ F(C.button, {
			type: "button",
			id: a.triggerId,
			"aria-haspopup": "menu",
			"aria-expanded": a.open,
			"aria-controls": a.open ? a.contentId : void 0,
			"data-state": a.open ? "open" : "closed",
			"data-disabled": r ? "" : void 0,
			disabled: r,
			...i,
			ref: s,
			onPointerDown: M(e.onPointerDown, (e) => {
				!r && e.button === 0 && e.ctrlKey === !1 && (a.onOpenToggle(), a.open || e.preventDefault());
			}),
			onKeyDown: M(e.onKeyDown, (e) => {
				r || (["Enter", " "].includes(e.key) && a.onOpenToggle(), e.key === "ArrowDown" && a.onOpenChange(!0), [
					"Enter",
					" ",
					"ArrowDown"
				].includes(e.key) && e.preventDefault());
			})
		})
	});
});
mr.displayName = pr;
var hr = "DropdownMenuPortal", gr = (e) => {
	let { __scopeDropdownMenu: t, ...n } = e;
	return /* @__PURE__ */ F(qn, {
		...L(t),
		...n
	});
};
gr.displayName = hr;
var _r = "DropdownMenuContent", vr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e, i = dr(_r, n), a = L(n), o = P.useRef(!1);
	return /* @__PURE__ */ F(Jn, {
		id: i.contentId,
		"aria-labelledby": i.triggerId,
		...a,
		...r,
		ref: t,
		onCloseAutoFocus: M(e.onCloseAutoFocus, (e) => {
			o.current || i.triggerRef.current?.focus(), o.current = !1, e.preventDefault();
		}),
		onInteractOutside: M(e.onInteractOutside, (e) => {
			let t = e.detail.originalEvent, n = t.button === 0 && t.ctrlKey === !0, r = t.button === 2 || n;
			(!i.modal || r) && (o.current = !0);
		}),
		style: {
			...e.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
});
vr.displayName = _r;
var yr = "DropdownMenuGroup", br = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(Yn, {
		...L(n),
		...r,
		ref: t
	});
});
br.displayName = yr;
var xr = "DropdownMenuLabel", Sr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(Xn, {
		...L(n),
		...r,
		ref: t
	});
});
Sr.displayName = xr;
var Cr = "DropdownMenuItem", wr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(Zn, {
		...L(n),
		...r,
		ref: t
	});
});
wr.displayName = Cr;
var Tr = "DropdownMenuCheckboxItem", Er = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(Qn, {
		...L(n),
		...r,
		ref: t
	});
});
Er.displayName = Tr;
var Dr = "DropdownMenuRadioGroup", Or = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F($n, {
		...L(n),
		...r,
		ref: t
	});
});
Or.displayName = Dr;
var kr = "DropdownMenuRadioItem", Ar = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(er, {
		...L(n),
		...r,
		ref: t
	});
});
Ar.displayName = kr;
var jr = "DropdownMenuItemIndicator", Mr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(tr, {
		...L(n),
		...r,
		ref: t
	});
});
Mr.displayName = jr;
var Nr = "DropdownMenuSeparator", Pr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(nr, {
		...L(n),
		...r,
		ref: t
	});
});
Pr.displayName = Nr;
var Fr = "DropdownMenuArrow", Ir = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(rr, {
		...L(n),
		...r,
		ref: t
	});
});
Ir.displayName = Fr;
var Lr = (e) => {
	let { __scopeDropdownMenu: t, children: n, open: r, onOpenChange: i, defaultOpen: a } = e, o = L(t), [s, c] = D({
		prop: r,
		defaultProp: a ?? !1,
		onChange: i,
		caller: "DropdownMenuSub"
	});
	return /* @__PURE__ */ F(ir, {
		...o,
		open: s,
		onOpenChange: c,
		children: n
	});
}, Rr = "DropdownMenuSubTrigger", zr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(ar, {
		...L(n),
		...r,
		ref: t
	});
});
zr.displayName = Rr;
var Br = "DropdownMenuSubContent", Vr = P.forwardRef((e, t) => {
	let { __scopeDropdownMenu: n, ...r } = e;
	return /* @__PURE__ */ F(or, {
		...L(n),
		...r,
		ref: t,
		style: {
			...e.style,
			"--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
			"--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
			"--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
});
Vr.displayName = Br;
var Hr = fr, Ur = mr, Wr = gr, Gr = vr, Kr = Sr, qr = wr, Jr = Er, Yr = Or, Xr = Ar, Zr = Mr, Qr = Pr, $r = Lr, ei = zr, ti = Vr, ni = [
	"relative flex cursor-pointer select-none items-center gap-2",
	"rounded-md px-2 py-1.5 text-body-medium-default outline-none",
	"text-[var(--content-secondary)]",
	"data-[highlighted]:bg-[var(--surface-hover)]",
	"data-[highlighted]:text-[var(--content-emphasised)]",
	"data-[disabled]:cursor-not-allowed data-[disabled]:text-[var(--content-disabled)]",
	"data-[disabled]:data-[highlighted]:bg-transparent",
	"transition-colors"
].join(" "), ri = [
	"z-50 min-w-[10rem] overflow-hidden rounded-lg bg-[var(--surface-lift)] p-2 shadow-[var(--shadow-popover)]",
	"data-[state=open]:animate-in data-[state=closed]:animate-out",
	"data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
	"data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95"
].join(" "), ii = () => {
	if (typeof navigator > "u") return "mac";
	let e = (navigator.userAgentData?.platform || navigator.platform || "").toLowerCase();
	return /mac|darwin|iphone|ipad|ipod/.test(e) ? "mac" : /win|linux/.test(e) ? "windows" : "mac";
}, ai = {
	mac: {
		modifiers: {
			command: "⌘",
			cmd: "⌘",
			commandorcontrol: "⌘",
			cmdorctrl: "⌘",
			super: "⌘",
			meta: "⌘",
			control: "⌃",
			ctrl: "⌃",
			alt: "⌥",
			option: "⌥",
			altgr: "⌥",
			shift: "⇧"
		},
		keys: {
			up: "↑",
			down: "↓",
			left: "←",
			right: "→",
			return: "↩",
			enter: "↩",
			space: "␣",
			backspace: "⌫",
			delete: "⌦",
			escape: "⎋",
			esc: "⎋",
			tab: "⇥",
			pageup: "⇞",
			pagedown: "⇟",
			home: "↖",
			end: "↘",
			plus: "+"
		}
	},
	windows: {
		modifiers: {
			command: "Win",
			cmd: "Win",
			commandorcontrol: "Ctrl",
			cmdorctrl: "Ctrl",
			super: "Win",
			meta: "Win",
			control: "Ctrl",
			ctrl: "Ctrl",
			alt: "Alt",
			option: "Alt",
			altgr: "AltGr",
			shift: "Shift"
		},
		keys: {
			up: "↑",
			down: "↓",
			left: "←",
			right: "→",
			return: "Enter",
			enter: "Enter",
			space: "Space",
			backspace: "Backspace",
			delete: "Del",
			escape: "Esc",
			esc: "Esc",
			tab: "Tab",
			pageup: "PgUp",
			pagedown: "PgDn",
			home: "Home",
			end: "End",
			plus: "+"
		}
	}
}, oi = (e) => {
	let t = e.split("+"), n = [];
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		r === "" && e === t.length - 1 && n.length > 0 ? n.push("+") : r !== "" && n.push(r);
	}
	return n;
}, si = (e, t) => {
	let n = e.toLowerCase(), { modifiers: r, keys: i } = ai[t];
	return r[n] ?? i[n] ?? e.toUpperCase();
}, ci = {
	command: "command",
	cmd: "command",
	super: "command",
	meta: "command",
	commandorcontrol: "platform",
	cmdorctrl: "platform",
	control: "control",
	ctrl: "control",
	alt: "alt",
	option: "alt",
	altgr: "alt",
	shift: "shift"
}, li = {
	mac: [
		"control",
		"alt",
		"shift",
		"command"
	],
	windows: [
		"command",
		"control",
		"alt",
		"shift"
	]
}, ui = (e, t) => {
	let n = ci[e.toLowerCase()];
	return n === void 0 ? null : n === "platform" ? t === "mac" ? "command" : "control" : n;
}, di = (e, t) => {
	let n = li[t], r = [], i = [];
	for (let n of e) ui(n, t) ? r.push(n) : i.push(n);
	return r.sort((e, r) => n.indexOf(ui(e, t)) - n.indexOf(ui(r, t))), [...r, ...i];
}, fi = (e, t = ii()) => di(oi(e), t).map((e) => si(e, t)), pi = (e, t = ii()) => fi(e, t).join(t === "mac" ? "" : "+"), mi = {
	mac: {
		command: "Meta",
		cmd: "Meta",
		commandorcontrol: "Meta",
		cmdorctrl: "Meta",
		super: "Meta",
		meta: "Meta",
		control: "Control",
		ctrl: "Control",
		alt: "Alt",
		option: "Alt",
		altgr: "AltGraph",
		shift: "Shift"
	},
	windows: {
		command: "Meta",
		cmd: "Meta",
		commandorcontrol: "Control",
		cmdorctrl: "Control",
		super: "Meta",
		meta: "Meta",
		control: "Control",
		ctrl: "Control",
		alt: "Alt",
		option: "Alt",
		altgr: "AltGraph",
		shift: "Shift"
	}
}, hi = {
	up: "ArrowUp",
	down: "ArrowDown",
	left: "ArrowLeft",
	right: "ArrowRight",
	return: "Enter",
	enter: "Enter",
	space: "Space",
	backspace: "Backspace",
	delete: "Delete",
	escape: "Escape",
	esc: "Escape",
	tab: "Tab",
	pageup: "PageUp",
	pagedown: "PageDown",
	home: "Home",
	end: "End",
	plus: "+",
	capslock: "CapsLock",
	numlock: "NumLock",
	scrolllock: "ScrollLock",
	printscreen: "PrintScreen",
	num0: "0",
	num1: "1",
	num2: "2",
	num3: "3",
	num4: "4",
	num5: "5",
	num6: "6",
	num7: "7",
	num8: "8",
	num9: "9",
	numdec: ".",
	numadd: "+",
	numsub: "-",
	nummult: "*",
	numdiv: "/",
	insert: "Insert",
	volumeup: "AudioVolumeUp",
	volumedown: "AudioVolumeDown",
	volumemute: "AudioVolumeMute",
	medianexttrack: "MediaTrackNext",
	mediaprevioustrack: "MediaTrackPrevious",
	mediastop: "MediaStop",
	mediaplaypause: "MediaPlayPause"
}, gi = /^f([1-9]|1\d|2[0-4])$/, _i = (e) => {
	if (e.length === 1) return e.toUpperCase();
	let t = e.toLowerCase();
	return gi.test(t) ? t.toUpperCase() : e;
}, vi = (e, t = ii()) => di(oi(e), t).map((e) => {
	let n = e.toLowerCase();
	return mi[t][n] ?? hi[n] ?? _i(e);
}).join("+"), yi = ["pl-4 text-body-small-default tracking-wide", "text-[var(--content-tertiary)]"].join(" ");
function bi({ accelerator: e, push: t = !0 }) {
	return /* @__PURE__ */ F("span", {
		"data-slot": "menu-item-shortcut",
		"aria-hidden": !0,
		className: v(yi, t && "ml-auto"),
		children: pi(e)
	});
}
function xi(e) {
	return e ? { "aria-keyshortcuts": vi(e) } : {};
}
function Si({ children: e }) {
	return /* @__PURE__ */ F("span", {
		"data-slot": "menu-item-trailing",
		className: v(yi, "ml-auto"),
		children: e
	});
}
//#endregion
//#region ../../packages/design-library/src/components/menu.tsx
var Ci = Hr;
function wi({ asChild: e = !0, ...t }) {
	return /* @__PURE__ */ F(Ur, {
		"data-slot": "menu-trigger",
		asChild: e,
		...t
	});
}
function Ti({ className: e, sideOffset: t = 6, collisionPadding: n = 8, onPointerDownOutside: r, onCloseAutoFocus: i, ref: a, ...o }) {
	let s = j(), c = je(!1);
	return /* @__PURE__ */ F(Wr, {
		container: s ?? void 0,
		children: /* @__PURE__ */ F(Gr, {
			ref: a,
			"data-slot": "menu-content",
			sideOffset: t,
			collisionPadding: n,
			onPointerDownOutside: (e) => {
				c.current = !0, r?.(e);
			},
			onCloseAutoFocus: (e) => {
				c.current &&= (e.preventDefault(), !1), i?.(e);
			},
			className: v(ri, e),
			...o
		})
	});
}
function Ei({ className: e, children: t, leftIcon: n, shortcut: r, trailing: i, ref: a, ...o }) {
	return /* @__PURE__ */ I(qr, {
		ref: a,
		"data-slot": "menu-item",
		className: v(ni, e),
		...xi(r),
		...o,
		children: [
			n ? /* @__PURE__ */ F("span", {
				"data-slot": "menu-item-icon",
				className: "flex h-4 w-4 shrink-0 items-center justify-center text-[var(--content-tertiary)]",
				"aria-hidden": !0,
				children: n
			}) : null,
			/* @__PURE__ */ F("span", {
				className: "flex-1 truncate",
				children: t
			}),
			i ? /* @__PURE__ */ F(Si, { children: i }) : null,
			r ? /* @__PURE__ */ F(bi, {
				accelerator: r,
				push: !i
			}) : null
		]
	});
}
function Di({ className: e, children: t, checked: n, shortcut: r, ref: a, ...o }) {
	return /* @__PURE__ */ I(Jr, {
		ref: a,
		checked: n,
		"data-slot": "menu-checkbox-item",
		className: v(ni, "pl-7", e),
		...xi(r),
		...o,
		children: [
			/* @__PURE__ */ F("span", {
				className: "absolute left-1.5 flex h-4 w-4 items-center justify-center",
				children: /* @__PURE__ */ F(Zr, { children: /* @__PURE__ */ F(i, {
					className: "h-3.5 w-3.5 text-[var(--content-default)]",
					"aria-hidden": !0
				}) })
			}),
			/* @__PURE__ */ F("span", {
				className: "flex-1 truncate",
				children: t
			}),
			r ? /* @__PURE__ */ F(bi, { accelerator: r }) : null
		]
	});
}
function Oi({ ref: e, ...t }) {
	return /* @__PURE__ */ F(Yr, {
		ref: e,
		"data-slot": "menu-radio-group",
		...t
	});
}
function ki({ className: e, children: t, shortcut: n, ref: r, ...i }) {
	return /* @__PURE__ */ I(Xr, {
		ref: r,
		"data-slot": "menu-radio-item",
		className: v(ni, "pl-7", e),
		...xi(n),
		...i,
		children: [
			/* @__PURE__ */ F("span", {
				className: "absolute left-1.5 flex h-4 w-4 items-center justify-center",
				children: /* @__PURE__ */ F(Zr, { children: /* @__PURE__ */ F(Ie, {
					className: "h-2 w-2 fill-current text-[var(--content-default)]",
					"aria-hidden": !0
				}) })
			}),
			/* @__PURE__ */ F("span", {
				className: "flex-1 truncate",
				children: t
			}),
			n ? /* @__PURE__ */ F(bi, { accelerator: n }) : null
		]
	});
}
function Ai({ className: e, ref: t, ...n }) {
	return /* @__PURE__ */ F(Qr, {
		ref: t,
		"data-slot": "menu-separator",
		className: v("my-1 h-px bg-[var(--border-base)]", e),
		...n
	});
}
function ji({ className: e, ref: t, ...n }) {
	return /* @__PURE__ */ F(Kr, {
		ref: t,
		"data-slot": "menu-label",
		className: v("px-2 py-1.5 text-body-small-default uppercase tracking-wide", "text-[var(--content-tertiary)]", e),
		...n
	});
}
var Mi = $r;
function Ni({ className: e, children: t, leftIcon: n, ref: r, ...i }) {
	return /* @__PURE__ */ I(ei, {
		ref: r,
		"data-slot": "menu-sub-trigger",
		className: v(ni, "data-[state=open]:bg-[var(--surface-hover)]", "data-[state=open]:text-[var(--content-emphasised)]", e),
		...i,
		children: [
			n ? /* @__PURE__ */ F("span", {
				"data-slot": "menu-item-icon",
				className: "flex h-4 w-4 shrink-0 items-center justify-center text-[var(--content-tertiary)]",
				"aria-hidden": !0,
				children: n
			}) : null,
			/* @__PURE__ */ F("span", {
				className: "flex-1 truncate",
				children: t
			}),
			/* @__PURE__ */ F(Fe, {
				className: "ml-auto h-3.5 w-3.5 text-[var(--content-tertiary)]",
				"aria-hidden": !0
			})
		]
	});
}
function Pi({ className: e, ref: t, ...n }) {
	return /* @__PURE__ */ F(Wr, {
		container: j() ?? void 0,
		children: /* @__PURE__ */ F(ti, {
			ref: t,
			"data-slot": "menu-sub-content",
			className: v(ri, e),
			...n
		})
	});
}
var Fi = {
	Root: Ci,
	Trigger: wi,
	Content: Ti,
	Item: Ei,
	CheckboxItem: Di,
	RadioGroup: Oi,
	RadioItem: ki,
	Separator: Ai,
	Label: ji,
	Sub: Mi,
	SubTrigger: Ni,
	SubContent: Pi
};
//#endregion
//#region ../../packages/design-library/src/components/crossfade-stack.tsx
function Ii({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ F("span", {
		"data-slot": "crossfade-stack",
		"data-reveal-slot": "",
		className: v("grid shrink-0 place-items-center", e),
		...n,
		children: t
	});
}
//#endregion
//#region ../../packages/design-library/src/components/panel-item/marquee-text.tsx
var Li = 50, Ri = 2e3, zi = .8;
function Bi({ children: e, className: t }) {
	let n = je(null), r = je(null), [i, a] = Me(0);
	De(() => {
		let e = n.current, t = r.current;
		if (!e || !t) return;
		let i = () => {
			let n = t.scrollWidth - e.clientWidth;
			a(n > 0 ? n : 0);
		};
		i();
		let o = new ResizeObserver(i);
		return o.observe(e), o.observe(t), () => o.disconnect();
	}, [e]);
	let o = i > 0, s = Math.max(Ri, Math.round(i * 2 / Li * 1e3)), c = Math.round(s / zi), l = o ? {
		"--panelitem-marquee-distance": `${i}px`,
		"--panelitem-marquee-duration": `${c}ms`
	} : void 0;
	return /* @__PURE__ */ I("span", {
		"data-slot": "marquee-text",
		ref: n,
		className: v("relative min-w-0 flex-1 overflow-hidden", t),
		children: [/* @__PURE__ */ F("span", {
			className: "block truncate motion-safe:group-hover:invisible",
			children: e
		}), /* @__PURE__ */ F("span", {
			ref: r,
			"aria-hidden": !0,
			className: v("absolute top-0 left-0 invisible block whitespace-nowrap", "motion-safe:group-hover:visible", o && "motion-safe:group-hover:animate-panelitem-marquee"),
			style: l,
			children: e
		})]
	});
}
//#endregion
//#region ../../packages/design-library/src/components/panel-item/panel-item.tsx
var Vi = [
	"group/panel-item group relative",
	"flex h-8 max-md:h-auto w-full items-center justify-between",
	"rounded-[6px] p-[8px] max-md:py-3 gap-[4px]",
	"text-left text-body-medium-lighter max-md:text-body-large-default",
	"transition-colors",
	"bg-transparent",
	"text-[var(--content-secondary)]",
	"outline-none"
].join(" "), Hi = ["keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)]", "cursor-pointer select-none"].join(" "), Ui = "[@media(hover:hover)]:hover:bg-[var(--panel-item-hover,var(--surface-hover))]", Wi = "[@media(hover:hover)]:hover:bg-[var(--panel-item-hover,var(--surface-active))]", Gi = [
	"w-fit max-w-full rounded-full",
	"h-[var(--side-menu-tile-size,36px)]",
	"max-md:min-h-[var(--side-menu-tile-size,36px)]",
	"bg-[var(--panel-item-bg,var(--surface-lift))]",
	"text-[color:var(--panel-item-fg,inherit)]"
].join(" "), Ki = ["aria-[current=page]:bg-[var(--panel-item-active,var(--panel-item-bg,var(--surface-active)))]", "aria-[current=page]:text-[var(--content-emphasised)]"].join(" "), qi = [
	"aria-[current=page]:bg-[color-mix(in_oklab,var(--primary-base)_10%,transparent)]",
	"aria-[current=page]:text-[var(--primary-base)]",
	"aria-[current=page]:font-medium"
].join(" "), Ji = "flex min-w-0 flex-1 items-center gap-[var(--panel-item-gap,8px)]", Yi = [
	"shrink-0",
	"text-[color:var(--panel-item-icon-fg,var(--content-tertiary))]",
	"[@media(hover:hover)]:group-hover:text-[color:var(--panel-item-icon-fg,var(--content-secondary))]"
].join(" "), Xi = "group-aria-[current=page]:text-[var(--content-default)]", Zi = "group-aria-[current=page]:text-[var(--primary-base)]", Qi = "min-w-0 flex-1 truncate", $i = "shrink-0 text-[var(--content-tertiary)]", ea = "flex items-center gap-2 shrink-0", ta = [
	"inline-flex items-center justify-center shrink-0",
	"text-label-small-default leading-none",
	"text-[var(--content-tertiary)]",
	"rounded-[4px] bg-[var(--surface-base)] px-[4px] py-[2px]",
	"[@media(hover:hover)]:group-hover:bg-transparent [@media(hover:hover)]:group-hover:rounded-none",
	"[@media(hover:hover)]:group-hover:px-0 [@media(hover:hover)]:group-hover:py-0",
	"group-aria-[current=page]:bg-transparent group-aria-[current=page]:rounded-none",
	"group-aria-[current=page]:px-0 group-aria-[current=page]:py-0"
].join(" "), na = "inline-flex items-center justify-center shrink-0", ra = "mr-2", ia = "flex items-center shrink-0";
function aa({ shape: e, active: t, activeVariant: n, interactive: r, className: i }) {
	return v(Vi, r && Hi, r && (e === "pill" ? Wi : Ui), n === "branded" ? qi : Ki, e === "pill" && Gi, i);
}
function oa(e) {
	return e.asChild === !0 ? /* @__PURE__ */ F(sa, { ...e }) : /* @__PURE__ */ F(ca, { ...e });
}
function sa({ asChild: e, shape: t = "row", active: n = !1, activeVariant: r = "default", className: i, "aria-label": a, children: o, ref: s, ...c }) {
	return /* @__PURE__ */ F(_, {
		"data-slot": "panel-item",
		ref: s,
		className: aa({
			shape: t,
			active: n,
			activeVariant: r,
			interactive: !0,
			className: i
		}),
		"aria-current": n ? "page" : void 0,
		"aria-label": a,
		...c,
		children: o
	});
}
function ca({ asChild: e, children: t, icon: n, leadingSlot: r, label: i, expandChevron: a, badge: o, badgeBare: s = !1, trailingAction: c, revealHold: l = !1, shape: u = "row", active: d = !1, activeVariant: f = "default", disabled: p = !1, onSelect: m, marqueeOnHover: h = !1, className: g, "aria-label": _, trigger: y = !1, ref: b, onClick: x, onKeyDown: S, ...C }) {
	let w = d ? "page" : void 0, T = _ ?? (typeof i == "string" ? i : void 0), E = r === void 0 ? n ? /* @__PURE__ */ F(n, {
		size: 14,
		"aria-hidden": !0,
		className: v("max-md:size-4", Yi, f === "branded" ? Zi : Xi)
	}) : null : r, D = h ? /* @__PURE__ */ F(Bi, { children: i }) : /* @__PURE__ */ F("span", {
		className: Qi,
		children: i
	}), O = a ? /* @__PURE__ */ F(a, {
		size: 12,
		"aria-hidden": !0,
		className: $i
	}) : null, k = o != null && c != null, A = o == null ? null : /* @__PURE__ */ F("span", {
		className: v(s ? na : ta, s && !c && ra),
		"data-reveal-yield": k ? "" : void 0,
		children: o
	}), j = /* @__PURE__ */ I(Pe, { children: [/* @__PURE__ */ I("span", {
		className: Ji,
		children: [
			E,
			D,
			O
		]
	}), /* @__PURE__ */ F("span", {
		className: ea,
		children: I(k ? Ii : Pe, { children: [A, c ? /* @__PURE__ */ F("span", {
			className: ia,
			"data-reveal": "",
			onClick: (e) => {
				e.stopPropagation(), e.preventDefault();
			},
			children: c
		}) : null] })
	})] }), M = m != null || y, N = aa({
		shape: u,
		active: d,
		activeVariant: f,
		interactive: M,
		className: g
	});
	if (M) {
		let e = (e) => {
			if (p) {
				e.preventDefault();
				return;
			}
			x?.(e), e.defaultPrevented || m?.();
		}, t = (e) => {
			if (!p && (S?.(e), !e.defaultPrevented && (e.key === "Enter" || e.key === " "))) {
				if (!m) return;
				e.preventDefault(), m();
			}
		};
		return /* @__PURE__ */ F("div", {
			...C,
			"data-slot": "panel-item",
			ref: b,
			role: "button",
			tabIndex: p ? -1 : 0,
			"aria-disabled": p || void 0,
			className: N,
			"data-reveal-row": "",
			"data-reveal-hold": d || l ? "" : void 0,
			"aria-current": w,
			"aria-label": T,
			onClick: e,
			onKeyDown: t,
			children: j
		});
	}
	return /* @__PURE__ */ F("div", {
		"data-slot": "panel-item",
		ref: b,
		className: N,
		"data-reveal-row": "",
		"data-reveal-hold": d || l ? "" : void 0,
		"aria-current": w,
		"aria-label": T,
		onClick: x,
		onKeyDown: S,
		...C,
		children: j
	});
}
//#endregion
//#region ../../packages/design-library/src/components/action-menu.tsx
var la = Se(null);
function ua(e) {
	let t = Ee(la);
	if (!t) throw Error(`ActionMenu.${e} must be rendered inside ActionMenu.Root`);
	return t;
}
function da({ open: e, defaultOpen: t = !1, onOpenChange: n, presentation: r, children: i }) {
	let a = ze(), [o, s] = Me(t), c = e ?? o, l = r ?? (a ? "sheet" : "anchored"), u = je(c), d = Te((t) => {
		e === void 0 && s(t), u.current !== t && (u.current = t, n?.(t));
	}, [n, e]);
	De(() => {
		u.current = c;
	}, [c]);
	let f = Te(() => d(!1), [d]), p = l === "sheet" ? $e.Root : Fi.Root;
	return /* @__PURE__ */ F(la, {
		value: {
			presentation: l,
			close: f
		},
		children: /* @__PURE__ */ F(p, {
			open: c,
			onOpenChange: d,
			children: i
		})
	});
}
function fa({ asChild: e = !0, ...t }) {
	let { presentation: n } = ua("Trigger");
	return F(n === "sheet" ? $e.Trigger : Fi.Trigger, {
		asChild: e,
		...t
	});
}
function pa({ title: e, showTitle: t = !1, closeLabel: n = "Close", children: r, className: i, side: o, align: s = "end", sideOffset: c = 4 }) {
	let { presentation: l } = ua("Content");
	return l === "sheet" ? /* @__PURE__ */ I($e.Content, {
		"aria-describedby": void 0,
		padded: !1,
		className: v("pt-2 pb-[calc(24px+var(--safe-area-inset-bottom,env(safe-area-inset-bottom,0px)))]", i),
		children: [
			/* @__PURE__ */ F($e.Grabber, {}),
			t ? /* @__PURE__ */ I($e.Header, {
				className: "flex-row items-center justify-between px-4 pt-3 pb-2",
				children: [/* @__PURE__ */ F($e.Title, {
					className: "text-body-large-default text-[var(--content-tertiary)]",
					children: e
				}), /* @__PURE__ */ F($e.Close, {
					"aria-label": n,
					className: "-m-2 flex shrink-0 items-center justify-center p-2 text-[var(--content-tertiary)] outline-none keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)]",
					children: /* @__PURE__ */ F(a, {
						size: 16,
						"aria-hidden": !0
					})
				})]
			}) : /* @__PURE__ */ F($e.Header, {
				className: "sr-only",
				children: /* @__PURE__ */ F($e.Title, { children: e })
			}),
			/* @__PURE__ */ F($e.Body, {
				className: "px-4 pt-3 [--panel-item-gap:12px]",
				children: r
			})
		]
	}) : /* @__PURE__ */ F(Fi.Content, {
		"aria-label": e,
		side: o,
		align: s,
		sideOffset: c,
		className: i,
		children: r
	});
}
var ma = {
	anchored: "text-[var(--system-negative-strong)] data-[highlighted]:text-[var(--system-negative-hover)] [&_[data-slot=menu-item-icon]]:text-inherit",
	sheet: "text-[var(--system-negative-strong)] [--panel-item-icon-fg:var(--system-negative-strong)]"
};
function ha({ Icon: e }) {
	return /* @__PURE__ */ F("span", {
		"aria-hidden": !0,
		"data-slot": "action-menu-chip",
		className: "flex size-10 shrink-0 items-center justify-center rounded-full bg-[var(--border-hover)]",
		children: /* @__PURE__ */ F(e, {
			size: 16,
			className: "text-[color:var(--panel-item-icon-fg,var(--content-secondary))]"
		})
	});
}
function ga({ icon: e, label: t, description: n, shortcut: r, trailing: i, tone: a = "default", disabled: o = !1, onSelect: s, className: c }) {
	let { presentation: l, close: u } = ua("Item"), d = a === "destructive";
	return l === "sheet" ? /* @__PURE__ */ F(oa, {
		leadingSlot: e ? /* @__PURE__ */ F(ha, { Icon: e }) : void 0,
		label: n ? /* @__PURE__ */ I("span", {
			className: "flex flex-col gap-0.5 overflow-visible whitespace-normal",
			children: [/* @__PURE__ */ F("span", { children: t }), /* @__PURE__ */ F("span", {
				className: "text-body-small-default text-[var(--content-tertiary)]",
				children: n
			})]
		}) : t,
		"aria-label": typeof t == "string" ? t : void 0,
		disabled: o,
		className: v("px-0 py-2 max-md:py-2", d && ma.sheet, c),
		onSelect: () => {
			u(), s?.();
		}
	}) : /* @__PURE__ */ F(Fi.Item, {
		leftIcon: e ? /* @__PURE__ */ F(e, { size: 14 }) : void 0,
		shortcut: r,
		trailing: i,
		disabled: o,
		className: v("whitespace-nowrap", d && ma.anchored, c),
		onSelect: () => {
			u(), s?.();
		},
		children: t
	});
}
function _a({ className: e }) {
	let { presentation: t } = ua("Separator");
	return t === "sheet" ? /* @__PURE__ */ F("div", {
		"data-slot": "action-menu-separator",
		role: "separator",
		className: v("my-1 h-px bg-[var(--border-base)]", e)
	}) : /* @__PURE__ */ F(Fi.Separator, { className: e });
}
function va({ children: e, className: t }) {
	let { presentation: n } = ua("Label");
	return n === "sheet" ? /* @__PURE__ */ F("div", {
		"data-slot": "action-menu-label",
		className: v("px-2 pt-2 pb-1 text-body-small-default uppercase tracking-wide text-[var(--content-tertiary)]", t),
		children: e
	}) : /* @__PURE__ */ F(Fi.Label, {
		className: t,
		children: e
	});
}
var ya = {
	Root: da,
	Trigger: fa,
	Content: pa,
	Item: ga,
	Separator: _a,
	Label: va
}, ba = {
	lift: "bg-[var(--surface-lift)]",
	overlay: "bg-[var(--surface-overlay)]"
}, xa = {
	sm: "p-3",
	md: "p-4",
	lg: "p-6"
}, Sa = ["text-[color:var(--content-default)]", "rounded-xl"].join(" "), Ca = ["border-[var(--primary-base)]", "bg-[color-mix(in_srgb,var(--primary-base)_10%,transparent)]"].join(" "), wa = [
	"block w-full text-left cursor-pointer outline-none transition-colors",
	"keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0",
	"disabled:pointer-events-none disabled:opacity-60",
	"aria-disabled:pointer-events-none aria-disabled:opacity-60"
].join(" "), Ta = ["hover:bg-[var(--surface-base)]", "active:bg-[var(--surface-active)]"].join(" ");
function Ea({ padding: e, surface: t, bordered: n, elevated: r, hasSections: i, noPadding: a, clipContents: o, interactive: s, selected: c }) {
	return v(Sa, "border", c ? Ca : [ba[t], n ? "border-[var(--border-subtle)]" : "border-transparent"], s ? wa : null, s && !c ? Ta : null, r ? "shadow-sm" : null, o ? "overflow-hidden" : null, !i && !a ? xa[e] : null);
}
function Da(e) {
	let t = !1, n = Array.isArray(e) ? e : [e];
	for (let e of n) if (typeof e == "object" && e && "type" in e && (e.type === ka || e.type === Aa || e.type === ja)) {
		t = !0;
		break;
	}
	return t;
}
function Oa({ padding: e = "md", surface: t = "lift", bordered: n = !0, elevated: r = !1, noPadding: i = !1, clipContents: a = !1, asChild: o = !1, interactive: s = !1, selected: c = !1, className: l, children: u, ref: d, ...f }) {
	let p = o ? _ : "div", m = Da(u);
	return /* @__PURE__ */ F(p, {
		...f,
		ref: d,
		"data-slot": "card",
		"data-selected": c ? "" : void 0,
		className: v(Ea({
			padding: e,
			surface: t,
			bordered: n,
			elevated: r,
			hasSections: m,
			noPadding: i,
			clipContents: a,
			interactive: s,
			selected: c
		}), l),
		children: u
	});
}
function ka({ padding: e = "md", className: t, children: n, ref: r, ...i }) {
	return /* @__PURE__ */ F(ae, {
		...i,
		ref: r,
		variant: "title-small",
		as: "div",
		"data-slot": "card-header",
		className: v(xa[e], "border-b border-[var(--border-base)]", "text-[color:var(--content-default)]", t),
		children: n
	});
}
function Aa({ padding: e = "md", className: t, children: n, ref: r, ...i }) {
	return /* @__PURE__ */ F("div", {
		...i,
		ref: r,
		"data-slot": "card-body",
		className: v(xa[e], t),
		children: n
	});
}
function ja({ padding: e = "md", className: t, children: n, ref: r, ...i }) {
	return /* @__PURE__ */ F("div", {
		...i,
		ref: r,
		"data-slot": "card-footer",
		className: v(xa[e], "border-t border-[var(--border-base)]", t),
		children: n
	});
}
function Ma({ children: e, padding: t = "md", noPadding: n = !1, ref: r, ...i }) {
	return /* @__PURE__ */ F(Oa, {
		ref: r,
		padding: t,
		noPadding: n,
		...i,
		children: n ? e : /* @__PURE__ */ F(Aa, {
			padding: t,
			children: e
		})
	});
}
var Na = Ma;
Na.Root = Oa, Na.Header = ka, Na.Body = Aa, Na.Footer = ja;
//#endregion
//#region ../../packages/design-library/src/utils/merge-refs.ts
function Pa(...e) {
	return (t) => {
		let n = e.map((e) => {
			if (typeof e == "function") {
				let n = e(t);
				return typeof n == "function" ? n : () => e(null);
			}
			if (e) return e.current = t, () => {
				e.current = null;
			};
		});
		return () => {
			let e = [];
			for (let t of n) try {
				t?.();
			} catch (t) {
				e.push(t);
			}
			if (e.length > 0) throw e[0];
		};
	};
}
Se(null), y([
	"group/option-card flex w-full cursor-pointer rounded-lg border p-3 text-left",
	"text-[color:var(--content-default)]",
	"outline-none transition-colors",
	"keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0",
	"disabled:cursor-not-allowed disabled:opacity-60"
].join(" "), {
	variants: {
		variant: {
			outlined: "",
			filled: [
				"bg-[var(--surface-overlay)]",
				"enabled:hover:bg-[var(--surface-active)]",
				"enabled:active:bg-[color-mix(in_srgb,var(--content-default)_8%,var(--surface-active))]"
			].join(" ")
		},
		orientation: {
			horizontal: "flex-row items-center gap-3",
			vertical: "flex-col items-stretch gap-1.5"
		},
		selected: {
			true: "",
			false: ""
		}
	},
	compoundVariants: [
		{
			variant: "outlined",
			selected: !1,
			class: [
				"border-[var(--border-element)] bg-[var(--surface-lift)]",
				"enabled:hover:bg-[var(--surface-base)]",
				"enabled:active:bg-[var(--surface-active)]"
			].join(" ")
		},
		{
			variant: "outlined",
			selected: !0,
			class: Ca
		},
		{
			variant: "filled",
			selected: !1,
			class: "border-transparent"
		},
		{
			variant: "filled",
			selected: !0,
			class: "border-[var(--primary-base)]"
		}
	],
	defaultVariants: {
		variant: "outlined",
		orientation: "horizontal",
		selected: !1
	}
}), Se({
	density: "default",
	inset: !0,
	dividers: "rows"
});
//#endregion
//#region ../../packages/design-library/src/hooks/use-resizable-pane.ts
var Fa = typeof window > "u" ? De : ke, Ia = 16, La = 4;
function Ra(e) {
	if (!e || typeof window > "u") return null;
	try {
		let t = localStorage.getItem(e);
		if (t == null) return null;
		let n = Number(t);
		return Number.isFinite(n) ? n : null;
	} catch {
		return null;
	}
}
function za(e, t, n) {
	return Math.max(n, Ra(e) ?? t);
}
function Ba(e, t) {
	if (e) try {
		localStorage.setItem(e, String(t));
	} catch {}
}
function Va({ minSize: e, maxSize: t, reserveForRest: n, containerSize: r }) {
	return Math.max(e, Math.min(t ?? Infinity, r > 0 ? r - n : Infinity));
}
function Ha(e, t, n) {
	return Number.isFinite(e) ? e : Math.max(t, n);
}
function Ua(e, t, n) {
	return Math.max(t, Math.min(e, n));
}
function Wa(e, t) {
	return t === "end" ? -e : e;
}
function Ga({ stored: e, containerSize: t, convert: n, minSize: r, maxSize: i, reserveForRest: a }) {
	let o = Math.round(n(e, t));
	return Number.isFinite(o) ? Ua(o, r, Va({
		minSize: r,
		maxSize: i,
		reserveForRest: a,
		containerSize: t
	})) : null;
}
function Ka(e, { shiftKey: t, size: n, side: r, minSize: i, maxSize: a }) {
	let o = t ? Ia * La : Ia;
	switch (e) {
		case "ArrowLeft": return n + Wa(-o, r);
		case "ArrowRight": return n + Wa(o, r);
		case "Home": return i;
		case "End": return a;
		default: return null;
	}
}
function qa({ side: e, defaultSize: t, minSize: n, maxSize: r, reserveForRest: i = 0, storageKey: a, legacySize: o, label: s, paneId: c, paneRef: l, onSizeCommit: u }) {
	let d = je(o);
	d.current = o;
	let f = je(t);
	f.current = t;
	let p = je(n);
	p.current = n;
	let m = Oe(), h = c ?? m, g = je(null), _ = je(null), [v, y] = Me(!1), [b, x] = Me(() => za(a, t, n)), [S, C] = Me(0);
	De(() => {
		let e = g.current;
		if (!e) return;
		C(e.offsetWidth);
		let t = new ResizeObserver(() => {
			C(e.offsetWidth);
		});
		return t.observe(e), () => t.disconnect();
	}, []);
	let w = je(a);
	Fa(() => {
		w.current !== a && (w.current = a, x(za(a, f.current, p.current)));
	}, [a]);
	let T = Va({
		minSize: n,
		maxSize: r,
		reserveForRest: i,
		containerSize: S
	}), E = Te((e) => Ua(e, n, T), [n, T]), D = Ha(T, n, b), O = o?.key;
	Fa(() => {
		let e = d.current;
		if (!e || !a || Ra(a) != null) return;
		let t = Ra(e.key);
		if (t == null) return;
		let o = g.current?.offsetWidth || S;
		if (o <= 0) return;
		let s = Ga({
			stored: t,
			containerSize: o,
			convert: e.convert,
			minSize: n,
			maxSize: r,
			reserveForRest: i
		});
		if (s != null) {
			x(s), Ba(a, s);
			try {
				localStorage.removeItem(e.key);
			} catch {}
		}
	}, [
		O,
		a,
		S,
		n,
		r,
		i
	]), De(() => {
		let e = E(b);
		e !== b && (x(e), l?.current && (l.current.style.width = `${e}px`));
	}, [
		b,
		E,
		l
	]);
	let k = Te((e) => {
		if (l?.current) {
			l.current.style.width = `${e}px`;
			return;
		}
		x(e);
	}, [l]), A = Te((e) => {
		let t = Math.round(e);
		x(t), Ba(a, t), u?.(t);
	}, [a, u]), j = Te((e) => {
		typeof document > "u" || (document.body.style.cursor = e ? "col-resize" : "", document.body.style.userSelect = e ? "none" : "");
	}, []);
	De(() => () => j(!1), [j]);
	let M = Te((e) => {
		e.preventDefault(), e.currentTarget.setPointerCapture(e.pointerId), _.current = {
			startX: e.clientX,
			startSize: b
		}, y(!0), j(!0);
	}, [b, j]), N = Te((t) => {
		let n = _.current;
		n && k(E(n.startSize + Wa(t.clientX - n.startX, e)));
	}, [
		k,
		E,
		e
	]), ee = Te((t) => {
		let n = _.current;
		n && (t.currentTarget.releasePointerCapture(t.pointerId), _.current = null, y(!1), j(!1), A(E(n.startSize + Wa(t.clientX - n.startX, e))));
	}, [
		A,
		E,
		e,
		j
	]), te = Te((t) => {
		let r = Ka(t.key, {
			shiftKey: t.shiftKey,
			size: b,
			side: e,
			minSize: n,
			maxSize: D
		});
		r != null && (t.preventDefault(), A(E(r)));
	}, [
		b,
		e,
		n,
		D,
		E,
		A
	]);
	return {
		size: b,
		containerSize: S,
		containerRef: g,
		paneId: h,
		isResizing: v,
		handleProps: {
			role: "separator",
			"aria-orientation": "vertical",
			"aria-label": s,
			"aria-controls": h,
			"aria-valuenow": Math.round(b),
			"aria-valuemin": Math.round(n),
			"aria-valuemax": Math.round(D),
			tabIndex: 0,
			onPointerDown: M,
			onPointerMove: N,
			onPointerUp: ee,
			onPointerCancel: ee,
			onKeyDown: te
		}
	};
}
//#endregion
//#region ../../packages/design-library/src/components/pane-resize-handle.tsx
function Ja({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ F("div", {
		...n,
		"data-slot": "pane-resize-handle",
		className: v("cursor-col-resize", "focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--ring)]", e),
		children: t
	});
}
//#endregion
//#region ../../packages/design-library/src/components/tag.tsx
var Ya = y([
	"inline-flex items-center gap-1 h-6 px-2 py-1 rounded-[6px] whitespace-nowrap select-none",
	"text-body-small-emphasised leading-none",
	"text-[color:var(--content-default)]"
].join(" "), {
	variants: { tone: {
		positive: "bg-[var(--system-positive-weak)]",
		negative: "bg-[var(--system-negative-weak)]",
		warning: "bg-[var(--system-mid-weak)]",
		info: "bg-[var(--system-info-weak)]",
		neutral: "bg-[var(--tag-bg-neutral)]"
	} },
	defaultVariants: { tone: "neutral" }
}), Xa = {
	positive: "var(--system-positive-strong)",
	negative: "var(--system-negative-strong)",
	warning: "var(--system-mid-strong)",
	info: "var(--system-info-strong)",
	neutral: "var(--content-secondary)"
}, Za = {
	width: 12,
	height: 12,
	flexShrink: 0,
	display: "inline-flex",
	alignItems: "center",
	justifyContent: "center"
};
function Qa(e) {
	return {
		...Za,
		color: e == null ? "var(--content-secondary)" : Xa[e]
	};
}
function $a({ tone: e = "neutral", leftIcon: t, rightIcon: n, onRemove: r, removeLabel: i = "Remove", className: o, children: s, ref: c, ...l }) {
	return /* @__PURE__ */ I("span", {
		...l,
		ref: c,
		"data-slot": "tag",
		className: v(Ya({ tone: e }), o),
		children: [
			t == null ? null : /* @__PURE__ */ F("span", {
				"aria-hidden": "true",
				style: Qa(e),
				children: t
			}),
			/* @__PURE__ */ F("span", {
				"data-slot": "tag-label",
				className: "min-w-0 truncate",
				children: s
			}),
			n != null && r == null ? /* @__PURE__ */ F("span", {
				"aria-hidden": "true",
				style: Qa(),
				children: n
			}) : null,
			r == null ? null : /* @__PURE__ */ F("button", {
				type: "button",
				"aria-label": i,
				onClick: (e) => {
					e.stopPropagation(), r(e);
				},
				className: v("inline-flex items-center justify-center rounded-full", "h-3.5 w-3.5 -mr-0.5 cursor-pointer", "text-[color:var(--content-secondary)]", "transition-colors duration-150", "hover:bg-[color-mix(in_srgb,currentColor_15%,transparent)]", "keyboard-focus:outline-none keyboard-focus:ring-2", "keyboard-focus:ring-[var(--ring)]"),
				children: /* @__PURE__ */ F(a, {
					style: Za,
					"aria-hidden": "true"
				})
			})
		]
	});
}
y([
	"cursor-pointer outline-none",
	"transition-[color,box-shadow] duration-150 ease-out",
	"keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0",
	"[--chip-wash:transparent]",
	"bg-[image:linear-gradient(var(--chip-wash),var(--chip-wash))]",
	"not-disabled:hover:[--chip-wash:color-mix(in_srgb,currentColor_8%,transparent)]",
	"not-disabled:active:[--chip-wash:color-mix(in_srgb,currentColor_14%,transparent)]",
	"disabled:cursor-not-allowed disabled:opacity-60",
	"aria-disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-60"
].join(" ")), y("-mb-px inline-flex items-center whitespace-nowrap border-b-2 border-transparent pb-2 text-body-medium-default transition-colors", {
	variants: {
		status: {
			active: "border-[var(--primary-base)] text-[var(--content-strong)]",
			completed: "text-[var(--content-default)]",
			upcoming: "text-[var(--content-disabled)]"
		},
		navigable: {
			true: "cursor-pointer outline-none hover:text-[var(--content-strong)] keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)] keyboard-focus:ring-offset-0",
			false: "cursor-default"
		}
	},
	defaultVariants: {
		status: "upcoming",
		navigable: !1
	}
});
//#endregion
//#region ../../node_modules/.bun/estree-util-is-identifier-name@3.0.0/node_modules/estree-util-is-identifier-name/lib/index.js
var eo = /^[$_\p{ID_Start}][$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, to = /^[$_\p{ID_Start}][-$_\u{200C}\u{200D}\p{ID_Continue}]*$/u, no = {};
function ro(e, t) {
	return ((t || no).jsx ? to : eo).test(e);
}
//#endregion
//#region ../../node_modules/.bun/hast-util-whitespace@3.0.0/node_modules/hast-util-whitespace/lib/index.js
var io = /[ \t\n\f\r]/g;
function ao(e) {
	return typeof e == "object" ? e.type === "text" ? oo(e.value) : !1 : oo(e);
}
function oo(e) {
	return e.replace(io, "") === "";
}
//#endregion
//#region ../../node_modules/.bun/inline-style-parser@0.2.9/node_modules/inline-style-parser/esm/index.mjs
var so = /\/\*(?:[^*]|\*(?!\/))*\*\//g, co = /\n/g, lo = /^\s*/, uo = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/, fo = /^:\s*/, po = /^((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|url\((?:'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|[^)]*)\)|[^};])+)/, mo = /^[;\s]*/, ho = "\n", go = "/", _o = "*", vo = "", yo = "comment", bo = "declaration";
function xo(e, t) {
	if (typeof e != "string") throw TypeError("First argument must be a string");
	if (!e) return [];
	t ||= {};
	var n = 1, r = 1;
	function i(e) {
		var t = e.match(co);
		t && (n += t.length);
		var i = e.lastIndexOf(ho);
		r = ~i ? e.length - i : r + e.length;
	}
	function a() {
		var e = {
			line: n,
			column: r
		};
		return function(t) {
			return t.position = new o(e), l(), t;
		};
	}
	function o(e) {
		this.start = e, this.end = {
			line: n,
			column: r
		}, this.source = t.source;
	}
	o.prototype.content = e;
	function s(i) {
		var a = /* @__PURE__ */ Error(t.source + ":" + n + ":" + r + ": " + i);
		if (a.reason = i, a.filename = t.source, a.line = n, a.column = r, a.source = e, !t.silent) throw a;
	}
	function c(t) {
		var n = t.exec(e);
		if (n) {
			var r = n[0];
			return i(r), e = e.slice(r.length), n;
		}
	}
	function l() {
		c(lo);
	}
	function u(e) {
		for (var t; t = d();) e.push(t);
		return e;
	}
	function d() {
		var t = a();
		if (!(go != e.charAt(0) || _o != e.charAt(1))) {
			for (var n = 2; vo != e.charAt(n) && (_o != e.charAt(n) || go != e.charAt(n + 1));) ++n;
			if (n += 2, vo === e.charAt(n - 1)) return s("End of comment missing");
			var o = e.slice(2, n - 2);
			return r += 2, i(o), e = e.slice(n), r += 2, t({
				type: yo,
				comment: o
			});
		}
	}
	function f() {
		var e = a(), t = c(uo);
		if (t) {
			if (d(), !c(fo)) return s("property missing ':'");
			var n = c(po), r = e({
				type: bo,
				property: t[0].replace(so, vo).trim(),
				value: n ? n[0].replace(so, vo).trim() : vo
			});
			return c(mo), r;
		}
	}
	function p() {
		var e = [];
		u(e);
		for (var t; t = f();) e.push(t), u(e);
		return e;
	}
	return l(), p();
}
//#endregion
//#region ../../node_modules/.bun/style-to-object@2.0.2/node_modules/style-to-object/esm/index.mjs
function So(e, t) {
	let n = null;
	if (!e || typeof e != "string") return n;
	let r = xo(e), i = typeof t == "function";
	return r.forEach((e) => {
		if (e.type !== "declaration") return;
		let { property: r, value: a } = e;
		i ? t(r, a, e) : a && (n ??= {}, n[r] = a);
	}), n;
}
//#endregion
//#region ../../node_modules/.bun/unist-util-position@5.0.0/node_modules/unist-util-position/lib/index.js
var Co = To("end"), wo = To("start");
function To(e) {
	return t;
	function t(t) {
		let n = t && t.position && t.position[e] || {};
		if (typeof n.line == "number" && n.line > 0 && typeof n.column == "number" && n.column > 0) return {
			line: n.line,
			column: n.column,
			offset: typeof n.offset == "number" && n.offset > -1 ? n.offset : void 0
		};
	}
}
function Eo(e) {
	let t = wo(e), n = Co(e);
	if (t && n) return {
		start: t,
		end: n
	};
}
//#endregion
//#region ../../node_modules/.bun/unist-util-stringify-position@4.0.0/node_modules/unist-util-stringify-position/lib/index.js
function Do(e) {
	return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? ko(e.position) : "start" in e || "end" in e ? ko(e) : "line" in e || "column" in e ? Oo(e) : "";
}
function Oo(e) {
	return Ao(e && e.line) + ":" + Ao(e && e.column);
}
function ko(e) {
	return Oo(e && e.start) + "-" + Oo(e && e.end);
}
function Ao(e) {
	return e && typeof e == "number" ? e : 1;
}
//#endregion
//#region ../../node_modules/.bun/vfile-message@4.0.4/node_modules/vfile-message/lib/index.js
var jo = class extends Error {
	constructor(e, t, n) {
		super(), typeof t == "string" && (n = t, t = void 0);
		let r = "", i = {}, a = !1;
		if (t && (i = "line" in t && "column" in t || "start" in t && "end" in t ? { place: t } : "type" in t ? {
			ancestors: [t],
			place: t.position
		} : { ...t }), typeof e == "string" ? r = e : !i.cause && e && (a = !0, r = e.message, i.cause = e), !i.ruleId && !i.source && typeof n == "string") {
			let e = n.indexOf(":");
			e === -1 ? i.ruleId = n : (i.source = n.slice(0, e), i.ruleId = n.slice(e + 1));
		}
		if (!i.place && i.ancestors) {
			let e = i.ancestors[i.ancestors.length - 1];
			e && (i.place = e.position);
		}
		let o = i.place && "start" in i.place ? i.place.start : i.place;
		this.ancestors = i.ancestors || void 0, this.cause = i.cause || void 0, this.column = o ? o.column : void 0, this.fatal = void 0, this.file = "", this.message = r, this.line = o ? o.line : void 0, this.name = Do(i.place) || "1:1", this.place = i.place || void 0, this.reason = this.message, this.ruleId = i.ruleId || void 0, this.source = i.source || void 0, this.stack = a && i.cause && typeof i.cause.stack == "string" ? i.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
	}
};
Object.defineProperties(jo.prototype, {
	file: {
		configurable: !0,
		enumerable: !0,
		value: "",
		writable: !0
	},
	name: {
		configurable: !0,
		enumerable: !0,
		value: "",
		writable: !0
	},
	reason: {
		configurable: !0,
		enumerable: !0,
		value: "",
		writable: !0
	},
	message: {
		configurable: !0,
		enumerable: !0,
		value: "",
		writable: !0
	},
	stack: {
		configurable: !0,
		enumerable: !0,
		value: "",
		writable: !0
	},
	column: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	line: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	ancestors: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	cause: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	fatal: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	place: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	ruleId: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	},
	source: {
		configurable: !0,
		enumerable: !0,
		writable: !0
	}
});
//#endregion
//#region ../../node_modules/.bun/hast-util-to-jsx-runtime@2.3.7/node_modules/hast-util-to-jsx-runtime/lib/index.js
var Mo = {}.hasOwnProperty, No = /* @__PURE__ */ new Map(), Po = /[A-Z]/g, Fo = /-([a-z])/g, Io = new Set([
	"table",
	"tbody",
	"thead",
	"tfoot",
	"tr"
]), Lo = new Set(["td", "th"]), Ro = "https://github.com/syntax-tree/hast-util-to-jsx-runtime";
function zo(e, t) {
	if (!t || t.Fragment === void 0) throw TypeError("Expected `Fragment` in options");
	let n = t.filePath || void 0, r;
	if (t.development) {
		if (typeof t.jsxDEV != "function") throw TypeError("Expected `jsxDEV` in options when `development: true`");
		r = Xo(n, t.jsxDEV);
	} else {
		if (typeof t.jsx != "function") throw TypeError("Expected `jsx` in production options");
		if (typeof t.jsxs != "function") throw TypeError("Expected `jsxs` in production options");
		r = Yo(n, t.jsx, t.jsxs);
	}
	let i = {
		Fragment: t.Fragment,
		ancestors: [],
		components: t.components || {},
		create: r,
		elementAttributeNameCase: t.elementAttributeNameCase || "react",
		evaluater: t.createEvaluater ? t.createEvaluater() : void 0,
		filePath: n,
		ignoreInvalidStyle: t.ignoreInvalidStyle || !1,
		passKeys: t.passKeys !== !1,
		passNode: t.passNode || !1,
		schema: t.space === "svg" ? me : ue,
		stylePropertyNameCase: t.stylePropertyNameCase || "dom",
		tableCellAlignToStyle: t.tableCellAlignToStyle !== !1
	}, a = Bo(i, e, void 0);
	return a && typeof a != "string" ? a : i.create(e, i.Fragment, { children: a || void 0 }, void 0);
}
function Bo(e, t, n) {
	if (t.type === "element") return Vo(e, t, n);
	if (t.type === "mdxFlowExpression" || t.type === "mdxTextExpression") return Ho(e, t);
	if (t.type === "mdxJsxFlowElement" || t.type === "mdxJsxTextElement") return Wo(e, t, n);
	if (t.type === "mdxjsEsm") return Uo(e, t);
	if (t.type === "root") return Go(e, t, n);
	if (t.type === "text") return Ko(e, t);
}
function Vo(e, t, n) {
	let r = e.schema, i = r;
	t.tagName.toLowerCase() === "svg" && r.space === "html" && (i = me, e.schema = i), e.ancestors.push(t);
	let a = ns(e, t.tagName, !1), o = Zo(e, t), s = $o(e, t);
	return Io.has(t.tagName) && (s = s.filter(function(e) {
		return typeof e == "string" ? !ao(e) : !0;
	})), qo(e, o, a, t), Jo(o, s), e.ancestors.pop(), e.schema = r, e.create(t, a, o, n);
}
function Ho(e, t) {
	if (t.data && t.data.estree && e.evaluater) {
		let n = t.data.estree.body[0];
		return n.type, e.evaluater.evaluateExpression(n.expression);
	}
	rs(e, t.position);
}
function Uo(e, t) {
	if (t.data && t.data.estree && e.evaluater) return e.evaluater.evaluateProgram(t.data.estree);
	rs(e, t.position);
}
function Wo(e, t, n) {
	let r = e.schema, i = r;
	t.name === "svg" && r.space === "html" && (i = me, e.schema = i), e.ancestors.push(t);
	let a = t.name === null ? e.Fragment : ns(e, t.name, !0), o = Qo(e, t), s = $o(e, t);
	return qo(e, o, a, t), Jo(o, s), e.ancestors.pop(), e.schema = r, e.create(t, a, o, n);
}
function Go(e, t, n) {
	let r = {};
	return Jo(r, $o(e, t)), e.create(t, e.Fragment, r, n);
}
function Ko(e, t) {
	return t.value;
}
function qo(e, t, n, r) {
	typeof n != "string" && n !== e.Fragment && e.passNode && (t.node = r);
}
function Jo(e, t) {
	if (t.length > 0) {
		let n = t.length > 1 ? t : t[0];
		n && (e.children = n);
	}
}
function Yo(e, t, n) {
	return r;
	function r(e, r, i, a) {
		let o = Array.isArray(i.children) ? n : t;
		return a ? o(r, i, a) : o(r, i);
	}
}
function Xo(e, t) {
	return n;
	function n(n, r, i, a) {
		let o = Array.isArray(i.children), s = wo(n);
		return t(r, i, a, o, {
			columnNumber: s ? s.column - 1 : void 0,
			fileName: e,
			lineNumber: s ? s.line : void 0
		}, void 0);
	}
}
function Zo(e, t) {
	let n = {}, r, i;
	for (i in t.properties) if (i !== "children" && Mo.call(t.properties, i)) {
		let a = es(e, i, t.properties[i]);
		if (a) {
			let [i, o] = a;
			e.tableCellAlignToStyle && i === "align" && typeof o == "string" && Lo.has(t.tagName) ? r = o : n[i] = o;
		}
	}
	if (r) {
		let t = n.style ||= {};
		t[e.stylePropertyNameCase === "css" ? "text-align" : "textAlign"] = r;
	}
	return n;
}
function Qo(e, t) {
	let n = {};
	for (let r of t.attributes) if (r.type === "mdxJsxExpressionAttribute") if (r.data && r.data.estree && e.evaluater) {
		let t = r.data.estree.body[0];
		t.type;
		let i = t.expression;
		i.type;
		let a = i.properties[0];
		a.type, Object.assign(n, e.evaluater.evaluateExpression(a.argument));
	} else rs(e, t.position);
	else {
		let { name: i } = r, a;
		if (r.value && typeof r.value == "object") if (r.value.data && r.value.data.estree && e.evaluater) {
			let t = r.value.data.estree.body[0];
			t.type, a = e.evaluater.evaluateExpression(t.expression);
		} else rs(e, t.position);
		else a = r.value === null ? !0 : r.value;
		n[i] = a;
	}
	return n;
}
function $o(e, t) {
	let n = [], r = -1, i = e.passKeys ? /* @__PURE__ */ new Map() : No;
	for (; ++r < t.children.length;) {
		let a = t.children[r], o;
		if (e.passKeys) {
			let e = a.type === "element" ? a.tagName : a.type === "mdxJsxFlowElement" || a.type === "mdxJsxTextElement" ? a.name : void 0;
			if (e) {
				let t = i.get(e) || 0;
				o = e + "-" + t, i.set(e, t + 1);
			}
		}
		let s = Bo(e, a, o);
		s !== void 0 && n.push(s);
	}
	return n;
}
function es(e, t, n) {
	if (n == null || typeof n == "number" && Number.isNaN(n)) return;
	let r = be(e.schema, t);
	return Array.isArray(n) && (n = r.commaSeparated ? fe(n) : ve(n)), r.property === "style" ? ["style", typeof n == "object" ? e.stylePropertyNameCase === "dom" ? n : is(n) : ts(e, String(n))] : [e.elementAttributeNameCase === "react" && r.space ? de[r.property] || r.property : r.attribute, n];
}
function ts(e, t) {
	let n = {};
	try {
		So(t, function(t, r) {
			if (t && r) {
				let i = t;
				i.slice(0, 2) !== "--" && (i = i.toLowerCase(), e.stylePropertyNameCase === "dom" && (i.slice(0, 4) === "-ms-" && (i = i.slice(1)), i = i.replace(Fo, ss))), n[i] = r;
			}
		});
	} catch (t) {
		if (e.ignoreInvalidStyle) return {};
		let n = t, r = new jo("Cannot parse `style` attribute", {
			ancestors: e.ancestors,
			cause: n,
			ruleId: "style",
			source: "hast-util-to-jsx-runtime"
		});
		throw r.file = e.filePath || void 0, r.url = Ro + "#cannot-parse-style-attribute", r;
	}
	return n;
}
function ns(e, t, n) {
	let r;
	if (!n) r = {
		type: "Literal",
		value: t
	};
	else if (t.includes(".")) {
		let e = t.split("."), n = -1, i;
		for (; ++n < e.length;) {
			let t = ro(e[n]) ? {
				type: "Identifier",
				name: e[n]
			} : {
				type: "Literal",
				value: e[n]
			};
			i = i ? {
				type: "MemberExpression",
				object: i,
				property: t,
				computed: !!(n && t.type === "Literal"),
				optional: !1
			} : t;
		}
		r = i;
	} else r = ro(t) && !/^[a-z]/.test(t) ? {
		type: "Identifier",
		name: t
	} : {
		type: "Literal",
		value: t
	};
	if (r.type === "Literal") {
		let t = r.value;
		return Mo.call(e.components, t) ? e.components[t] : t;
	}
	if (e.evaluater) return e.evaluater.evaluateExpression(r);
	rs(e);
}
function rs(e, t) {
	let n = new jo("Cannot handle MDX estrees without `createEvaluater`", {
		ancestors: e.ancestors,
		place: t,
		ruleId: "mdx-estree",
		source: "hast-util-to-jsx-runtime"
	});
	throw n.file = e.filePath || void 0, n.url = Ro + "#cannot-handle-mdx-estrees-without-createevaluater", n;
}
function is(e) {
	let t = {}, n;
	for (n in e) Mo.call(e, n) && (t[as(n)] = e[n]);
	return t;
}
function as(e) {
	if (e.slice(0, 2) === "--") return e;
	let t = e.replace(Po, os);
	return t.slice(0, 3) === "ms-" && (t = "-" + t), t;
}
function os(e) {
	return "-" + e.toLowerCase();
}
function ss(e, t) {
	return t.toUpperCase();
}
//#endregion
//#region ../../node_modules/.bun/html-url-attributes@3.0.1/node_modules/html-url-attributes/lib/index.js
var cs = {
	action: ["form"],
	cite: [
		"blockquote",
		"del",
		"ins",
		"q"
	],
	data: ["object"],
	formAction: ["button", "input"],
	href: [
		"a",
		"area",
		"base",
		"link"
	],
	icon: ["menuitem"],
	itemId: null,
	manifest: ["html"],
	ping: ["a", "area"],
	poster: ["video"],
	src: [
		"audio",
		"embed",
		"iframe",
		"img",
		"input",
		"script",
		"source",
		"track",
		"video"
	]
}, ls = {};
function us(e, t) {
	let n = t || ls;
	return ds(e, typeof n.includeImageAlt == "boolean" ? n.includeImageAlt : !0, typeof n.includeHtml == "boolean" ? n.includeHtml : !0);
}
function ds(e, t, n) {
	if (ps(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return fs(e.children, t, n);
	}
	return Array.isArray(e) ? fs(e, t, n) : "";
}
function fs(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = ds(e[i], t, n);
	return r.join("");
}
function ps(e) {
	return !!(e && typeof e == "object");
}
//#endregion
//#region ../../node_modules/.bun/decode-named-character-reference@1.3.0/node_modules/decode-named-character-reference/index.dom.js
var ms = document.createElement("i");
function hs(e) {
	let t = "&" + e + ";";
	ms.innerHTML = t;
	let n = ms.textContent;
	return n.charCodeAt(n.length - 1) === 59 && e !== "semi" || n === t ? !1 : n;
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-chunked@2.0.1/node_modules/micromark-util-chunked/index.js
function gs(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function _s(e, t) {
	return e.length > 0 ? (gs(e, e.length, 0, t), e) : t;
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-combine-extensions@2.0.1/node_modules/micromark-util-combine-extensions/index.js
var vs = {}.hasOwnProperty;
function ys(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) bs(t, e[n]);
	return t;
}
function bs(e, t) {
	let n;
	for (n in t) {
		let r = (vs.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			vs.call(r, a) || (r[a] = []);
			let e = i[a];
			xs(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function xs(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	gs(e, 0, 0, r);
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-decode-numeric-character-reference@2.0.2/node_modules/micromark-util-decode-numeric-character-reference/index.js
function Ss(e, t) {
	let n = Number.parseInt(e, t);
	return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) == 65535 || (n & 65535) == 65534 || n > 1114111 ? "�" : String.fromCodePoint(n);
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-normalize-identifier@2.0.1/node_modules/micromark-util-normalize-identifier/index.js
function Cs(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-character@2.1.1/node_modules/micromark-util-character/index.js
var R = js(/[A-Za-z]/), z = js(/[\dA-Za-z]/), ws = js(/[#-'*+\--9=?A-Z^-~]/);
function Ts(e) {
	return e !== null && (e < 32 || e === 127);
}
var Es = js(/\d/), Ds = js(/[\dA-Fa-f]/), Os = js(/[!-/:-@[-`{-~]/);
function B(e) {
	return e !== null && e < -2;
}
function V(e) {
	return e !== null && (e < 0 || e === 32);
}
function H(e) {
	return e === -2 || e === -1 || e === 32;
}
var ks = js(/\p{P}|\p{S}/u), As = js(/\s/);
function js(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-sanitize-uri@2.0.1/node_modules/micromark-util-sanitize-uri/index.js
function Ms(e) {
	let t = [], n = -1, r = 0, i = 0;
	for (; ++n < e.length;) {
		let a = e.charCodeAt(n), o = "";
		if (a === 37 && z(e.charCodeAt(n + 1)) && z(e.charCodeAt(n + 2))) i = 2;
		else if (a < 128) /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(a)) || (o = String.fromCharCode(a));
		else if (a > 55295 && a < 57344) {
			let t = e.charCodeAt(n + 1);
			a < 56320 && t > 56319 && t < 57344 ? (o = String.fromCharCode(a, t), i = 1) : o = "�";
		} else o = String.fromCharCode(a);
		o &&= (t.push(e.slice(r, n), encodeURIComponent(o)), r = n + i + 1, ""), i &&= (n += i, 0);
	}
	return t.join("") + e.slice(r);
}
//#endregion
//#region ../../node_modules/.bun/micromark-factory-space@2.1.0/node_modules/micromark-factory-space/index.js
function U(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return H(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return H(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function Ns(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && H(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return H(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/initialize/content.js
var Ps = { tokenize: Fs };
function Fs(e) {
	let t = e.attempt(this.parser.constructs.contentInitial, r, i), n;
	return t;
	function r(n) {
		if (n === null) {
			e.consume(n);
			return;
		}
		return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), U(e, t, "linePrefix");
	}
	function i(t) {
		return e.enter("paragraph"), a(t);
	}
	function a(t) {
		let r = e.enter("chunkText", {
			contentType: "text",
			previous: n
		});
		return n && (n.next = r), n = r, o(t);
	}
	function o(t) {
		if (t === null) {
			e.exit("chunkText"), e.exit("paragraph"), e.consume(t);
			return;
		}
		return B(t) ? (e.consume(t), e.exit("chunkText"), a) : (e.consume(t), o);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-edit-map@1.0.0/node_modules/micromark-util-edit-map/index.js
var Is = class {
	constructor() {
		this.index = /* @__PURE__ */ new Map(), this.map = [];
	}
	add(e, t, n) {
		Ls(this, e, t, n, !1);
	}
	addBefore(e, t, n) {
		Ls(this, e, t, n, !0);
	}
	consume(e) {
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function Ls(e, t, n, r, i) {
	if (n === 0 && r.length === 0) return;
	let a = e.index.get(t);
	if (a) {
		a[1] += n, i ? (r.push(...a[2]), a[2] = r) : a[2].push(...r);
		return;
	}
	let o = [
		t,
		n,
		r
	];
	e.map.push(o), e.index.set(t, o);
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/initialize/document.js
var Rs = { tokenize: Bs }, zs = { tokenize: Vs };
function Bs(e) {
	let t = this, n = [], r = 0, i, a, o;
	return s;
	function s(i) {
		if (r < n.length) {
			let a = n[r];
			return t.containerState = a[1], e.attempt(a[0].continuation, c, l)(i);
		}
		return l(i);
	}
	function c(e) {
		if (r++, t.containerState._closeFlow) {
			t.containerState._closeFlow = void 0, i && v();
			let n = t.events.length, a = n, o;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				o = t.events[a][1].end;
				break;
			}
			_(r);
			let s = n;
			for (; s < t.events.length;) t.events[s][1].end = { ...o }, s++;
			let c = new Is();
			return c.add(a + 1, 0, t.events.slice(n)), c.add(n, s - n, []), c.consume(t.events), l(e);
		}
		return s(e);
	}
	function l(a) {
		if (r === n.length) {
			if (!i) return f(a);
			if (i.currentConstruct && i.currentConstruct.concrete) return m(a);
			t.interrupt = !!(i.currentConstruct && !i._gfmTableDynamicInterruptHack);
		}
		return t.containerState = {}, e.check(zs, u, d)(a);
	}
	function u(e) {
		return i && v(), _(r), f(e);
	}
	function d(e) {
		return t.parser.lazy[t.now().line] = r !== n.length, o = t.now().offset, m(e);
	}
	function f(n) {
		return t.containerState = {}, e.attempt(zs, p, m)(n);
	}
	function p(e) {
		return r++, n.push([t.currentConstruct, t.containerState]), f(e);
	}
	function m(n) {
		if (n === null) {
			i && v(), _(0), e.consume(n);
			return;
		}
		return i ||= t.parser.flow(t.now()), e.enter("chunkFlow", {
			_tokenizer: i,
			contentType: "flow",
			previous: a
		}), h(n);
	}
	function h(n) {
		if (n === null) {
			g(e.exit("chunkFlow"), !0), _(0), e.consume(n);
			return;
		}
		return B(n) ? (e.consume(n), g(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(n), h);
	}
	function g(e, n) {
		let s = t.sliceStream(e);
		if (n && s.push(null), e.previous = a, a && (a.next = e), a = e, i.defineSkip(e.start), i.write(s), t.parser.lazy[e.start.line]) {
			let e = i.events.length;
			for (; e--;) if (i.events[e][1].start.offset < o && (!i.events[e][1].end || i.events[e][1].end.offset > o)) return;
			let n = t.events.length, a = n, s, c;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				if (s) {
					c = t.events[a][1].end;
					break;
				}
				s = !0;
			}
			for (_(r), e = n; e < t.events.length;) t.events[e][1].end = { ...c }, e++;
			let l = new Is();
			l.add(a + 1, 0, t.events.slice(n)), l.add(n, e - n, []), l.consume(t.events);
		}
	}
	function _(r) {
		let i = n.length;
		for (; i-- > r;) {
			let r = n[i];
			t.containerState = r[1], r[0].exit.call(t, e);
		}
		n.length = r;
	}
	function v() {
		i.write([null]), a = void 0, i = void 0, t.containerState._closeFlow = void 0;
	}
}
function Vs(e, t, n) {
	return U(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-classify-character@2.0.1/node_modules/micromark-util-classify-character/index.js
function Hs(e) {
	if (e === null || V(e) || As(e)) return 1;
	if (ks(e)) return 2;
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-resolve-all@2.0.1/node_modules/micromark-util-resolve-all/index.js
function Us(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/attention.js
var Ws = {
	name: "attention",
	resolveAll: Gs,
	tokenize: Ks
};
function Gs(e, t) {
	let n = -1, r;
	for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
		let i = n;
		for (; i--;) if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
			if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
			let a = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, o = { ...e[i][1].end }, s = { ...e[n][1].start };
			qs(o, -a), qs(s, a);
			let c = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: o,
				end: { ...e[i][1].end }
			}, l = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: { ...e[n][1].start },
				end: s
			}, u = {
				type: a > 1 ? "strongText" : "emphasisText",
				start: { ...e[i][1].end },
				end: { ...e[n][1].start }
			}, d = {
				type: a > 1 ? "strong" : "emphasis",
				start: { ...c.start },
				end: { ...l.end }
			};
			e[i][1].end = { ...c.start }, e[n][1].start = { ...l.end }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = _s(r, [[
				"enter",
				e[i][1],
				t
			], [
				"exit",
				e[i][1],
				t
			]])), r = _s(r, [
				[
					"enter",
					d,
					t
				],
				[
					"enter",
					c,
					t
				],
				[
					"exit",
					c,
					t
				],
				[
					"enter",
					u,
					t
				]
			]), r = _s(r, Us(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = _s(r, [
				[
					"exit",
					u,
					t
				],
				[
					"enter",
					l,
					t
				],
				[
					"exit",
					l,
					t
				],
				[
					"exit",
					d,
					t
				]
			]);
			let f = 0;
			e[n][1].end.offset - e[n][1].start.offset && (f = 2, r = _s(r, [[
				"enter",
				e[n][1],
				t
			], [
				"exit",
				e[n][1],
				t
			]])), gs(e, i - 1, n - i + 3, r), n = i + r.length - f - 2;
			break;
		}
	}
	for (n = -1; ++n < e.length;) e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
	return e;
}
function Ks(e, t) {
	let n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = Hs(r), a;
	return o;
	function o(t) {
		return a = t, e.enter("attentionSequence"), s(t);
	}
	function s(o) {
		if (o === a) return e.consume(o), s;
		let c = e.exit("attentionSequence"), l = Hs(o), u = !l || l === 2 && i || n.includes(o) && o !== 42 && o !== 95, d = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
		return c._open = !!(a === 42 ? u : u && (i || !d)), c._close = !!(a === 42 ? d : d && (l || !u)), t(o);
	}
}
function qs(e, t) {
	e.column += t, e.offset += t, e._bufferIndex += t;
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/autolink.js
var Js = {
	name: "autolink",
	tokenize: Ys
};
function Ys(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(t), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), a;
	}
	function a(t) {
		return R(t) ? (e.consume(t), o) : t === 64 ? n(t) : l(t);
	}
	function o(e) {
		return e === 43 || e === 45 || e === 46 || z(e) ? (r = 1, s(e)) : l(e);
	}
	function s(t) {
		return t === 58 ? (e.consume(t), r = 0, c) : (t === 43 || t === 45 || t === 46 || z(t)) && r++ < 32 ? (e.consume(t), s) : (r = 0, l(t));
	}
	function c(r) {
		return r === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(r), e.exit("autolinkMarker"), e.exit("autolink"), t) : r === null || r === 32 || r === 60 || Ts(r) ? n(r) : (e.consume(r), c);
	}
	function l(t) {
		return t === 64 ? (e.consume(t), u) : ws(t) ? (e.consume(t), l) : n(t);
	}
	function u(e) {
		return z(e) ? d(e) : n(e);
	}
	function d(n) {
		return n === 46 ? (e.consume(n), r = 0, u) : n === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(n), e.exit("autolinkMarker"), e.exit("autolink"), t) : f(n);
	}
	function f(t) {
		if ((t === 45 || z(t)) && r++ < 63) {
			let n = t === 45 ? f : d;
			return e.consume(t), n;
		}
		return n(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/blank-line.js
var Xs = {
	partial: !0,
	tokenize: Zs
};
function Zs(e, t, n) {
	return r;
	function r(t) {
		return H(t) ? U(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || B(e) ? t(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/block-quote.js
var Qs = {
	continuation: { tokenize: ec },
	exit: tc,
	name: "blockQuote",
	tokenize: $s
};
function $s(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		if (t === 62) {
			let n = r.containerState;
			return n.open ||= (e.enter("blockQuote", { _container: !0 }), !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(t), e.exit("blockQuoteMarker"), a;
		}
		return n(t);
	}
	function a(n) {
		return H(n) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(n), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(n));
	}
}
function ec(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return H(t) ? U(e, a, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : a(t);
	}
	function a(r) {
		return e.attempt(Qs, t, n)(r);
	}
}
function tc(e) {
	e.exit("blockQuote");
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/character-escape.js
var nc = {
	name: "characterEscape",
	tokenize: rc
};
function rc(e, t, n) {
	return r;
	function r(t) {
		return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(t), e.exit("escapeMarker"), i;
	}
	function i(r) {
		return Os(r) ? (e.enter("characterEscapeValue"), e.consume(r), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(r);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/character-reference.js
var ic = {
	name: "characterReference",
	tokenize: ac
};
function ac(e, t, n) {
	let r = this, i = 0, a, o;
	return s;
	function s(t) {
		return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(t), e.exit("characterReferenceMarker"), c;
	}
	function c(t) {
		return t === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(t), e.exit("characterReferenceMarkerNumeric"), l) : (e.enter("characterReferenceValue"), a = 31, o = z, u(t));
	}
	function l(t) {
		return t === 88 || t === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(t), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), a = 6, o = Ds, u) : (e.enter("characterReferenceValue"), a = 7, o = Es, u(t));
	}
	function u(s) {
		if (s === 59 && i) {
			let i = e.exit("characterReferenceValue");
			return o === z && !hs(r.sliceSerialize(i)) ? n(s) : (e.enter("characterReferenceMarker"), e.consume(s), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
		}
		return o(s) && i++ < a ? (e.consume(s), u) : n(s);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/partial-non-lazy-continuation.js
var oc = {
	partial: !0,
	tokenize: sc
};
function sc(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t === null ? n(t) : (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), a);
	}
	function a(e) {
		return r.parser.lazy[r.now().line] ? n(e) : t(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/code-fenced.js
var cc = {
	concrete: !0,
	name: "codeFenced",
	tokenize: lc
};
function lc(e, t, n) {
	let r = this, i = {
		partial: !0,
		tokenize: x
	}, a = 0, o = 0, s;
	return c;
	function c(e) {
		return l(e);
	}
	function l(t) {
		let n = r.events[r.events.length - 1];
		return a = n && n[1].type === "linePrefix" ? n[2].sliceSerialize(n[1], !0).length : 0, s = t, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), u(t);
	}
	function u(t) {
		return t === s ? (o++, e.consume(t), u) : o < 3 ? n(t) : (e.exit("codeFencedFenceSequence"), H(t) ? U(e, d, "whitespace")(t) : d(t));
	}
	function d(n) {
		return n === null || B(n) ? (e.exit("codeFencedFence"), r.interrupt ? t(n) : e.check(oc, h, b)(n)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", { contentType: "string" }), f(n));
	}
	function f(t) {
		return t === null || B(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), d(t)) : H(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), U(e, p, "whitespace")(t)) : t === 96 && t === s ? n(t) : (e.consume(t), f);
	}
	function p(t) {
		return t === null || B(t) ? d(t) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", { contentType: "string" }), m(t));
	}
	function m(t) {
		return t === null || B(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), d(t)) : t === 96 && t === s ? n(t) : (e.consume(t), m);
	}
	function h(t) {
		return e.attempt(i, b, g)(t);
	}
	function g(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), _;
	}
	function _(t) {
		return a > 0 && H(t) ? U(e, v, "linePrefix", a + 1)(t) : v(t);
	}
	function v(t) {
		return t === null || B(t) ? e.check(oc, h, b)(t) : (e.enter("codeFlowValue"), y(t));
	}
	function y(t) {
		return t === null || B(t) ? (e.exit("codeFlowValue"), v(t)) : (e.consume(t), y);
	}
	function b(n) {
		return e.exit("codeFenced"), t(n);
	}
	function x(e, t, n) {
		let i = 0;
		return a;
		function a(t) {
			return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c;
		}
		function c(t) {
			return e.enter("codeFencedFence"), H(t) ? U(e, l, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : l(t);
		}
		function l(t) {
			return t === s ? (e.enter("codeFencedFenceSequence"), u(t)) : n(t);
		}
		function u(t) {
			return t === s ? (i++, e.consume(t), u) : i >= o ? (e.exit("codeFencedFenceSequence"), H(t) ? U(e, d, "whitespace")(t) : d(t)) : n(t);
		}
		function d(r) {
			return r === null || B(r) ? (e.exit("codeFencedFence"), t(r)) : n(r);
		}
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/code-indented.js
var uc = {
	name: "codeIndented",
	tokenize: fc
}, dc = {
	partial: !0,
	tokenize: pc
};
function fc(e, t, n) {
	return r;
	function r(t) {
		return e.enter("codeIndented"), Ns(e, i, n, "linePrefix", 4, 4)(t);
	}
	function i(t) {
		return t === null ? o(t) : B(t) ? e.attempt(dc, i, o)(t) : (e.enter("codeFlowValue"), a(t));
	}
	function a(t) {
		return t === null || B(t) ? (e.exit("codeFlowValue"), i(t)) : (e.consume(t), a);
	}
	function o(n) {
		return e.exit("codeIndented"), t(n);
	}
}
function pc(e, t, n) {
	let r = this;
	return i;
	function i(o) {
		return r.parser.lazy[r.now().line] ? n(o) : B(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), i) : Ns(e, t, a, "linePrefix", 4, 4)(o);
	}
	function a(e) {
		return B(e) ? i(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/code-text.js
var mc = {
	name: "codeText",
	previous: gc,
	resolve: hc,
	tokenize: _c
};
function hc(e) {
	let t = e.length - 4, n = 3, r, i;
	if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
		for (r = n; ++r < t;) if (e[r][1].type === "codeTextData") {
			e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
			break;
		}
	}
	for (r = n - 1, t++; ++r <= t;) i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
	return e;
}
function gc(e) {
	return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function _c(e, t, n) {
	let r = 0, i, a;
	return o;
	function o(t) {
		return e.enter("codeText"), e.enter("codeTextSequence"), s(t);
	}
	function s(t) {
		return t === 96 ? (e.consume(t), r++, s) : (e.exit("codeTextSequence"), c(t));
	}
	function c(t) {
		return t === null ? n(t) : t === 32 ? (e.enter("space"), e.consume(t), e.exit("space"), c) : t === 96 ? (a = e.enter("codeTextSequence"), i = 0, u(t)) : B(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c) : (e.enter("codeTextData"), l(t));
	}
	function l(t) {
		return t === null || t === 32 || t === 96 || B(t) ? (e.exit("codeTextData"), c(t)) : (e.consume(t), l);
	}
	function u(n) {
		return n === 96 ? (e.consume(n), i++, u) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(n)) : (a.type = "codeTextData", l(n));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-subtokenize@2.1.0/node_modules/micromark-util-subtokenize/lib/splice-buffer.js
var vc = class {
	constructor(e) {
		this.left = e ? [...e] : [], this.right = [];
	}
	get(e) {
		if (e < 0 || e >= this.left.length + this.right.length) throw RangeError("Cannot access index `" + e + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
		return e < this.left.length ? this.left[e] : this.right[this.right.length - e + this.left.length - 1];
	}
	get length() {
		return this.left.length + this.right.length;
	}
	shift() {
		return this.setCursor(0), this.right.pop();
	}
	slice(e, t) {
		let n = t ?? Infinity;
		return n < this.left.length ? this.left.slice(e, n) : e > this.left.length ? this.right.slice(this.right.length - n + this.left.length, this.right.length - e + this.left.length).reverse() : this.left.slice(e).concat(this.right.slice(this.right.length - n + this.left.length).reverse());
	}
	splice(e, t, n) {
		let r = t || 0;
		this.setCursor(Math.trunc(e));
		let i = this.right.splice(this.right.length - r, Infinity);
		return n && yc(this.left, n), i.reverse();
	}
	pop() {
		return this.setCursor(Infinity), this.left.pop();
	}
	push(e) {
		this.setCursor(Infinity), this.left.push(e);
	}
	pushMany(e) {
		this.setCursor(Infinity), yc(this.left, e);
	}
	unshift(e) {
		this.setCursor(0), this.right.push(e);
	}
	unshiftMany(e) {
		this.setCursor(0), yc(this.right, e.reverse());
	}
	setCursor(e) {
		if (!(e === this.left.length || e > this.left.length && this.right.length === 0 || e < 0 && this.left.length === 0)) if (e < this.left.length) {
			let t = this.left.splice(e, Infinity);
			yc(this.right, t.reverse());
		} else {
			let t = this.right.splice(this.left.length + this.right.length - e, Infinity);
			yc(this.left, t.reverse());
		}
	}
};
function yc(e, t) {
	let n = 0;
	if (t.length < 1e4) e.push(...t);
	else for (; n < t.length;) e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-subtokenize@2.1.0/node_modules/micromark-util-subtokenize/index.js
function bc(e) {
	let t = {}, n = -1, r, i, a, o, s, c, l, u = new vc(e);
	for (; ++n < u.length;) {
		for (; n in t;) n = t[n];
		if (r = u.get(n), n && r[1].type === "chunkFlow" && u.get(n - 1)[1].type === "listItemPrefix" && (c = r[1]._tokenizer.events, a = 0, a < c.length && c[a][1].type === "lineEndingBlank" && (a += 2), a < c.length && c[a][1].type === "content")) for (; ++a < c.length && c[a][1].type !== "content";) c[a][1].type === "chunkText" && (c[a][1]._isInFirstContentOfListItem = !0, a++);
		if (r[0] === "enter") r[1].contentType && (Object.assign(t, xc(u, n)), n = t[n], l = !0);
		else if (r[1]._container) {
			for (a = n, i = void 0; a--;) if (o = u.get(a), o[1].type === "lineEnding" || o[1].type === "lineEndingBlank") o[0] === "enter" && (i && (u.get(i)[1].type = "lineEndingBlank"), o[1].type = "lineEnding", i = a);
			else if (!(o[1].type === "linePrefix" || o[1].type === "listItemIndent")) break;
			i && (r[1].end = { ...u.get(i)[1].start }, s = u.slice(i, n), s.unshift(r), u.splice(i, n - i + 1, s));
		}
	}
	return gs(e, 0, Infinity, u.slice(0)), !l;
}
function xc(e, t) {
	let n = e.get(t)[1], r = e.get(t)[2], i = t - 1, a = [], o = n._tokenizer;
	o || (o = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (o._contentTypeTextTrailing = !0));
	let s = o.events, c = [], l = {}, u, d, f = -1, p = n, m = 0, h = 0, g = [h];
	for (; p;) {
		for (; e.get(++i)[1] !== p;);
		a.push(i), p._tokenizer || (u = r.sliceStream(p), p.next || u.push(null), d && o.defineSkip(p.start), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = !0), o.write(u), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = void 0)), d = p, p = p.next;
	}
	for (p = n; ++f < s.length;) s[f][0] === "exit" && s[f - 1][0] === "enter" && s[f][1].type === s[f - 1][1].type && s[f][1].start.line !== s[f][1].end.line && (h = f + 1, g.push(h), p._tokenizer = void 0, p.previous = void 0, p = p.next);
	for (o.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : g.pop(), f = g.length; f--;) {
		let t = s.slice(g[f], g[f + 1]), n = a.pop();
		c.push([n, n + t.length - 1]), e.splice(n, 2, t);
	}
	for (c.reverse(), f = -1; ++f < c.length;) l[m + c[f][0]] = m + c[f][1], m += c[f][1] - c[f][0] - 1;
	return l;
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/content.js
var Sc = {
	resolve: wc,
	tokenize: Tc
}, Cc = {
	partial: !0,
	tokenize: Ec
};
function wc(e) {
	return bc(e), e;
}
function Tc(e, t) {
	let n;
	return r;
	function r(t) {
		return e.enter("content"), n = e.enter("chunkContent", { contentType: "content" }), i(t);
	}
	function i(t) {
		return t === null ? a(t) : B(t) ? e.check(Cc, o, a)(t) : (e.consume(t), i);
	}
	function a(n) {
		return e.exit("chunkContent"), e.exit("content"), t(n);
	}
	function o(t) {
		return e.consume(t), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
			contentType: "content",
			previous: n
		}), n = n.next, i;
	}
}
function Ec(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), U(e, a, "linePrefix");
	}
	function a(i) {
		if (i === null || B(i)) return n(i);
		let a = r.events[r.events.length - 1];
		return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? t(i) : e.interrupt(r.parser.constructs.flow, n, t)(i);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-factory-destination@2.0.1/node_modules/micromark-factory-destination/index.js
function Dc(e, t, n, r, i, a, o, s, c) {
	let l = c || Infinity, u = 0;
	return d;
	function d(t) {
		return t === 60 ? (e.enter(r), e.enter(i), e.enter(a), e.consume(t), e.exit(a), f) : t === null || t === 32 || t === 41 || Ts(t) ? n(t) : (e.enter(r), e.enter(o), e.enter(s), e.enter("chunkString", { contentType: "string" }), h(t));
	}
	function f(n) {
		return n === 62 ? (e.enter(a), e.consume(n), e.exit(a), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", { contentType: "string" }), p(n));
	}
	function p(t) {
		return t === 62 ? (e.exit("chunkString"), e.exit(s), f(t)) : t === null || t === 60 || B(t) ? n(t) : (e.consume(t), t === 92 ? m : p);
	}
	function m(t) {
		return t === 60 || t === 62 || t === 92 ? (e.consume(t), p) : p(t);
	}
	function h(i) {
		return !u && (i === null || i === 41 || V(i)) ? (e.exit("chunkString"), e.exit(s), e.exit(o), e.exit(r), t(i)) : u < l && i === 40 ? (e.consume(i), u++, h) : i === 41 ? (e.consume(i), u--, h) : i === null || i === 32 || i === 40 || Ts(i) ? n(i) : (e.consume(i), i === 92 ? g : h);
	}
	function g(t) {
		return t === 40 || t === 41 || t === 92 ? (e.consume(t), h) : h(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-factory-label@2.0.1/node_modules/micromark-factory-label/index.js
function Oc(e, t, n, r, i, a) {
	let o = this, s = 0, c;
	return l;
	function l(t) {
		return e.enter(r), e.enter(i), e.consume(t), e.exit(i), e.enter(a), u;
	}
	function u(l) {
		return s > 999 || l === null || l === 91 || l === 93 && !c || l === 94 && !s && "_hiddenFootnoteSupport" in o.parser.constructs ? n(l) : l === 93 ? (e.exit(a), e.enter(i), e.consume(l), e.exit(i), e.exit(r), t) : B(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), u) : (e.enter("chunkString", { contentType: "string" }), d(l));
	}
	function d(t) {
		return t === null || t === 91 || t === 93 || B(t) || s++ > 999 ? (e.exit("chunkString"), u(t)) : (e.consume(t), c ||= !H(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), s++, d) : d(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-factory-title@2.0.1/node_modules/micromark-factory-title/index.js
function kc(e, t, n, r, i, a) {
	let o;
	return s;
	function s(t) {
		return t === 34 || t === 39 || t === 40 ? (e.enter(r), e.enter(i), e.consume(t), e.exit(i), o = t === 40 ? 41 : t, c) : n(t);
	}
	function c(n) {
		return n === o ? (e.enter(i), e.consume(n), e.exit(i), e.exit(r), t) : (e.enter(a), l(n));
	}
	function l(t) {
		return t === o ? (e.exit(a), c(o)) : t === null ? n(t) : B(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), U(e, l, "linePrefix")) : (e.enter("chunkString", { contentType: "string" }), u(t));
	}
	function u(t) {
		return t === o || t === null || B(t) ? (e.exit("chunkString"), l(t)) : (e.consume(t), t === 92 ? d : u);
	}
	function d(t) {
		return t === o || t === 92 ? (e.consume(t), u) : u(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-factory-whitespace@2.0.1/node_modules/micromark-factory-whitespace/index.js
function Ac(e, t) {
	let n;
	return r;
	function r(i) {
		return B(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : H(i) ? U(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/definition.js
var jc = {
	name: "definition",
	tokenize: Nc
}, Mc = {
	partial: !0,
	tokenize: Pc
};
function Nc(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("definition"), o(t);
	}
	function o(t) {
		return Oc.call(r, e, s, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(t);
	}
	function s(t) {
		return i = Cs(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), c) : n(t);
	}
	function c(t) {
		return V(t) ? Ac(e, l)(t) : l(t);
	}
	function l(t) {
		return Dc(e, u, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(t);
	}
	function u(t) {
		return e.attempt(Mc, d, d)(t);
	}
	function d(t) {
		return H(t) ? U(e, f, "whitespace")(t) : f(t);
	}
	function f(a) {
		return a === null || B(a) ? (e.exit("definition"), r.parser.defined.push(i), t(a)) : n(a);
	}
}
function Pc(e, t, n) {
	return r;
	function r(t) {
		return V(t) ? Ac(e, i)(t) : n(t);
	}
	function i(t) {
		return kc(e, a, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(t);
	}
	function a(t) {
		return H(t) ? U(e, o, "whitespace")(t) : o(t);
	}
	function o(e) {
		return e === null || B(e) ? t(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/hard-break-escape.js
var Fc = {
	name: "hardBreakEscape",
	tokenize: Ic
};
function Ic(e, t, n) {
	return r;
	function r(t) {
		return e.enter("hardBreakEscape"), e.consume(t), i;
	}
	function i(r) {
		return B(r) ? (e.exit("hardBreakEscape"), t(r)) : n(r);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/heading-atx.js
var Lc = {
	name: "headingAtx",
	resolve: Rc,
	tokenize: zc
};
function Rc(e, t) {
	let n = e.length - 2, r = 3;
	if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
		let i = {
			type: "atxHeadingText",
			start: e[r][1].start,
			end: e[n][1].end
		}, a = {
			type: "chunkText",
			start: e[r][1].start,
			end: e[n][1].end,
			contentType: "text"
		};
		gs(e, r, n - r + 1, [
			[
				"enter",
				i,
				t
			],
			[
				"enter",
				a,
				t
			],
			[
				"exit",
				a,
				t
			],
			[
				"exit",
				i,
				t
			]
		]);
	}
	return e;
}
function zc(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("atxHeading"), a(t);
	}
	function a(t) {
		return e.enter("atxHeadingSequence"), o(t);
	}
	function o(t) {
		return t === 35 && r++ < 6 ? (e.consume(t), o) : t === null || V(t) ? (e.exit("atxHeadingSequence"), s(t)) : n(t);
	}
	function s(n) {
		return n === 35 ? (e.enter("atxHeadingSequence"), c(n)) : n === null || B(n) ? (e.exit("atxHeading"), t(n)) : H(n) ? U(e, s, "whitespace")(n) : (e.enter("atxHeadingText"), l(n));
	}
	function c(t) {
		return t === 35 ? (e.consume(t), c) : (e.exit("atxHeadingSequence"), s(t));
	}
	function l(t) {
		return t === null || t === 35 || V(t) ? (e.exit("atxHeadingText"), s(t)) : (e.consume(t), l);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-html-tag-name@2.0.1/node_modules/micromark-util-html-tag-name/index.js
var Bc = /* @__PURE__ */ "address.article.aside.base.basefont.blockquote.body.caption.center.col.colgroup.dd.details.dialog.dir.div.dl.dt.fieldset.figcaption.figure.footer.form.frame.frameset.h1.h2.h3.h4.h5.h6.head.header.hr.html.iframe.legend.li.link.main.menu.menuitem.nav.noframes.ol.optgroup.option.p.param.search.section.summary.table.tbody.td.tfoot.th.thead.title.tr.track.ul".split("."), Vc = [
	"pre",
	"script",
	"style",
	"textarea"
], Hc = {
	concrete: !0,
	name: "htmlFlow",
	resolveTo: Wc,
	tokenize: Gc
}, Uc = {
	partial: !0,
	tokenize: Kc
};
function Wc(e) {
	let t = e.length;
	for (; t-- && !(e[t][0] === "enter" && e[t][1].type === "htmlFlow"););
	return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function Gc(e, t, n) {
	let r = this, i, a, o, s, c;
	return l;
	function l(e) {
		return u(e);
	}
	function u(t) {
		return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(t), d;
	}
	function d(s) {
		return s === 33 ? (e.consume(s), f) : s === 47 ? (e.consume(s), a = !0, h) : s === 63 ? (e.consume(s), i = 3, r.interrupt ? t : ne) : R(s) ? (e.consume(s), o = String.fromCharCode(s), g) : n(s);
	}
	function f(a) {
		return a === 45 ? (e.consume(a), i = 2, p) : a === 91 ? (e.consume(a), i = 5, s = 0, m) : R(a) ? (e.consume(a), i = 4, r.interrupt ? t : ne) : n(a);
	}
	function p(i) {
		return i === 45 ? (e.consume(i), r.interrupt ? t : ne) : n(i);
	}
	function m(i) {
		return i === "CDATA[".charCodeAt(s++) ? (e.consume(i), s === 6 ? r.interrupt ? t : O : m) : n(i);
	}
	function h(t) {
		return R(t) ? (e.consume(t), o = String.fromCharCode(t), g) : n(t);
	}
	function g(s) {
		if (s === null || s === 47 || s === 62 || V(s)) {
			let c = s === 47, l = o.toLowerCase();
			return !c && !a && Vc.includes(l) ? (i = 1, r.interrupt ? t(s) : O(s)) : Bc.includes(o.toLowerCase()) ? (i = 6, c ? (e.consume(s), _) : r.interrupt ? t(s) : O(s)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(s) : a ? v(s) : y(s));
		}
		return s === 45 || z(s) ? (e.consume(s), o += String.fromCharCode(s), g) : n(s);
	}
	function _(i) {
		return i === 62 ? (e.consume(i), r.interrupt ? t : O) : n(i);
	}
	function v(t) {
		return H(t) ? (e.consume(t), v) : E(t);
	}
	function y(t) {
		return t === 47 ? (e.consume(t), E) : t === 58 || t === 95 || R(t) ? (e.consume(t), b) : H(t) ? (e.consume(t), y) : E(t);
	}
	function b(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || z(t) ? (e.consume(t), b) : x(t);
	}
	function x(t) {
		return t === 61 ? (e.consume(t), S) : H(t) ? (e.consume(t), x) : y(t);
	}
	function S(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), c = t, C) : H(t) ? (e.consume(t), S) : w(t);
	}
	function C(t) {
		return t === c ? (e.consume(t), c = null, T) : t === null || B(t) ? n(t) : (e.consume(t), C);
	}
	function w(t) {
		return t === null || t === 34 || t === 39 || t === 47 || t === 60 || t === 61 || t === 62 || t === 96 || V(t) ? x(t) : (e.consume(t), w);
	}
	function T(e) {
		return e === 47 || e === 62 || H(e) ? y(e) : n(e);
	}
	function E(t) {
		return t === 62 ? (e.consume(t), D) : n(t);
	}
	function D(t) {
		return t === null || B(t) ? O(t) : H(t) ? (e.consume(t), D) : n(t);
	}
	function O(t) {
		return t === 45 && i === 2 ? (e.consume(t), M) : t === 60 && i === 1 ? (e.consume(t), N) : t === 62 && i === 4 ? (e.consume(t), re) : t === 63 && i === 3 ? (e.consume(t), ne) : t === 93 && i === 5 ? (e.consume(t), te) : B(t) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(Uc, ie, k)(t)) : t === null || B(t) ? (e.exit("htmlFlowData"), k(t)) : (e.consume(t), O);
	}
	function k(t) {
		return e.check(oc, A, ie)(t);
	}
	function A(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), j;
	}
	function j(t) {
		return t === null || B(t) ? k(t) : (e.enter("htmlFlowData"), O(t));
	}
	function M(t) {
		return t === 45 ? (e.consume(t), ne) : O(t);
	}
	function N(t) {
		return t === 47 ? (e.consume(t), o = "", ee) : O(t);
	}
	function ee(t) {
		if (t === 62) {
			let n = o.toLowerCase();
			return Vc.includes(n) ? (e.consume(t), re) : O(t);
		}
		return R(t) && o.length < 8 ? (e.consume(t), o += String.fromCharCode(t), ee) : O(t);
	}
	function te(t) {
		return t === 93 ? (e.consume(t), ne) : O(t);
	}
	function ne(t) {
		return t === 62 ? (e.consume(t), re) : t === 45 && i === 2 ? (e.consume(t), ne) : O(t);
	}
	function re(t) {
		return t === null || B(t) ? (e.exit("htmlFlowData"), ie(t)) : (e.consume(t), re);
	}
	function ie(n) {
		return e.exit("htmlFlow"), t(n);
	}
}
function Kc(e, t, n) {
	return r;
	function r(r) {
		return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), e.attempt(Xs, t, n);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/html-text.js
var qc = {
	name: "htmlText",
	tokenize: Jc
};
function Jc(e, t, n) {
	let r = this, i, a, o;
	return s;
	function s(t) {
		return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), c;
	}
	function c(t) {
		return t === 33 ? (e.consume(t), l) : t === 47 ? (e.consume(t), x) : t === 63 ? (e.consume(t), y) : R(t) ? (e.consume(t), w) : n(t);
	}
	function l(t) {
		return t === 45 ? (e.consume(t), u) : t === 91 ? (e.consume(t), a = 0, m) : R(t) ? (e.consume(t), v) : n(t);
	}
	function u(t) {
		return t === 45 ? (e.consume(t), p) : n(t);
	}
	function d(t) {
		return t === null ? n(t) : t === 45 ? (e.consume(t), f) : B(t) ? (o = d, N(t)) : (e.consume(t), d);
	}
	function f(t) {
		return t === 45 ? (e.consume(t), p) : d(t);
	}
	function p(e) {
		return e === 62 ? M(e) : e === 45 ? f(e) : d(e);
	}
	function m(t) {
		return t === "CDATA[".charCodeAt(a++) ? (e.consume(t), a === 6 ? h : m) : n(t);
	}
	function h(t) {
		return t === null ? n(t) : t === 93 ? (e.consume(t), g) : B(t) ? (o = h, N(t)) : (e.consume(t), h);
	}
	function g(t) {
		return t === 93 ? (e.consume(t), _) : h(t);
	}
	function _(t) {
		return t === 62 ? M(t) : t === 93 ? (e.consume(t), _) : h(t);
	}
	function v(t) {
		return t === null || t === 62 ? M(t) : B(t) ? (o = v, N(t)) : (e.consume(t), v);
	}
	function y(t) {
		return t === null ? n(t) : t === 63 ? (e.consume(t), b) : B(t) ? (o = y, N(t)) : (e.consume(t), y);
	}
	function b(e) {
		return e === 62 ? M(e) : y(e);
	}
	function x(t) {
		return R(t) ? (e.consume(t), S) : n(t);
	}
	function S(t) {
		return t === 45 || z(t) ? (e.consume(t), S) : C(t);
	}
	function C(t) {
		return B(t) ? (o = C, N(t)) : H(t) ? (e.consume(t), C) : M(t);
	}
	function w(t) {
		return t === 45 || z(t) ? (e.consume(t), w) : t === 47 || t === 62 || V(t) ? T(t) : n(t);
	}
	function T(t) {
		return t === 47 ? (e.consume(t), M) : t === 58 || t === 95 || R(t) ? (e.consume(t), E) : B(t) ? (o = T, N(t)) : H(t) ? (e.consume(t), T) : M(t);
	}
	function E(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || z(t) ? (e.consume(t), E) : D(t);
	}
	function D(t) {
		return t === 61 ? (e.consume(t), O) : B(t) ? (o = D, N(t)) : H(t) ? (e.consume(t), D) : T(t);
	}
	function O(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), i = t, k) : B(t) ? (o = O, N(t)) : H(t) ? (e.consume(t), O) : (e.consume(t), A);
	}
	function k(t) {
		return t === i ? (e.consume(t), i = void 0, j) : t === null ? n(t) : B(t) ? (o = k, N(t)) : (e.consume(t), k);
	}
	function A(t) {
		return t === null || t === 34 || t === 39 || t === 60 || t === 61 || t === 96 ? n(t) : t === 47 || t === 62 || V(t) ? T(t) : (e.consume(t), A);
	}
	function j(e) {
		return e === 47 || e === 62 || V(e) ? T(e) : n(e);
	}
	function M(r) {
		return r === 62 ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(r);
	}
	function N(t) {
		return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), ee;
	}
	function ee(t) {
		return H(t) ? U(e, te, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : te(t);
	}
	function te(t) {
		return e.enter("htmlTextData"), o(t);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/label-end.js
var Yc = {
	name: "labelEnd",
	resolveAll: $c,
	resolveTo: el,
	tokenize: tl
}, Xc = { tokenize: nl }, Zc = { tokenize: rl }, Qc = { tokenize: il };
function $c(e) {
	let t = -1, n = [];
	for (; ++t < e.length;) {
		let r = e[t][1];
		if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
			let e = r.type === "labelImage" ? 4 : 2;
			r.type = "data", t += e;
		}
	}
	return e.length !== n.length && gs(e, 0, e.length, n), e;
}
function el(e, t) {
	let n = e.length, r = 0, i, a, o;
	for (; n--;) {
		let t = e[n][1];
		if (i) {
			if (t.type === "link" || t.type === "labelLink" && t._inactive) break;
			e[n][0] === "enter" && t.type === "labelLink" && (t._inactive = !0);
		} else if (a) {
			if (e[n][0] === "enter" && (t.type === "labelImage" || t.type === "labelLink") && !t._balanced && (i = n, t.type !== "labelLink")) {
				r = 2;
				break;
			}
		} else t.type === "labelEnd" && (a = n);
	}
	let s = {
		type: e[i][1].type === "labelLink" ? "link" : "image",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	}, c = {
		type: "label",
		start: { ...e[i][1].start },
		end: { ...e[a][1].end }
	}, l = {
		type: "labelText",
		start: { ...e[i + r + 2][1].end },
		end: { ...e[a - 2][1].start }
	};
	return o = [[
		"enter",
		s,
		t
	], [
		"enter",
		c,
		t
	]], o = _s(o, e.slice(i + 1, i + r + 3)), o = _s(o, [[
		"enter",
		l,
		t
	]]), o = _s(o, Us(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, a - 3), t)), o = _s(o, [
		[
			"exit",
			l,
			t
		],
		e[a - 2],
		e[a - 1],
		[
			"exit",
			c,
			t
		]
	]), o = _s(o, e.slice(a + 1)), o = _s(o, [[
		"exit",
		s,
		t
	]]), gs(e, i, e.length, o), e;
}
function tl(e, t, n) {
	let r = this, i = r._labelStarts, a, o;
	if (i) {
		for (; i.length > 0 && i[i.length - 1]._balanced;) i.pop();
		a = i[i.length - 1];
	}
	return s;
	function s(t) {
		return a ? a._inactive ? d(t) : (o = r.parser.defined.includes(Cs(r.sliceSerialize({
			start: a.end,
			end: r.now()
		}))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelEnd"), c) : n(t);
	}
	function c(t) {
		return t === 40 ? e.attempt(Xc, u, o ? u : d)(t) : t === 91 ? e.attempt(Zc, u, o ? l : d)(t) : o ? u(t) : d(t);
	}
	function l(t) {
		return e.attempt(Qc, u, d)(t);
	}
	function u(e) {
		return i.pop(), t(e);
	}
	function d(e) {
		return a._balanced = !0, n(e);
	}
}
function nl(e, t, n) {
	return r;
	function r(t) {
		return e.enter("resource"), e.enter("resourceMarker"), e.consume(t), e.exit("resourceMarker"), i;
	}
	function i(t) {
		return V(t) ? Ac(e, a)(t) : a(t);
	}
	function a(t) {
		return t === 41 ? u(t) : Dc(e, o, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(t);
	}
	function o(t) {
		return V(t) ? Ac(e, c)(t) : u(t);
	}
	function s(e) {
		return n(e);
	}
	function c(t) {
		return t === 34 || t === 39 || t === 40 ? kc(e, l, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(t) : u(t);
	}
	function l(t) {
		return V(t) ? Ac(e, u)(t) : u(t);
	}
	function u(r) {
		return r === 41 ? (e.enter("resourceMarker"), e.consume(r), e.exit("resourceMarker"), e.exit("resource"), t) : n(r);
	}
}
function rl(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return Oc.call(r, e, a, o, "reference", "referenceMarker", "referenceString")(t);
	}
	function a(e) {
		return r.parser.defined.includes(Cs(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(e) : n(e);
	}
	function o(e) {
		return n(e);
	}
}
function il(e, t, n) {
	return r;
	function r(t) {
		return e.enter("reference"), e.enter("referenceMarker"), e.consume(t), e.exit("referenceMarker"), i;
	}
	function i(r) {
		return r === 93 ? (e.enter("referenceMarker"), e.consume(r), e.exit("referenceMarker"), e.exit("reference"), t) : n(r);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/label-start-image.js
var al = {
	name: "labelStartImage",
	resolveAll: Yc.resolveAll,
	tokenize: ol
};
function ol(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(t), e.exit("labelImageMarker"), o;
	}
	function o(t) {
		return t === 91 ? (e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(t);
	}
	function s(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/label-start-link.js
var sl = {
	name: "labelStartLink",
	resolveAll: Yc.resolveAll,
	tokenize: cl
};
function cl(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelLink"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelLink"), o;
	}
	function o(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/line-ending.js
var ll = {
	name: "lineEnding",
	tokenize: ul
};
function ul(e, t) {
	return n;
	function n(n) {
		return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), U(e, t, "linePrefix");
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/thematic-break.js
var dl = {
	name: "thematicBreak",
	tokenize: fl
};
function fl(e, t, n) {
	let r = 0, i;
	return a;
	function a(t) {
		return e.enter("thematicBreak"), o(t);
	}
	function o(e) {
		return i = e, s(e);
	}
	function s(a) {
		return a === i ? (e.enter("thematicBreakSequence"), c(a)) : r >= 3 && (a === null || B(a)) ? (e.exit("thematicBreak"), t(a)) : n(a);
	}
	function c(t) {
		return t === i ? (e.consume(t), r++, c) : (e.exit("thematicBreakSequence"), H(t) ? U(e, s, "whitespace")(t) : s(t));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/list.js
var pl = {
	continuation: { tokenize: _l },
	exit: yl,
	name: "list",
	tokenize: gl
}, ml = {
	partial: !0,
	tokenize: bl
}, hl = {
	partial: !0,
	tokenize: vl
};
function gl(e, t, n) {
	let r = this, i = r.events[r.events.length - 1], a = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
	return s;
	function s(t) {
		let i = r.containerState.type || (t === 42 || t === 43 || t === 45 ? "listUnordered" : "listOrdered");
		if (i === "listUnordered" ? !r.containerState.marker || t === r.containerState.marker : Es(t)) {
			if (r.containerState.type || (r.containerState.type = i, e.enter(i, { _container: !0 })), i === "listUnordered") return e.enter("listItemPrefix"), t === 42 || t === 45 ? e.check(dl, n, l)(t) : l(t);
			if (!r.interrupt || t === 49) return e.enter("listItemPrefix"), e.enter("listItemValue"), c(t);
		}
		return n(t);
	}
	function c(t) {
		return Es(t) && ++o < 10 ? (e.consume(t), c) : (!r.interrupt || o < 2) && (r.containerState.marker ? t === r.containerState.marker : t === 41 || t === 46) ? (e.exit("listItemValue"), l(t)) : n(t);
	}
	function l(t) {
		return e.enter("listItemMarker"), e.consume(t), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || t, e.check(Xs, r.interrupt ? n : u, e.attempt(ml, f, d));
	}
	function u(e) {
		return r.containerState.initialBlankLine = !0, a++, f(e);
	}
	function d(t) {
		return H(t) ? (e.enter("listItemPrefixWhitespace"), e.consume(t), e.exit("listItemPrefixWhitespace"), f) : n(t);
	}
	function f(n) {
		return r.containerState.size = a + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(n);
	}
}
function _l(e, t, n) {
	let r = this;
	return r.containerState._closeFlow = void 0, e.check(Xs, i, a);
	function i(n) {
		return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, U(e, t, "listItemIndent", r.containerState.size + 1)(n);
	}
	function a(n) {
		return r.containerState.furtherBlankLines || !H(n) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, o(n)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(hl, t, o)(n));
	}
	function o(i) {
		return r.containerState._closeFlow = !0, r.interrupt = void 0, U(e, e.attempt(pl, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(i);
	}
}
function vl(e, t, n) {
	let r = this;
	return U(e, i, "listItemIndent", r.containerState.size + 1);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "listItemIndent" && i[2].sliceSerialize(i[1], !0).length === r.containerState.size ? t(e) : n(e);
	}
}
function yl(e) {
	e.exit(this.containerState.type);
}
function bl(e, t, n) {
	let r = this;
	return U(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return !H(e) && i && i[1].type === "listItemPrefixWhitespace" ? t(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-core-commonmark@2.0.4/node_modules/micromark-core-commonmark/lib/setext-underline.js
var xl = {
	name: "setextUnderline",
	resolveTo: Sl,
	tokenize: Cl
};
function Sl(e, t) {
	let n = new Is(), r = e.length, i, a, o;
	for (; r--;) if (e[r][0] === "enter") {
		if (e[r][1].type === "content") {
			i = r;
			break;
		}
		e[r][1].type === "paragraph" && (a = r);
	} else e[r][1].type === "content" && n.add(r, 1, []), !o && e[r][1].type === "definition" && (o = r);
	let s = {
		type: "setextHeading",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	};
	return e[a][1].type = "setextHeadingText", o ? (n.add(a, 0, [[
		"enter",
		s,
		t
	]]), n.add(o + 1, 0, [[
		"exit",
		e[i][1],
		t
	]]), e[i][1].end = { ...e[o][1].end }) : e[i][1] = s, n.add(e.length, 0, [[
		"exit",
		s,
		t
	]]), n.consume(e), e;
}
function Cl(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		let a = r.events.length, s;
		for (; a--;) if (r.events[a][1].type !== "lineEnding" && r.events[a][1].type !== "linePrefix" && r.events[a][1].type !== "content") {
			s = r.events[a][1].type === "paragraph";
			break;
		}
		return !r.parser.lazy[r.now().line] && (r.interrupt || s) ? (e.enter("setextHeadingLine"), i = t, o(t)) : n(t);
	}
	function o(t) {
		return e.enter("setextHeadingLineSequence"), s(t);
	}
	function s(t) {
		return t === i ? (e.consume(t), s) : (e.exit("setextHeadingLineSequence"), H(t) ? U(e, c, "lineSuffix")(t) : c(t));
	}
	function c(r) {
		return r === null || B(r) ? (e.exit("setextHeadingLine"), t(r)) : n(r);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/initialize/flow.js
var wl = { tokenize: Tl };
function Tl(e) {
	let t = this, n = e.attempt(Xs, r, e.attempt(this.parser.constructs.flowInitial, i, U(e, e.attempt(this.parser.constructs.flow, i, e.attempt(Sc, i)), "linePrefix")));
	return n;
	function r(r) {
		if (r === null) {
			e.consume(r);
			return;
		}
		return e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
	}
	function i(r) {
		if (r === null) {
			e.consume(r);
			return;
		}
		return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), t.currentConstruct = void 0, n;
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/initialize/text.js
var El = { resolveAll: Al() }, Dl = kl("string"), Ol = kl("text");
function kl(e) {
	return {
		resolveAll: Al(e === "text" ? jl : void 0),
		tokenize: t
	};
	function t(t) {
		let n = this, r = this.parser.constructs[e], i = t.attempt(r, a, o);
		return a;
		function a(e) {
			return c(e) ? i(e) : o(e);
		}
		function o(e) {
			if (e === null) {
				t.consume(e);
				return;
			}
			return t.enter("data"), t.consume(e), s;
		}
		function s(e) {
			return c(e) ? (t.exit("data"), i(e)) : (t.consume(e), s);
		}
		function c(e) {
			if (e === null) return !0;
			let t = r[e], i = -1;
			if (t) for (; ++i < t.length;) {
				let e = t[i];
				if (!e.previous || e.previous.call(n, n.previous)) return !0;
			}
			return !1;
		}
	}
}
function Al(e) {
	return t;
	function t(t, n) {
		let r = -1, i;
		for (; ++r <= t.length;) i === void 0 ? t[r] && t[r][1].type === "data" && (i = r, r++) : (!t[r] || t[r][1].type !== "data") && (r !== i + 2 && (t[i][1].end = t[r - 1][1].end, t.splice(i + 2, r - i - 2), r = i + 2), i = void 0);
		return e ? e(t, n) : t;
	}
}
function jl(e, t) {
	let n = new Is(), r = 0;
	for (; ++r <= e.length;) if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
		let i = e[r - 1][1], a = t.sliceStream(i), o = a.length, s = -1, c = 0, l;
		for (; o--;) {
			let e = a[o];
			if (typeof e == "string") {
				for (s = e.length; e.charCodeAt(s - 1) === 32;) c++, s--;
				if (s) break;
				s = -1;
			} else if (e === -2) l = !0, c++;
			else if (e !== -1) {
				o++;
				break;
			}
		}
		if (t._contentTypeTextTrailing && r === e.length && (c = 0), c) {
			let a = {
				type: r === e.length || l || c < 2 ? "lineSuffix" : "hardBreakTrailing",
				start: {
					_bufferIndex: o ? s : i.start._bufferIndex + s,
					_index: i.start._index + o,
					line: i.end.line,
					column: i.end.column - c,
					offset: i.end.offset - c
				},
				end: { ...i.end }
			};
			i.end = { ...a.start }, i.start.offset === i.end.offset ? Object.assign(i, a) : n.add(r, 0, [[
				"enter",
				a,
				t
			], [
				"exit",
				a,
				t
			]]);
		}
		r++;
	}
	return n.consume(e), e;
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/constructs.js
var Ml = /* @__PURE__ */ t({
	attentionMarkers: () => Bl,
	contentInitial: () => Pl,
	disable: () => Vl,
	document: () => Nl,
	flow: () => Il,
	flowInitial: () => Fl,
	insideSpan: () => zl,
	string: () => Ll,
	text: () => Rl
}), Nl = {
	42: pl,
	43: pl,
	45: pl,
	48: pl,
	49: pl,
	50: pl,
	51: pl,
	52: pl,
	53: pl,
	54: pl,
	55: pl,
	56: pl,
	57: pl,
	62: Qs
}, Pl = { 91: jc }, Fl = {
	[-2]: uc,
	[-1]: uc,
	32: uc
}, Il = {
	35: Lc,
	42: dl,
	45: [xl, dl],
	60: Hc,
	61: xl,
	95: dl,
	96: cc,
	126: cc
}, Ll = {
	38: ic,
	92: nc
}, Rl = {
	[-5]: ll,
	[-4]: ll,
	[-3]: ll,
	33: al,
	38: ic,
	42: Ws,
	60: [Js, qc],
	91: sl,
	92: [Fc, nc],
	93: Yc,
	95: Ws,
	96: mc
}, zl = { null: [Ws, El] }, Bl = { null: [42, 95] }, Vl = { null: [] };
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/create-tokenizer.js
function Hl(e, t, n) {
	let r = {
		_bufferIndex: -1,
		_index: 0,
		line: n && n.line || 1,
		column: n && n.column || 1,
		offset: n && n.offset || 0
	}, i = {}, a = [], o = [], s = [], c = {
		attempt: C(x),
		check: C(S),
		consume: v,
		enter: y,
		exit: b,
		interrupt: C(S, { interrupt: !0 })
	}, l = {
		code: null,
		containerState: {},
		defineSkip: h,
		events: [],
		now: m,
		parser: e,
		previous: null,
		sliceSerialize: f,
		sliceStream: p,
		write: d
	}, u = t.tokenize.call(l, c);
	return t.resolveAll && a.push(t), l;
	function d(e) {
		return o = _s(o, e), g(), o[o.length - 1] === null ? (w(t, 0), l.events = Us(a, l.events, l), l.events) : [];
	}
	function f(e, t) {
		return Wl(p(e), t);
	}
	function p(e) {
		return Ul(o, e);
	}
	function m() {
		let { _bufferIndex: e, _index: t, line: n, column: i, offset: a } = r;
		return {
			_bufferIndex: e,
			_index: t,
			line: n,
			column: i,
			offset: a
		};
	}
	function h(e) {
		i[e.line] = e.column, E();
	}
	function g() {
		for (; r._index < o.length;) {
			let e = o[r._index];
			if (typeof e == "string") {
				let t = r._index;
				for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === t && r._bufferIndex < e.length;) _(e.charCodeAt(r._bufferIndex));
			} else _(e);
		}
	}
	function _(e) {
		u = u(e);
	}
	function v(e) {
		B(e) ? (r.line++, r.column = 1, r.offset += e === -3 ? 2 : 1, E()) : e !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === o[r._index].length && (r._bufferIndex = -1, r._index++)), l.previous = e;
	}
	function y(e, t) {
		let n = t || {};
		return n.type = e, n.start = m(), l.events.push([
			"enter",
			n,
			l
		]), s.push(n), n;
	}
	function b(e) {
		let t = s.pop();
		return t.end = m(), l.events.push([
			"exit",
			t,
			l
		]), t;
	}
	function x(e, t) {
		w(e, t.from);
	}
	function S(e, t) {
		t.restore();
	}
	function C(e, t) {
		return n;
		function n(n, r, i) {
			let a, o, s, u;
			return Array.isArray(n) ? f(n) : "tokenize" in n ? f([n]) : d(n);
			function d(e) {
				return t;
				function t(t) {
					let n = t !== null && e[t], r = t !== null && e.null;
					return f([...Array.isArray(n) ? n : n ? [n] : [], ...Array.isArray(r) ? r : r ? [r] : []])(t);
				}
			}
			function f(e) {
				return a = e, o = 0, e.length === 0 ? i : p(e[o]);
			}
			function p(e) {
				return n;
				function n(n) {
					return u = T(), s = e, e.partial || (l.currentConstruct = e), e.name && l.parser.constructs.disable.null.includes(e.name) ? h(n) : e.tokenize.call(t ? Object.assign(Object.create(l), t) : l, c, m, h)(n);
				}
			}
			function m(t) {
				return e(s, u), r;
			}
			function h(e) {
				return u.restore(), ++o < a.length ? p(a[o]) : i;
			}
		}
	}
	function w(e, t) {
		e.resolveAll && !a.includes(e) && a.push(e), e.resolve && gs(l.events, t, l.events.length - t, e.resolve(l.events.slice(t), l)), e.resolveTo && (l.events = e.resolveTo(l.events, l));
	}
	function T() {
		let e = m(), t = l.previous, n = l.currentConstruct, i = l.events.length, a = Array.from(s);
		return {
			from: i,
			restore: o
		};
		function o() {
			r = e, l.previous = t, l.currentConstruct = n, l.events.length = i, s = a, E();
		}
	}
	function E() {
		r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
	}
}
function Ul(e, t) {
	let n = t.start._index, r = t.start._bufferIndex, i = t.end._index, a = t.end._bufferIndex, o;
	if (n === i) o = [e[n].slice(r, a)];
	else {
		if (o = e.slice(n, i), r > -1) {
			let e = o[0];
			typeof e == "string" ? o[0] = e.slice(r) : o.shift();
		}
		a > 0 && o.push(e[i].slice(0, a));
	}
	return o;
}
function Wl(e, t) {
	let n = -1, r = [], i;
	for (; ++n < e.length;) {
		let a = e[n], o;
		if (typeof a == "string") o = a;
		else switch (a) {
			case -5:
				o = "\r";
				break;
			case -4:
				o = "\n";
				break;
			case -3:
				o = "\r\n";
				break;
			case -2:
				o = t ? " " : "	";
				break;
			case -1:
				if (!t && i) continue;
				o = " ";
				break;
			default: o = String.fromCharCode(a);
		}
		i = a === -2, r.push(o);
	}
	return r.join("");
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/parse.js
function Gl(e) {
	let t = {
		constructs: ys([Ml, ...(e || {}).extensions || []]),
		content: n(Ps),
		defined: [],
		document: n(Rs),
		flow: n(wl),
		lazy: {},
		string: n(Dl),
		text: n(Ol)
	};
	return t;
	function n(e) {
		return n;
		function n(n) {
			return Hl(t, e, n);
		}
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/postprocess.js
function Kl(e) {
	for (; !bc(e););
	return e;
}
//#endregion
//#region ../../node_modules/.bun/micromark@4.0.3/node_modules/micromark/lib/preprocess.js
var ql = /[\0\t\n\r]/g;
function Jl() {
	let e = 1, t = "", n = !0, r;
	return i;
	function i(i, a, o) {
		i = t + (typeof i == "string" ? i.toString() : new TextDecoder(a || void 0).decode(i));
		let s = [], c = 0;
		for (t = "", n &&= (i.charCodeAt(0) === 65279 && c++, void 0); c < i.length;) {
			ql.lastIndex = c;
			let n = ql.exec(i), a = n && n.index !== void 0 ? n.index : i.length, o = i.charCodeAt(a);
			if (!n) {
				t = i.slice(c);
				break;
			}
			if (o === 10 && c === a && r) s.push(-3), r = void 0;
			else switch (r &&= (s.push(-5), void 0), c < a && (s.push(i.slice(c, a)), e += a - c), o) {
				case 0:
					s.push(65533), e++;
					break;
				case 9: {
					let t = Math.ceil(e / 4) * 4;
					for (s.push(-2); e++ < t;) s.push(-1);
					break;
				}
				case 10:
					s.push(-4), e = 1;
					break;
				default: r = !0, e = 1;
			}
			c = a + 1;
		}
		return o && (r && s.push(-5), t && s.push(t), s.push(null)), s;
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-util-decode-string@2.0.1/node_modules/micromark-util-decode-string/index.js
var Yl = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function Xl(e) {
	return e.replace(Yl, Zl);
}
function Zl(e, t, n) {
	if (t) return t;
	if (n.charCodeAt(0) === 35) {
		let e = n.charCodeAt(1), t = e === 120 || e === 88;
		return Ss(n.slice(t ? 2 : 1), t ? 16 : 10);
	}
	return hs(n) || e;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-from-markdown@2.1.0/node_modules/mdast-util-from-markdown/lib/index.js
var Ql = {}.hasOwnProperty;
function $l(e, t, n) {
	return t && typeof t == "object" && (n = t, t = void 0), eu(n)(Kl(Gl(n).document().write(Jl()(e, t, !0))));
}
function eu(e) {
	let t = {
		afterExit: [],
		beforeEnter: [],
		transforms: [],
		canContainEols: [
			"emphasis",
			"fragment",
			"heading",
			"paragraph",
			"strong"
		],
		enter: {
			autolink: o(xe),
			autolinkProtocol: E,
			autolinkEmail: E,
			atxHeading: o(ve),
			blockQuote: o(pe),
			characterEscape: E,
			characterReference: E,
			codeFenced: o(me),
			codeFencedFenceInfo: s,
			codeFencedFenceMeta: s,
			codeIndented: o(me, s),
			codeText: o(he, s),
			codeTextData: E,
			data: E,
			codeFlowValue: E,
			definition: o(ge),
			definitionDestinationString: s,
			definitionLabelString: s,
			definitionTitleString: s,
			emphasis: o(_e),
			hardBreakEscape: o(ye),
			hardBreakTrailing: o(ye),
			htmlFlow: o(be, s),
			htmlFlowData: E,
			htmlText: o(be, s),
			htmlTextData: E,
			image: o(P),
			label: s,
			link: o(xe),
			listItem: o(Ce),
			listItemValue: p,
			listOrdered: o(Se, f),
			listUnordered: o(Se),
			paragraph: o(we),
			reference: oe,
			referenceString: s,
			resourceDestinationString: s,
			resourceTitleString: s,
			setextHeading: o(ve),
			strong: o(Te),
			thematicBreak: o(De)
		},
		exit: {
			atxHeading: l(),
			atxHeadingSequence: S,
			autolink: l(),
			autolinkEmail: fe,
			autolinkProtocol: de,
			blockQuote: l(),
			characterEscapeValue: D,
			characterReferenceMarkerHexadecimal: ce,
			characterReferenceMarkerNumeric: ce,
			characterReferenceValue: le,
			characterReference: ue,
			codeFenced: l(_),
			codeFencedFence: g,
			codeFencedFenceInfo: m,
			codeFencedFenceMeta: h,
			codeFlowValue: D,
			codeIndented: l(v),
			codeText: l(M),
			codeTextData: D,
			data: D,
			definition: l(),
			definitionDestinationString: x,
			definitionLabelString: y,
			definitionTitleString: b,
			emphasis: l(),
			hardBreakEscape: l(k),
			hardBreakTrailing: l(k),
			htmlFlow: l(A),
			htmlFlowData: D,
			htmlText: l(j),
			htmlTextData: D,
			image: l(ee),
			label: ne,
			labelText: te,
			lineEnding: O,
			link: l(N),
			listItem: l(),
			listOrdered: l(),
			listUnordered: l(),
			paragraph: l(),
			referenceString: se,
			resourceDestinationString: re,
			resourceTitleString: ie,
			resource: ae,
			setextHeading: l(T),
			setextHeadingLineSequence: w,
			setextHeadingText: C,
			strong: l(),
			thematicBreak: l()
		}
	};
	nu(t, (e || {}).mdastExtensions || []);
	let n = {};
	return r;
	function r(e) {
		let r = {
			type: "root",
			children: [],
			position: void 0
		}, o = {
			stack: [r],
			tokenStack: [],
			config: t,
			enter: c,
			exit: u,
			buffer: s,
			resume: d,
			data: n
		}, l = [], f = [], p = -1;
		for (; ++p < e.length;) f.push(e[p]), (e[p][1].type === "listOrdered" || e[p][1].type === "listUnordered") && (e[p][0] === "enter" ? l.push(f.length - 1) : a(f, l.pop()));
		for (e = f, p = -1; ++p < e.length;) {
			let n = t[e[p][0]];
			e[p][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), Ql.call(n, e[p][1].type) && n[e[p][1].type].call({
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), e[p][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]);
		}
		if (o.tokenStack.length > 0) {
			let e = o.tokenStack[o.tokenStack.length - 1];
			(e[1] || iu).call(o, void 0, e[0]);
		}
		for (r.position = {
			start: tu(e.length > 0 ? e[0][1].start : {
				line: 1,
				column: 1,
				offset: 0
			}),
			end: tu(e.length > 0 ? e[e.length - 2][1].end : {
				line: 1,
				column: 1,
				offset: 0
			})
		}, p = -1; ++p < t.transforms.length;) r = t.transforms[p](r) || r;
		return r;
	}
	function i(e, t, n) {
		let r = -1;
		for (; ++r < e.length;) e[r].call(t, n);
	}
	function a(e, t) {
		let n = e.length - 1, r = t - 1, i = -1, a = !1, o, s, c, l, u = [];
		for (; ++r <= n;) {
			let t = e[r];
			switch (t[1].type) {
				case "listUnordered":
				case "listOrdered":
				case "blockQuote":
					t[0] === "enter" ? i++ : i--, l = void 0;
					break;
				case "lineEndingBlank":
					t[0] === "enter" && (o && !l && !i && !c && (c = r), l = void 0);
					break;
				case "linePrefix":
				case "listItemValue":
				case "listItemMarker":
				case "listItemPrefix":
				case "listItemPrefixWhitespace": break;
				default: l = void 0;
			}
			if (!i && t[0] === "enter" && t[1].type === "listItemPrefix" || i === -1 && t[0] === "exit" && (t[1].type === "listUnordered" || t[1].type === "listOrdered")) {
				if (o) {
					let n = r;
					for (s = void 0; n--;) {
						let t = e[n];
						if (t[1].type === "lineEnding" || t[1].type === "lineEndingBlank") {
							if (t[0] === "exit") continue;
							s && (e[s][1].type = "lineEndingBlank", a = !0), t[1].type = "lineEnding", s = n;
						} else if (!(t[1].type === "linePrefix" || t[1].type === "blockQuotePrefix" || t[1].type === "blockQuotePrefixWhitespace" || t[1].type === "blockQuoteMarker" || t[1].type === "listItemIndent")) break;
					}
					c && (!s || c < s) && (o._spread = !0), o.end = Object.assign({}, s ? e[s][1].start : t[1].end), u.push({
						at: s || r,
						event: [
							"exit",
							o,
							t[2]
						]
					});
				}
				if (t[1].type === "listItemPrefix") {
					let e = {
						type: "listItem",
						_spread: !1,
						start: Object.assign({}, t[1].start),
						end: void 0
					};
					o = e, u.push({
						at: r,
						event: [
							"enter",
							e,
							t[2]
						]
					}), c = void 0, l = !0;
				}
			}
		}
		let d = e.splice(t), f = 0;
		for (r = -1; ++r < d.length;) {
			for (; f < u.length && u[f].at === t + r;) e.push(u[f++].event);
			e.push(d[r]);
		}
		e[t][1]._spread = a;
	}
	function o(e, t) {
		return n;
		function n(n) {
			c.call(this, e(n), n), t && t.call(this, n);
		}
	}
	function s() {
		this.stack.push({
			type: "fragment",
			children: []
		});
	}
	function c(e, t, n) {
		this.stack[this.stack.length - 1].children.push(e), this.stack.push(e), this.tokenStack.push([t, n || void 0]), e.position = {
			start: tu(t.start),
			end: void 0
		};
	}
	function l(e) {
		return t;
		function t(t) {
			e && e.call(this, t), u.call(this, t);
		}
	}
	function u(e, t) {
		let n = this.stack.pop(), r = this.tokenStack.pop();
		if (!r) throw Error("Cannot close `" + e.type + "` (" + Do({
			start: e.start,
			end: e.end
		}) + "): it’s not open");
		r[0].type !== e.type && (t ? t.call(this, e, r[0]) : (r[1] || iu).call(this, e, r[0])), n.position.end = tu(e.end);
	}
	function d() {
		return us(this.stack.pop());
	}
	function f() {
		this.data.expectingFirstListItemValue = !0;
	}
	function p(e) {
		if (this.data.expectingFirstListItemValue) {
			let t = this.stack[this.stack.length - 2];
			t.start = Number.parseInt(this.sliceSerialize(e), 10), this.data.expectingFirstListItemValue = void 0;
		}
	}
	function m() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.lang = e;
	}
	function h() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.meta = e;
	}
	function g() {
		this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
	}
	function _() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
	}
	function v() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/(\r?\n|\r)$/g, "");
	}
	function y(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = Cs(this.sliceSerialize(e)).toLowerCase();
	}
	function b() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function x() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function S(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth ||= this.sliceSerialize(e).length;
	}
	function C() {
		this.data.setextHeadingSlurpLineEnding = !0;
	}
	function w(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth = this.sliceSerialize(e).codePointAt(0) === 61 ? 1 : 2;
	}
	function T() {
		this.data.setextHeadingSlurpLineEnding = void 0;
	}
	function E(e) {
		let t = this.stack[this.stack.length - 1].children, n = t[t.length - 1];
		(!n || n.type !== "text") && (n = Ee(), n.position = {
			start: tu(e.start),
			end: void 0
		}, t.push(n)), this.stack.push(n);
	}
	function D(e) {
		let t = this.stack.pop();
		t.value += this.sliceSerialize(e), t.position.end = tu(e.end);
	}
	function O(e) {
		let n = this.stack[this.stack.length - 1];
		if (this.data.atHardBreak) {
			let t = n.children[n.children.length - 1];
			t.position.end = tu(e.end), this.data.atHardBreak = void 0;
			return;
		}
		!this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(n.type) && (E.call(this, e), D.call(this, e));
	}
	function k() {
		this.data.atHardBreak = !0;
	}
	function A() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function j() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function M() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function N() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function ee() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function te(e) {
		let t = this.sliceSerialize(e), n = this.stack[this.stack.length - 2];
		n.label = Xl(t), n.identifier = Cs(t).toLowerCase();
	}
	function ne() {
		let e = this.stack[this.stack.length - 1], t = this.resume(), n = this.stack[this.stack.length - 1];
		this.data.inReference = !0, n.type === "link" ? n.children = e.children : n.alt = t;
	}
	function re() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function ie() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function ae() {
		this.data.inReference = void 0;
	}
	function oe() {
		this.data.referenceType = "collapsed";
	}
	function se(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = Cs(this.sliceSerialize(e)).toLowerCase(), this.data.referenceType = "full";
	}
	function ce(e) {
		this.data.characterReferenceType = e.type;
	}
	function le(e) {
		let t = this.sliceSerialize(e), n = this.data.characterReferenceType, r;
		n ? (r = Ss(t, n === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : r = hs(t);
		let i = this.stack[this.stack.length - 1];
		i.value += r;
	}
	function ue(e) {
		let t = this.stack.pop();
		t.position.end = tu(e.end);
	}
	function de(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = this.sliceSerialize(e);
	}
	function fe(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = "mailto:" + this.sliceSerialize(e);
	}
	function pe() {
		return {
			type: "blockquote",
			children: [],
			position: void 0
		};
	}
	function me() {
		return {
			type: "code",
			lang: null,
			meta: null,
			value: "",
			position: void 0
		};
	}
	function he() {
		return {
			type: "inlineCode",
			value: "",
			position: void 0
		};
	}
	function ge() {
		return {
			type: "definition",
			identifier: "",
			label: null,
			title: null,
			url: "",
			position: void 0
		};
	}
	function _e() {
		return {
			type: "emphasis",
			children: [],
			position: void 0
		};
	}
	function ve() {
		return {
			type: "heading",
			depth: 0,
			children: [],
			position: void 0
		};
	}
	function ye() {
		return {
			type: "break",
			position: void 0
		};
	}
	function be() {
		return {
			type: "html",
			value: "",
			position: void 0
		};
	}
	function P() {
		return {
			type: "image",
			title: null,
			url: "",
			alt: null,
			position: void 0
		};
	}
	function xe() {
		return {
			type: "link",
			title: null,
			url: "",
			children: [],
			position: void 0
		};
	}
	function Se(e) {
		return {
			type: "list",
			ordered: e.type === "listOrdered",
			start: null,
			spread: e._spread,
			children: [],
			position: void 0
		};
	}
	function Ce(e) {
		return {
			type: "listItem",
			spread: e._spread,
			checked: null,
			children: [],
			position: void 0
		};
	}
	function we() {
		return {
			type: "paragraph",
			children: [],
			position: void 0
		};
	}
	function Te() {
		return {
			type: "strong",
			children: [],
			position: void 0
		};
	}
	function Ee() {
		return {
			type: "text",
			value: "",
			position: void 0
		};
	}
	function De() {
		return {
			type: "thematicBreak",
			position: void 0
		};
	}
}
function tu(e) {
	return {
		line: e.line,
		column: e.column,
		offset: e.offset
	};
}
function nu(e, t) {
	let n = -1;
	for (; ++n < t.length;) {
		let r = t[n];
		Array.isArray(r) ? nu(e, r) : ru(e, r);
	}
}
function ru(e, t) {
	let n;
	for (n in t) if (Ql.call(t, n)) switch (n) {
		case "canContainEols": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "transforms": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "afterExit":
		case "beforeEnter": {
			let r = t[n];
			r && e[n].push(r);
			break;
		}
		case "enter":
		case "exit": {
			let r = t[n];
			r && Object.assign(e[n], r);
			break;
		}
	}
}
function iu(e, t) {
	throw Error(e ? "Cannot close `" + e.type + "` (" + Do({
		start: e.start,
		end: e.end
	}) + "): a different token (`" + t.type + "`, " + Do({
		start: t.start,
		end: t.end
	}) + ") is open" : "Cannot close document, a token (`" + t.type + "`, " + Do({
		start: t.start,
		end: t.end
	}) + ") is still open");
}
//#endregion
//#region ../../node_modules/.bun/remark-parse@11.0.0/node_modules/remark-parse/lib/index.js
function au(e) {
	let t = this;
	t.parser = n;
	function n(n) {
		return $l(n, {
			...t.data("settings"),
			...e,
			extensions: t.data("micromarkExtensions") || [],
			mdastExtensions: t.data("fromMarkdownExtensions") || []
		});
	}
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/blockquote.js
function ou(e, t) {
	let n = {
		type: "element",
		tagName: "blockquote",
		properties: {},
		children: e.wrap(e.all(t), !0)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/break.js
function su(e, t) {
	let n = {
		type: "element",
		tagName: "br",
		properties: {},
		children: []
	};
	return e.patch(t, n), [e.applyData(t, n), {
		type: "text",
		value: "\n"
	}];
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/code.js
function cu(e, t) {
	let n = t.value ? t.value + "\n" : "", r = {}, i = t.lang ? t.lang.split(/\s+/) : [];
	i.length > 0 && (r.className = ["language-" + i[0]]);
	let a = {
		type: "element",
		tagName: "code",
		properties: r,
		children: [{
			type: "text",
			value: n
		}]
	};
	return t.meta && (a.data = { meta: t.meta }), e.patch(t, a), a = e.applyData(t, a), a = {
		type: "element",
		tagName: "pre",
		properties: {},
		children: [a]
	}, e.patch(t, a), a;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/delete.js
function lu(e, t) {
	let n = {
		type: "element",
		tagName: "del",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/emphasis.js
function uu(e, t) {
	let n = {
		type: "element",
		tagName: "em",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/footnote-reference.js
function du(e, t) {
	let n = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", r = String(t.identifier).toUpperCase(), i = Ms(r.toLowerCase()), a = e.footnoteOrder.indexOf(r), o, s = e.footnoteCounts.get(r);
	s === void 0 ? (s = 0, e.footnoteOrder.push(r), o = e.footnoteOrder.length) : o = a + 1, s += 1, e.footnoteCounts.set(r, s);
	let c = {
		type: "element",
		tagName: "a",
		properties: {
			href: "#" + n + "fn-" + i,
			id: n + "fnref-" + i + (s > 1 ? "-" + s : ""),
			dataFootnoteRef: !0,
			ariaDescribedBy: ["footnote-label"]
		},
		children: [{
			type: "text",
			value: String(o)
		}]
	};
	e.patch(t, c);
	let l = {
		type: "element",
		tagName: "sup",
		properties: {},
		children: [c]
	};
	return e.patch(t, l), e.applyData(t, l);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/heading.js
function fu(e, t) {
	let n = {
		type: "element",
		tagName: "h" + t.depth,
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/html.js
function pu(e, t) {
	if (e.options.allowDangerousHtml) {
		let n = {
			type: "raw",
			value: t.value
		};
		return e.patch(t, n), e.applyData(t, n);
	}
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/revert.js
function mu(e, t) {
	let n = t.referenceType, r = "]";
	if (n === "collapsed" ? r += "[]" : n === "full" && (r += "[" + (t.label || t.identifier) + "]"), t.type === "imageReference") return [{
		type: "text",
		value: "![" + t.alt + r
	}];
	let i = e.all(t), a = i[0];
	a && a.type === "text" ? a.value = "[" + a.value : i.unshift({
		type: "text",
		value: "["
	});
	let o = i[i.length - 1];
	return o && o.type === "text" ? o.value += r : i.push({
		type: "text",
		value: r
	}), i;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/image-reference.js
function hu(e, t) {
	let n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
	if (!r) return mu(e, t);
	let i = {
		src: Ms(r.url || ""),
		alt: t.alt
	};
	r.title !== null && r.title !== void 0 && (i.title = r.title);
	let a = {
		type: "element",
		tagName: "img",
		properties: i,
		children: []
	};
	return e.patch(t, a), e.applyData(t, a);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/image.js
function gu(e, t) {
	let n = { src: Ms(t.url) };
	t.alt !== null && t.alt !== void 0 && (n.alt = t.alt), t.title !== null && t.title !== void 0 && (n.title = t.title);
	let r = {
		type: "element",
		tagName: "img",
		properties: n,
		children: []
	};
	return e.patch(t, r), e.applyData(t, r);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/inline-code.js
function _u(e, t) {
	let n = {
		type: "text",
		value: t.value.replace(/\r?\n|\r/g, " ")
	};
	e.patch(t, n);
	let r = {
		type: "element",
		tagName: "code",
		properties: {},
		children: [n]
	};
	return e.patch(t, r), e.applyData(t, r);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/link-reference.js
function vu(e, t) {
	let n = String(t.identifier).toUpperCase(), r = e.definitionById.get(n);
	if (!r) return mu(e, t);
	let i = { href: Ms(r.url || "") };
	r.title !== null && r.title !== void 0 && (i.title = r.title);
	let a = {
		type: "element",
		tagName: "a",
		properties: i,
		children: e.all(t)
	};
	return e.patch(t, a), e.applyData(t, a);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/link.js
function yu(e, t) {
	let n = { href: Ms(t.url) };
	t.title !== null && t.title !== void 0 && (n.title = t.title);
	let r = {
		type: "element",
		tagName: "a",
		properties: n,
		children: e.all(t)
	};
	return e.patch(t, r), e.applyData(t, r);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/list-item.js
function bu(e, t, n) {
	let r = e.all(t), i = n ? xu(n) : Su(t), a = {}, o = [];
	if (typeof t.checked == "boolean") {
		let e = r[0], n;
		e && e.type === "element" && e.tagName === "p" ? n = e : (n = {
			type: "element",
			tagName: "p",
			properties: {},
			children: []
		}, r.unshift(n)), n.children.length > 0 && n.children.unshift({
			type: "text",
			value: " "
		}), n.children.unshift({
			type: "element",
			tagName: "input",
			properties: {
				type: "checkbox",
				checked: t.checked,
				disabled: !0
			},
			children: []
		}), a.className = ["task-list-item"];
	}
	let s = -1;
	for (; ++s < r.length;) {
		let e = r[s];
		(i || s !== 0 || e.type !== "element" || e.tagName !== "p") && o.push({
			type: "text",
			value: "\n"
		}), e.type === "element" && e.tagName === "p" && !i ? o.push(...e.children) : o.push(e);
	}
	let c = r[r.length - 1];
	c && (i || c.type !== "element" || c.tagName !== "p") && o.push({
		type: "text",
		value: "\n"
	});
	let l = {
		type: "element",
		tagName: "li",
		properties: a,
		children: o
	};
	return e.patch(t, l), e.applyData(t, l);
}
function xu(e) {
	let t = !1;
	if (e.type === "list") {
		t = e.spread || !1;
		let n = e.children, r = -1;
		for (; !t && ++r < n.length;) t = Su(n[r]);
	}
	return t;
}
function Su(e) {
	return e.spread ?? e.children.length > 1;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/list.js
function Cu(e, t) {
	let n = {}, r = e.all(t), i = -1;
	for (typeof t.start == "number" && t.start !== 1 && (n.start = t.start); ++i < r.length;) {
		let e = r[i];
		if (e.type === "element" && e.tagName === "li" && e.properties && Array.isArray(e.properties.className) && e.properties.className.includes("task-list-item")) {
			n.className = ["contains-task-list"];
			break;
		}
	}
	let a = {
		type: "element",
		tagName: t.ordered ? "ol" : "ul",
		properties: n,
		children: e.wrap(r, !0)
	};
	return e.patch(t, a), e.applyData(t, a);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/paragraph.js
function wu(e, t) {
	let n = {
		type: "element",
		tagName: "p",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/root.js
function Tu(e, t) {
	let n = {
		type: "root",
		children: e.wrap(e.all(t))
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/strong.js
function Eu(e, t) {
	let n = {
		type: "element",
		tagName: "strong",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/table.js
function Du(e, t) {
	let n = e.all(t), r = n.shift(), i = [];
	if (r) {
		let n = {
			type: "element",
			tagName: "thead",
			properties: {},
			children: e.wrap([r], !0)
		};
		e.patch(t.children[0], n), i.push(n);
	}
	if (n.length > 0) {
		let r = {
			type: "element",
			tagName: "tbody",
			properties: {},
			children: e.wrap(n, !0)
		}, a = wo(t.children[1]), o = Co(t.children[t.children.length - 1]);
		a && o && (r.position = {
			start: a,
			end: o
		}), i.push(r);
	}
	let a = {
		type: "element",
		tagName: "table",
		properties: {},
		children: e.wrap(i, !0)
	};
	return e.patch(t, a), e.applyData(t, a);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/table-row.js
function Ou(e, t, n) {
	let r = n ? n.children : void 0, i = (r ? r.indexOf(t) : 1) === 0 ? "th" : "td", a = n && n.type === "table" ? n.align : void 0, o = a ? a.length : t.children.length, s = -1, c = [];
	for (; ++s < o;) {
		let n = t.children[s], r = {}, o = a ? a[s] : void 0;
		o && (r.align = o);
		let l = {
			type: "element",
			tagName: i,
			properties: r,
			children: []
		};
		n && (l.children = e.all(n), e.patch(n, l), l = e.applyData(n, l)), c.push(l);
	}
	let l = {
		type: "element",
		tagName: "tr",
		properties: {},
		children: e.wrap(c, !0)
	};
	return e.patch(t, l), e.applyData(t, l);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/table-cell.js
function ku(e, t) {
	let n = {
		type: "element",
		tagName: "td",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/trim-lines@3.0.1/node_modules/trim-lines/index.js
var Au = 9, ju = 32;
function Mu(e) {
	let t = String(e), n = /\r?\n|\r/g, r = n.exec(t), i = 0, a = [];
	for (; r;) a.push(Nu(t.slice(i, r.index), i > 0, !0), r[0]), i = r.index + r[0].length, r = n.exec(t);
	return a.push(Nu(t.slice(i), i > 0, !1)), a.join("");
}
function Nu(e, t, n) {
	let r = 0, i = e.length;
	if (t) {
		let t = e.codePointAt(r);
		for (; t === Au || t === ju;) r++, t = e.codePointAt(r);
	}
	if (n) {
		let t = e.codePointAt(i - 1);
		for (; t === Au || t === ju;) i--, t = e.codePointAt(i - 1);
	}
	return i > r ? e.slice(r, i) : "";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/text.js
function Pu(e, t) {
	let n = {
		type: "text",
		value: Mu(String(t.value))
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/thematic-break.js
function Fu(e, t) {
	let n = {
		type: "element",
		tagName: "hr",
		properties: {},
		children: []
	};
	return e.patch(t, n), e.applyData(t, n);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/handlers/index.js
var Iu = {
	blockquote: ou,
	break: su,
	code: cu,
	delete: lu,
	emphasis: uu,
	footnoteReference: du,
	heading: fu,
	html: pu,
	imageReference: hu,
	image: gu,
	inlineCode: _u,
	linkReference: vu,
	link: yu,
	listItem: bu,
	list: Cu,
	paragraph: wu,
	root: Tu,
	strong: Eu,
	table: Du,
	tableCell: ku,
	tableRow: Ou,
	text: Pu,
	thematicBreak: Fu,
	toml: Lu,
	yaml: Lu,
	definition: Lu,
	footnoteDefinition: Lu
};
function Lu() {}
//#endregion
//#region ../../node_modules/.bun/@ungap+structured-clone@1.4.0/node_modules/@ungap/structured-clone/esm/deserialize.js
var { defineProperty: Ru } = Object, zu = typeof self == "object" ? self : globalThis, Bu = (e, t) => {
	switch (e) {
		case "Function":
		case "SharedWorker":
		case "Worker":
		case "eval":
		case "setInterval":
		case "setTimeout": throw TypeError("unable to deserialize " + e);
	}
	return new zu[e](t);
}, Vu = (e, t) => {
	let n = (t, n) => (e.set(n, t), t), r = (i) => {
		if (e.has(i)) return e.get(i);
		let [a, o] = t[i];
		switch (a) {
			case 0:
			case -1: return n(o, i);
			case 1: {
				let e = n([], i);
				for (let t of o) e.push(r(t));
				return e;
			}
			case 2: {
				let e = n({}, i);
				for (let [t, n] of o) {
					let i = r(t), a = r(n);
					i === "__proto__" ? Ru(e, i, {
						value: a,
						configurable: !0,
						enumerable: !0,
						writable: !0
					}) : e[i] = a;
				}
				return e;
			}
			case 3: return n(new Date(o), i);
			case 4: {
				let { source: e, flags: t } = o;
				return n(new RegExp(e, t), i);
			}
			case 5: {
				let e = n(/* @__PURE__ */ new Map(), i);
				for (let [t, n] of o) e.set(r(t), r(n));
				return e;
			}
			case 6: {
				let e = n(/* @__PURE__ */ new Set(), i);
				for (let t of o) e.add(r(t));
				return e;
			}
			case 7: {
				let { name: e, message: t } = o;
				return n(typeof zu[e] == "function" ? Bu(e, t) : Error(t), i);
			}
			case 8: return n(BigInt(o), i);
			case "BigInt": return n(Object(BigInt(o)), i);
			case "ArrayBuffer": return n(new Uint8Array(o).buffer, o);
			case "DataView": {
				let { buffer: e } = new Uint8Array(o);
				return n(new DataView(e), o);
			}
			case "-0": return -0;
		}
		return n(Bu(a, o), i);
	};
	return r;
}, Hu = (e) => Vu(/* @__PURE__ */ new Map(), e)(0), Uu = "", { toString: Wu } = {}, { keys: Gu, is: Ku } = Object, qu = (e) => {
	let t = typeof e;
	if (t !== "object" || !e) return [0, t];
	let n = Wu.call(e).slice(8, -1);
	switch (n) {
		case "Array": return [1, Uu];
		case "Object": return [2, Uu];
		case "Date": return [3, Uu];
		case "RegExp": return [4, Uu];
		case "Map": return [5, Uu];
		case "Set": return [6, Uu];
		case "DataView": return [1, n];
	}
	return n.includes("Array") ? [1, n] : e instanceof Error ? [7, e.name || "Error"] : [2, n];
}, Ju = ([e, t]) => e === 0 && (t === "function" || t === "symbol"), Yu = (e, t, n, r) => {
	let i = (e, t) => {
		let i = r.push(e) - 1;
		return n.set(t, i), i;
	}, a = (o) => {
		if (n.has(o)) return n.get(o);
		let [s, c] = qu(o);
		switch (s) {
			case 0: {
				let t = o;
				switch (c) {
					case "bigint":
						s = 8, t = o.toString();
						break;
					case "number":
						if (!o && Ku(o, -0)) return r.push(["-0"]) - 1;
						break;
					case "function":
					case "symbol":
						if (e) throw TypeError("unable to serialize " + c);
						t = null;
						break;
					case "undefined": return i([-1], o);
				}
				return i([s, t], o);
			}
			case 1: {
				if (c) {
					let e = o;
					return c === "DataView" ? e = new Uint8Array(o.buffer) : c === "ArrayBuffer" && (e = new Uint8Array(o)), i([c, [...e]], o);
				}
				let e = [], t = i([s, e], o);
				for (let t of o) e.push(a(t));
				return t;
			}
			case 2: {
				if (c) switch (c) {
					case "BigInt": return i([c, o.toString()], o);
					case "Boolean":
					case "Number":
					case "String": return i([c, o.valueOf()], o);
				}
				if (t && "toJSON" in o) return a(o.toJSON());
				let n = [], r = i([s, n], o);
				for (let t of Gu(o)) (e || !Ju(qu(o[t]))) && n.push([a(t), a(o[t])]);
				return r;
			}
			case 3: return i([s, isNaN(o.getTime()) ? Uu : o.toISOString()], o);
			case 4: {
				let { source: e, flags: t } = o;
				return i([s, {
					source: e,
					flags: t
				}], o);
			}
			case 5: {
				let t = [], n = i([s, t], o);
				for (let [n, r] of o) (e || !(Ju(qu(n)) || Ju(qu(r)))) && t.push([a(n), a(r)]);
				return n;
			}
			case 6: {
				let t = [], n = i([s, t], o);
				for (let n of o) (e || !Ju(qu(n))) && t.push(a(n));
				return n;
			}
		}
		let { message: l } = o;
		return i([s, {
			name: c,
			message: l
		}], o);
	};
	return a;
}, Xu = (e, { json: t, lossy: n } = {}) => {
	let r = [];
	return Yu(!(t || n), !!t, /* @__PURE__ */ new Map(), r)(e), r;
}, Zu = typeof structuredClone == "function" ? (e, t) => t && ("json" in t || "lossy" in t) ? Hu(Xu(e, t)) : structuredClone(e) : (e, t) => Hu(Xu(e, t));
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/footer.js
function Qu(e, t) {
	let n = [{
		type: "text",
		value: "↩"
	}];
	return t > 1 && n.push({
		type: "element",
		tagName: "sup",
		properties: {},
		children: [{
			type: "text",
			value: String(t)
		}]
	}), n;
}
function $u(e, t) {
	return "Back to reference " + (e + 1) + (t > 1 ? "-" + t : "");
}
function ed(e) {
	let t = typeof e.options.clobberPrefix == "string" ? e.options.clobberPrefix : "user-content-", n = e.options.footnoteBackContent || Qu, r = e.options.footnoteBackLabel || $u, i = e.options.footnoteLabel || "Footnotes", a = e.options.footnoteLabelTagName || "h2", o = e.options.footnoteLabelProperties || { className: ["sr-only"] }, s = [], c = -1;
	for (; ++c < e.footnoteOrder.length;) {
		let i = e.footnoteById.get(e.footnoteOrder[c]);
		if (!i) continue;
		let a = e.all(i), o = String(i.identifier).toUpperCase(), l = Ms(o.toLowerCase()), u = 0, d = [], f = e.footnoteCounts.get(o);
		for (; f !== void 0 && ++u <= f;) {
			d.length > 0 && d.push({
				type: "text",
				value: " "
			});
			let e = typeof n == "string" ? n : n(c, u);
			typeof e == "string" && (e = {
				type: "text",
				value: e
			}), d.push({
				type: "element",
				tagName: "a",
				properties: {
					href: "#" + t + "fnref-" + l + (u > 1 ? "-" + u : ""),
					dataFootnoteBackref: "",
					ariaLabel: typeof r == "string" ? r : r(c, u),
					className: ["data-footnote-backref"]
				},
				children: Array.isArray(e) ? e : [e]
			});
		}
		let p = a[a.length - 1];
		if (p && p.type === "element" && p.tagName === "p") {
			let e = p.children[p.children.length - 1];
			e && e.type === "text" ? e.value += " " : p.children.push({
				type: "text",
				value: " "
			}), p.children.push(...d);
		} else a.push(...d);
		let m = {
			type: "element",
			tagName: "li",
			properties: { id: t + "fn-" + l },
			children: e.wrap(a, !0)
		};
		e.patch(i, m), s.push(m);
	}
	if (s.length !== 0) return {
		type: "element",
		tagName: "section",
		properties: {
			dataFootnotes: !0,
			className: ["footnotes"]
		},
		children: [
			{
				type: "element",
				tagName: a,
				properties: {
					...Zu(o),
					id: "footnote-label"
				},
				children: [{
					type: "text",
					value: i
				}]
			},
			{
				type: "text",
				value: "\n"
			},
			{
				type: "element",
				tagName: "ol",
				properties: {},
				children: e.wrap(s, !0)
			},
			{
				type: "text",
				value: "\n"
			}
		]
	};
}
//#endregion
//#region ../../node_modules/.bun/unist-util-visit@5.2.0/node_modules/unist-util-visit/lib/index.js
function td(e, t, n, r) {
	let i, a, o;
	typeof n == "function" || n && typeof n == "object" ? (i = t, a = n, o = r) : (a = t, o = n), typeof a == "function" ? le(e, i, rd(a), o) : le(e, i, nd(a), o);
}
function nd(e) {
	return !e || typeof e != "object" ? e : {
		enter: typeof e.enter == "function" ? rd(e.enter) : e.enter,
		exit: typeof e.exit == "function" ? rd(e.exit) : e.exit
	};
}
function rd(e) {
	return t;
	function t(t, n, r) {
		return e(t, r, n[n.length - 1]);
	}
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/state.js
var id = {}.hasOwnProperty, ad = {};
function od(e, t) {
	let n = t || ad, r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = {
		all: s,
		applyData: cd,
		definitionById: r,
		footnoteById: i,
		footnoteCounts: /* @__PURE__ */ new Map(),
		footnoteOrder: [],
		handlers: {
			...Iu,
			...n.handlers
		},
		one: o,
		options: n,
		patch: sd,
		wrap: ud
	};
	return td(e, function(e) {
		if (e.type === "definition" || e.type === "footnoteDefinition") {
			let t = e.type === "definition" ? r : i, n = String(e.identifier).toUpperCase();
			t.has(n) || t.set(n, e);
		}
	}), a;
	function o(e, t) {
		let n = e.type, r = a.handlers[n];
		if (id.call(a.handlers, n) && r) return r(a, e, t);
		if (a.options.passThrough && a.options.passThrough.includes(n)) {
			if ("children" in e) {
				let { children: t, ...n } = e, r = Zu(n);
				return r.children = a.all(e), r;
			}
			return Zu(e);
		}
		return (a.options.unknownHandler || ld)(a, e, t);
	}
	function s(e) {
		let t = [];
		if ("children" in e) {
			let n = e.children, r = -1;
			for (; ++r < n.length;) {
				let i = a.one(n[r], e);
				if (i) {
					if (r && n[r - 1].type === "break" && (!Array.isArray(i) && i.type === "text" && (i.value = dd(i.value)), !Array.isArray(i) && i.type === "element")) {
						let e = i.children[0];
						e && e.type === "text" && (e.value = dd(e.value));
					}
					Array.isArray(i) ? t.push(...i) : t.push(i);
				}
			}
		}
		return t;
	}
}
function sd(e, t) {
	e.position && (t.position = Eo(e));
}
function cd(e, t) {
	let n = t;
	if (e && e.data) {
		let t = e.data.hName, r = e.data.hChildren, i = e.data.hProperties;
		typeof t == "string" && (n.type === "element" ? n.tagName = t : n = {
			type: "element",
			tagName: t,
			properties: {},
			children: "children" in n ? n.children : [n]
		}), n.type === "element" && i && Object.assign(n.properties, Zu(i)), "children" in n && n.children && r != null && (n.children = r);
	}
	return n;
}
function ld(e, t) {
	let n = t.data || {}, r = "value" in t && !(id.call(n, "hProperties") || id.call(n, "hChildren")) ? {
		type: "text",
		value: t.value
	} : {
		type: "element",
		tagName: "div",
		properties: {},
		children: e.all(t)
	};
	return e.patch(t, r), e.applyData(t, r);
}
function ud(e, t) {
	let n = [], r = -1;
	for (t && n.push({
		type: "text",
		value: "\n"
	}); ++r < e.length;) r && n.push({
		type: "text",
		value: "\n"
	}), n.push(e[r]);
	return t && e.length > 0 && n.push({
		type: "text",
		value: "\n"
	}), n;
}
function dd(e) {
	let t = 0, n = e.charCodeAt(t);
	for (; n === 9 || n === 32;) t++, n = e.charCodeAt(t);
	return e.slice(t);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-hast@13.2.1/node_modules/mdast-util-to-hast/lib/index.js
function fd(e, t) {
	let n = od(e, t), r = n.one(e, void 0), i = ed(n), a = Array.isArray(r) ? {
		type: "root",
		children: r
	} : r || {
		type: "root",
		children: []
	};
	return i && ("children" in a, a.children.push({
		type: "text",
		value: "\n"
	}, i)), a;
}
//#endregion
//#region ../../node_modules/.bun/remark-rehype@11.1.2/node_modules/remark-rehype/lib/index.js
function pd(e, t) {
	return e && "run" in e ? async function(n, r) {
		let i = fd(n, {
			file: r,
			...t
		});
		await e.run(i, r);
	} : function(n, r) {
		return fd(n, {
			file: r,
			...e || t
		});
	};
}
//#endregion
//#region ../../node_modules/.bun/bail@2.0.2/node_modules/bail/index.js
function md(e) {
	if (e) throw e;
}
//#endregion
//#region ../../node_modules/.bun/is-plain-obj@4.1.0/node_modules/is-plain-obj/index.js
var hd = /* @__PURE__ */ e((/* @__PURE__ */ n(((e, t) => {
	var n = Object.prototype.hasOwnProperty, r = Object.prototype.toString, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = function(e) {
		return typeof Array.isArray == "function" ? Array.isArray(e) : r.call(e) === "[object Array]";
	}, s = function(e) {
		if (!e || r.call(e) !== "[object Object]") return !1;
		var t = n.call(e, "constructor"), i = e.constructor && e.constructor.prototype && n.call(e.constructor.prototype, "isPrototypeOf");
		if (e.constructor && !t && !i) return !1;
		for (var a in e);
		return a === void 0 || n.call(e, a);
	}, c = function(e, t) {
		i && t.name === "__proto__" ? i(e, t.name, {
			enumerable: !0,
			configurable: !0,
			value: t.newValue,
			writable: !0
		}) : e[t.name] = t.newValue;
	}, l = function(e, t) {
		if (t === "__proto__") {
			if (!n.call(e, t)) return;
			if (a) return a(e, t).value;
		}
		return e[t];
	};
	t.exports = function e() {
		var t, n, r, i, a, u, d = arguments[0], f = 1, p = arguments.length, m = !1;
		for (typeof d == "boolean" && (m = d, d = arguments[1] || {}, f = 2), (d == null || typeof d != "object" && typeof d != "function") && (d = {}); f < p; ++f) if (t = arguments[f], t != null) for (n in t) r = l(d, n), i = l(t, n), d !== i && (m && i && (s(i) || (a = o(i))) ? (a ? (a = !1, u = r && o(r) ? r : []) : u = r && s(r) ? r : {}, c(d, {
			name: n,
			newValue: e(m, u, i)
		})) : i !== void 0 && c(d, {
			name: n,
			newValue: i
		}));
		return d;
	};
})))(), 1);
function gd(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
//#endregion
//#region ../../node_modules/.bun/trough@2.2.0/node_modules/trough/lib/index.js
function _d() {
	let e = [], t = {
		run: n,
		use: r
	};
	return t;
	function n(...t) {
		let n = -1, r = t.pop();
		if (typeof r != "function") throw TypeError("Expected function as last argument, not " + r);
		i(null, ...t);
		function i(a, ...o) {
			let s = e[++n], c = -1;
			if (a) {
				r(a);
				return;
			}
			for (; ++c < t.length;) (o[c] === null || o[c] === void 0) && (o[c] = t[c]);
			t = o, s ? vd(s, i)(...o) : r(null, ...o);
		}
	}
	function r(n) {
		if (typeof n != "function") throw TypeError("Expected `middelware` to be a function, not " + n);
		return e.push(n), t;
	}
}
function vd(e, t) {
	let n;
	return r;
	function r(...t) {
		let r = e.length > t.length, o;
		r && t.push(i);
		try {
			o = e.apply(this, t);
		} catch (e) {
			let t = e;
			if (r && n) throw t;
			return i(t);
		}
		r || (o && o.then && typeof o.then == "function" ? o.then(a, i) : o instanceof Error ? i(o) : a(o));
	}
	function i(e, ...r) {
		n || (n = !0, t(e, ...r));
	}
	function a(e) {
		i(null, e);
	}
}
//#endregion
//#region ../../node_modules/.bun/vfile@6.0.3/node_modules/vfile/lib/minpath.browser.js
var yd = {
	basename: bd,
	dirname: xd,
	extname: Sd,
	join: Cd,
	sep: "/"
};
function bd(e, t) {
	if (t !== void 0 && typeof t != "string") throw TypeError("\"ext\" argument must be a string");
	Ed(e);
	let n = 0, r = -1, i = e.length, a;
	if (t === void 0 || t.length === 0 || t.length > e.length) {
		for (; i--;) if (e.codePointAt(i) === 47) {
			if (a) {
				n = i + 1;
				break;
			}
		} else r < 0 && (a = !0, r = i + 1);
		return r < 0 ? "" : e.slice(n, r);
	}
	if (t === e) return "";
	let o = -1, s = t.length - 1;
	for (; i--;) if (e.codePointAt(i) === 47) {
		if (a) {
			n = i + 1;
			break;
		}
	} else o < 0 && (a = !0, o = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = o));
	return n === r ? r = o : r < 0 && (r = e.length), e.slice(n, r);
}
function xd(e) {
	if (Ed(e), e.length === 0) return ".";
	let t = -1, n = e.length, r;
	for (; --n;) if (e.codePointAt(n) === 47) {
		if (r) {
			t = n;
			break;
		}
	} else r ||= !0;
	return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function Sd(e) {
	Ed(e);
	let t = e.length, n = -1, r = 0, i = -1, a = 0, o;
	for (; t--;) {
		let s = e.codePointAt(t);
		if (s === 47) {
			if (o) {
				r = t + 1;
				break;
			}
			continue;
		}
		n < 0 && (o = !0, n = t + 1), s === 46 ? i < 0 ? i = t : a !== 1 && (a = 1) : i > -1 && (a = -1);
	}
	return i < 0 || n < 0 || a === 0 || a === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function Cd(...e) {
	let t = -1, n;
	for (; ++t < e.length;) Ed(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
	return n === void 0 ? "." : wd(n);
}
function wd(e) {
	Ed(e);
	let t = e.codePointAt(0) === 47, n = Td(e, !t);
	return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function Td(e, t) {
	let n = "", r = 0, i = -1, a = 0, o = -1, s, c;
	for (; ++o <= e.length;) {
		if (o < e.length) s = e.codePointAt(o);
		else if (s === 47) break;
		else s = 47;
		if (s === 47) {
			if (!(i === o - 1 || a === 1)) if (i !== o - 1 && a === 2) {
				if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
					if (n.length > 2) {
						if (c = n.lastIndexOf("/"), c !== n.length - 1) {
							c < 0 ? (n = "", r = 0) : (n = n.slice(0, c), r = n.length - 1 - n.lastIndexOf("/")), i = o, a = 0;
							continue;
						}
					} else if (n.length > 0) {
						n = "", r = 0, i = o, a = 0;
						continue;
					}
				}
				t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
			} else n.length > 0 ? n += "/" + e.slice(i + 1, o) : n = e.slice(i + 1, o), r = o - i - 1;
			i = o, a = 0;
		} else s === 46 && a > -1 ? a++ : a = -1;
	}
	return n;
}
function Ed(e) {
	if (typeof e != "string") throw TypeError("Path must be a string. Received " + JSON.stringify(e));
}
//#endregion
//#region ../../node_modules/.bun/vfile@6.0.3/node_modules/vfile/lib/minproc.browser.js
var Dd = { cwd: Od };
function Od() {
	return "/";
}
//#endregion
//#region ../../node_modules/.bun/vfile@6.0.3/node_modules/vfile/lib/minurl.shared.js
function kd(e) {
	return !!(typeof e == "object" && e && "href" in e && e.href && "protocol" in e && e.protocol && e.auth === void 0);
}
//#endregion
//#region ../../node_modules/.bun/vfile@6.0.3/node_modules/vfile/lib/minurl.browser.js
function Ad(e) {
	if (typeof e == "string") e = new URL(e);
	else if (!kd(e)) {
		let t = /* @__PURE__ */ TypeError("The \"path\" argument must be of type string or an instance of URL. Received `" + e + "`");
		throw t.code = "ERR_INVALID_ARG_TYPE", t;
	}
	if (e.protocol !== "file:") {
		let e = /* @__PURE__ */ TypeError("The URL must be of scheme file");
		throw e.code = "ERR_INVALID_URL_SCHEME", e;
	}
	return jd(e);
}
function jd(e) {
	if (e.hostname !== "") {
		let e = /* @__PURE__ */ TypeError("File URL host must be \"localhost\" or empty on darwin");
		throw e.code = "ERR_INVALID_FILE_URL_HOST", e;
	}
	let t = e.pathname, n = -1;
	for (; ++n < t.length;) if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
		let e = t.codePointAt(n + 2);
		if (e === 70 || e === 102) {
			let e = /* @__PURE__ */ TypeError("File URL path must not include encoded / characters");
			throw e.code = "ERR_INVALID_FILE_URL_PATH", e;
		}
	}
	return decodeURIComponent(t);
}
//#endregion
//#region ../../node_modules/.bun/vfile@6.0.3/node_modules/vfile/lib/index.js
var Md = [
	"history",
	"path",
	"basename",
	"stem",
	"extname",
	"dirname"
], Nd = class {
	constructor(e) {
		let t;
		t = e ? kd(e) ? { path: e } : typeof e == "string" || Ld(e) ? { value: e } : e : {}, this.cwd = "cwd" in t ? "" : Dd.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
		let n = -1;
		for (; ++n < Md.length;) {
			let e = Md[n];
			e in t && t[e] !== void 0 && t[e] !== null && (this[e] = e === "history" ? [...t[e]] : t[e]);
		}
		let r;
		for (r in t) Md.includes(r) || (this[r] = t[r]);
	}
	get basename() {
		return typeof this.path == "string" ? yd.basename(this.path) : void 0;
	}
	set basename(e) {
		Fd(e, "basename"), Pd(e, "basename"), this.path = yd.join(this.dirname || "", e);
	}
	get dirname() {
		return typeof this.path == "string" ? yd.dirname(this.path) : void 0;
	}
	set dirname(e) {
		Id(this.basename, "dirname"), this.path = yd.join(e || "", this.basename);
	}
	get extname() {
		return typeof this.path == "string" ? yd.extname(this.path) : void 0;
	}
	set extname(e) {
		if (Pd(e, "extname"), Id(this.dirname, "extname"), e) {
			if (e.codePointAt(0) !== 46) throw Error("`extname` must start with `.`");
			if (e.includes(".", 1)) throw Error("`extname` cannot contain multiple dots");
		}
		this.path = yd.join(this.dirname, this.stem + (e || ""));
	}
	get path() {
		return this.history[this.history.length - 1];
	}
	set path(e) {
		kd(e) && (e = Ad(e)), Fd(e, "path"), this.path !== e && this.history.push(e);
	}
	get stem() {
		return typeof this.path == "string" ? yd.basename(this.path, this.extname) : void 0;
	}
	set stem(e) {
		Fd(e, "stem"), Pd(e, "stem"), this.path = yd.join(this.dirname || "", e + (this.extname || ""));
	}
	fail(e, t, n) {
		let r = this.message(e, t, n);
		throw r.fatal = !0, r;
	}
	info(e, t, n) {
		let r = this.message(e, t, n);
		return r.fatal = void 0, r;
	}
	message(e, t, n) {
		let r = new jo(e, t, n);
		return this.path && (r.name = this.path + ":" + r.name, r.file = this.path), r.fatal = !1, this.messages.push(r), r;
	}
	toString(e) {
		return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(e || void 0).decode(this.value);
	}
};
function Pd(e, t) {
	if (e && e.includes(yd.sep)) throw Error("`" + t + "` cannot be a path: did not expect `" + yd.sep + "`");
}
function Fd(e, t) {
	if (!e) throw Error("`" + t + "` cannot be empty");
}
function Id(e, t) {
	if (!e) throw Error("Setting `" + t + "` requires `path` to be set too");
}
function Ld(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
//#endregion
//#region ../../node_modules/.bun/unified@11.0.5/node_modules/unified/lib/callable-instance.js
var Rd = (function(e) {
	let t = this.constructor.prototype, n = t[e], r = function() {
		return n.apply(r, arguments);
	};
	return Object.setPrototypeOf(r, t), r;
}), zd = {}.hasOwnProperty, Bd = new class e extends Rd {
	constructor() {
		super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = _d();
	}
	copy() {
		let t = new e(), n = -1;
		for (; ++n < this.attachers.length;) {
			let e = this.attachers[n];
			t.use(...e);
		}
		return t.data((0, hd.default)(!0, {}, this.namespace)), t;
	}
	data(e, t) {
		return typeof e == "string" ? arguments.length === 2 ? (Ud("data", this.frozen), this.namespace[e] = t, this) : zd.call(this.namespace, e) && this.namespace[e] || void 0 : e ? (Ud("data", this.frozen), this.namespace = e, this) : this.namespace;
	}
	freeze() {
		if (this.frozen) return this;
		let e = this;
		for (; ++this.freezeIndex < this.attachers.length;) {
			let [t, ...n] = this.attachers[this.freezeIndex];
			if (n[0] === !1) continue;
			n[0] === !0 && (n[0] = void 0);
			let r = t.call(e, ...n);
			typeof r == "function" && this.transformers.use(r);
		}
		return this.frozen = !0, this.freezeIndex = Infinity, this;
	}
	parse(e) {
		this.freeze();
		let t = Kd(e), n = this.parser || this.Parser;
		return Vd("parse", n), n(String(t), t);
	}
	process(e, t) {
		let n = this;
		return this.freeze(), Vd("process", this.parser || this.Parser), Hd("process", this.compiler || this.Compiler), t ? r(void 0, t) : new Promise(r);
		function r(r, i) {
			let a = Kd(e), o = n.parse(a);
			n.run(o, a, function(e, t, r) {
				if (e || !t || !r) return s(e);
				let i = t, a = n.stringify(i, r);
				Jd(a) ? r.value = a : r.result = a, s(e, r);
			});
			function s(e, n) {
				e || !n ? i(e) : r ? r(n) : t(void 0, n);
			}
		}
	}
	processSync(e) {
		let t = !1, n;
		return this.freeze(), Vd("processSync", this.parser || this.Parser), Hd("processSync", this.compiler || this.Compiler), this.process(e, r), Gd("processSync", "process", t), n;
		function r(e, r) {
			t = !0, md(e), n = r;
		}
	}
	run(e, t, n) {
		Wd(e), this.freeze();
		let r = this.transformers;
		return !n && typeof t == "function" && (n = t, t = void 0), n ? i(void 0, n) : new Promise(i);
		function i(i, a) {
			let o = Kd(t);
			r.run(e, o, s);
			function s(t, r, o) {
				let s = r || e;
				t ? a(t) : i ? i(s) : n(void 0, s, o);
			}
		}
	}
	runSync(e, t) {
		let n = !1, r;
		return this.run(e, t, i), Gd("runSync", "run", n), r;
		function i(e, t) {
			md(e), r = t, n = !0;
		}
	}
	stringify(e, t) {
		this.freeze();
		let n = Kd(t), r = this.compiler || this.Compiler;
		return Hd("stringify", r), Wd(e), r(e, n);
	}
	use(e, ...t) {
		let n = this.attachers, r = this.namespace;
		if (Ud("use", this.frozen), e != null) if (typeof e == "function") s(e, t);
		else if (typeof e == "object") Array.isArray(e) ? o(e) : a(e);
		else throw TypeError("Expected usable value, not `" + e + "`");
		return this;
		function i(e) {
			if (typeof e == "function") s(e, []);
			else if (typeof e == "object") if (Array.isArray(e)) {
				let [t, ...n] = e;
				s(t, n);
			} else a(e);
			else throw TypeError("Expected usable value, not `" + e + "`");
		}
		function a(e) {
			if (!("plugins" in e) && !("settings" in e)) throw Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
			o(e.plugins), e.settings && (r.settings = (0, hd.default)(!0, r.settings, e.settings));
		}
		function o(e) {
			let t = -1;
			if (e != null) if (Array.isArray(e)) for (; ++t < e.length;) {
				let n = e[t];
				i(n);
			}
			else throw TypeError("Expected a list of plugins, not `" + e + "`");
		}
		function s(e, t) {
			let r = -1, i = -1;
			for (; ++r < n.length;) if (n[r][0] === e) {
				i = r;
				break;
			}
			if (i === -1) n.push([e, ...t]);
			else if (t.length > 0) {
				let [r, ...a] = t, o = n[i][1];
				gd(o) && gd(r) && (r = (0, hd.default)(!0, o, r)), n[i] = [
					e,
					r,
					...a
				];
			}
		}
	}
}().freeze();
function Vd(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `parser`");
}
function Hd(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `compiler`");
}
function Ud(e, t) {
	if (t) throw Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
}
function Wd(e) {
	if (!gd(e) || typeof e.type != "string") throw TypeError("Expected node, got `" + e + "`");
}
function Gd(e, t, n) {
	if (!n) throw Error("`" + e + "` finished async. Use `" + t + "` instead");
}
function Kd(e) {
	return qd(e) ? e : new Nd(e);
}
function qd(e) {
	return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function Jd(e) {
	return typeof e == "string" || Yd(e);
}
function Yd(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
//#endregion
//#region ../../node_modules/.bun/react-markdown@10.1.0+bf264c7668a20073/node_modules/react-markdown/lib/index.js
var Xd = [], Zd = { allowDangerousHtml: !0 }, Qd = /^(https?|ircs?|mailto|xmpp)$/i, $d = [
	{
		from: "astPlugins",
		id: "remove-buggy-html-in-markdown-parser"
	},
	{
		from: "allowDangerousHtml",
		id: "remove-buggy-html-in-markdown-parser"
	},
	{
		from: "allowNode",
		id: "replace-allownode-allowedtypes-and-disallowedtypes",
		to: "allowElement"
	},
	{
		from: "allowedTypes",
		id: "replace-allownode-allowedtypes-and-disallowedtypes",
		to: "allowedElements"
	},
	{
		from: "className",
		id: "remove-classname"
	},
	{
		from: "disallowedTypes",
		id: "replace-allownode-allowedtypes-and-disallowedtypes",
		to: "disallowedElements"
	},
	{
		from: "escapeHtml",
		id: "remove-buggy-html-in-markdown-parser"
	},
	{
		from: "includeElementIndex",
		id: "#remove-includeelementindex"
	},
	{
		from: "includeNodeIndex",
		id: "change-includenodeindex-to-includeelementindex"
	},
	{
		from: "linkTarget",
		id: "remove-linktarget"
	},
	{
		from: "plugins",
		id: "change-plugins-to-remarkplugins",
		to: "remarkPlugins"
	},
	{
		from: "rawSourcePos",
		id: "#remove-rawsourcepos"
	},
	{
		from: "renderers",
		id: "change-renderers-to-components",
		to: "components"
	},
	{
		from: "source",
		id: "change-source-to-children",
		to: "children"
	},
	{
		from: "sourcePos",
		id: "#remove-sourcepos"
	},
	{
		from: "transformImageUri",
		id: "#add-urltransform",
		to: "urlTransform"
	},
	{
		from: "transformLinkUri",
		id: "#add-urltransform",
		to: "urlTransform"
	}
];
function ef(e) {
	let t = tf(e), n = nf(e);
	return rf(t.runSync(t.parse(n), n), e);
}
function tf(e) {
	let t = e.rehypePlugins || Xd, n = e.remarkPlugins || Xd, r = e.remarkRehypeOptions ? {
		...e.remarkRehypeOptions,
		...Zd
	} : Zd;
	return Bd().use(au).use(n).use(pd, r).use(t);
}
function nf(e) {
	let t = e.children || "", n = new Nd();
	return typeof t == "string" ? n.value = t : "" + t, n;
}
function rf(e, t) {
	let n = t.allowedElements, r = t.allowElement, i = t.components, a = t.disallowedElements, o = t.skipHtml, s = t.unwrapDisallowed, c = t.urlTransform || af;
	for (let e of $d) Object.hasOwn(t, e.from) && "" + e.from + (e.to ? "use `" + e.to + "` instead" : "remove it") + e.id;
	return td(e, l), zo(e, {
		Fragment: Pe,
		components: i,
		ignoreInvalidStyle: !0,
		jsx: F,
		jsxs: I,
		passKeys: !0,
		passNode: !0
	});
	function l(e, t, i) {
		if (e.type === "raw" && i && typeof t == "number") return o ? i.children.splice(t, 1) : i.children[t] = {
			type: "text",
			value: e.value
		}, t;
		if (e.type === "element") {
			let t;
			for (t in cs) if (Object.hasOwn(cs, t) && Object.hasOwn(e.properties, t)) {
				let n = e.properties[t], r = cs[t];
				(r === null || r.includes(e.tagName)) && (e.properties[t] = c(String(n || ""), t, e));
			}
		}
		if (e.type === "element") {
			let o = n ? !n.includes(e.tagName) : a ? a.includes(e.tagName) : !1;
			if (!o && r && typeof t == "number" && (o = !r(e, t, i)), o && i && typeof t == "number") return s && e.children ? i.children.splice(t, 1, ...e.children) : i.children.splice(t, 1), t;
		}
	}
}
function af(e) {
	let t = e.indexOf(":"), n = e.indexOf("?"), r = e.indexOf("#"), i = e.indexOf("/");
	return t === -1 || i !== -1 && t > i || n !== -1 && t > n || r !== -1 && t > r || Qd.test(e.slice(0, t)) ? e : "";
}
//#endregion
//#region ../../node_modules/.bun/vfile-location@5.0.4/node_modules/vfile-location/lib/index.js
function of(e) {
	let t = String(e), n = [], r = -1, i = -1;
	return {
		toOffset: s,
		toPoint: o
	};
	function a() {
		let e = n.at(-1) ?? 0;
		r < e && (r = t.indexOf("\r", e), r === -1 && (r = Infinity)), i < e && (i = t.indexOf("\n", e), i === -1 && (i = Infinity));
		let a = r + 1 === i ? i : Math.min(r, i);
		n.push((a === Infinity ? t.length : a) + 1);
	}
	function o(e) {
		if (typeof e == "number" && e > -1 && e <= t.length) {
			for (; (n.at(-1) ?? 0) <= e;) a();
			let t = 0, r = n.length - 1;
			for (; t < r;) {
				let i = Math.floor((t + r) / 2);
				n[i] > e ? r = i : t = i + 1;
			}
			return {
				line: t + 1,
				column: e - (t > 0 ? n[t - 1] : 0) + 1,
				offset: e
			};
		}
	}
	function s(e) {
		if (e && typeof e.line == "number" && typeof e.column == "number" && !Number.isNaN(e.line) && e.column > 0) {
			for (; n.length < e.line && (n.at(-1) ?? 0) <= t.length;) a();
			let r = (e.line > 1 ? n[e.line - 2] : 0) + e.column - 1;
			if (r < n[e.line - 1]) return r;
		}
	}
}
//#endregion
//#region ../../node_modules/.bun/hast-util-from-parse5@8.0.4/node_modules/hast-util-from-parse5/lib/index.js
var sf = {}.hasOwnProperty, cf = Object.prototype;
function lf(e, t) {
	let n = t || {};
	return uf({
		file: n.file || void 0,
		location: !1,
		schema: n.space === "svg" ? me : ue,
		verbose: n.verbose || !1
	}, e);
}
function uf(e, t) {
	let n;
	switch (t.nodeName) {
		case "#comment": {
			let r = t;
			return n = {
				type: "comment",
				value: r.data
			}, pf(e, r, n), n;
		}
		case "#document":
		case "#document-fragment": {
			let r = t, i = "mode" in r ? r.mode === "quirks" || r.mode === "limited-quirks" : !1;
			if (n = {
				type: "root",
				children: df(e, t.childNodes),
				data: { quirksMode: i }
			}, e.file && e.location) {
				let t = String(e.file), r = of(t), i = r.toPoint(0), a = r.toPoint(t.length);
				n.position = {
					start: i,
					end: a
				};
			}
			return n;
		}
		case "#documentType": {
			let r = t;
			return n = { type: "doctype" }, pf(e, r, n), n;
		}
		case "#text": {
			let r = t;
			return n = {
				type: "text",
				value: r.value
			}, pf(e, r, n), n;
		}
		default: return n = ff(e, t), n;
	}
}
function df(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) {
		let i = uf(e, t[n]);
		r.push(i);
	}
	return r;
}
function ff(e, t) {
	let { schema: n } = e;
	e.schema = t.namespaceURI === ye.svg ? me : ue;
	let r = -1, i = {};
	for (; ++r < t.attrs.length;) {
		let e = t.attrs[r], n = (e.prefix ? e.prefix + ":" : "") + e.name;
		sf.call(cf, n) || (i[n] = e.value);
	}
	let a = (e.schema.space === "svg" ? _e : he)(t.tagName, i, df(e, t.childNodes));
	if (pf(e, t, a), a.tagName === "template") if (t.namespaceURI === ye.html) {
		let n = t, r = n.sourceCodeLocation, i = r && r.startTag && hf(r.startTag), o = r && r.endTag && hf(r.endTag), s = uf(e, n.content);
		i && o && e.file && (s.position = {
			start: i.end,
			end: o.start
		}), a.content = s;
	} else a.content && (a.children = a.content.children, delete a.content);
	return e.schema = n, a;
}
function pf(e, t, n) {
	if ("sourceCodeLocation" in t && t.sourceCodeLocation && e.file) {
		let r = mf(e, n, t.sourceCodeLocation);
		r && (e.location = !0, n.position = r);
	}
}
function mf(e, t, n) {
	let r = hf(n);
	if (t.type === "element") {
		let i = t.children[t.children.length - 1];
		if (r && !n.endTag && i && i.position && i.position.end && (r.end = Object.assign({}, i.position.end)), e.verbose) {
			let r = {}, i;
			if (n.attrs) for (i in n.attrs) sf.call(n.attrs, i) && (r[be(e.schema, i).property] = hf(n.attrs[i]));
			n.startTag;
			let a = hf(n.startTag), o = n.endTag ? hf(n.endTag) : void 0, s = { opening: a };
			o && (s.closing = o), s.properties = r, t.data = { position: s };
		}
	}
	return r;
}
function hf(e) {
	let t = gf({
		line: e.startLine,
		column: e.startCol,
		offset: e.startOffset
	}), n = gf({
		line: e.endLine,
		column: e.endCol,
		offset: e.endOffset
	});
	return t || n ? {
		start: t,
		end: n
	} : void 0;
}
function gf(e) {
	return e.line && e.column ? e : void 0;
}
//#endregion
//#region ../../node_modules/.bun/zwitch@2.0.4/node_modules/zwitch/index.js
var _f = {}.hasOwnProperty;
function vf(e, t) {
	let n = t || {};
	function r(t, ...n) {
		let i = r.invalid, a = r.handlers;
		if (t && _f.call(t, e)) {
			let n = String(t[e]);
			i = _f.call(a, n) ? a[n] : r.unknown;
		}
		if (i) return i.call(this, t, ...n);
	}
	return r.handlers = n.handlers || {}, r.invalid = n.invalid, r.unknown = n.unknown, r;
}
//#endregion
//#region ../../node_modules/.bun/hast-util-to-parse5@8.0.1/node_modules/hast-util-to-parse5/lib/index.js
var yf = {}, bf = {}.hasOwnProperty, xf = vf("type", { handlers: {
	root: Cf,
	element: Of,
	text: Ef,
	comment: Df,
	doctype: Tf
} });
function Sf(e, t) {
	let n = (t || yf).space;
	return xf(e, n === "svg" ? me : ue);
}
function Cf(e, t) {
	let n = {
		nodeName: "#document",
		mode: (e.data || {}).quirksMode ? "quirks" : "no-quirks",
		childNodes: []
	};
	return n.childNodes = Af(e.children, n, t), jf(e, n), n;
}
function wf(e, t) {
	let n = {
		nodeName: "#document-fragment",
		childNodes: []
	};
	return n.childNodes = Af(e.children, n, t), jf(e, n), n;
}
function Tf(e) {
	let t = {
		nodeName: "#documentType",
		name: "html",
		publicId: "",
		systemId: "",
		parentNode: null
	};
	return jf(e, t), t;
}
function Ef(e) {
	let t = {
		nodeName: "#text",
		value: e.value,
		parentNode: null
	};
	return jf(e, t), t;
}
function Df(e) {
	let t = {
		nodeName: "#comment",
		data: e.value,
		parentNode: null
	};
	return jf(e, t), t;
}
function Of(e, t) {
	let n = t, r = n;
	e.type === "element" && e.tagName.toLowerCase() === "svg" && n.space === "html" && (r = me);
	let i = [], a;
	if (e.properties) {
		for (a in e.properties) if (a !== "children" && bf.call(e.properties, a)) {
			let t = kf(r, a, e.properties[a]);
			t && i.push(t);
		}
	}
	let o = r.space, s = {
		nodeName: e.tagName,
		tagName: e.tagName,
		attrs: i,
		namespaceURI: ye[o],
		childNodes: [],
		parentNode: null
	};
	return s.childNodes = Af(e.children, s, r), jf(e, s), e.tagName === "template" && e.content && (s.content = wf(e.content, r)), s;
}
function kf(e, t, n) {
	let r = be(e, t);
	if (n === !1 || n == null || typeof n == "number" && Number.isNaN(n) || !n && r.boolean) return;
	Array.isArray(n) && (n = r.commaSeparated ? fe(n) : ve(n));
	let i = {
		name: r.attribute,
		value: n === !0 ? "" : String(n)
	};
	if (r.space && r.space !== "html" && r.space !== "svg") {
		let e = i.name.indexOf(":");
		e < 0 ? i.prefix = "" : (i.name = i.name.slice(e + 1), i.prefix = r.attribute.slice(0, e)), i.namespace = ye[r.space];
	}
	return i;
}
function Af(e, t, n) {
	let r = -1, i = [];
	if (e) for (; ++r < e.length;) {
		let a = xf(e[r], n);
		a.parentNode = t, i.push(a);
	}
	return i;
}
function jf(e, t) {
	let n = e.position;
	n && n.start && n.end && (n.start.offset, n.end.offset, t.sourceCodeLocation = {
		startLine: n.start.line,
		startCol: n.start.column,
		startOffset: n.start.offset,
		endLine: n.end.line,
		endCol: n.end.column,
		endOffset: n.end.offset
	});
}
//#endregion
//#region ../../node_modules/.bun/html-void-elements@3.0.0/node_modules/html-void-elements/index.js
var Mf = [
	"area",
	"base",
	"basefont",
	"bgsound",
	"br",
	"col",
	"command",
	"embed",
	"frame",
	"hr",
	"image",
	"img",
	"input",
	"keygen",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
], Nf = new Set([
	65534,
	65535,
	131070,
	131071,
	196606,
	196607,
	262142,
	262143,
	327678,
	327679,
	393214,
	393215,
	458750,
	458751,
	524286,
	524287,
	589822,
	589823,
	655358,
	655359,
	720894,
	720895,
	786430,
	786431,
	851966,
	851967,
	917502,
	917503,
	983038,
	983039,
	1048574,
	1048575,
	1114110,
	1114111
]), W;
(function(e) {
	e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(W ||= {});
var Pf = {
	DASH_DASH: "--",
	CDATA_START: "[CDATA[",
	DOCTYPE: "doctype",
	SCRIPT: "script",
	PUBLIC: "public",
	SYSTEM: "system"
};
function Ff(e) {
	return e >= 55296 && e <= 57343;
}
function If(e) {
	return e >= 56320 && e <= 57343;
}
function Lf(e, t) {
	return (e - 55296) * 1024 + 9216 + t;
}
function Rf(e) {
	return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function zf(e) {
	return e >= 64976 && e <= 65007 || Nf.has(e);
}
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/common/error-codes.js
var G;
(function(e) {
	e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(G ||= {});
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/tokenizer/preprocessor.js
var Bf = 65536, Vf = class {
	constructor(e) {
		this.handler = e, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = Bf, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
	}
	get col() {
		return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
	}
	get codePointStart() {
		return this.pos - Number(this.lastGapPos === this.pos);
	}
	get offset() {
		return this.droppedBufferSize + this.codePointStart;
	}
	getError(e, t) {
		let { line: n, col: r, offset: i } = this, a = r + t, o = i + t;
		return {
			code: e,
			startLine: n,
			endLine: n,
			startCol: a,
			endCol: a,
			startOffset: o,
			endOffset: o
		};
	}
	_err(e) {
		this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(e, 0)));
	}
	_addGap() {
		this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
	}
	_processSurrogate(e) {
		if (this.pos !== this.html.length - 1) {
			let t = this.html.charCodeAt(this.pos + 1);
			if (!If(e) && If(t)) return this.pos++, this._addGap(), Lf(e, t);
		} else if (!this.lastChunkWritten) return this.endOfChunkHit = !0, W.EOF;
		return this._err(G.surrogateInInputStream), e;
	}
	willDropParsedChunk() {
		return this.pos > this.bufferWaterline;
	}
	dropParsedChunk(e = 0) {
		if (this.willDropParsedChunk()) {
			let t = this.offset - this.droppedBufferSize - e;
			this.html = this.html.substring(t), this.lineStartPos -= t, this.droppedBufferSize += t, this.pos -= t, this.lastGapPos = -2, this.gapStack.length = 0, this.pos > e && this._addGap();
		}
	}
	write(e, t) {
		this.html.length > 0 ? this.html += e : this.html = e, this.endOfChunkHit = !1, this.lastChunkWritten = t;
	}
	insertHtmlAtCurrentPos(e) {
		this.html = this.html.substring(0, this.pos + 1) + e + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
	}
	startsWith(e, t) {
		if (this.pos + e.length > this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, !1;
		if (t) return this.html.startsWith(e, this.pos);
		for (let t = 0; t < e.length; t++) if ((this.html.charCodeAt(this.pos + t) | 32) !== e.charCodeAt(t)) return !1;
		return !0;
	}
	peek(e) {
		let t = this.pos + e;
		if (t >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, W.EOF;
		let n = this.html.charCodeAt(t);
		return n === W.CARRIAGE_RETURN ? W.LINE_FEED : n;
	}
	advance() {
		if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, W.EOF;
		let e = this.html.charCodeAt(this.pos);
		return e === W.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, W.LINE_FEED) : e === W.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, Ff(e) && (e = this._processSurrogate(e)), this.handler.onParseError === null || e > 31 && e < 127 || e === W.LINE_FEED || e === W.CARRIAGE_RETURN || e > 159 && e < 64976 || this._checkForProblematicCharacters(e), e);
	}
	_checkForProblematicCharacters(e) {
		Rf(e) ? this._err(G.controlCharacterInInputStream) : zf(e) && this._err(G.noncharacterInInputStream);
	}
	retreat(e) {
		for (this.pos -= e; this.pos < this.lastGapPos;) this.lastGapPos = this.gapStack.pop(), this.pos--;
		this.isEol = !1;
	}
}, K;
(function(e) {
	e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(K ||= {});
function Hf(e, t) {
	for (let n = e.attrs.length - 1; n >= 0; n--) if (e.attrs[n].name === t) return e.attrs[n].value;
	return null;
}
//#endregion
//#region ../../node_modules/.bun/entities@9.0.0/node_modules/entities/dist/decode-codepoint.js
var Uf = [
	8364,
	0,
	8218,
	402,
	8222,
	8230,
	8224,
	8225,
	710,
	8240,
	352,
	8249,
	338,
	0,
	381,
	0,
	0,
	8216,
	8217,
	8220,
	8221,
	8226,
	8211,
	8212,
	732,
	8482,
	353,
	8250,
	339,
	0,
	382,
	376
];
function Wf(e) {
	return e === 0 || e >= 55296 && e <= 57343 || e > 1114111;
}
function Gf(e) {
	return Wf(e) ? 65533 : e >= 128 && e <= 159 && Uf[e - 128] || e;
}
//#endregion
//#region ../../node_modules/.bun/entities@9.0.0/node_modules/entities/dist/generated/decode-data-html.js
var Kf = ["Q=¨`p0AEligMPacutebrevecircyfrgravelphamacrndogonpfpplyFunctionringscrsigntildeumlBackslashrvwedcyecausernoullistafropfrevescrumpeqCHcyOPYacutepitalDifferentialDyleyscaronedilirconintdotedillanterDotfrhiircleDotMinusPlusTimeslockwiseContourIntegralseCurlyDoubleQuoteQuoteolonengruentinttourIntegralpfroductunterClockwiseContourIntegralrossscrupCapDDotrahdJcyScyZcyaggerrrshvcaronyeltafriacriticalAcuteDotubleAcuteGraveTildemondfferentialDopftDotEqualubleContourIntegralDotwnArrowLeftArrowRightArrowTeeongLeftArrowRightArrowRightArrowRightArrowTeeUpArrowDownArrowVerticalBarwnArrowBarUpArrowBreveLeftRightVectorTeeVectorVectorBarRightTeeVectorVectorBarTeeArrowarrowscrtrokENGTHacutecaronircydotfrgravelementmacrptySmallSquareVerySmallSquareogonpfpsilonqualTildeilibriumscrimtaumlxistsponentialEFcyfrilledSmallSquareVerySmallSquareopfrAlluriertrfscrGJcyTammadbrevecedilircydotfrgopfreaterEqualLessFullEqualGreaterLessSlantEqualTildescrtHARDcyacektcircfrilbertSpaceopfrizontalLinescrtrokumpDownHumpEqualIEcyJligOcyacutecircydotfrgravemacrginaryIpliesntegralrsectionvisibleCommaTimesogonpftascrtildeukcymlJcircyfropfscrercyukcyKHcyJcyappacedilyfropfscrLJcyTacutembdangplacetrfrrcaronedilyeftAngleBracketrrowBarRightArrowCeilingDoubleBracketwnTeeVectorVectorBarFloorRightArrowVectorTeeArrowVectorriangleBarEqualUpDownVectorTeeVectorVectorBarVectorBararrowrightarrowssEqualGreaterFullEqualGreaterLessSlantEqualTildefrleftarrowmidotongLeftArrowRightArrowRightArrowleftarrowrightarrowrightarrowpfwerLeftArrowRightArrowscrhtroktMapcyediumSpacellintrffrinusPlusopfscruNJcyacutecaronedilyegativeMediumSpaceThickSpacenSpaceVeryThinSpacestedGreaterGreaterLessLesswLinefroBreaknBreakingSpacepftCongruentupCapDoubleVerticalBarElementqualTildexistsGreaterEqualFullEqualGreaterLessSlantEqualTildeHumpDownHumpEqualLeftTriangleBarEqualssEqualGreaterLessSlantEqualTildeNestedGreaterGreaterLessLessPrecedesEqualSlantEqualReverseElementightTriangleBarEqualSquareSubsetEqualpersetEqualubsetEqualcceedsEqualSlantEqualTildepersetEqualTildeEqualFullEqualTildeVerticalBarscrtildeuOEligacutecircydblacfrgravemacregaicronopfpenCurlyDoubleQuoteQuoterscrlashtildemesumlverBarraceketParenthesisPartialDcyfrhiilusMinusoincareplanepfrecedesEqualSlantEqualTildeimeoductportionalscriQUOTfropfscrRBarrEGacutengrrtlcaronedilyeverseElementquilibriumUpEquilibriumfrhoightAngleBracketrrowBarLeftArrowCeilingDoubleBracketwnTeeVectorVectorBarFloorTeeArrowVectorriangleBarEqualUpDownVectorTeeVectorVectorBarVectorBararrowopfundImpliesrightarrowscrhuleDelayedSHCHcycyOFTcyacutecaronedilircyfrhortDownArrowLeftArrowRightArrowUpArrowigmamallCircleopfqrtuareIntersectionSubsetEqualpersetEqualUnionscrtarubsetEqualcceedsEqualSlantEqualTildehThatmpersetEqualsetTHORNRADESHcycyabucaronedilyfrhereforetaickSpacenSpaceildeEqualFullEqualTildeopfripleDotscrtrokUacuterrocirbrcyevecircydblacfrgravemacrnderBarraceketParenthesisionPlusogonpfpArrowBarDownArrowDownArrowEquilibriumTeeArrowarrowdownarrowperLeftArrowRightArrowsilonringscrtildeumlVDashbarcydashleerbarticalBarLineSeparatorTildeyThinSpacefropfscrvdashWcircedgefropfscrXfriopfscrYAcyIcyUcyacutecircyfropfscrumlZHcyacutecaronydoteroWidthSpacetafropfscraacutebrevecEdircuteyeligfrgravelefsymphphamacrlgpndanddslopevgelemsdaabcdefghrtvbdsphtzarrogonpfpEacireidosproxeqringscrtympeqtildeumlwconintintbNotackcongepsilonprimesimeqrveewedgebrktbrkcongydquoecausemptyvpsirnoutahweenfrigcapircupodotplustimessqcuptartriangledownupuplusveewedgekarowlacklozengesquaretriangledownleftrightnkk12434ocknequivotopfttomwtiexDLRlrHDUduULRlrVHLRhlrboxdLRlrhDUduminusplustimesuLRlrvHLRhlrprimerevevbarscremiimeolbhsubulletmpEeqcacutepandbrcupcapupdotsretoncapsronedilircupssmdotedilmptyvnterdotfrhcyeckmarkiirEceqlearrowleftrightdRSastcircdashefnintmidscirlubsuitoloneqmmatpfnlementxesngdotintpfrodysrrarrossscrubepetdotudarrlreprsclarrppbrcapcapupdotorsrarrmlyeqprecsuccveewedgerenvearrowleftrightveewedwconintintylctydArrHaraggerlethrrshvbkarowlaccaronydaggerrrotseqegltamptyvfishtrharlriamondsuitsegammasinvideontimesonxjcylcornropollarpfteqdotminusplussquareublebarwedgewnarrowdownarrowsharpoonleftrightrbkarowcornropscryoltroktdotrifuarrharwanglezcyigrarreDDototacutestercaronircolonydotefDotrgravesdotlinterslsdotmacrptysetvsp134ngspogonpfparsllussilonvqcircolonsimlantgtrlessualsestivDDvparslrDotarrscrdotimtahumlroxclistpectationonentialefallingdotseqcyemalefiligligligriligjliglatligtnsnofopfrallkvpartintrac123456823534584556878slownscrgElacutemmadpbrevecircydotelqqslantsccdotollesfrggimeljcylEajnEapproxeqqsimopfravescrimeltccirdotlParquestrapproxrrdoteqlessqlesslesssimvertneqqnEhArrairsplfmiltrdcyrcirwbarcirceartsuitlliprconfrksearowwarowoarrmthtokleftarrowrightarrowpfrbarscrlashtrokybullpheniacutecircyecyxclffrgraveiiintntnfinotajligmacrgelinepartthofpedncarefintieodottcalegersrcallarhkprodocygonpftaprodquestscrinEdotsvvtildeukcymljcircyfrmathopfscrercyukcykappavcedilyfrgreenhcyjcyopfscrlAarrrrtailBarrEgHaracuteemptyvgranmbdangdlepquorrbfsfshklpplsimtltailesbarrbrkracekkeslducaronedililubydcaquorrdharusharsheftarrowtailharpoondownupleftarrowsrightarrowsharpoonssquigarrowthreetimesgqqslantsccdotorgessapproxdoteqgtrqgtrgtrsimfishtloorrgEhardulblkjcylarrcornerhardtrimidotoustachenEapproxeqqsimoangrrbrkngleftarrowrightarrowmapstorightarrowoparrowleftrightparflustimeswastbarzengefparltrarrcornerhardmtrisaquocrhimegqbuortroktccirdothreeimeslarrquestrPariefurdsharuharvertneqqnEmDDotacrletesepstodownleftuprkercommaydasheasuredanglefrhoicrodastcirdotnusbdulcpdrnplusodelspfpscrtposultimapmapnGgtvLeftarrowrightarrowltvRightarrowVDashdashablacutengpEidosproxturalsbspumpecapronedilongdotupydasheArrarhkrowdotquivsearimxistsfrgEeqqslantssimtrhArrarrparisdvjcylArrEarrdreftarrowrightarrowqqslantsssimtriemidopftinEdotvabcnivabcparallelsltolintrcueeceqrArrarrcwightarrowtriesccueerhortmidparallelimeqmidparqsubepeubEeseteqqcceqpEeseteqqtglildelgrianglelefteqrightequmerospvDashHarrapdashgetinfinlArretrierArrtriesimwArrarhkrownearoSacutestcircydashblacivotsoldeligfcirrgonravethbarmintlarrcirrossinetmacregaicrondnusopfparerplusrarrderoffmigoforslopevscrlasholtildemesasumlvbarparallelsimltcyercntiodmilptenkfrhivmmatoneitchforkvlanckhkvusacirbcirdouemnsimtwomointintpfundrEapcueecapproxcurlyeqeqnapproxeqqsimsimimesnEapsimodfalarlinesurfptosimurelscriuncspqfrintopfprimescruaternionsintesteqotrAarrrrtailBarrHaraceutedicemptyvngdelequorrapbfscfshklpplsimtlwtailionalsbarrbrkracekkeslducaronedililubydcaldharquorshealinepartsctgfishtloorrhardulovightarrowtailharpoondownupleftarrowsharpoonsrightarrowssquigarrowthreetimesngsingdotseqlarrharmmoustachenmidoangrrbrkparflustimespargtpolintrarrsaquocrhqbuorthreeimesriefltriuluharxsacutebquocEaproncueedilircnEapsimpolintsimydotbeeArrarhkrowctmiswartminusnxtfrownharpchcyyortmidparallelyigmafvmdoteqgElEneplusrarrlarrmallsetminusshpeparslidletesoftcylbarpfpadesuitrqcapsupssubeseteqpesetequareffrarrscretmnmiletarftarfraightepsilonphinsubEdotedotmultnEeplusrarrseteqqneqqimubpccapproxcurlyeqeqnapproxeqqsimsimmngp123EdotsubedothsolublarrmultnEeplusseteqqneqqimubpwArrarhkrownwarzligtargetubrkcaronedilydotelrecfrhere4foretasymvickapproxsimnspkapsimornildemesbardntoeapbotcirforksaprimeradeiangledownlefteqqrighteqdoteminusplussbtimepeziumscryhcytrokwixtoheadleftarrowrightarrowuArrHaracuterrbrcyevecircydarrblacharfishtrgraveharlrblklcornerroptrimacrlogonpfparrowdownarrowharpoonleftrightlussihlonuparrowsrcornerropingtriscrtdotilderifuarrmlwanglevArrBarvDashangrtrepsilonkappanothingphiiroptorhosigmaubsetneqqpsetneqqthetariangleleftrightcydasheebareqlliprbartfrltrinsubpopfproprtriscrubnEepnEezigzagwcircedbargeqierpfropfpreathscrxcapircupdtrifrhArrarrilArrarrmapnisodotpflustimerArrarrscrqcupuplustriveewedgeyacuteycircyenfricyopfscrucymlzacutecaronydoteetrftafrhcyigrarropfscrwjnjC(D%D($(D'%$$ED($'$'$%$'%E$/D'$F%'D(D&#,%%&&$%$)%+%%$E$F$'$&$(#'D&$(%$&4%($(E'%&%($&$)%*$%$%$+)()')($:&5-($'($%*&&&/%%&)%@$'$F$%&&#%%)$&$&$&$(%%%&$(%$$%&%$E$2.&0,.(.(&'%.$F%$&&&(%6)&+*),---&*/1---)-.&)*+,).%*,&,*'('2+,+)1&'1,)2&'&*('($F%'#&D%D($(E&%$$&$ED($)$'%1(2$'%E$)$'((&+$&%%$%D&$(%-#&$E$3)2$F%'%+$&#'D$$'($$($(%&%$$&$E$$$F$./'*,***'*-*($F$$#)$'%$$'$%$.$&%/$&%'$.'(#'$'$&D(D'%$$&$%D($$%&&*%($%&('+%/,($'%E%%$&$($'E%#(%$$E$F$F%'$'#'$&$'$(%$$E$F$F#'D$$(%'%%%+%%$(%'%$$2(',&,-'*'0).+)1&'('-,)'&*(*)(*/&/('/),))/&')-&'('-%1','*'''-'($E$$%+$($/+-'-',+-'-%E%/(-$&%$%'$$#&$%$-%*$E$+$F$&$$#'$($(%'%$$5+-.)+0%5)+%($E$)%1%%%$&,'(&4&*''+H'(&*-(-L-J-'-M-(&O*H&/2F2((%*(***G*M*(&W,K&+.H.-&1'/3F3(&O2(.I4('H,(().H.-.H(I.(&(+(+,+(&.$FD($$#(D(D'%$$($ED($'%&%($F$6,($$$FE'D(&&D&$)('+&'.#+$%$E$%$$$+$/%%$$%)+(+-+(%&%(&*-%$F%$C'$E$&$F#(D%$(%%%%'%$(%'%$$$%/+-*0$%$%$3)'-&-,(*(0*.,)2&(((&+(+))*0&0((/*,*)0&().&(($&%-$-$&%$$-#)%%$($($$%'%'%&%$$E$0(,(-(*$'$-$F$&%')/))/(+)1()($F$&$%&&)(%)+(+-+(&(%$%$&(+(&&C($'$'%%$%%$$(%'%$$E$+&%%K&)$'(((,(($F$+$F%'C)%%''$'&&D'%$$($ED($'$*)',&(.%&('$'%E$)*&*,%,%.%&((%(%,%/(-%%'&$'$F$(D&#($&$%$'($$%%'&$'*+'+,+(&-$E$F$F$(#($'$E$F$F#F$$$F$F#'$&$&D($'%$$E$F$F$&#'$($(%$$&$0%%$%$&$FC)$($$%D%$E&E&%$D'$$%DD($)&%%&$'&%E$$%&&&$&(&$%$&$&%&&)%*$*$*$*$*$*$*$&%(%*$&&'$&'$'%E$$%$%'%$%%%%%')%D'$F%$%&(%D(D&$*%&#'$*'*'('&*%%'&&)%$&''$'%$$'$()$%(%&%'%%&$&'$E$('&'%&''''(&('&&/.%&(&&&($($.()(+0'0'0(&%%&'$&%%&$E&G%%$F%$&&%'%&'$'$'$&$'$'$'$'$&%'$'$'$&$'$'$'$'$'$'$&&&%'$'$'$&$'$'$'$'$&(&'&(&%'$'$'$&$'$'$'$'$'$'$$($'E'$F%&%%'$%%'$''$&'%%%'$'$($#)%$&&&(&&'%&&&D%&&%$'&&E'%&%&(%$&D'%(E%'($E$&%&('%$$%&$&$'%'..()%*$*&*'*'&$&(&&&'$'(&$'($)$%&($&$'%'))&%%'&&&%E&&F$'%$'%&$F%%'$&$'$$'$))$%&&%%')$%$&(&&'%&&&%&D%')$&+*'(&((F&&.-(%&%&$*%&$(#'$&$(%'%%%%'$$)%&$(%$$$%(&%%(D%%&%($(%D$''$$&'&*''$%$%(%&%$F&)*&&$&$(&&$(%E%$&%(&&(&'&)%/%*'-'..($*%'&&$F&$%%%'$'%%'$$'%&$)$&%)#(%%D(%'$(%%G$%'%$$&$$$'%D$$E'%$&&$$%)%$%$&&$'%&(&($%%'%($$%%%$'%E$&'%%&%%'&'$$(&'%&&**'%'&&&%(%%)$'%&$&%&%%$%E$D&%%$&%&%,&,#0$%$($(%&&&%D$'$G$&%&%&$&$F%'&$'$$*D(($H$($($($'%($G%($($'%'%($'%&%%&$F#%%$$(%&($%$$($'%$$&$$%$%$&$&(%$&%&&)$*$&D'%$E$$%$$'$&$$%$%$%$$%%%''%$&$'$%&$F$'$&%%'$'$D$%%&%%&%'%(%*'%&&&)((&'&&$K%E#'$(%%%'%'&$'&'$$&$'$()&%'%'$E$*&($'%'%.'-%E%'$F%'%'$(%'C)$$E&%$$&E&$%%DD($$%'&%%'%&$'$'&%''''&%%%%&$$%'%&(&%'%$&&&(''&(&'$&%&%E%%$'D($F%%'$'&'$($'$$$%'$'E%#(%$$E$'$F$F%'$'#(($$(%$$E$($&$&$F$F#(%%%'$'$$%$$&$(%)%'%'%%'$'%%$E&%%'$(%'%'%'%'%'&'%%$&&&$'D$'%&%'($&%'&)$$(%'&%%%%$$&%&($%(&(%%$$%*,''..%'-'-1$,+,-'-%$%$&$&(%$&%&&)$*$&D'%&*'&'()''&'&$(%'%D$$%$$''$($%&$&$$%&%)%'%&$(%')'$%%%''%$&$'$%&$'&%%&%.+-')'-%.,(%&&D&&%(%'&&%$&'&$$&'%$'%)%&($%$%&$(%E%$%%'$'$%%&%($%'D$%%&%%&%'%'%'%(%'&$'$'$$*&'$K%E#(D&%%&$'&%$&&)')')%%'$(%$$'$/$E$%D'%$&&&&F&%&($($)$$&%%$($(%E$$$F%'$$%)%&#F%D&D$,(-%D%D&D$-$(%'$'%'%E%$&D&E&%&'%&(%*$D&%F(D$&&&%'%&(F%%%$$'$$%&%''$(%%F%'%'&E%')$$E$E%$&$'D'H&D%&%$&$$'%&%&$$%$&$%$$&$'%D%&%%%$&*(-&$'D'H&D'$%&%$&%($$&$FE$&%(D(F(%)$)$&%(%)$)$$&'('E'D%(%$&&&D'$(E$'%&(D(D%,%&($$%&&&D&D%*)+%%'$($%&%&%((%%%'D'$'F*%,D&%(E&$'D'$'F*%,D$&E'%%%.0%,(1%$$%$&&&%$(%'%E%'%E&D%(%'&D&D'F%'&G%F$'%''$(%%'#%D(%%$&G$%$$'%'%%%%%'$'$'%D$&E'%$$'%$$&$'%&&'%&%$$'%&%(&$&&$F$&%&%&$$%&%$&%(%F$F$%'%%%(%$$&E'%%D(&&)%D&$'#&F$''&&'$&$$%$(&&&&&$&'$E$%&$%'%&$$%*%$$()$'%%%'''$'&'%($'$G%'&'&$$$*%EE&$$%$%%%&%$&$')'*'%'*(&(&'&%&($%%&%&&%%&(''''&$'%%&%'$F%$$(#F$&$F$($F$-'&%&(%E%#(%%%'$'$&$F&&%&%)%%'$'$'%E&%%'%'$(%'$'%'%'%'%'&'%'$%'&%('$'%&%'($&%'&)$$(%'&%%%%$$&%(%&($%%$&'&'''$%%E$$(%'%D$''$($%$&$$,-'(./%(-,+(.(-(-%%%-$'%&%$$()'$'$'&%%&%&&D&&%($&'%%)$'$(%E%$%%&%($$(%'%%'$'$''$)$$#)$'$$%$%%&&%&%$&&%&%%&%&&%)%&%$$&'$'$$'%''$(%E%%%%'%)'$%%$E&&$'%'&$%)(+E$$'($($%$&&&$'$&$'$&$'$&%&'&'$'$/&&%)%%&%%$&$'D$(%$&$'%%E$()&&$$'(D&%(D%&($(&+%'$($(&+%%$&&($&$$'$F%'%'%'$&'$%0+&&%$%&$&&&$'&&'&%'$&'&'&&)%+$)&,$'%'%($%%')'*'%'*(&(&'&%$%%%$F$F$F$&$&&'&&$'&&'(%&'&'&%'$&'&&)%+$)&,$'%'%($$'%''$(%%'D'#)%$$&$(%'%$$&$($E$(('&%(&($%,(&&&%&&&E&$'E&($)%($%%$&%$&&&&&D'&%%$($'%)+'+'/%+$+(0%&&&$&(&'&%&'%)$F&$%&%'$'%1*-#'$&D(%%$'&&D'%$$'%'%&$(%DD($''$%&$()%&&%&$'E$$'%E$)%,%.,(%&%%'$'&%+$()%&&%&%&$F$'%'%%'$$'E%$)#'$&'$$'$(%+&(&*&&'$'(&$'%&('K/D(J/D&('..($%$'$%&&&%%'%'&$$E$'$G'D$F$'$'$F%G(D&F(D$)#($(&%($%'$E$F$$$$%'$F#'%&%%$'$E$'%&$$$'%&$&$&$'%E&&%'$'%&$F%'$(%&$&$(C)&$$'%$D%$E$&$F$F$&E%#)$(%$$&$(%%$E$&$)$F$F$%%%0@0000H8H40H000047P00P@001000@0B0HP@:H9T8P000LB8d@800@I0<110000QQ8400P10030005940@410020000Q02000@0200000@P0101@8000440400000000808000000000@00000000P`0000000040400@0004<000000000008000030000000000P020T400020@0@00000000000000000000000000P0000000400400000400220080000100000000000000000P000000000000P000000@00402000000000@00000000000000000000040000000000000", "Æ&ÁĂÂА𝔄ÀΑĀ⩓Ą𝔸⁡Å𝒜≔ÃÄ∖⫧⌆Б∵ℬΒ𝔅𝔹˘ℬ≎Ч©Ć⋒ⅅℭČÇĈ∰Ċ¸·ℭΧ⊙⊖⊕⊗∲”’∷⩴≡∯∮ℂ∐∳⨯𝒞⋓≍ⅅ⤑ЂЅЏ‡↡⫤ĎД∇Δ𝔇´˙˝`˜⋄ⅆ𝔻¨⃜≐∯¨⇓⇐⇔⫤⟸⟺⟹⇒⊨⇑⇕∥↓⤓⇵̑⥐⥞↽⥖⥟⇁⥗⊤↧⇓𝒟ĐŊÐÉĚÊЭĖ𝔈È∈Ē◻▫Ę𝔼Ε⩵≂⇌ℰ⩳ΗË∃ⅇФ𝔉◼▪𝔽∀ℱℱЃ>ΓϜĞĢĜГĠ𝔊⋙𝔾≥⋛≧⪢≷⩾≳𝒢≫Ъˇ^Ĥℌℋℍ─ℋĦ≎≏ЕĲЁÍÎИİℑÌℑĪⅈ⇒∬∫⋂⁣⁢Į𝕀ΙℐĨІÏĴЙ𝔍𝕁𝒥ЈЄХЌΚĶК𝔎𝕂𝒦Љ<ĹΛ⟪ℒ↞ĽĻЛ⟨←⇤⇆⌈⟦⥡⇃⥙⌊↔⥎⊣↤⥚⊲⧏⊴⥑⥠↿⥘↼⥒⇐⇔⋚≦≶⪡⩽≲𝔏⋘⇚Ŀ⟵⟷⟶⟸⟺⟹𝕃↙↘ℒ↰Ł≪⤅М ℳ𝔐∓𝕄ℳΜЊŃŇŅН​​​​≫≪\n𝔑⁠\xA0ℕ⫬≢≭∦∉≠≂̸∄≯≱≧̸≫̸≹⩾̸≵≎̸≏̸⋪⧏̸⋬≮≰≸≪̸⩽̸≴⪢̸⪡̸⊀⪯̸⋠∌⋫⧐̸⋭⊏̸⋢⊐̸⋣⊂⃒⊈⊁⪰̸⋡≿̸⊃⃒⊉≁≄≇≉∤𝒩ÑΝŒÓÔОŐ𝔒ÒŌΩΟ𝕆“‘⩔𝒪ØÕ⨷Ö‾⏞⎴⏜∂П𝔓ΦΠ±ℌℙ⪻≺⪯≼≾″∏∷∝𝒫Ψ\"𝔔ℚ𝒬⤐®Ŕ⟫↠⤖ŘŖРℜ∋⇋⥯ℜΡ⟩→⇥⇄⌉⟧⥝⇂⥕⌋⊢↦⥛⊳⧐⊵⥏⥜↾⥔⇀⥓⇒ℝ⥰⇛ℛ↱⧴ЩШЬŚ⪼ŠŞŜС𝔖↓←→↑Σ∘𝕊√□⊓⊏⊑⊐⊒⊔𝒮⋆⋐⋐⊆≻⪰≽≿∋∑⋑⊃⊇⋑Þ™ЋЦ	ΤŤŢТ𝔗∴Θ   ∼≃≅≈𝕋⃛𝒯ŦÚ↟⥉ЎŬÛУŰ𝔘ÙŪ_⏟⎵⏝⋃⊎Ų𝕌↑⤒⇅↕⥮⊥↥⇑⇕↖↗ϒΥŮ𝒰ŨÜ⊫⫫В⊩⫦⋁‖‖∣|❘≀ 𝔙𝕍𝒱⊪Ŵ⋀𝔚𝕎𝒲𝔛Ξ𝕏𝒳ЯЇЮÝŶЫ𝔜𝕐𝒴ŸЖŹŽЗŻ​Ζℨℤ𝒵áă∾∾̳∿â´аæ⁡𝔞àℵℵαā⨿&∧⩕⩜⩘⩚∠⦤∠∡⦨⦩⦪⦫⦬⦭⦮⦯∟⊾⦝∢Å⍼ą𝕒≈⩰⩯≊≋'≈≊å𝒶*≈≍ãä∳⨑⫭≌϶‵∽⋍⊽⌅⌅⎵⎶≌б„∵∵⦰϶ℬβℶ≬𝔟⋂◯⋃⨀⨁⨂⨆★▽△⨄⋁⋀⤍⧫▪▴▾◂▸␣▒░▓█=⃥≡⃥⌐𝕓⊥⊥⋈╗╔╖╓═╦╩╤╧╝╚╜╙║╬╣╠╫╢╟⧉╕╒┐┌─╥╨┬┴⊟⊞⊠╛╘┘└│╪╡╞┼┤├‵˘¦𝒷⁏∽⋍\\⧅⟈••≎⪮≏≏ć∩⩄⩉⩋⩇⩀∩︀⁁ˇ⩍čçĉ⩌⩐ċ¸⦲¢·𝔠ч✓✓χ○⧃ˆ≗↺↻®Ⓢ⊛⊚⊝≗⨐⫯⧂♣♣:≔≔,@∁∘∁ℂ≅⩭∮𝕔∐©℗↵✗𝒸⫏⫑⫐⫒⋯⤸⤵⋞⋟↶⤽∪⩈⩆⩊⊍⩅∪︀↷⤼⋞⋟⋎⋏¤↶↷⋎⋏∲∱⌭⇓⥥†ℸ↓‐⊣⤏˝ďдⅆ‡⇊⩷°δ⦱⥿𝔡⇃⇂⋄⋄♦♦¨ϝ⋲÷÷⋇⋇ђ⌞⌍$𝕕˙≐≑∸∔⊡⌆↓⇊⇃⇂⤐⌟⌌𝒹ѕ⧶đ⋱▿▾⇵⥯⦦џ⟿⩷≑é⩮ě≖ê≕эėⅇ≒𝔢⪚è⪖⪘⪙⏧ℓ⪕⪗ē∅∅∅   ŋ ę𝕖⋕⧣⩱εεϵ≖≕≂⪖⪕=≟≡⩸⧥≓⥱ℯ≐≂ηðë€!∃ℰⅇ≒ф♀ﬃﬀﬄ𝔣ﬁfj♭ﬂ▱ƒ𝕗∀⋔⫙⨍½⅓¼⅕⅙⅛⅔⅖¾⅗⅜⅘⅚⅝⅞⁄⌢𝒻≧⪌ǵγϝ⪆ğĝгġ≥⋛≥≧⩾⩾⪩⪀⪂⪄⋛︀⪔𝔤≫⋙ℷѓ≷⪒⪥⪤≩⪊⪊⪈⪈≩⋧𝕘`ℊ≳⪎⪐>⪧⩺⋗⦕⩼⪆⥸⋗⋛⪌≷≳≩︀≩︀⇔ ½ℋъ↔⥈↭ℏĥ♥♥…⊹𝔥⤥⤦⇿∻↩↪𝕙―𝒽ℏħ⁃‐í⁣îие¡⇔𝔦ìⅈ⨌∭⧜℩ĳīℑℐℑı⊷Ƶ∈℅∞⧝ı∫⊺ℤ⊺⨗⨼ёį𝕚ι⨼¿𝒾∈⋹⋵⋴⋳∈⁢ĩіïĵй𝔧ȷ𝕛𝒿јєκϰķк𝔨ĸхќ𝕜𝓀⇚⇐⤛⤎≦⪋⥢ĺ⦴ℒλ⟨⦑⟨⪅«←⇤⤟⤝↩↫⤹⥳↢⪫⤙⪭⪭︀⤌❲{[⦋⦏⦍ľļ⌈{л⤶“„⥧⥋↲≤←↢↽↼⇇↔⇆⇋↭⋋⋚≤≦⩽⩽⪨⩿⪁⪃⋚︀⪓⪅⋖⋚⪋≶≲⥼⌊𝔩≶⪑↽↼⥪▄љ≪⇇⌞⥫◺ŀ⎰⎰≨⪉⪉⪇⪇≨⋦⟬⇽⟦⟵⟷⟼⟶↫↬⦅𝕝⨭⨴∗_◊◊⧫(⦓⇆⌟⇋⥭‎⊿‹𝓁↰≲⪍⪏[‘‚ł<⪦⩹⋖⋋⋉⥶⩻⦖◃⊴◂⥊⥦≨︀≨︀∺¯♂✠✠↦↦↧↤↥▮⨩м—∡𝔪℧µ∣*⫰·−⊟∸⨪⫛…∓⊧𝕞∓𝓂∾μ⊸⊸⋙̸≫⃒≫̸⇍⇎⋘̸≪⃒≪̸⇏⊯⊮∇ń∠⃒≉⩰̸≋̸ŉ≉♮♮ℕ\xA0≎̸≏̸⩃ňņ≇⩭̸⩂н–≠⇗⤤↗↗≐̸≢⤨≂̸∄∄𝔫≧̸≱≱≧̸⩾̸⩾̸≵≯≯⇎↮⫲∋⋼⋺∋њ⇍≦̸↚‥≰↚↮≰≦̸⩽̸⩽̸≮≴≮⋪⋬∤𝕟¬∉⋹̸⋵̸∉⋷⋶∌∌⋾⋽∦∦⫽⃥∂̸⨔⊀⋠⪯̸⊀⪯̸⇏↛⤳̸↝̸↛⋫⋭⊁⋡⪰̸𝓃∤∦≁≄≄∤∦⋢⋣⊄⫅̸⊈⊂⃒⊈⫅̸⊁⪰̸⊅⫆̸⊉⊃⃒⊉⫆̸≹ñ≸⋪⋬⋫⋭ν#№ ⊭⤄≍⃒⊬≥⃒>⃒⧞⤂≤⃒<⃒⊴⃒⤃⊵⃒∼⃒⇖⤣↖↖⤧Ⓢó⊛⊚ôо⊝ő⨸⊙⦼œ⦿𝔬˛ò⧁⦵Ω∮↺⦾⦻‾⧀ōωο⦶⊖𝕠⦷⦹⊕∨↻⩝ℴℴªº⊶⩖⩗⩛ℴø⊘õ⊗⨶ö⌽∥¶∥⫳⫽∂п%.‰⊥‱𝔭φϕℳ☎π⋔ϖℏℎℏ+⨣⊞⨢∔⨥⩲±⨦⨧±⨕𝕡£≺⪳⪷≼⪯≺⪷≼⪯⪹⪵⋨≾′ℙ⪵⪹⋨∏⌮⌒⌓∝∝≾⊰𝓅ψ 𝔮⨌𝕢⁗𝓆ℍ⨖?≟\"⇛⇒⤜⤏⥤∽̱ŕ√⦳⟩⦒⦥⟩»→⥵⇥⤠⤳⤞↪↬⥅⥴↣↝⤚∶ℚ⤍❳}]⦌⦎⦐řŗ⌉}р⤷⥩””↳ℜℛℜℝ▭®⥽⌋𝔯⇁⇀⥬ρϱ→↣⇁⇀⇄⇌⇉↝⋌˚≓⇄⇌‏⎱⎱⫮⟭⇾⟧⦆𝕣⨮⨵)⦔⨒⇉›𝓇↱]’’⋌⋊▹⊵▸⧎⥨℞ś‚≻⪴⪸š≽⪰şŝ⪶⪺⋩⨓≿с⋅⊡⩦⇘⤥↘↘§;⤩∖∖✶𝔰⌢♯щш∣∥­σςς∼⩪≃≃⪞⪠⪝⪟≆⨤⥲←∖⨳⧤∣⌣⪪⪬⪬︀ь/⧄⌿𝕤♠♠∥⊓⊓︀⊔⊔︀⊏⊑⊏⊑⊐⊒⊐⊒□□▪▪→𝓈∖⌣⋆☆★ϵϕ¯⊂⫅⪽⊆⫃⫁⫋⊊⪿⥹⊂⊆⫅⊊⫋⫇⫕⫓≻⪸≽⪰⪺⪶⋩≿∑♪⊃¹²³⫆⪾⫘⊇⫄⟉⫗⥻⫂⫌⊋⫀⊃⊇⫆⊋⫌⫈⫔⫖⇙⤦↙↙⤪ß⌖τ⎴ťţт⃛⌕𝔱∴∴θϑϑ≈∼ ≈∼þ˜×⊠⨱⨰∭⤨⊤⌶⫱𝕥⫚⤩‴™▵▿◃⊴≜▹⊵◬≜⨺⨹⧍⨻⏢𝓉цћŧ≬↞↠⇑⥣ú↑ўŭûу⇅ű⥮⥾𝔲ù↿↾▀⌜⌜⌏◸ū¨ų𝕦↑↕↿↾⊎υϒυ⇈⌝⌝⌎ů◹𝓊⋰ũ▵▴⇈ü⦧⇕⫨⫩⊨⦜ϵϰ∅ϕϖ∝↕ϱς⊊︀⫋︀⊋︀⫌︀ϑ⊲⊳в⊢∨⊻≚⋮||𝔳⊲⊂⃒⊃⃒𝕧∝⊳𝓋⫋︀⊊︀⫌︀⊋︀⦚ŵ⩟∧≙℘𝔴𝕨℘≀≀𝓌⋂◯⋃▽𝔵⟺⟷ξ⟸⟵⟼⋻⨀𝕩⨁⨂⟹⟶𝓍⨆⨄△⋁⋀ýяŷы¥𝔶ї𝕪𝓎юÿźžзżℨζ𝔷ж⇝𝕫𝓏‍‌"], qf = 2654435761, Jf = 2246822507, Yf = 1024, Xf = (() => {
	let e = new Uint8Array(128);
	for (let t = 48; t <= 57; t++) e[t] = t - 47;
	for (let t = 65; t <= 90; t++) e[t] = t - 54;
	for (let t = 97; t <= 122; t++) e[t] = t - 60;
	return e;
})();
function Zf(e, t, n) {
	return e.charCodeAt(t) << 25 | e.charCodeAt(t + 1) << 18 | e.charCodeAt(t + n - 2) << 11 | Xf[e.charCodeAt(t + n - 1)] << 5 | n;
}
function Qf(e, t) {
	return (e * 3 << 3 ^ t) & Yf - 1;
}
function $f(e, t) {
	return (Math.imul(e, qf) >>> 16) * t >>> 16;
}
function ep(e, t) {
	return (Math.imul(e, Jf) >>> 16) * t >>> 16;
}
function tp(e) {
	let [t, n] = e, r = t.charCodeAt(0) - 48 << 6 | t.charCodeAt(1) - 48, i = t.charCodeAt(2) - 48 << 6 | t.charCodeAt(3) - 48, a = t.charCodeAt(4) - 48 << 6 | t.charCodeAt(5) - 48, o = 6 + i, s = o + 2 * r, c = 2 * a, l = new Int32Array(c), u = new Uint16Array(c), d = new Uint16Array(c), f = new Uint32Array(Yf), p = /* @__PURE__ */ new Map(), m = [], h = "", g = 6, _ = 0;
	for (let e = 0; e < r; e++) {
		let n = t.charCodeAt(o + 2 * e) - 35, r = t.charCodeAt(o + 2 * e + 1) - 35, i = n & 31, c = i + (r & 31), v = (r >> 5) + 1;
		h = h.slice(0, i) + t.slice(g, g + c - i), g += c - i;
		let y = Zf(h, 0, c), b = 2 * (t.charCodeAt(s + Math.floor(e / 6)) - 48 & 1 << e % 6 ? ep : $f)(y, a);
		if (l[b] !== 0 && (b += 1), l[b] = y, c > 4) {
			let e = h.slice(2, c - 2), t = p.get(e);
			if (t === void 0) {
				p.set(e, m.length), u[b] = m.length;
				for (let t = 0; t < e.length; t += 2) m.push(e.charCodeAt(t) | e.charCodeAt(t + 1) << 16);
			} else u[b] = t;
		}
		let x = Qf(h.charCodeAt(0), h.charCodeAt(1));
		f[x] |= c <= 16 ? 1 << c - 2 : 32768, n & 32 && (f[x] |= 1 << c - 2 + 16), d[b] = _ << 2 | v - 1 | (n & 32) >> 4, _ += v;
	}
	return {
		keys: l,
		buckets: a,
		slotMidOff: u,
		slotValue: d,
		values: n,
		lengthBits: f,
		middles: new Uint32Array(m)
	};
}
//#endregion
//#region ../../node_modules/.bun/entities@9.0.0/node_modules/entities/dist/decode.js
var np = 35, rp = 59, ip = 61, ap = 48, op = 97, sp = 120, cp = 65, lp = 32;
function up(e) {
	return e - ap >>> 0 <= 9;
}
function dp(e) {
	return up(e) || (e | lp) - op >>> 0 <= 25;
}
function fp(e) {
	return e === ip || dp(e);
}
var pp;
(function(e) {
	e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(pp ||= {});
var mp = /* @__PURE__ */ tp(Kf), hp = mp.keys, gp = mp.buckets, _p = mp.slotMidOff, vp = mp.lengthBits, yp = mp.middles, bp = mp.slotValue, xp = mp.values;
function Sp(e, t, n) {
	let r = e.charCodeAt(t), i = e.charCodeAt(t + 1), a = e.charCodeAt(t + n - 2), o = e.charCodeAt(t + n - 1);
	if ((r | i | a | o) > 127) return -1;
	let s = r << 25 | i << 18 | a << 11 | Xf[o] << 5 | n, c = 2 * ((Math.imul(s, qf) >>> 16) * gp >>> 16);
	for (let r = 0;; r++) {
		if (hp[c] === s && (n <= 4 || Cp(c, e, t, n))) return c;
		if (hp[c + 1] === s && (n <= 4 || Cp(c + 1, e, t, n))) return c + 1;
		if (r === 1) return -1;
		c = 2 * ((Math.imul(s, Jf) >>> 16) * gp >>> 16);
	}
}
function Cp(e, t, n, r) {
	let i = _p[e], a = n + 2, o = n + r - 2;
	for (; a + 1 < o;) {
		if ((t.charCodeAt(a) | t.charCodeAt(a + 1) << 16) !== yp[i++]) return !1;
		a += 2;
	}
	return a === o || t.charCodeAt(a) === (yp[i] & 65535);
}
var wp = /* @__PURE__ */ (() => {
	let e = new Uint8Array(128).fill(255);
	for (let t = 0; t < 10; t++) e[ap + t] = t;
	for (let t = 0; t < 6; t++) e[cp + t] = t + 10, e[op + t] = t + 10;
	return e;
})();
function Tp(e, t, n) {
	let r = vp[Qf(e.charCodeAt(t), e.charCodeAt(t + 1))] >>> 16 & 31;
	for (; r !== 0;) {
		let i = 31 - Math.clz32(r);
		if (r ^= 1 << i, i + 2 > n) continue;
		let a = Sp(e, t, i + 2);
		if (a >= 0 && bp[a] & 2) return a << 3 | i + 2;
	}
	return -1;
}
function Ep(e, t, n) {
	let r = e.slice(t, t + 32).indexOf(";");
	if (r - 2 >>> 0 <= 29) {
		let n = Sp(e, t, r);
		if (n >= 0) return n << 6 | r + 1;
	}
	if (n !== pp.Strict) {
		let r = Tp(e, t, Math.min(31, e.length - t));
		if (r >= 0) {
			let i = r & 7;
			if (n !== pp.Attribute || t + i >= e.length || !fp(e.charCodeAt(t + i))) return r >> 3 << 6 | i;
		}
	}
	return -1;
}
var Dp = 0, Op = 1, kp = 2, Ap = 3, jp = 4, Mp = class {
	emitCodePoint;
	errors;
	state = Dp;
	consumed = 1;
	result = 0;
	decodeMode = pp.Strict;
	replaceNumericCodePoint = Gf;
	constructor(e, t) {
		this.emitCodePoint = e, this.errors = t;
	}
	stateNumericStart(e, t) {
		return t >= e.length ? -1 : (e.charCodeAt(t) | lp) === sp ? (this.state = Ap, this.consumed += 1, this.stateNumericHex(e, t + 1)) : (this.state = kp, this.stateNumericDecimal(e, t));
	}
	stateNumericHex(e, t) {
		let n = e.length, { result: r, consumed: i } = this, a = t;
		for (; a < n;) {
			let t = e.charCodeAt(a), n = wp[t];
			if (n <= 15) r = r * 16 + n;
			else return this.result = r, this.consumed = i, this.emitNumericEntity(t, 3);
			i += 1, a += 1;
		}
		return this.result = r, this.consumed = i, -1;
	}
	stateNumericDecimal(e, t) {
		let n = e.length, { result: r, consumed: i } = this, a = t;
		for (; a < n;) {
			let t = e.charCodeAt(a) - ap;
			if (t >>> 0 > 9) return this.result = r, this.consumed = i, this.emitNumericEntity(t + ap, 2);
			r = r * 10 + t, i += 1, a += 1;
		}
		return this.result = r, this.consumed = i, -1;
	}
	emitNumericEntity(e, t) {
		if (this.consumed <= t) return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
		if (e === rp) this.consumed += 1;
		else if (this.decodeMode === pp.Strict) return 0;
		return this.emitCodePoint(this.replaceNumericCodePoint(this.result), this.consumed), this.errors && (e !== rp && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
	}
	startEntity(e) {
		this.decodeMode = e, this.state = Dp, this.result = 0, this.consumed = 1;
	}
	write(e, t) {
		switch (this.state) {
			case Dp: return e.charCodeAt(t) === np ? (this.state = Op, this.consumed += 1, this.stateNumericStart(e, t + 1)) : (this.state = jp, this.stateNamedEntity(e, t));
			case Op: return this.stateNumericStart(e, t);
			case kp: return this.stateNumericDecimal(e, t);
			case Ap: return this.stateNumericHex(e, t);
			default: return this.stateNamedEntity(e, t);
		}
	}
	end() {
		switch (this.state) {
			case jp: return this.endNamedEntity();
			case kp: return this.emitNumericEntity(0, 2);
			case Ap: return this.emitNumericEntity(0, 3);
			case Op: return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
			default: return 0;
		}
	}
}, Np = class extends Mp {
	runLength = 0;
	nameBuffer = new Uint8Array(32);
	emitSlot(e) {
		let t = bp[e], n = t >> 2;
		this.emitCodePoint(xp.charCodeAt(n), this.consumed), t & 1 && this.emitCodePoint(xp.charCodeAt(n + 1), this.consumed);
	}
	startEntity(e) {
		super.startEntity(e), this.runLength = 0;
	}
	stateNamedEntity(e, t) {
		let n = e.length;
		if (this.runLength === 0 && t + 17 <= n) {
			let r = vp[Qf(e.charCodeAt(t), e.charCodeAt(t + 1))];
			if (r & 32768 && t + 32 <= n) {
				let n = Ep(e, t, this.decodeMode);
				if (n >= 0) {
					let r = n & 63;
					return this.consumed = r + 1, this.emitSlot(n >> 6), e.charCodeAt(t + r - 1) !== rp && this.errors?.missingSemicolonAfterCharacterReference(), this.consumed;
				}
				return 0;
			}
			let i = r & 32767;
			for (; i !== 0;) {
				let n = i & -i;
				i ^= n;
				let r = 33 - Math.clz32(n);
				if (e.charCodeAt(t + r) === rp) {
					let n = Sp(e, t, r);
					if (n >= 0) return this.consumed = r + 2, this.emitSlot(n), this.consumed;
				}
			}
			if (!(r & 32768)) {
				if (this.decodeMode !== pp.Strict) {
					let n = Tp(e, t, 31);
					if (n >= 0) {
						let r = n & 7, i = e.charCodeAt(t + r);
						return this.decodeMode === pp.Attribute && fp(i) ? 0 : (this.consumed = r + 1, this.emitSlot(n >> 3), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed);
					}
				}
				return 0;
			}
		}
		let r = t, { runLength: i } = this, a = -1, o = Math.min(n, t + 32 - i);
		for (; r < o;) {
			let t = e.charCodeAt(r);
			if (!dp(t)) {
				a = t;
				break;
			}
			this.nameBuffer[i++] = t, r++;
		}
		if (a < 0 && i < 32) return this.runLength = i, -1;
		if (a === rp && i - 2 >>> 0 <= 29) {
			let e = Pp(this.nameBuffer, i);
			if (e >= 0) return this.consumed = i + 2, this.emitSlot(e), this.consumed;
		}
		if (this.decodeMode !== pp.Strict && i >= 2) {
			let e = Ip(this.nameBuffer, i);
			if (e >= 0) {
				let t = e & 7, n = t < i ? this.nameBuffer[t] : a;
				return this.decodeMode === pp.Attribute && fp(n) ? 0 : (this.consumed = t + 1, this.emitSlot(e >> 3), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed);
			}
		}
		return 0;
	}
	endNamedEntity() {
		if (this.decodeMode === pp.Strict || this.runLength < 2) return 0;
		let e = Ip(this.nameBuffer, this.runLength);
		return e < 0 || this.decodeMode === pp.Attribute && (e & 7) < this.runLength ? 0 : (this.consumed = (e & 7) + 1, this.emitSlot(e >> 3), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed);
	}
};
function Pp(e, t) {
	let n = e[0] << 25 | e[1] << 18 | e[t - 2] << 11 | Xf[e[t - 1]] << 5 | t, r = 2 * ((Math.imul(n, qf) >>> 16) * gp >>> 16);
	for (let i = 0;; i++) {
		if (hp[r] === n && (t <= 4 || Fp(r, e, t))) return r;
		if (hp[r + 1] === n && (t <= 4 || Fp(r + 1, e, t))) return r + 1;
		if (i === 1) return -1;
		r = 2 * ((Math.imul(n, Jf) >>> 16) * gp >>> 16);
	}
}
function Fp(e, t, n) {
	let r = _p[e], i = 2, a = n - 2;
	for (; i + 1 < a;) {
		if ((t[i] | t[i + 1] << 16) !== yp[r++]) return !1;
		i += 2;
	}
	return i === a || t[i] === (yp[r] & 65535);
}
function Ip(e, t) {
	let n = vp[Qf(e[0], e[1])] >>> 16 & 31;
	for (; n !== 0;) {
		let r = 31 - Math.clz32(n);
		if (n ^= 1 << r, r + 2 > t) continue;
		let i = Pp(e, r + 2);
		if (i >= 0 && bp[i] & 2) return i << 3 | r + 2;
	}
	return -1;
}
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/common/html.js
var q;
(function(e) {
	e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(q ||= {});
var Lp;
(function(e) {
	e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(Lp ||= {});
var Rp;
(function(e) {
	e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(Rp ||= {});
var J;
(function(e) {
	e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(J ||= {});
var Y;
(function(e) {
	e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(Y ||= {});
var zp = new Map([
	[J.A, Y.A],
	[J.ADDRESS, Y.ADDRESS],
	[J.ANNOTATION_XML, Y.ANNOTATION_XML],
	[J.APPLET, Y.APPLET],
	[J.AREA, Y.AREA],
	[J.ARTICLE, Y.ARTICLE],
	[J.ASIDE, Y.ASIDE],
	[J.B, Y.B],
	[J.BASE, Y.BASE],
	[J.BASEFONT, Y.BASEFONT],
	[J.BGSOUND, Y.BGSOUND],
	[J.BIG, Y.BIG],
	[J.BLOCKQUOTE, Y.BLOCKQUOTE],
	[J.BODY, Y.BODY],
	[J.BR, Y.BR],
	[J.BUTTON, Y.BUTTON],
	[J.CAPTION, Y.CAPTION],
	[J.CENTER, Y.CENTER],
	[J.CODE, Y.CODE],
	[J.COL, Y.COL],
	[J.COLGROUP, Y.COLGROUP],
	[J.DD, Y.DD],
	[J.DESC, Y.DESC],
	[J.DETAILS, Y.DETAILS],
	[J.DIALOG, Y.DIALOG],
	[J.DIR, Y.DIR],
	[J.DIV, Y.DIV],
	[J.DL, Y.DL],
	[J.DT, Y.DT],
	[J.EM, Y.EM],
	[J.EMBED, Y.EMBED],
	[J.FIELDSET, Y.FIELDSET],
	[J.FIGCAPTION, Y.FIGCAPTION],
	[J.FIGURE, Y.FIGURE],
	[J.FONT, Y.FONT],
	[J.FOOTER, Y.FOOTER],
	[J.FOREIGN_OBJECT, Y.FOREIGN_OBJECT],
	[J.FORM, Y.FORM],
	[J.FRAME, Y.FRAME],
	[J.FRAMESET, Y.FRAMESET],
	[J.H1, Y.H1],
	[J.H2, Y.H2],
	[J.H3, Y.H3],
	[J.H4, Y.H4],
	[J.H5, Y.H5],
	[J.H6, Y.H6],
	[J.HEAD, Y.HEAD],
	[J.HEADER, Y.HEADER],
	[J.HGROUP, Y.HGROUP],
	[J.HR, Y.HR],
	[J.HTML, Y.HTML],
	[J.I, Y.I],
	[J.IMG, Y.IMG],
	[J.IMAGE, Y.IMAGE],
	[J.INPUT, Y.INPUT],
	[J.IFRAME, Y.IFRAME],
	[J.KEYGEN, Y.KEYGEN],
	[J.LABEL, Y.LABEL],
	[J.LI, Y.LI],
	[J.LINK, Y.LINK],
	[J.LISTING, Y.LISTING],
	[J.MAIN, Y.MAIN],
	[J.MALIGNMARK, Y.MALIGNMARK],
	[J.MARQUEE, Y.MARQUEE],
	[J.MATH, Y.MATH],
	[J.MENU, Y.MENU],
	[J.META, Y.META],
	[J.MGLYPH, Y.MGLYPH],
	[J.MI, Y.MI],
	[J.MO, Y.MO],
	[J.MN, Y.MN],
	[J.MS, Y.MS],
	[J.MTEXT, Y.MTEXT],
	[J.NAV, Y.NAV],
	[J.NOBR, Y.NOBR],
	[J.NOFRAMES, Y.NOFRAMES],
	[J.NOEMBED, Y.NOEMBED],
	[J.NOSCRIPT, Y.NOSCRIPT],
	[J.OBJECT, Y.OBJECT],
	[J.OL, Y.OL],
	[J.OPTGROUP, Y.OPTGROUP],
	[J.OPTION, Y.OPTION],
	[J.P, Y.P],
	[J.PARAM, Y.PARAM],
	[J.PLAINTEXT, Y.PLAINTEXT],
	[J.PRE, Y.PRE],
	[J.RB, Y.RB],
	[J.RP, Y.RP],
	[J.RT, Y.RT],
	[J.RTC, Y.RTC],
	[J.RUBY, Y.RUBY],
	[J.S, Y.S],
	[J.SCRIPT, Y.SCRIPT],
	[J.SEARCH, Y.SEARCH],
	[J.SECTION, Y.SECTION],
	[J.SELECT, Y.SELECT],
	[J.SOURCE, Y.SOURCE],
	[J.SMALL, Y.SMALL],
	[J.SPAN, Y.SPAN],
	[J.STRIKE, Y.STRIKE],
	[J.STRONG, Y.STRONG],
	[J.STYLE, Y.STYLE],
	[J.SUB, Y.SUB],
	[J.SUMMARY, Y.SUMMARY],
	[J.SUP, Y.SUP],
	[J.TABLE, Y.TABLE],
	[J.TBODY, Y.TBODY],
	[J.TEMPLATE, Y.TEMPLATE],
	[J.TEXTAREA, Y.TEXTAREA],
	[J.TFOOT, Y.TFOOT],
	[J.TD, Y.TD],
	[J.TH, Y.TH],
	[J.THEAD, Y.THEAD],
	[J.TITLE, Y.TITLE],
	[J.TR, Y.TR],
	[J.TRACK, Y.TRACK],
	[J.TT, Y.TT],
	[J.U, Y.U],
	[J.UL, Y.UL],
	[J.SVG, Y.SVG],
	[J.VAR, Y.VAR],
	[J.WBR, Y.WBR],
	[J.XMP, Y.XMP]
]);
function Bp(e) {
	return zp.get(e) ?? Y.UNKNOWN;
}
var X = Y, Vp = {
	[q.HTML]: new Set([
		X.ADDRESS,
		X.APPLET,
		X.AREA,
		X.ARTICLE,
		X.ASIDE,
		X.BASE,
		X.BASEFONT,
		X.BGSOUND,
		X.BLOCKQUOTE,
		X.BODY,
		X.BR,
		X.BUTTON,
		X.CAPTION,
		X.CENTER,
		X.COL,
		X.COLGROUP,
		X.DD,
		X.DETAILS,
		X.DIR,
		X.DIV,
		X.DL,
		X.DT,
		X.EMBED,
		X.FIELDSET,
		X.FIGCAPTION,
		X.FIGURE,
		X.FOOTER,
		X.FORM,
		X.FRAME,
		X.FRAMESET,
		X.H1,
		X.H2,
		X.H3,
		X.H4,
		X.H5,
		X.H6,
		X.HEAD,
		X.HEADER,
		X.HGROUP,
		X.HR,
		X.HTML,
		X.IFRAME,
		X.IMG,
		X.INPUT,
		X.LI,
		X.LINK,
		X.LISTING,
		X.MAIN,
		X.MARQUEE,
		X.MENU,
		X.META,
		X.NAV,
		X.NOEMBED,
		X.NOFRAMES,
		X.NOSCRIPT,
		X.OBJECT,
		X.OL,
		X.P,
		X.PARAM,
		X.PLAINTEXT,
		X.PRE,
		X.SCRIPT,
		X.SECTION,
		X.SELECT,
		X.SOURCE,
		X.STYLE,
		X.SUMMARY,
		X.TABLE,
		X.TBODY,
		X.TD,
		X.TEMPLATE,
		X.TEXTAREA,
		X.TFOOT,
		X.TH,
		X.THEAD,
		X.TITLE,
		X.TR,
		X.TRACK,
		X.UL,
		X.WBR,
		X.XMP
	]),
	[q.MATHML]: new Set([
		X.MI,
		X.MO,
		X.MN,
		X.MS,
		X.MTEXT,
		X.ANNOTATION_XML
	]),
	[q.SVG]: new Set([
		X.TITLE,
		X.FOREIGN_OBJECT,
		X.DESC
	]),
	[q.XLINK]: /* @__PURE__ */ new Set(),
	[q.XML]: /* @__PURE__ */ new Set(),
	[q.XMLNS]: /* @__PURE__ */ new Set()
}, Hp = new Set([
	X.H1,
	X.H2,
	X.H3,
	X.H4,
	X.H5,
	X.H6
]);
new Set([
	J.STYLE,
	J.SCRIPT,
	J.XMP,
	J.IFRAME,
	J.NOEMBED,
	J.NOFRAMES,
	J.PLAINTEXT
]);
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/tokenizer/index.js
var Up = 64, Z;
(function(e) {
	e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(Z ||= {});
var Q = {
	DATA: Z.DATA,
	RCDATA: Z.RCDATA,
	RAWTEXT: Z.RAWTEXT,
	SCRIPT_DATA: Z.SCRIPT_DATA,
	PLAINTEXT: Z.PLAINTEXT,
	CDATA_SECTION: Z.CDATA_SECTION
};
function Wp(e) {
	return e >= W.DIGIT_0 && e <= W.DIGIT_9;
}
function Gp(e) {
	return e >= W.LATIN_CAPITAL_A && e <= W.LATIN_CAPITAL_Z;
}
function Kp(e) {
	return e >= W.LATIN_SMALL_A && e <= W.LATIN_SMALL_Z;
}
function qp(e) {
	return Kp(e) || Gp(e);
}
function Jp(e) {
	return qp(e) || Wp(e);
}
function Yp(e) {
	return e + 32;
}
function Xp(e) {
	return e === W.SPACE || e === W.LINE_FEED || e === W.TABULATION || e === W.FORM_FEED || e === W.CARRIAGE_RETURN;
}
function Zp(e) {
	return Xp(e) || e === W.SOLIDUS || e === W.GREATER_THAN_SIGN;
}
function Qp(e) {
	return e === W.NULL ? G.nullCharacterReference : e > 1114111 ? G.characterReferenceOutsideUnicodeRange : Ff(e) ? G.surrogateCharacterReference : zf(e) ? G.noncharacterCharacterReference : Rf(e) || e === W.CARRIAGE_RETURN ? G.controlCharacterReference : null;
}
var $p = class {
	constructor(e, t) {
		this.options = e, this.handler = t, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = Z.DATA, this.returnState = Z.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = {
			name: "",
			value: ""
		}, this.currentAttrLocation = null, this.currentAttrNames = null, this.runStart = 0, this.runEnd = 0, this.preprocessor = new Vf(t), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new Np((e, t) => {
			this.preprocessor.pos = this.entityStartPos + t - 1, this._isCharacterReferenceInAttribute() || this._ensureCharacterToken(Xp(e) ? K.WHITESPACE_CHARACTER : e === W.NULL ? K.NULL_CHARACTER : K.CHARACTER), this._extendRunWith(String.fromCodePoint(e), 0), this.entityStartPos = this.preprocessor.pos - t + 1;
		}, t.onParseError ? {
			missingSemicolonAfterCharacterReference: () => {
				this._err(G.missingSemicolonAfterCharacterReference, 1);
			},
			absenceOfDigitsInNumericCharacterReference: (e) => {
				this._err(G.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + e);
			},
			validateNumericCharacterReference: (e) => {
				let t = Qp(e);
				t && this._err(t, 1);
			}
		} : void 0);
	}
	_err(e, t = 0) {
		var n, r;
		(r = (n = this.handler).onParseError) == null || r.call(n, this.preprocessor.getError(e, t));
	}
	getCurrentLocation(e) {
		return this.options.sourceCodeLocationInfo ? {
			startLine: this.preprocessor.line,
			startCol: this.preprocessor.col - e,
			startOffset: this.preprocessor.offset - e,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		} : null;
	}
	_runParsingLoop() {
		if (!this.inLoop) {
			for (this.inLoop = !0; this.active && !this.paused;) {
				this.consumedAfterSnapshot = 0;
				let e = this._consume();
				this._ensureHibernation() || this._callState(e);
			}
			this.inLoop = !1;
		}
	}
	flushCharacters() {
		if (this.inLoop) throw Error("Cannot flush characters from a tokenizer callback");
		let e = this.currentCharacterToken?.location, t = null;
		e && (t = this.getCharacterTokenEndLocation(e), this.currentLocation = t), this.inLoop = !0;
		try {
			this._emitCurrentCharacterToken(t);
		} finally {
			this.inLoop = !1;
		}
		this._runParsingLoop();
	}
	getCharacterTokenEndLocation(e) {
		let t = this.getCharacterTokenEndOffset(), n = this.preprocessor.html.slice(e.startOffset - this.preprocessor.droppedBufferSize, t - this.preprocessor.droppedBufferSize), r = e.startLine, i = -1;
		for (let e = n.indexOf("\n"); e !== -1; e = n.indexOf("\n", e + 1)) r++, i = e;
		for (let e = n.indexOf("\r"); e !== -1; e = n.indexOf("\r", e + 1)) n.charCodeAt(e + 1) !== W.LINE_FEED && (r++, i = Math.max(i, e));
		return {
			startLine: r,
			startCol: i === -1 ? e.startCol + n.length : n.length - i,
			startOffset: t,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		};
	}
	getCharacterTokenEndOffset() {
		let e = this.preprocessor.droppedBufferSize + this.preprocessor.pos + 1, t = this.currentToken?.location;
		switch (this.state) {
			case Z.TAG_OPEN:
			case Z.RCDATA_LESS_THAN_SIGN:
			case Z.RAWTEXT_LESS_THAN_SIGN:
			case Z.SCRIPT_DATA_LESS_THAN_SIGN:
			case Z.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
			case Z.CDATA_SECTION_BRACKET: return e - 1;
			case Z.END_TAG_OPEN:
			case Z.MARKUP_DECLARATION_OPEN:
			case Z.RCDATA_END_TAG_OPEN:
			case Z.RCDATA_END_TAG_NAME:
			case Z.RAWTEXT_END_TAG_OPEN:
			case Z.RAWTEXT_END_TAG_NAME:
			case Z.SCRIPT_DATA_END_TAG_OPEN:
			case Z.SCRIPT_DATA_END_TAG_NAME:
			case Z.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
			case Z.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
			case Z.CDATA_SECTION_END: return e - 2;
			case Z.CHARACTER_REFERENCE: return this._isCharacterReferenceInAttribute() && t ? t.startOffset : this.preprocessor.droppedBufferSize + this.entityStartPos;
			case Z.DOCTYPE:
			case Z.BEFORE_DOCTYPE_NAME: return this.currentLocation.startOffset;
			default: return t && (this.state === Z.TAG_NAME || this.state >= Z.BEFORE_ATTRIBUTE_NAME && this.state <= Z.BOGUS_COMMENT || this.state >= Z.COMMENT_START && this.state <= Z.BOGUS_DOCTYPE) ? t.startOffset : e;
		}
	}
	pause() {
		this.paused = !0;
	}
	resume(e) {
		if (!this.paused) throw Error("Parser was already resumed");
		this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || e?.());
	}
	write(e, t, n) {
		this.active = !0, this.preprocessor.write(e, t), this._runParsingLoop(), this.paused || n?.();
	}
	insertHtmlAtCurrentPos(e) {
		this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(e), this._runParsingLoop();
	}
	flushCurrentCharacterToken() {
		if (this.paused || this.active || !this.currentCharacterToken || this.currentToken || this.state === Z.DOCTYPE || this.state === Z.BEFORE_DOCTYPE_NAME || !this.preprocessor.willDropParsedChunk()) return;
		let e = this.preprocessor.droppedBufferSize + this.preprocessor.pos + 1 - this.getCharacterTokenEndOffset();
		this.preprocessor.advance(), this.currentLocation = this.getCurrentLocation(e), this.preprocessor.retreat(1), this._emitCurrentCharacterToken(this.currentLocation), this._createCharacterToken(K.CHARACTER), this.preprocessor.dropParsedChunk(Math.max(e - 1, 0)), this.entityStartPos = this.preprocessor.pos + 1 - e;
	}
	_ensureHibernation() {
		return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
	}
	_consume() {
		return this.consumedAfterSnapshot++, this.preprocessor.advance();
	}
	_advanceBy(e) {
		this.consumedAfterSnapshot += e;
		for (let t = 0; t < e; t++) this.preprocessor.advance();
	}
	_consumeSequenceIfMatch(e, t) {
		return this.preprocessor.startsWith(e, t) ? (this._advanceBy(e.length - 1), !0) : !1;
	}
	_createStartTagToken() {
		this._flushRun(""), this.currentToken = {
			type: K.START_TAG,
			tagName: "",
			tagID: Y.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(1)
		};
	}
	_createEndTagToken() {
		this._flushRun(""), this.currentToken = {
			type: K.END_TAG,
			tagName: "",
			tagID: Y.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(2)
		};
	}
	_createCommentToken(e) {
		this._flushRun(""), this.currentToken = {
			type: K.COMMENT,
			data: "",
			location: this.getCurrentLocation(e)
		};
	}
	_createDoctypeToken(e) {
		this._flushRun(""), this.currentToken = {
			type: K.DOCTYPE,
			name: e,
			forceQuirks: !1,
			publicId: null,
			systemId: null,
			location: this.currentLocation
		};
	}
	_createCharacterToken(e) {
		if (this.currentLocation) {
			let e = this.currentLocation.startOffset - this.preprocessor.droppedBufferSize;
			this.preprocessor.html[e] === "\n" && this.preprocessor.html[e - 1] === "\r" && this.currentLocation.startOffset++;
		}
		this.currentCharacterToken = {
			type: e,
			chars: "",
			location: this.currentLocation
		};
	}
	_createAttr(e) {
		this._flushRun(""), this.currentAttr = {
			name: e,
			value: ""
		}, this.currentAttrLocation = this.getCurrentLocation(0);
	}
	_leaveAttrName() {
		var e;
		let t = this.currentToken, { name: n } = this.currentAttr, r = this.currentAttrNames, i;
		if (r === null ? (i = Hf(t, n) !== null, !i && t.attrs.length === Up && (this.currentAttrNames = new Set(t.attrs.map((e) => e.name)).add(n))) : (i = r.has(n), i || r.add(n)), i) this._err(G.duplicateAttribute);
		else if (t.attrs.push(this.currentAttr), t.location && this.currentAttrLocation) {
			let n = (e = t.location).attrs ?? (e.attrs = Object.create(null));
			n[this.currentAttr.name] = this.currentAttrLocation, this._leaveAttrValue();
		}
	}
	_leaveAttrValue() {
		this.currentAttrLocation && (this.currentAttrLocation.endLine = this.preprocessor.line, this.currentAttrLocation.endCol = this.preprocessor.col, this.currentAttrLocation.endOffset = this.preprocessor.offset);
	}
	_flushRun(e) {
		if (this.runEnd === this.runStart && e.length === 0) return;
		let t = this.preprocessor.html.slice(this.runStart, this.runEnd), n = (t.length < 13 ? t : ` ${t}`.slice(1)) + e, r = this.currentToken;
		this.runStart = this.runEnd, r === null ? this.currentCharacterToken.chars += n : r.type === K.COMMENT ? r.data += n : this.currentAttr.value += n;
	}
	_extendRun(e) {
		let { preprocessor: t } = this;
		if (e === W.LINE_FEED && t.html.charCodeAt(t.pos) !== W.LINE_FEED) this._flushRun("\n"), this.runStart = t.pos + 1;
		else {
			let n = t.pos - Number(e > 65535);
			n !== this.runEnd && (this._flushRun(""), this.runStart = n);
		}
		this.runEnd = t.pos + 1;
	}
	_extendRunWith(e, t) {
		let { preprocessor: n } = this, r = n.codePointStart + 1 + t - e.length;
		r >= 0 && n.html.startsWith(e, r) ? r !== this.runEnd && (this._flushRun(""), this.runStart = r) : (this._flushRun(e), this.runStart = r + e.length), this.runEnd = r + e.length;
	}
	prepareToken(e) {
		this._emitCurrentCharacterToken(e.location), this.currentToken = null, e.location && (e.location.endLine = this.preprocessor.line, e.location.endCol = this.preprocessor.col + 1, e.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
	}
	emitCurrentTagToken() {
		let e = this.currentToken;
		this.currentAttrNames = null, this.prepareToken(e), e.tagID = Bp(e.tagName), e.type === K.START_TAG ? (this.lastStartTagName = e.tagName, this.handler.onStartTag(e)) : (e.attrs.length > 0 && this._err(G.endTagWithAttributes), e.selfClosing && this._err(G.endTagWithTrailingSolidus), this.handler.onEndTag(e)), this.preprocessor.dropParsedChunk();
	}
	emitCurrentComment(e) {
		this.prepareToken(e), this.handler.onComment(e), this.preprocessor.dropParsedChunk();
	}
	emitCurrentDoctype(e) {
		this.prepareToken(e), this.handler.onDoctype(e), this.preprocessor.dropParsedChunk();
	}
	_emitCurrentCharacterToken(e) {
		if (this._flushRun(""), this.currentCharacterToken) {
			switch (e && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = e.startLine, this.currentCharacterToken.location.endCol = e.startCol, this.currentCharacterToken.location.endOffset = e.startOffset), this.currentCharacterToken.type) {
				case K.CHARACTER:
					this.handler.onCharacter(this.currentCharacterToken);
					break;
				case K.NULL_CHARACTER:
					this.handler.onNullCharacter(this.currentCharacterToken);
					break;
				case K.WHITESPACE_CHARACTER:
					this.handler.onWhitespaceCharacter(this.currentCharacterToken);
					break;
			}
			this.currentCharacterToken = null;
		}
	}
	_emitEOFToken() {
		let e = this.getCurrentLocation(0);
		e && (e.endLine = e.startLine, e.endCol = e.startCol, e.endOffset = e.startOffset), this._emitCurrentCharacterToken(this.currentToken?.location ?? e), this.handler.onEof({
			type: K.EOF,
			location: e
		}), this.active = !1;
	}
	_ensureCharacterToken(e) {
		if (this.currentCharacterToken) {
			if (this.currentCharacterToken.type === e) return;
			this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
		}
		this._createCharacterToken(e);
	}
	_emitCodePoint(e) {
		let t = Xp(e) ? K.WHITESPACE_CHARACTER : e === W.NULL ? K.NULL_CHARACTER : K.CHARACTER, n = this.currentCharacterToken;
		(n === null || n.type !== t) && this._ensureCharacterToken(t), this._extendRun(e);
	}
	_emitChars(e, t = 0) {
		this.options.sourceCodeLocationInfo && t !== 0 && this.currentCharacterToken && this.currentCharacterToken.type !== K.CHARACTER ? (this.currentLocation = this.getCurrentLocation(e.length - 1 - t), this._emitCurrentCharacterToken(this.currentLocation), this._createCharacterToken(K.CHARACTER)) : this._ensureCharacterToken(K.CHARACTER), this._extendRunWith(e, t);
	}
	_startCharacterReference() {
		this.returnState = this.state, this.state = Z.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? pp.Attribute : pp.Legacy);
	}
	_isCharacterReferenceInAttribute() {
		return this.returnState === Z.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === Z.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === Z.ATTRIBUTE_VALUE_UNQUOTED;
	}
	_flushCodePointConsumedAsCharacterReference(e) {
		this._isCharacterReferenceInAttribute() ? this._extendRun(e) : this._emitCodePoint(e);
	}
	_callState(e) {
		switch (this.state) {
			case Z.DATA:
				this._stateData(e);
				break;
			case Z.RCDATA:
				this._stateRcdata(e);
				break;
			case Z.RAWTEXT:
				this._stateRawtext(e);
				break;
			case Z.SCRIPT_DATA:
				this._stateScriptData(e);
				break;
			case Z.PLAINTEXT:
				this._statePlaintext(e);
				break;
			case Z.TAG_OPEN:
				this._stateTagOpen(e);
				break;
			case Z.END_TAG_OPEN:
				this._stateEndTagOpen(e);
				break;
			case Z.TAG_NAME:
				this._stateTagName(e);
				break;
			case Z.RCDATA_LESS_THAN_SIGN:
				this._stateRcdataLessThanSign(e);
				break;
			case Z.RCDATA_END_TAG_OPEN:
				this._stateRcdataEndTagOpen(e);
				break;
			case Z.RCDATA_END_TAG_NAME:
				this._stateRcdataEndTagName(e);
				break;
			case Z.RAWTEXT_LESS_THAN_SIGN:
				this._stateRawtextLessThanSign(e);
				break;
			case Z.RAWTEXT_END_TAG_OPEN:
				this._stateRawtextEndTagOpen(e);
				break;
			case Z.RAWTEXT_END_TAG_NAME:
				this._stateRawtextEndTagName(e);
				break;
			case Z.SCRIPT_DATA_LESS_THAN_SIGN:
				this._stateScriptDataLessThanSign(e);
				break;
			case Z.SCRIPT_DATA_END_TAG_OPEN:
				this._stateScriptDataEndTagOpen(e);
				break;
			case Z.SCRIPT_DATA_END_TAG_NAME:
				this._stateScriptDataEndTagName(e);
				break;
			case Z.SCRIPT_DATA_ESCAPE_START:
				this._stateScriptDataEscapeStart(e);
				break;
			case Z.SCRIPT_DATA_ESCAPE_START_DASH:
				this._stateScriptDataEscapeStartDash(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED:
				this._stateScriptDataEscaped(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED_DASH:
				this._stateScriptDataEscapedDash(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED_DASH_DASH:
				this._stateScriptDataEscapedDashDash(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataEscapedLessThanSign(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
				this._stateScriptDataEscapedEndTagOpen(e);
				break;
			case Z.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
				this._stateScriptDataEscapedEndTagName(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPE_START:
				this._stateScriptDataDoubleEscapeStart(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPED:
				this._stateScriptDataDoubleEscaped(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
				this._stateScriptDataDoubleEscapedDash(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
				this._stateScriptDataDoubleEscapedDashDash(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataDoubleEscapedLessThanSign(e);
				break;
			case Z.SCRIPT_DATA_DOUBLE_ESCAPE_END:
				this._stateScriptDataDoubleEscapeEnd(e);
				break;
			case Z.BEFORE_ATTRIBUTE_NAME:
				this._stateBeforeAttributeName(e);
				break;
			case Z.ATTRIBUTE_NAME:
				this._stateAttributeName(e);
				break;
			case Z.AFTER_ATTRIBUTE_NAME:
				this._stateAfterAttributeName(e);
				break;
			case Z.BEFORE_ATTRIBUTE_VALUE:
				this._stateBeforeAttributeValue(e);
				break;
			case Z.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
				this._stateAttributeValueDoubleQuoted(e);
				break;
			case Z.ATTRIBUTE_VALUE_SINGLE_QUOTED:
				this._stateAttributeValueSingleQuoted(e);
				break;
			case Z.ATTRIBUTE_VALUE_UNQUOTED:
				this._stateAttributeValueUnquoted(e);
				break;
			case Z.AFTER_ATTRIBUTE_VALUE_QUOTED:
				this._stateAfterAttributeValueQuoted(e);
				break;
			case Z.SELF_CLOSING_START_TAG:
				this._stateSelfClosingStartTag(e);
				break;
			case Z.BOGUS_COMMENT:
				this._stateBogusComment(e);
				break;
			case Z.MARKUP_DECLARATION_OPEN:
				this._stateMarkupDeclarationOpen(e);
				break;
			case Z.COMMENT_START:
				this._stateCommentStart(e);
				break;
			case Z.COMMENT_START_DASH:
				this._stateCommentStartDash(e);
				break;
			case Z.COMMENT:
				this._stateComment(e);
				break;
			case Z.COMMENT_LESS_THAN_SIGN:
				this._stateCommentLessThanSign(e);
				break;
			case Z.COMMENT_LESS_THAN_SIGN_BANG:
				this._stateCommentLessThanSignBang(e);
				break;
			case Z.COMMENT_LESS_THAN_SIGN_BANG_DASH:
				this._stateCommentLessThanSignBangDash(e);
				break;
			case Z.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
				this._stateCommentLessThanSignBangDashDash(e);
				break;
			case Z.COMMENT_END_DASH:
				this._stateCommentEndDash(e);
				break;
			case Z.COMMENT_END:
				this._stateCommentEnd(e);
				break;
			case Z.COMMENT_END_BANG:
				this._stateCommentEndBang(e);
				break;
			case Z.DOCTYPE:
				this._stateDoctype(e);
				break;
			case Z.BEFORE_DOCTYPE_NAME:
				this._stateBeforeDoctypeName(e);
				break;
			case Z.DOCTYPE_NAME:
				this._stateDoctypeName(e);
				break;
			case Z.AFTER_DOCTYPE_NAME:
				this._stateAfterDoctypeName(e);
				break;
			case Z.AFTER_DOCTYPE_PUBLIC_KEYWORD:
				this._stateAfterDoctypePublicKeyword(e);
				break;
			case Z.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateBeforeDoctypePublicIdentifier(e);
				break;
			case Z.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypePublicIdentifierDoubleQuoted(e);
				break;
			case Z.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypePublicIdentifierSingleQuoted(e);
				break;
			case Z.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateAfterDoctypePublicIdentifier(e);
				break;
			case Z.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
				this._stateBetweenDoctypePublicAndSystemIdentifiers(e);
				break;
			case Z.AFTER_DOCTYPE_SYSTEM_KEYWORD:
				this._stateAfterDoctypeSystemKeyword(e);
				break;
			case Z.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateBeforeDoctypeSystemIdentifier(e);
				break;
			case Z.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypeSystemIdentifierDoubleQuoted(e);
				break;
			case Z.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypeSystemIdentifierSingleQuoted(e);
				break;
			case Z.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateAfterDoctypeSystemIdentifier(e);
				break;
			case Z.BOGUS_DOCTYPE:
				this._stateBogusDoctype(e);
				break;
			case Z.CDATA_SECTION:
				this._stateCdataSection(e);
				break;
			case Z.CDATA_SECTION_BRACKET:
				this._stateCdataSectionBracket(e);
				break;
			case Z.CDATA_SECTION_END:
				this._stateCdataSectionEnd(e);
				break;
			case Z.CHARACTER_REFERENCE:
				this._stateCharacterReference();
				break;
			case Z.AMBIGUOUS_AMPERSAND:
				this._stateAmbiguousAmpersand(e);
				break;
			default: throw Error("Unknown state");
		}
	}
	_stateData(e) {
		switch (e) {
			case W.LESS_THAN_SIGN:
				this.state = Z.TAG_OPEN;
				break;
			case W.AMPERSAND:
				this._startCharacterReference();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitCodePoint(e);
				break;
			case W.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRcdata(e) {
		switch (e) {
			case W.AMPERSAND:
				this._startCharacterReference();
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.RCDATA_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRawtext(e) {
		switch (e) {
			case W.LESS_THAN_SIGN:
				this.state = Z.RAWTEXT_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptData(e) {
		switch (e) {
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_statePlaintext(e) {
		switch (e) {
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateTagOpen(e) {
		if (qp(e)) this._createStartTagToken(), this.state = Z.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case W.EXCLAMATION_MARK:
				this.state = Z.MARKUP_DECLARATION_OPEN;
				break;
			case W.SOLIDUS:
				this.state = Z.END_TAG_OPEN;
				break;
			case W.QUESTION_MARK:
				this._err(G.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = Z.BOGUS_COMMENT, this._stateBogusComment(e);
				break;
			case W.EOF:
				this._err(G.eofBeforeTagName), this._emitChars("<", -1), this._emitEOFToken();
				break;
			default: this._err(G.invalidFirstCharacterOfTagName), this._emitChars("<", -1), this.state = Z.DATA, this._stateData(e);
		}
	}
	_stateEndTagOpen(e) {
		if (qp(e)) this._createEndTagToken(), this.state = Z.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case W.GREATER_THAN_SIGN:
				this._err(G.missingEndTagName), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofBeforeTagName), this._emitChars("</", -1), this._emitEOFToken();
				break;
			default: this._err(G.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = Z.BOGUS_COMMENT, this._stateBogusComment(e);
		}
	}
	_stateTagName(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.BEFORE_ATTRIBUTE_NAME;
				break;
			case W.SOLIDUS:
				this.state = Z.SELF_CLOSING_START_TAG;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.tagName += "�";
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: t.tagName += String.fromCodePoint(Gp(e) ? Yp(e) : e);
		}
	}
	_stateRcdataLessThanSign(e) {
		e === W.SOLIDUS ? this.state = Z.RCDATA_END_TAG_OPEN : (this._emitChars("<", -1), this.state = Z.RCDATA, this._stateRcdata(e));
	}
	_stateRcdataEndTagOpen(e) {
		qp(e) ? (this.state = Z.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(e)) : (this._emitChars("</", -1), this.state = Z.RCDATA, this._stateRcdata(e));
	}
	handleSpecialEndTag(e) {
		if (!this.preprocessor.startsWith(this.lastStartTagName, !1)) return !this._ensureHibernation();
		this._createEndTagToken();
		let t = this.currentToken;
		switch (t.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: return this._advanceBy(this.lastStartTagName.length), this.state = Z.BEFORE_ATTRIBUTE_NAME, !1;
			case W.SOLIDUS: return this._advanceBy(this.lastStartTagName.length), this.state = Z.SELF_CLOSING_START_TAG, !1;
			case W.GREATER_THAN_SIGN: return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = Z.DATA, !1;
			default: return this.currentToken = null, !this._ensureHibernation();
		}
	}
	_stateRcdataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</", -1), this.state = Z.RCDATA, this._stateRcdata(e));
	}
	_stateRawtextLessThanSign(e) {
		e === W.SOLIDUS ? this.state = Z.RAWTEXT_END_TAG_OPEN : (this._emitChars("<", -1), this.state = Z.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagOpen(e) {
		qp(e) ? (this.state = Z.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(e)) : (this._emitChars("</", -1), this.state = Z.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</", -1), this.state = Z.RAWTEXT, this._stateRawtext(e));
	}
	_stateScriptDataLessThanSign(e) {
		switch (e) {
			case W.SOLIDUS:
				this.state = Z.SCRIPT_DATA_END_TAG_OPEN;
				break;
			case W.EXCLAMATION_MARK:
				this.state = Z.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
				break;
			default: this._emitChars("<", -1), this.state = Z.SCRIPT_DATA, this._stateScriptData(e);
		}
	}
	_stateScriptDataEndTagOpen(e) {
		qp(e) ? (this.state = Z.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(e)) : (this._emitChars("</", -1), this.state = Z.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</", -1), this.state = Z.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStart(e) {
		e === W.HYPHEN_MINUS ? (this.state = Z.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = Z.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStartDash(e) {
		e === W.HYPHEN_MINUS ? (this.state = Z.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = Z.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscaped(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDash(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this.state = Z.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = Z.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDashDash(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.SCRIPT_DATA, this._emitChars(">");
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this.state = Z.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = Z.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedLessThanSign(e) {
		e === W.SOLIDUS ? this.state = Z.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : qp(e) ? (this._emitChars("<", -1), this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(e)) : (this._emitChars("<", -1), this.state = Z.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagOpen(e) {
		qp(e) ? (this.state = Z.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(e)) : (this._emitChars("</", -1), this.state = Z.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</", -1), this.state = Z.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscapeStart(e) {
		if (this.preprocessor.startsWith(Pf.SCRIPT, !1) && Zp(this.preprocessor.peek(Pf.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < Pf.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED;
		} else this._ensureHibernation() || (this.state = Z.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscaped(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDash(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDashDash(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case W.LESS_THAN_SIGN:
				this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.SCRIPT_DATA, this._emitChars(">");
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case W.EOF:
				this._err(G.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedLessThanSign(e) {
		e === W.SOLIDUS ? (this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateScriptDataDoubleEscapeEnd(e) {
		if (this.preprocessor.startsWith(Pf.SCRIPT, !1) && Zp(this.preprocessor.peek(Pf.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < Pf.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = Z.SCRIPT_DATA_ESCAPED;
		} else this._ensureHibernation() || (this.state = Z.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateBeforeAttributeName(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.SOLIDUS:
			case W.GREATER_THAN_SIGN:
			case W.EOF:
				this.state = Z.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case W.EQUALS_SIGN:
				this._err(G.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = Z.ATTRIBUTE_NAME;
				break;
			default: this._createAttr(""), this.state = Z.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateAttributeName(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
			case W.SOLIDUS:
			case W.GREATER_THAN_SIGN:
			case W.EOF:
				this._leaveAttrName(), this.state = Z.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case W.EQUALS_SIGN:
				this._leaveAttrName(), this.state = Z.BEFORE_ATTRIBUTE_VALUE;
				break;
			case W.QUOTATION_MARK:
			case W.APOSTROPHE:
			case W.LESS_THAN_SIGN:
				this._err(G.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(e);
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this.currentAttr.name += "�";
				break;
			default: this.currentAttr.name += String.fromCodePoint(Gp(e) ? Yp(e) : e);
		}
	}
	_stateAfterAttributeName(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.SOLIDUS:
				this.state = Z.SELF_CLOSING_START_TAG;
				break;
			case W.EQUALS_SIGN:
				this.state = Z.BEFORE_ATTRIBUTE_VALUE;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._createAttr(""), this.state = Z.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateBeforeAttributeValue(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.QUOTATION_MARK:
				this.state = Z.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				this.state = Z.ATTRIBUTE_VALUE_SINGLE_QUOTED;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.missingAttributeValue), this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			default: this.state = Z.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(e);
		}
	}
	_stateAttributeValueDoubleQuoted(e) {
		switch (e) {
			case W.QUOTATION_MARK:
				this.state = Z.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case W.AMPERSAND:
				this._startCharacterReference();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._extendRunWith("�", 0);
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._extendRun(e);
		}
	}
	_stateAttributeValueSingleQuoted(e) {
		switch (e) {
			case W.APOSTROPHE:
				this.state = Z.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case W.AMPERSAND:
				this._startCharacterReference();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._extendRunWith("�", 0);
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._extendRun(e);
		}
	}
	_stateAttributeValueUnquoted(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this._leaveAttrValue(), this.state = Z.BEFORE_ATTRIBUTE_NAME;
				break;
			case W.AMPERSAND:
				this._startCharacterReference();
				break;
			case W.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._extendRunWith("�", 0);
				break;
			case W.QUOTATION_MARK:
			case W.APOSTROPHE:
			case W.LESS_THAN_SIGN:
			case W.EQUALS_SIGN:
			case W.GRAVE_ACCENT:
				this._err(G.unexpectedCharacterInUnquotedAttributeValue), this._extendRun(e);
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._extendRun(e);
		}
	}
	_stateAfterAttributeValueQuoted(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this._leaveAttrValue(), this.state = Z.BEFORE_ATTRIBUTE_NAME;
				break;
			case W.SOLIDUS:
				this._leaveAttrValue(), this.state = Z.SELF_CLOSING_START_TAG;
				break;
			case W.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._err(G.missingWhitespaceBetweenAttributes), this._leaveAttrValue(), this.state = Z.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateSelfClosingStartTag(e) {
		switch (e) {
			case W.GREATER_THAN_SIGN: {
				let e = this.currentToken;
				e.selfClosing = !0, this.state = Z.DATA, this.emitCurrentTagToken();
				break;
			}
			case W.EOF:
				this._err(G.eofInTag), this._emitEOFToken();
				break;
			default: this._err(G.unexpectedSolidusInTag), this.state = Z.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateBogusComment(e) {
		let t = this.currentToken;
		switch (e) {
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentComment(t);
				break;
			case W.EOF:
				this.emitCurrentComment(t), this._emitEOFToken();
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._extendRunWith("�", 0);
				break;
			default: this._extendRun(e);
		}
	}
	_stateMarkupDeclarationOpen(e) {
		this._consumeSequenceIfMatch(Pf.DASH_DASH, !0) ? (this._createCommentToken(Pf.DASH_DASH.length + 1), this.state = Z.COMMENT_START) : this._consumeSequenceIfMatch(Pf.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(Pf.DOCTYPE.length + 1), this.state = Z.DOCTYPE) : this._consumeSequenceIfMatch(Pf.CDATA_START, !0) ? this.inForeignNode ? this.state = Z.CDATA_SECTION : (this._err(G.cdataInHtmlContent), this._createCommentToken(Pf.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = Z.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(G.incorrectlyOpenedComment), this._createCommentToken(2), this.state = Z.BOGUS_COMMENT, this._stateBogusComment(e));
	}
	_stateCommentStart(e) {
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.COMMENT_START_DASH;
				break;
			case W.GREATER_THAN_SIGN: {
				this._err(G.abruptClosingOfEmptyComment), this.state = Z.DATA;
				let e = this.currentToken;
				this.emitCurrentComment(e);
				break;
			}
			default: this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentStartDash(e) {
		let t = this.currentToken;
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.COMMENT_END;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.abruptClosingOfEmptyComment), this.state = Z.DATA, this.emitCurrentComment(t);
				break;
			case W.EOF:
				this._err(G.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: this._extendRunWith("-", -1), this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateComment(e) {
		let t = this.currentToken;
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.COMMENT_END_DASH;
				break;
			case W.LESS_THAN_SIGN:
				this._extendRunWith("<", 0), this.state = Z.COMMENT_LESS_THAN_SIGN;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._extendRunWith("�", 0);
				break;
			case W.EOF:
				this._err(G.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: this._extendRun(e);
		}
	}
	_stateCommentLessThanSign(e) {
		switch (e) {
			case W.EXCLAMATION_MARK:
				this._extendRunWith("!", 0), this.state = Z.COMMENT_LESS_THAN_SIGN_BANG;
				break;
			case W.LESS_THAN_SIGN:
				this._extendRunWith("<", 0);
				break;
			default: this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentLessThanSignBang(e) {
		e === W.HYPHEN_MINUS ? this.state = Z.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = Z.COMMENT, this._stateComment(e));
	}
	_stateCommentLessThanSignBangDash(e) {
		e === W.HYPHEN_MINUS ? this.state = Z.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = Z.COMMENT_END_DASH, this._stateCommentEndDash(e));
	}
	_stateCommentLessThanSignBangDashDash(e) {
		e !== W.GREATER_THAN_SIGN && e !== W.EOF && this._err(G.nestedComment), this.state = Z.COMMENT_END, this._stateCommentEnd(e);
	}
	_stateCommentEndDash(e) {
		let t = this.currentToken;
		switch (e) {
			case W.HYPHEN_MINUS:
				this.state = Z.COMMENT_END;
				break;
			case W.EOF:
				this._err(G.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: this._extendRunWith("-", -1), this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEnd(e) {
		let t = this.currentToken;
		switch (e) {
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentComment(t);
				break;
			case W.EXCLAMATION_MARK:
				this.state = Z.COMMENT_END_BANG;
				break;
			case W.HYPHEN_MINUS:
				this._extendRunWith("-", -2);
				break;
			case W.EOF:
				this._err(G.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: this._extendRunWith("--", -1), this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEndBang(e) {
		let t = this.currentToken;
		switch (e) {
			case W.HYPHEN_MINUS:
				this._extendRunWith("--!", -1), this.state = Z.COMMENT_END_DASH;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.incorrectlyClosedComment), this.state = Z.DATA, this.emitCurrentComment(t);
				break;
			case W.EOF:
				this._err(G.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: this._extendRunWith("--!", -1), this.state = Z.COMMENT, this._stateComment(e);
		}
	}
	_stateDoctype(e) {
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.BEFORE_DOCTYPE_NAME;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
				break;
			case W.EOF: {
				this._err(G.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._err(G.missingWhitespaceBeforeDoctypeName), this.state = Z.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
		}
	}
	_stateBeforeDoctypeName(e) {
		if (Gp(e)) this._createDoctypeToken(String.fromCharCode(Yp(e))), this.state = Z.DOCTYPE_NAME;
		else switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), this._createDoctypeToken("�"), this.state = Z.DOCTYPE_NAME;
				break;
			case W.GREATER_THAN_SIGN: {
				this._err(G.missingDoctypeName), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this.state = Z.DATA;
				break;
			}
			case W.EOF: {
				this._err(G.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._createDoctypeToken(String.fromCodePoint(e)), this.state = Z.DOCTYPE_NAME;
		}
	}
	_stateDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.AFTER_DOCTYPE_NAME;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.name += "�";
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.name += String.fromCodePoint(Gp(e) ? Yp(e) : e);
		}
	}
	_stateAfterDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._consumeSequenceIfMatch(Pf.PUBLIC, !1) ? this.state = Z.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(Pf.SYSTEM, !1) ? this.state = Z.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(G.invalidCharacterSequenceAfterDoctypeName), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e));
		}
	}
	_stateAfterDoctypePublicKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case W.QUOTATION_MARK:
				this._err(G.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = Z.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				this._err(G.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = Z.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.QUOTATION_MARK:
				t.publicId = "", this.state = Z.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				t.publicId = "", this.state = Z.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypePublicIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case W.QUOTATION_MARK:
				this.state = Z.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.publicId += "�";
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateDoctypePublicIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case W.APOSTROPHE:
				this.state = Z.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.publicId += "�";
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
				break;
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.QUOTATION_MARK:
				this._err(G.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				this._err(G.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBetweenDoctypePublicAndSystemIdentifiers(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.QUOTATION_MARK:
				t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateAfterDoctypeSystemKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED:
				this.state = Z.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case W.QUOTATION_MARK:
				this._err(G.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				this._err(G.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.QUOTATION_MARK:
				t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case W.APOSTROPHE:
				t.systemId = "", this.state = Z.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.DATA, this.emitCurrentDoctype(t);
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypeSystemIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case W.QUOTATION_MARK:
				this.state = Z.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.systemId += "�";
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateDoctypeSystemIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case W.APOSTROPHE:
				this.state = Z.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter), t.systemId += "�";
				break;
			case W.GREATER_THAN_SIGN:
				this._err(G.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case W.SPACE:
			case W.LINE_FEED:
			case W.TABULATION:
			case W.FORM_FEED: break;
			case W.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.EOF:
				this._err(G.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(G.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = Z.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBogusDoctype(e) {
		let t = this.currentToken;
		switch (e) {
			case W.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = Z.DATA;
				break;
			case W.NULL:
				this._err(G.unexpectedNullCharacter);
				break;
			case W.EOF:
				this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default:
		}
	}
	_stateCdataSection(e) {
		switch (e) {
			case W.RIGHT_SQUARE_BRACKET:
				this.state = Z.CDATA_SECTION_BRACKET;
				break;
			case W.EOF:
				this._err(G.eofInCdata), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateCdataSectionBracket(e) {
		e === W.RIGHT_SQUARE_BRACKET ? this.state = Z.CDATA_SECTION_END : (this._emitChars("]", -1), this.state = Z.CDATA_SECTION, this._stateCdataSection(e));
	}
	_stateCdataSectionEnd(e) {
		switch (e) {
			case W.GREATER_THAN_SIGN:
				this.state = Z.DATA;
				break;
			case W.RIGHT_SQUARE_BRACKET:
				this._emitChars("]", -2);
				break;
			default: this._emitChars("]]", -1), this.state = Z.CDATA_SECTION, this._stateCdataSection(e);
		}
	}
	_stateCharacterReference() {
		let e = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
		if (e < 0) if (this.preprocessor.lastChunkWritten) e = this.entityDecoder.end();
		else {
			this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
			return;
		}
		e === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(W.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && Jp(this.preprocessor.peek(1)) ? Z.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
	}
	_stateAmbiguousAmpersand(e) {
		Jp(e) ? this._flushCodePointConsumedAsCharacterReference(e) : (e === W.SEMICOLON && this._err(G.unknownNamedCharacterReference), this.state = this.returnState, this._callState(e));
	}
}, em = new Set([
	Y.DD,
	Y.DT,
	Y.LI,
	Y.OPTGROUP,
	Y.OPTION,
	Y.P,
	Y.RB,
	Y.RP,
	Y.RT,
	Y.RTC
]), tm = new Set([
	...em,
	Y.CAPTION,
	Y.COLGROUP,
	Y.TBODY,
	Y.TD,
	Y.TFOOT,
	Y.TH,
	Y.THEAD,
	Y.TR
]), nm = 64, rm = 256, im = 512, am = 768, om = [
	Y.H1,
	Y.H2,
	Y.H3,
	Y.H4,
	Y.H5,
	Y.H6
], sm = [
	Y.TBODY,
	Y.TFOOT,
	Y.THEAD
], cm = [
	Y.TR,
	Y.TEMPLATE,
	Y.HTML
], lm = [
	...sm,
	Y.TEMPLATE,
	Y.HTML
], um = [
	Y.TABLE,
	Y.TEMPLATE,
	Y.HTML
], dm = [Y.TD, Y.TH], fm = 1, pm = 2, mm = 4, hm = 8, gm = 16, _m = 32, vm = new Uint8Array(am);
for (let [e, t] of [
	[q.HTML, 0],
	[q.SVG, rm],
	[q.MATHML, im]
]) for (let n of Vp[e]) vm[t + n] = e === q.HTML && (n === Y.ADDRESS || n === Y.DIV || n === Y.P) ? fm : fm | pm;
for (let e of [
	Y.APPLET,
	Y.CAPTION,
	Y.HTML,
	Y.MARQUEE,
	Y.OBJECT,
	Y.TABLE,
	Y.TD,
	Y.TEMPLATE,
	Y.TH,
	rm + Y.DESC,
	rm + Y.FOREIGN_OBJECT,
	rm + Y.TITLE,
	im + Y.ANNOTATION_XML,
	im + Y.MI,
	im + Y.MN,
	im + Y.MO,
	im + Y.MS,
	im + Y.MTEXT
]) vm[e] |= hm | 20;
vm[Y.OL] |= hm, vm[Y.UL] |= hm, vm[Y.BUTTON] |= gm, vm[Y.TABLE] |= _m, vm[Y.HTML] |= _m;
var ym = new Uint8Array(am);
for (let e of [
	Y.A,
	Y.B,
	Y.BIG,
	Y.CODE,
	Y.EM,
	Y.FONT,
	Y.I,
	Y.NOBR,
	Y.S,
	Y.SMALL,
	Y.STRIKE,
	Y.STRONG,
	Y.TT,
	Y.U
]) ym[e] = 1;
function bm(e, t) {
	if (t === Y.UNKNOWN) return -1;
	switch (e) {
		case q.HTML: return t;
		case q.SVG: return rm + t;
		case q.MATHML: return im + t;
		default: return -1;
	}
}
var xm = class {
	get currentTmplContentOrNode() {
		return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
	}
	constructor(e, t, n) {
		this.treeAdapter = t, this.handler = n, this.items = [], this.tagIDs = [], this.stackTop = -1, this.depth = 0, this.tmplCount = 0, this.currentTagId = Y.UNKNOWN, this.indexed = !1, this.below = [], this.above = [], this.keys = [], this.keyPrev = [], this.keyNext = [], this.keyTops = new Int32Array(), this.specials = [], this.listItemBoundaries = [], this.scopeBoundaries = [], this.htmlSlots = [], this.formattingSlots = /* @__PURE__ */ new Map(), this.current = e;
	}
	_indexOf(e) {
		if (this.indexed) {
			let t = this.formattingSlots.get(e);
			if (t !== void 0) return t;
			if (ym[Bp(this.treeAdapter.getTagName(e))]) return -1;
		}
		return this.items.lastIndexOf(e, this.stackTop);
	}
	slotBelow(e) {
		return this.indexed ? this.below[e] : e - 1;
	}
	slotAbove(e) {
		return this.indexed ? this.above[e] : e === this.stackTop ? -1 : e + 1;
	}
	_isInTemplate() {
		return this.currentTagId === Y.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === q.HTML;
	}
	_updateCurrentElement() {
		this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
	}
	_nameKey(e, t, n) {
		let r = `${e} ${t}`, i = this.nameKeys?.get(r);
		if (i === void 0 && n && (this.nameKeys ??= /* @__PURE__ */ new Map(), i = am + this.nameKeys.size, this.nameKeys.set(r, i), i === this.keyTops.length)) {
			let e = new Int32Array(2 * i).fill(-1);
			e.set(this.keyTops), this.keyTops = e;
		}
		return i ?? -1;
	}
	_indexAll() {
		this.indexed = !0, this.keyTops = new Int32Array(am).fill(-1);
		for (let e = 0; e <= this.stackTop; e++) this._index(e, e - 1);
	}
	_index(e, t) {
		let n = this.items[e], r = this.tagIDs[e], i = this.treeAdapter.getNamespaceURI(n), a = bm(i, r);
		a === -1 && (a = this._nameKey(i, this.treeAdapter.getTagName(n), !0));
		let o = this.keyTops[a];
		this.keys[e] = a, this.keyPrev[e] = o, this.keyNext[e] = -1, o !== -1 && (this.keyNext[o] = e), this.keyTops[a] = e, this.above[e] = -1, this._link(e, t, i === q.HTML), ym[r] && this.formattingSlots.set(n, e);
	}
	_link(e, t, n) {
		let r = this.keys[e], i = r < am ? vm[r] : 0;
		this.below[e] = t, t === -1 ? (this.specials[e] = i & fm, this.listItemBoundaries[e] = (i & pm) >> 1, this.scopeBoundaries[e] = (i & mm) >> 2, this.htmlSlots[e] = n ? e : -1) : (this.above[t] = e, this.specials[e] = this.specials[t] + (i & fm), this.listItemBoundaries[e] = this.listItemBoundaries[t] + ((i & pm) >> 1), this.scopeBoundaries[e] = this.scopeBoundaries[t] + ((i & mm) >> 2), this.htmlSlots[e] = n ? e : this.htmlSlots[t]);
	}
	_unindex(e) {
		let t = this.keys[e], n = this.keyPrev[e], r = this.keyNext[e];
		n !== -1 && (this.keyNext[n] = r), r === -1 ? this.keyTops[t] = n : this.keyPrev[r] = n, ym[this.tagIDs[e]] && this.formattingSlots.delete(this.items[e]);
	}
	_move(e, t) {
		let n = this.items[e], r = this.keys[e], i = this.keyPrev[e], a = this.keyNext[e];
		this.items[t] = n, this.tagIDs[t] = this.tagIDs[e], this.keys[t] = r, this.keyPrev[t] = i, this.keyNext[t] = a, i !== -1 && (this.keyNext[i] = t), a === -1 ? this.keyTops[r] = t : this.keyPrev[a] = t, ym[this.tagIDs[t]] && this.formattingSlots.set(n, t);
	}
	indexOfTopmost(e) {
		if (this.indexed) return this.keyTops[e];
		for (let t = this.stackTop; t >= 0; t--) if (this.tagIDs[t] === e && this.treeAdapter.getNamespaceURI(this.items[t]) === q.HTML) return t;
		return -1;
	}
	indexOfTopmostOf(e) {
		if (this.indexed) {
			let t = -1;
			for (let n of e) this.keyTops[n] > t && (t = this.keyTops[n]);
			return t;
		}
		for (let t = this.stackTop; t >= 0; t--) if (e.includes(this.tagIDs[t]) && this.treeAdapter.getNamespaceURI(this.items[t]) === q.HTML) return t;
		return -1;
	}
	indexOfTopmostByName(e, t) {
		if (this.indexed) {
			let n = bm(e, Bp(t));
			return n === -1 && (n = this._nameKey(e, t, !1)), n === -1 ? -1 : this.keyTops[n];
		}
		for (let n = this.stackTop; n >= 0; n--) {
			let r = this.items[n];
			if (this.treeAdapter.getTagName(r) === t && this.treeAdapter.getNamespaceURI(r) === e) return n;
		}
		return -1;
	}
	indexOfTopmostHtmlElement() {
		if (this.indexed) return this.stackTop === -1 ? -1 : this.htmlSlots[this.stackTop];
		let e = this.stackTop;
		for (; e >= 0 && this.treeAdapter.getNamespaceURI(this.items[e]) !== q.HTML;) e--;
		return e;
	}
	_hasAbove(e, t) {
		for (let n = this.stackTop; n > e; n--) {
			let e = bm(this.treeAdapter.getNamespaceURI(this.items[n]), this.tagIDs[n]);
			if (e !== -1 && vm[e] & t) return !0;
		}
		return !1;
	}
	hasSpecialElementAbove(e) {
		return this.indexed ? this.specials[this.stackTop] !== this.specials[e] : this._hasAbove(e, fm);
	}
	hasListItemBoundaryAbove(e) {
		return this.indexed ? this.listItemBoundaries[this.stackTop] !== this.listItemBoundaries[e] : this._hasAbove(e, pm);
	}
	push(e, t) {
		let n = this.stackTop;
		this.stackTop++, this.depth++, this.items[this.stackTop] = e, this.current = e, this.tagIDs[this.stackTop] = t, this.currentTagId = t, this.indexed ? this._index(this.stackTop, n) : this.depth === nm && this._indexAll(), this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(e, t, !0);
	}
	_popCurrent() {
		this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.indexed ? (this._unindex(this.stackTop), this.stackTop = this.below[this.stackTop], this.stackTop !== -1 && (this.above[this.stackTop] = -1)) : this.stackTop--, this.depth--, this._updateCurrentElement();
	}
	pop() {
		let e = this.current;
		this._popCurrent(), this.handler.onItemPop(e, !0);
	}
	replace(e, t) {
		let n = this._indexOf(e);
		this.items[n] = t, this.indexed && ym[this.tagIDs[n]] && (this.formattingSlots.delete(e), this.formattingSlots.set(t, n)), n === this.stackTop && (this.current = t);
	}
	replaceFormattingElement(e, t, n, r) {
		let i = this.items[e];
		if (!this.indexed) {
			this.items.splice(e, 1), this.tagIDs.splice(e, 1), this.handler.onItemPop(i, !1), this.items.splice(t, 0, n), this.tagIDs.splice(t, 0, r), t === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, t === this.stackTop);
			return;
		}
		let a = this.keys[e], o = this.below[e], s = this.above[t], c = [];
		for (let n = this.above[e]; n !== t; n = this.above[n]) c.push(n);
		let l = this.keyNext[e];
		this._unindex(e), this.items[e] = void 0, this.handler.onItemPop(i, !1);
		let u = t - 1;
		for (; c.length > 0 && c[c.length - 1] === u;) c.pop(), u--;
		for (let e = u + 1; e <= t; e++) this._move(e, e - 1);
		let d = l === -1 ? this.keyTops[a] : this.keyPrev[l];
		this.items[t] = n, this.tagIDs[t] = r, this.keys[t] = a, this.keyPrev[t] = d, this.keyNext[t] = l, d !== -1 && (this.keyNext[d] = t), l === -1 ? this.keyTops[a] = t : this.keyPrev[l] = t, ym[r] && this.formattingSlots.set(n, t);
		let f = o;
		for (let e of c) this._link(e, f, !0), f = e;
		for (let e = u; e < t; e++) this._link(e, f, !0), f = e;
		this._link(t, f, !0), s === -1 && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, s === -1);
	}
	popUntilTagNamePopped(e) {
		this.shortenToLength(Math.max(this.indexOfTopmost(e), 0));
	}
	shortenToLength(e) {
		for (; this.stackTop >= e;) {
			let t = this.current;
			this._popCurrent(), this.handler.onItemPop(t, this.stackTop < e);
		}
	}
	popUntilElementPopped(e) {
		let t = this._indexOf(e);
		this.shortenToLength(Math.max(t, 0));
	}
	popUntilNumberedHeaderPopped() {
		this.shortenToLength(Math.max(this.indexOfTopmostOf(om), 0));
	}
	popUntilTableCellPopped() {
		this.shortenToLength(Math.max(this.indexOfTopmostOf(dm), 0));
	}
	popAllUpToHtmlElement() {
		this.tmplCount = 0, this.shortenToLength(1);
	}
	clearBackToTableContext() {
		this.shortenToLength(this.indexOfTopmostOf(um) + 1);
	}
	clearBackToTableBodyContext() {
		this.shortenToLength(this.indexOfTopmostOf(lm) + 1);
	}
	clearBackToTableRowContext() {
		this.shortenToLength(this.indexOfTopmostOf(cm) + 1);
	}
	remove(e) {
		let t = this._indexOf(e);
		t !== -1 && this.removeAt(t);
	}
	removeAt(e) {
		if (e === this.stackTop) {
			this.pop();
			return;
		}
		let t = this.items[e];
		if (this.depth--, this.indexed) {
			let t = this.keys[e] < am ? vm[this.keys[e]] : 0, n = this.below[e], r = this.above[e];
			if (this._unindex(e), this.items[e] = void 0, this.below[r] = n, n !== -1 && (this.above[n] = r), t !== 0) for (let e = r; e !== -1; e = this.above[e]) this.specials[e] -= t & fm, this.listItemBoundaries[e] -= (t & pm) >> 1, this.scopeBoundaries[e] -= (t & mm) >> 2;
			let i = n === -1 ? -1 : this.htmlSlots[n];
			for (let t = r; t !== -1 && this.htmlSlots[t] === e; t = this.above[t]) this.htmlSlots[t] = i;
		} else this.items.splice(e, 1), this.tagIDs.splice(e, 1), this.stackTop--, this._updateCurrentElement();
		this.handler.onItemPop(t, !1);
	}
	tryPeekProperlyNestedBodyElement() {
		return this.stackTop >= 1 && this.tagIDs[1] === Y.BODY ? this.items[1] : null;
	}
	contains(e) {
		return this._indexOf(e) > -1;
	}
	getCommonAncestor(e) {
		let t = this._indexOf(e), n = t === -1 ? -1 : this.slotBelow(t);
		return n === -1 ? null : this.items[n];
	}
	isRootHtmlElementCurrent() {
		return this.stackTop === 0 && this.tagIDs[0] === Y.HTML;
	}
	_isInScope(e, t) {
		let n = -1;
		switch (t) {
			case hm:
				n = Math.max(this.keyTops[Y.OL], this.keyTops[Y.UL]);
				break;
			case gm:
				n = this.keyTops[Y.BUTTON];
				break;
			case _m: return n = Math.max(this.keyTops[Y.TABLE], this.keyTops[Y.HTML]), e === -1 ? n === -1 : e >= n;
			default:
		}
		return e === -1 ? n === -1 && (this.stackTop === -1 || this.scopeBoundaries[this.stackTop] === 0) : e >= n && this.scopeBoundaries[this.stackTop] === this.scopeBoundaries[e];
	}
	_scanScope(e, t, n, r) {
		for (let i = this.stackTop; i >= 0; i--) {
			let a = bm(this.treeAdapter.getNamespaceURI(this.items[i]), this.tagIDs[i]);
			if (a !== -1) {
				if ((t ? t.includes(a) : a === e) && (!r || this.items[i] === r)) return !0;
				if (vm[a] & n) return !1;
			}
		}
		return !0;
	}
	hasInScope(e, t) {
		return this.indexed ? this._isInScope(t ? this._indexOf(t) : this.keyTops[e], mm) : this._scanScope(e, null, mm, t);
	}
	hasInListItemScope(e) {
		return this.indexed ? this._isInScope(this.keyTops[e], hm) : this._scanScope(e, null, hm);
	}
	hasInButtonScope(e) {
		return this.indexed ? this._isInScope(this.keyTops[e], gm) : this._scanScope(e, null, gm);
	}
	hasNumberedHeaderInScope() {
		return this.indexed ? this._isInScope(this.indexOfTopmostOf(om), mm) : this._scanScope(Y.UNKNOWN, om, mm);
	}
	hasInTableScope(e) {
		return this.indexed ? this._isInScope(this.keyTops[e], _m) : this._scanScope(e, null, _m);
	}
	hasTableBodyContextInTableScope() {
		return this.indexed ? this._isInScope(this.indexOfTopmostOf(sm), _m) : this._scanScope(Y.UNKNOWN, sm, _m);
	}
	hasInSelectScope(e) {
		for (let t = this.stackTop; t >= 0; t = this.slotBelow(t)) if (this.treeAdapter.getNamespaceURI(this.items[t]) === q.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case Y.OPTION:
			case Y.OPTGROUP: break;
			default: return !1;
		}
		return !0;
	}
	generateImpliedEndTags() {
		for (; this.currentTagId !== void 0 && em.has(this.currentTagId) && this.treeAdapter.getNamespaceURI(this.current) === q.HTML;) this.pop();
	}
	generateImpliedEndTagsThoroughly() {
		for (; this.currentTagId !== void 0 && tm.has(this.currentTagId) && this.treeAdapter.getNamespaceURI(this.current) === q.HTML;) this.pop();
	}
	generateImpliedEndTagsWithExclusion(e) {
		for (; this.currentTagId !== void 0 && this.currentTagId !== e && tm.has(this.currentTagId) && this.treeAdapter.getNamespaceURI(this.current) === q.HTML;) this.pop();
	}
}, Sm = 3, Cm;
(function(e) {
	e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(Cm ||= {});
var wm = class {
	constructor() {
		this.newest = null, this.bookmark = null, this.index = null, this.elementEntries = /* @__PURE__ */ new Map();
	}
	_insertElementEntry(e, t, n) {
		let r = n === null ? null : n.newer, i = {
			type: Cm.Element,
			element: e,
			token: t,
			older: n,
			newer: r,
			ark: null,
			olderSameTag: null,
			newerSameTag: null
		};
		return r === null ? this.newest = i : r.older = i, n !== null && (n.newer = i), this.index === null ? null : this._addToIndex(this.index, i);
	}
	_addToIndex(e, t) {
		let { tagName: n, attrs: r } = t.token, i = n + r.map(({ name: e, value: t }) => `\0${e}\0${t}`).sort().join(""), a = e.arks.get(i);
		a === void 0 && (a = {
			entries: [],
			key: i
		}, e.arks.set(i, a)), a.entries.push(t), t.ark = a, this.elementEntries.set(t.element, t);
		let o = e.tagNames.get(n);
		return o === void 0 && (o = { olderSameTag: null }, e.tagNames.set(n, o)), t.olderSameTag = o.olderSameTag, t.newerSameTag = o, o.olderSameTag !== null && (o.olderSameTag.newerSameTag = t), o.olderSameTag = t, a;
	}
	insertMarker() {
		if (this.index === null) for (let e = this.newest; e !== null && e.type === Cm.Element; e = e.older) this.elementEntries.set(e.element, e);
		let e = {
			type: Cm.Marker,
			older: this.newest,
			newer: null,
			outerIndex: this.index
		};
		this.newest !== null && (this.newest.newer = e), this.newest = e, this.index = null;
	}
	pushElement(e, t) {
		if (this.index === null) {
			let e = null, t = 0;
			for (let n = this.newest; n !== null && n.type === Cm.Element; n = n.older) e = n, t++;
			if (t >= Sm) {
				this.index = {
					arks: /* @__PURE__ */ new Map(),
					tagNames: /* @__PURE__ */ new Map()
				};
				for (let t = e; t !== null && t.type === Cm.Element; t = t.newer) this._addToIndex(this.index, t);
			}
		}
		let n = this._insertElementEntry(e, t, this.newest);
		n !== null && n.entries.length > Sm && this.removeEntry(n.entries[0]);
	}
	insertElementAfterBookmark(e, t) {
		let { bookmark: n } = this;
		this.bookmark = null, this._insertElementEntry(e, t, n);
	}
	removeEntry(e) {
		var t;
		if (!(e.newer === null ? this.newest !== e : e.newer.older !== e)) {
			if (this.elementEntries.delete(e.element), e.newer === null ? this.newest = e.older : e.newer.older = e.older, e.older !== null && (e.older.newer = e.newer), e.ark !== null) {
				let { entries: n, key: r } = e.ark;
				n.splice(n.indexOf(e), 1), n.length === 0 && ((t = this.index) == null || t.arks.delete(r));
			}
			e.newerSameTag !== null && (e.newerSameTag.olderSameTag = e.olderSameTag, e.olderSameTag !== null && (e.olderSameTag.newerSameTag = e.newerSameTag));
		}
	}
	replaceElement(e, t) {
		this.elementEntries.delete(e.element) && this.elementEntries.set(t, e), e.element = t;
	}
	clearToLastMarker() {
		let e = this.newest;
		for (; e !== null && e.type === Cm.Element; e = e.older) this.elementEntries.delete(e.element);
		this.newest = e === null ? null : e.older, this.index = e === null ? null : e.outerIndex, this.newest !== null && (this.newest.newer = null);
	}
	getElementEntryInScopeWithTagName(e) {
		if (this.index !== null) return this.index.tagNames.get(e)?.olderSameTag ?? null;
		for (let t = this.newest; t !== null && t.type === Cm.Element; t = t.older) if (t.token.tagName === e) return t;
		return null;
	}
	getElementEntry(e) {
		if (this.index === null) {
			for (let t = this.newest; t !== null && t.type === Cm.Element; t = t.older) if (t.element === e) return t;
		}
		return this.elementEntries.get(e);
	}
}, Tm = /* @__PURE__ */ new WeakMap(), Em = {
	createDocument() {
		return {
			nodeName: "#document",
			mode: Rp.NO_QUIRKS,
			childNodes: []
		};
	},
	createDocumentFragment() {
		return {
			nodeName: "#document-fragment",
			childNodes: []
		};
	},
	createElement(e, t, n) {
		return {
			nodeName: e,
			tagName: e,
			attrs: n,
			namespaceURI: t,
			childNodes: [],
			parentNode: null
		};
	},
	createCommentNode(e) {
		return {
			nodeName: "#comment",
			data: e,
			parentNode: null
		};
	},
	createTextNode(e) {
		return {
			nodeName: "#text",
			value: e,
			parentNode: null
		};
	},
	appendChild(e, t) {
		e.childNodes.push(t), t.parentNode = e;
	},
	insertBefore(e, t, n) {
		let { childNodes: r } = e, i = r[r.length - 1] === n ? r.length - 1 : r.indexOf(n);
		r.splice(i, 0, t), t.parentNode = e;
	},
	setTemplateContent(e, t) {
		e.content = t;
	},
	getTemplateContent(e) {
		return e.content;
	},
	setDocumentType(e, t, n, r) {
		let i = e.childNodes.find((e) => e.nodeName === "#documentType");
		if (i) i.name = t, i.publicId = n, i.systemId = r;
		else {
			let i = {
				nodeName: "#documentType",
				name: t,
				publicId: n,
				systemId: r,
				parentNode: null
			};
			Em.appendChild(e, i);
		}
	},
	setDocumentMode(e, t) {
		e.mode = t;
	},
	getDocumentMode(e) {
		return e.mode;
	},
	detachNode(e) {
		if (e.parentNode) {
			let { childNodes: t } = e.parentNode, n = t[t.length - 1] === e ? t.length - 1 : t.indexOf(e);
			t.splice(n, 1), e.parentNode = null;
		}
	},
	insertText(e, t) {
		if (e.childNodes.length > 0) {
			let n = e.childNodes[e.childNodes.length - 1];
			if (Em.isTextNode(n)) {
				n.value += t;
				return;
			}
		}
		Em.appendChild(e, Em.createTextNode(t));
	},
	insertTextBefore(e, t, n) {
		let { childNodes: r } = e, i = r[(r[r.length - 1] === n ? r.length - 1 : r.indexOf(n)) - 1];
		i && Em.isTextNode(i) ? i.value += t : Em.insertBefore(e, Em.createTextNode(t), n);
	},
	adoptAttributes(e, t) {
		if (t.length === 0 || t === e.attrs) return;
		let n = Tm.get(e.attrs), r = n?.size === e.attrs.length && t.every(({ name: t }) => {
			let r = n.get(t);
			return r === void 0 || e.attrs[r]?.name === t;
		}), i = r ? n : /* @__PURE__ */ new Map();
		if (!r) {
			for (let t = 0; t < e.attrs.length; t++) {
				let n = e.attrs[t];
				n !== void 0 && i.set(n.name, t);
			}
			Tm.set(e.attrs, i);
		}
		let a = e.attrs.length;
		for (let n = 0; n < t.length; n++) i.has(t[n].name) || e.attrs.push(t[n]);
		for (let t = a; t < e.attrs.length; t++) i.set(e.attrs[t].name, t);
		i.size !== e.attrs.length && Tm.delete(e.attrs);
	},
	getFirstChild(e) {
		return e.childNodes[0];
	},
	getChildNodes(e) {
		return e.childNodes;
	},
	getParentNode(e) {
		return e.parentNode;
	},
	getAttrList(e) {
		return e.attrs;
	},
	getTagName(e) {
		return e.tagName;
	},
	getNamespaceURI(e) {
		return e.namespaceURI;
	},
	getTextNodeContent(e) {
		return e.value;
	},
	getCommentNodeContent(e) {
		return e.data;
	},
	getDocumentTypeNodeName(e) {
		return e.name;
	},
	getDocumentTypeNodePublicId(e) {
		return e.publicId;
	},
	getDocumentTypeNodeSystemId(e) {
		return e.systemId;
	},
	isTextNode(e) {
		return e.nodeName === "#text";
	},
	isCommentNode(e) {
		return e.nodeName === "#comment";
	},
	isDocumentTypeNode(e) {
		return e.nodeName === "#documentType";
	},
	isElementNode(e) {
		return Object.prototype.hasOwnProperty.call(e, "tagName");
	},
	setNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = t;
	},
	getNodeSourceCodeLocation(e) {
		return e.sourceCodeLocation;
	},
	updateNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = {
			...e.sourceCodeLocation,
			...t
		};
	}
}, Dm = "html", Om = "about:legacy-compat", km = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", Am = /* @__PURE__ */ "+//silmaril//dtd html pro v0r11 19970101//,-//as//dtd html 3.0 aswedit + extensions//,-//advasoft ltd//dtd html 3.0 aswedit + extensions//,-//ietf//dtd html 2.0 level 1//,-//ietf//dtd html 2.0 level 2//,-//ietf//dtd html 2.0 strict level 1//,-//ietf//dtd html 2.0 strict level 2//,-//ietf//dtd html 2.0 strict//,-//ietf//dtd html 2.0//,-//ietf//dtd html 2.1e//,-//ietf//dtd html 3.0//,-//ietf//dtd html 3.2 final//,-//ietf//dtd html 3.2//,-//ietf//dtd html 3//,-//ietf//dtd html level 0//,-//ietf//dtd html level 1//,-//ietf//dtd html level 2//,-//ietf//dtd html level 3//,-//ietf//dtd html strict level 0//,-//ietf//dtd html strict level 1//,-//ietf//dtd html strict level 2//,-//ietf//dtd html strict level 3//,-//ietf//dtd html strict//,-//ietf//dtd html//,-//metrius//dtd metrius presentational//,-//microsoft//dtd internet explorer 2.0 html strict//,-//microsoft//dtd internet explorer 2.0 html//,-//microsoft//dtd internet explorer 2.0 tables//,-//microsoft//dtd internet explorer 3.0 html strict//,-//microsoft//dtd internet explorer 3.0 html//,-//microsoft//dtd internet explorer 3.0 tables//,-//netscape comm. corp.//dtd html//,-//netscape comm. corp.//dtd strict html//,-//o'reilly and associates//dtd html 2.0//,-//o'reilly and associates//dtd html extended 1.0//,-//o'reilly and associates//dtd html extended relaxed 1.0//,-//sq//dtd html 2.0 hotmetal + extensions//,-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//,-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//,-//spyglass//dtd html 2.0 extended//,-//sun microsystems corp.//dtd hotjava html//,-//sun microsystems corp.//dtd hotjava strict html//,-//w3c//dtd html 3 1995-03-24//,-//w3c//dtd html 3.2 draft//,-//w3c//dtd html 3.2 final//,-//w3c//dtd html 3.2//,-//w3c//dtd html 3.2s draft//,-//w3c//dtd html 4.0 frameset//,-//w3c//dtd html 4.0 transitional//,-//w3c//dtd html experimental 19960712//,-//w3c//dtd html experimental 970421//,-//w3c//dtd w3 html//,-//w3o//dtd w3 html 3.0//,-//webtechs//dtd mozilla html 2.0//,-//webtechs//dtd mozilla html//".split(","), jm = [
	...Am,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
], Mm = new Set([
	"-//w3o//dtd w3 html strict 3.0//en//",
	"-/w3c/dtd html 4.0 transitional/en",
	"html"
]), Nm = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], Pm = [
	...Nm,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
];
function Fm(e, t) {
	return t.some((t) => e.startsWith(t));
}
function Im(e) {
	return e.name === Dm && e.publicId === null && (e.systemId === null || e.systemId === Om);
}
function Lm(e) {
	if (e.name !== Dm) return Rp.QUIRKS;
	let { systemId: t } = e;
	if (t && t.toLowerCase() === km) return Rp.QUIRKS;
	let { publicId: n } = e;
	if (n !== null) {
		if (n = n.toLowerCase(), Mm.has(n)) return Rp.QUIRKS;
		let e = t === null ? jm : Am;
		if (Fm(n, e)) return Rp.QUIRKS;
		if (e = t === null ? Nm : Pm, Fm(n, e)) return Rp.LIMITED_QUIRKS;
	}
	return Rp.NO_QUIRKS;
}
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/common/foreign-content.js
var Rm = {
	TEXT_HTML: "text/html",
	APPLICATION_XML: "application/xhtml+xml"
}, zm = "definitionurl", Bm = "definitionURL", Vm = new Map((/* @__PURE__ */ "attributeName.attributeType.baseFrequency.baseProfile.calcMode.clipPathUnits.diffuseConstant.edgeMode.filterUnits.glyphRef.gradientTransform.gradientUnits.kernelMatrix.kernelUnitLength.keyPoints.keySplines.keyTimes.lengthAdjust.limitingConeAngle.markerHeight.markerUnits.markerWidth.maskContentUnits.maskUnits.numOctaves.pathLength.patternContentUnits.patternTransform.patternUnits.pointsAtX.pointsAtY.pointsAtZ.preserveAlpha.preserveAspectRatio.primitiveUnits.refX.refY.repeatCount.repeatDur.requiredExtensions.requiredFeatures.specularConstant.specularExponent.spreadMethod.startOffset.stdDeviation.stitchTiles.surfaceScale.systemLanguage.tableValues.targetX.targetY.textLength.viewBox.viewTarget.xChannelSelector.yChannelSelector.zoomAndPan".split(".")).map((e) => [e.toLowerCase(), e])), Hm = new Map([
	["xlink:actuate", {
		prefix: "xlink",
		name: "actuate",
		namespace: q.XLINK
	}],
	["xlink:arcrole", {
		prefix: "xlink",
		name: "arcrole",
		namespace: q.XLINK
	}],
	["xlink:href", {
		prefix: "xlink",
		name: "href",
		namespace: q.XLINK
	}],
	["xlink:role", {
		prefix: "xlink",
		name: "role",
		namespace: q.XLINK
	}],
	["xlink:show", {
		prefix: "xlink",
		name: "show",
		namespace: q.XLINK
	}],
	["xlink:title", {
		prefix: "xlink",
		name: "title",
		namespace: q.XLINK
	}],
	["xlink:type", {
		prefix: "xlink",
		name: "type",
		namespace: q.XLINK
	}],
	["xml:lang", {
		prefix: "xml",
		name: "lang",
		namespace: q.XML
	}],
	["xml:space", {
		prefix: "xml",
		name: "space",
		namespace: q.XML
	}],
	["xmlns", {
		prefix: "",
		name: "xmlns",
		namespace: q.XMLNS
	}],
	["xmlns:xlink", {
		prefix: "xmlns",
		name: "xlink",
		namespace: q.XMLNS
	}]
]), Um = new Map((/* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.textPath".split(".")).map((e) => [e.toLowerCase(), e])), Wm = new Set([
	Y.B,
	Y.BIG,
	Y.BLOCKQUOTE,
	Y.BODY,
	Y.BR,
	Y.CENTER,
	Y.CODE,
	Y.DD,
	Y.DIV,
	Y.DL,
	Y.DT,
	Y.EM,
	Y.EMBED,
	Y.H1,
	Y.H2,
	Y.H3,
	Y.H4,
	Y.H5,
	Y.H6,
	Y.HEAD,
	Y.HR,
	Y.I,
	Y.IMG,
	Y.LI,
	Y.LISTING,
	Y.MENU,
	Y.META,
	Y.NOBR,
	Y.OL,
	Y.P,
	Y.PRE,
	Y.RUBY,
	Y.S,
	Y.SMALL,
	Y.SPAN,
	Y.STRONG,
	Y.STRIKE,
	Y.SUB,
	Y.SUP,
	Y.TABLE,
	Y.TT,
	Y.U,
	Y.UL,
	Y.VAR
]);
function Gm(e) {
	let t = e.tagID;
	return t === Y.FONT && e.attrs.some(({ name: e }) => e === Lp.COLOR || e === Lp.SIZE || e === Lp.FACE) || Wm.has(t);
}
function Km(e) {
	for (let t = 0; t < e.attrs.length; t++) if (e.attrs[t].name === zm) {
		e.attrs[t].name = Bm;
		break;
	}
}
function qm(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Vm.get(e.attrs[t].name);
		n != null && (e.attrs[t].name = n);
	}
}
function Jm(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Hm.get(e.attrs[t].name);
		n && (e.attrs[t].prefix = n.prefix, e.attrs[t].name = n.name, e.attrs[t].namespace = n.namespace);
	}
}
function Ym(e) {
	let t = Um.get(e.tagName);
	t != null && (e.tagName = t, e.tagID = Bp(e.tagName));
}
function Xm(e, t) {
	return t === q.MATHML && (e === Y.MI || e === Y.MO || e === Y.MN || e === Y.MS || e === Y.MTEXT);
}
function Zm(e, t, n) {
	if (t === q.MATHML && e === Y.ANNOTATION_XML) {
		for (let e = 0; e < n.length; e++) if (n[e].name === Lp.ENCODING) {
			let t = n[e].value.toLowerCase();
			return t === Rm.TEXT_HTML || t === Rm.APPLICATION_XML;
		}
	}
	return t === q.SVG && (e === Y.FOREIGN_OBJECT || e === Y.DESC || e === Y.TITLE);
}
function Qm(e, t, n, r) {
	return (!r || r === q.HTML) && Zm(e, t, n) || (!r || r === q.MATHML) && Xm(e, t);
}
//#endregion
//#region ../../node_modules/.bun/parse5@8.1.1/node_modules/parse5/dist/parser/index.js
var $m = [
	Y.TR,
	Y.TBODY,
	Y.THEAD,
	Y.TFOOT,
	Y.CAPTION,
	Y.COLGROUP,
	Y.TABLE,
	Y.FRAMESET,
	Y.SELECT,
	Y.TEMPLATE,
	Y.TD,
	Y.TH,
	Y.HEAD,
	Y.BODY,
	Y.HTML
], eh = "hidden", th = [], nh = 8, rh = 3, $;
(function(e) {
	e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})($ ||= {});
var ih = {
	startLine: -1,
	startCol: -1,
	startOffset: -1,
	endLine: -1,
	endCol: -1,
	endOffset: -1
}, ah = new Set([
	Y.TABLE,
	Y.TBODY,
	Y.TFOOT,
	Y.THEAD,
	Y.TR
]), oh = {
	scriptingEnabled: !0,
	sourceCodeLocationInfo: !1,
	treeAdapter: Em,
	onParseError: null
}, sh = class {
	constructor(e, t, n = null, r = null) {
		this.fragmentContext = n, this.scriptHandler = r, this.currentToken = null, this.stopped = !1, this.insertionMode = $.INITIAL, this.originalInsertionMode = $.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
			...oh,
			...e
		}, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = t ?? this.treeAdapter.createDocument(), this.tokenizer = new $p(this.options, this), this.activeFormattingElements = new wm(), this.fragmentContextID = n ? Bp(this.treeAdapter.getTagName(n)) : Y.UNKNOWN, this._setContextModes(n ?? this.document, this.fragmentContextID), this.openElements = new xm(this.document, this.treeAdapter, this);
	}
	static parse(e, t) {
		let n = new this(t);
		return n.tokenizer.write(e, !0), n.document;
	}
	static getFragmentParser(e, t) {
		let n = {
			...oh,
			...t
		};
		e ??= n.treeAdapter.createElement(J.TEMPLATE, q.HTML, []);
		let r = n.treeAdapter.createElement("documentmock", q.HTML, []), i = new this(n, r, e);
		return i.fragmentContextID === Y.TEMPLATE && i.tmplInsertionModeStack.push($.IN_TEMPLATE), i._initTokenizerForFragmentParsing(), i._insertFakeRootElement(), i._resetInsertionMode(), i._findFormInFragmentContext(), i;
	}
	getFragment() {
		let e = this.treeAdapter.getFirstChild(this.document), t = this.treeAdapter.createDocumentFragment();
		return this._adoptNodes(e, t), t;
	}
	_err(e, t, n) {
		if (!this.onParseError) return;
		let r = e.location ?? ih, i = {
			code: t,
			startLine: r.startLine,
			startCol: r.startCol,
			startOffset: r.startOffset,
			endLine: n ? r.startLine : r.endLine,
			endCol: n ? r.startCol : r.endCol,
			endOffset: n ? r.startOffset : r.endOffset
		};
		this.onParseError(i);
	}
	onItemPush(e, t, n) {
		var r, i;
		(i = (r = this.treeAdapter).onItemPush) == null || i.call(r, e), n && this.openElements.stackTop > 0 && this._setContextModes(e, t);
	}
	onItemPop(e, t) {
		var n, r, i;
		if (this.options.sourceCodeLocationInfo && this._setEndLocation(e, this.currentToken), (r = (n = this.treeAdapter).onItemPop) == null || r.call(n, e, this.openElements.current), (i = this.annotationXmlIntegrationPoints) == null || i.delete(e), t) {
			let e, t;
			this.openElements.stackTop === 0 && this.fragmentContext ? (e = this.fragmentContext, t = this.fragmentContextID) : {current: e, currentTagId: t} = this.openElements, this._setContextModes(e, t);
		}
	}
	_setContextModes(e, t) {
		let n = e === this.document || e && this.treeAdapter.getNamespaceURI(e) === q.HTML;
		this.currentNotInHTML = !n, this.tokenizer.inForeignNode = !n && e !== void 0 && t !== void 0 && !this._isIntegrationPoint(t, e);
	}
	_switchToTextParsing(e, t) {
		this._insertElement(e, q.HTML), this.tokenizer.state = t, this.originalInsertionMode = this.insertionMode, this.insertionMode = $.TEXT;
	}
	switchToPlaintextParsing() {
		this.insertionMode = $.TEXT, this.originalInsertionMode = $.IN_BODY, this.tokenizer.state = Q.PLAINTEXT;
	}
	_getAdjustedCurrentElement() {
		return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
	}
	_findFormInFragmentContext() {
		let e = this.fragmentContext;
		for (; e;) {
			if (this.treeAdapter.getTagName(e) === J.FORM && this.treeAdapter.getNamespaceURI(e) === q.HTML) {
				this.formElement = e;
				break;
			}
			e = this.treeAdapter.getParentNode(e);
		}
	}
	_initTokenizerForFragmentParsing() {
		if (!(!this.fragmentContext || this.treeAdapter.getNamespaceURI(this.fragmentContext) !== q.HTML)) switch (this.fragmentContextID) {
			case Y.TITLE:
			case Y.TEXTAREA:
				this.tokenizer.state = Q.RCDATA;
				break;
			case Y.STYLE:
			case Y.XMP:
			case Y.IFRAME:
			case Y.NOEMBED:
			case Y.NOFRAMES:
			case Y.NOSCRIPT:
				this.tokenizer.state = Q.RAWTEXT;
				break;
			case Y.SCRIPT:
				this.tokenizer.state = Q.SCRIPT_DATA;
				break;
			case Y.PLAINTEXT:
				this.tokenizer.state = Q.PLAINTEXT;
				break;
			default:
		}
	}
	_setDocumentType(e) {
		let t = e.name || "", n = e.publicId || "", r = e.systemId || "";
		if (this.treeAdapter.setDocumentType(this.document, t, n, r), e.location) {
			let t = this.treeAdapter.getChildNodes(this.document).find((e) => this.treeAdapter.isDocumentTypeNode(e));
			t && this.treeAdapter.setNodeSourceCodeLocation(t, e.location);
		}
	}
	_attachElementToTree(e, t, n) {
		if (this.options.sourceCodeLocationInfo) {
			let n = t && {
				...t,
				startTag: t
			};
			this.treeAdapter.setNodeSourceCodeLocation(e, n);
		}
		n.beforeElement ? this.treeAdapter.insertBefore(n.parent, e, n.beforeElement) : this.treeAdapter.appendChild(n.parent, e);
	}
	_getInsertionLocation() {
		return this._shouldFosterParentOnInsertion() ? this._findFosterParentingLocation() : {
			parent: this.openElements.currentTmplContentOrNode ?? this.document,
			beforeElement: null
		};
	}
	_createElement(e, t, n, r) {
		var i, a;
		let o = this.treeAdapter.createElement(e, t, n);
		return (a = (i = this.treeAdapter).onElementCreated) == null || a.call(i, o, {
			intendedParent: r,
			formElement: this.formElement,
			isInTemplate: this.openElements.tmplCount > 0
		}), o;
	}
	_appendElement(e, t) {
		let n = this._getInsertionLocation(), r = this._createElement(e.tagName, t, e.attrs, n.parent);
		this._attachElementToTree(r, e.location, n);
	}
	_insertElement(e, t) {
		let n = this._getInsertionLocation(), r = this._createElement(e.tagName, t, e.attrs, n.parent);
		this._attachElementToTree(r, e.location, n), this.openElements.push(r, e.tagID);
	}
	_insertFakeElement(e, t) {
		let n = this._getInsertionLocation(), r = this._createElement(e, q.HTML, [], n.parent);
		this._attachElementToTree(r, null, n), this.openElements.push(r, t);
	}
	_insertTemplate(e) {
		let t = this._getInsertionLocation(), n = this._createElement(e.tagName, q.HTML, e.attrs, t.parent), r = this.treeAdapter.createDocumentFragment();
		this.treeAdapter.setTemplateContent(n, r), this._attachElementToTree(n, e.location, t), this.openElements.push(n, e.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(r, null);
	}
	_insertFakeRootElement() {
		let e = this._createElement(J.HTML, q.HTML, [], this.document);
		this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(e, null), this.treeAdapter.appendChild(this.document, e), this.openElements.push(e, Y.HTML);
	}
	_appendCommentNode(e, t) {
		let n = this.treeAdapter.createCommentNode(e.data);
		this.treeAdapter.appendChild(t, n), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, e.location);
	}
	_insertCharacters(e) {
		let t, n;
		if (this._shouldFosterParentOnInsertion() ? ({parent: t, beforeElement: n} = this._findFosterParentingLocation(), n ? this.treeAdapter.insertTextBefore(t, e.chars, n) : this.treeAdapter.insertText(t, e.chars)) : (t = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(t, e.chars)), !e.location) return;
		let r = this.treeAdapter.getChildNodes(t), i = r[(n ? r.lastIndexOf(n) : r.length) - 1];
		if (this.treeAdapter.getNodeSourceCodeLocation(i)) {
			let { endLine: t, endCol: n, endOffset: r } = e.location;
			this.treeAdapter.updateNodeSourceCodeLocation(i, {
				endLine: t,
				endCol: n,
				endOffset: r
			});
		} else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(i, e.location);
	}
	_adoptNodes(e, t) {
		let n = [...this.treeAdapter.getChildNodes(e)];
		for (let e = n.length - 1; e >= 0; e--) this.treeAdapter.detachNode(n[e]);
		for (let e of n) this.treeAdapter.appendChild(t, e);
	}
	_setEndLocation(e, t) {
		if (this.treeAdapter.getNodeSourceCodeLocation(e) && t.location) {
			let n = t.location, r = this.treeAdapter.getTagName(e), i = t.type === K.END_TAG && r === t.tagName ? {
				endTag: { ...n },
				endLine: n.endLine,
				endCol: n.endCol,
				endOffset: n.endOffset
			} : {
				endLine: n.startLine,
				endCol: n.startCol,
				endOffset: n.startOffset
			};
			this.treeAdapter.updateNodeSourceCodeLocation(e, i);
		}
	}
	shouldProcessStartTagTokenInForeignContent(e) {
		if (!this.currentNotInHTML) return !1;
		let t, n;
		return this.openElements.stackTop === 0 && this.fragmentContext ? (t = this.fragmentContext, n = this.fragmentContextID) : {current: t, currentTagId: n} = this.openElements, e.tagID === Y.SVG && this.treeAdapter.getTagName(t) === J.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(t) === q.MATHML ? !1 : this.tokenizer.inForeignNode || (e.tagID === Y.MGLYPH || e.tagID === Y.MALIGNMARK) && n !== void 0 && !this._isIntegrationPoint(n, t, q.HTML);
	}
	_processToken(e) {
		switch (e.type) {
			case K.CHARACTER:
				this.onCharacter(e);
				break;
			case K.NULL_CHARACTER:
				this.onNullCharacter(e);
				break;
			case K.COMMENT:
				this.onComment(e);
				break;
			case K.DOCTYPE:
				this.onDoctype(e);
				break;
			case K.START_TAG:
				this._processStartTag(e);
				break;
			case K.END_TAG:
				this.onEndTag(e);
				break;
			case K.EOF:
				this.onEof(e);
				break;
			case K.WHITESPACE_CHARACTER:
				this.onWhitespaceCharacter(e);
				break;
		}
	}
	_isIntegrationPoint(e, t, n) {
		let r = this.treeAdapter.getNamespaceURI(t);
		if (e === Y.ANNOTATION_XML && r === q.MATHML && n !== q.MATHML) {
			let n = this.annotationXmlIntegrationPoints ??= /* @__PURE__ */ new Map(), i = n.get(t);
			return i === void 0 && (i = Qm(e, r, this.treeAdapter.getAttrList(t)), n.set(t, i)), i;
		}
		return Qm(e, r, th, n);
	}
	_reconstructActiveFormattingElements() {
		let e = null;
		for (let t = this.activeFormattingElements.newest; t !== null && t.type === Cm.Element && !this.openElements.contains(t.element); t = t.older) e = t;
		for (let t = e; t !== null && t.type === Cm.Element; t = t.newer) this._insertElement(t.token, this.treeAdapter.getNamespaceURI(t.element)), this.activeFormattingElements.replaceElement(t, this.openElements.current);
	}
	_closeTableCell() {
		this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = $.IN_ROW;
	}
	_closePElement() {
		this.openElements.generateImpliedEndTagsWithExclusion(Y.P), this.openElements.popUntilTagNamePopped(Y.P);
	}
	_resetInsertionMode() {
		let e = this.openElements.indexOfTopmostOf($m), t = e === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[e], n = e === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.items[e];
		if (n !== void 0 && this.treeAdapter.getNamespaceURI(n) === q.HTML) switch (t) {
			case Y.TR:
				this.insertionMode = $.IN_ROW;
				return;
			case Y.TBODY:
			case Y.THEAD:
			case Y.TFOOT:
				this.insertionMode = $.IN_TABLE_BODY;
				return;
			case Y.CAPTION:
				this.insertionMode = $.IN_CAPTION;
				return;
			case Y.COLGROUP:
				this.insertionMode = $.IN_COLUMN_GROUP;
				return;
			case Y.TABLE:
				this.insertionMode = $.IN_TABLE;
				return;
			case Y.BODY:
				this.insertionMode = $.IN_BODY;
				return;
			case Y.FRAMESET:
				this.insertionMode = $.IN_FRAMESET;
				return;
			case Y.SELECT:
				this._resetInsertionModeForSelect(e);
				return;
			case Y.TEMPLATE:
				this.insertionMode = this.tmplInsertionModeStack[this.tmplInsertionModeStack.length - 1];
				return;
			case Y.HTML:
				this.insertionMode = this.headElement ? $.AFTER_HEAD : $.BEFORE_HEAD;
				return;
			case Y.TD:
			case Y.TH:
				if (e > 0) {
					this.insertionMode = $.IN_CELL;
					return;
				}
				break;
			case Y.HEAD:
				if (e > 0) {
					this.insertionMode = $.IN_HEAD;
					return;
				}
				break;
		}
		this.insertionMode = $.IN_BODY;
	}
	_resetInsertionModeForSelect(e) {
		if (e > 0) {
			let e = this.openElements.indexOfTopmost(Y.TABLE);
			if (e > 0 && e > this.openElements.indexOfTopmost(Y.TEMPLATE)) {
				this.insertionMode = $.IN_SELECT_IN_TABLE;
				return;
			}
		}
		this.insertionMode = $.IN_SELECT;
	}
	_isElementCausesFosterParenting(e) {
		return ah.has(e);
	}
	_shouldFosterParentOnInsertion() {
		return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
	}
	_findFosterParentingLocation() {
		let { openElements: e } = this, t = e.indexOfTopmost(Y.TABLE), n = e.indexOfTopmost(Y.TEMPLATE);
		if (n > t) return {
			parent: this.treeAdapter.getTemplateContent(e.items[n]),
			beforeElement: null
		};
		if (t !== -1) {
			let n = e.items[t], r = this.treeAdapter.getParentNode(n);
			return r ? {
				parent: r,
				beforeElement: n
			} : {
				parent: e.items[e.slotBelow(t)],
				beforeElement: null
			};
		}
		return {
			parent: e.items[0],
			beforeElement: null
		};
	}
	_fosterParentElement(e) {
		let t = this._findFosterParentingLocation();
		t.beforeElement ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement) : this.treeAdapter.appendChild(t.parent, e);
	}
	_isSpecialElement(e, t) {
		return Vp[this.treeAdapter.getNamespaceURI(e)].has(t);
	}
	onCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
			T_(this, e);
			return;
		}
		switch (this.insertionMode) {
			case $.INITIAL:
				bh(this, e);
				break;
			case $.BEFORE_HTML:
				Ch(this, e);
				break;
			case $.BEFORE_HEAD:
				Eh(this, e);
				break;
			case $.IN_HEAD:
				Ah(this, e);
				break;
			case $.IN_HEAD_NO_SCRIPT:
				Nh(this, e);
				break;
			case $.AFTER_HEAD:
				Ih(this, e);
				break;
			case $.IN_BODY:
			case $.IN_CAPTION:
			case $.IN_CELL:
			case $.IN_TEMPLATE:
				zh(this, e);
				break;
			case $.TEXT:
			case $.IN_SELECT:
			case $.IN_SELECT_IN_TABLE:
				this._insertCharacters(e);
				break;
			case $.IN_TABLE:
			case $.IN_TABLE_BODY:
			case $.IN_ROW:
				Pg(this, e);
				break;
			case $.IN_TABLE_TEXT:
				qg(this, e);
				break;
			case $.IN_COLUMN_GROUP:
				e_(this, e);
				break;
			case $.AFTER_BODY:
				g_(this, e);
				break;
			case $.AFTER_AFTER_BODY:
				S_(this, e);
				break;
			default:
		}
	}
	onNullCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) {
			w_(this, e);
			return;
		}
		switch (this.insertionMode) {
			case $.INITIAL:
				bh(this, e);
				break;
			case $.BEFORE_HTML:
				Ch(this, e);
				break;
			case $.BEFORE_HEAD:
				Eh(this, e);
				break;
			case $.IN_HEAD:
				Ah(this, e);
				break;
			case $.IN_HEAD_NO_SCRIPT:
				Nh(this, e);
				break;
			case $.AFTER_HEAD:
				Ih(this, e);
				break;
			case $.TEXT:
				this._insertCharacters(e);
				break;
			case $.IN_TABLE:
			case $.IN_TABLE_BODY:
			case $.IN_ROW:
				Pg(this, e);
				break;
			case $.IN_COLUMN_GROUP:
				e_(this, e);
				break;
			case $.AFTER_BODY:
				g_(this, e);
				break;
			case $.AFTER_AFTER_BODY:
				S_(this, e);
				break;
			default:
		}
	}
	onComment(e) {
		if (this.skipNextNewLine = !1, this.currentNotInHTML) {
			hh(this, e);
			return;
		}
		switch (this.insertionMode) {
			case $.INITIAL:
			case $.BEFORE_HTML:
			case $.BEFORE_HEAD:
			case $.IN_HEAD:
			case $.IN_HEAD_NO_SCRIPT:
			case $.AFTER_HEAD:
			case $.IN_BODY:
			case $.IN_TABLE:
			case $.IN_CAPTION:
			case $.IN_COLUMN_GROUP:
			case $.IN_TABLE_BODY:
			case $.IN_ROW:
			case $.IN_CELL:
			case $.IN_SELECT:
			case $.IN_SELECT_IN_TABLE:
			case $.IN_TEMPLATE:
			case $.IN_FRAMESET:
			case $.AFTER_FRAMESET:
				hh(this, e);
				break;
			case $.IN_TABLE_TEXT:
				Jg(this, e);
				break;
			case $.AFTER_BODY:
				gh(this, e);
				break;
			case $.AFTER_AFTER_BODY:
			case $.AFTER_AFTER_FRAMESET:
				_h(this, e);
				break;
			default:
		}
	}
	onDoctype(e) {
		switch (this.skipNextNewLine = !1, this.insertionMode) {
			case $.INITIAL:
				yh(this, e);
				break;
			case $.BEFORE_HEAD:
			case $.IN_HEAD:
			case $.IN_HEAD_NO_SCRIPT:
			case $.AFTER_HEAD:
				this._err(e, G.misplacedDoctype);
				break;
			case $.IN_TABLE_TEXT:
				Jg(this, e);
				break;
			default:
		}
	}
	onStartTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this._processStartTag(e), e.selfClosing && !e.ackSelfClosing && this._err(e, G.nonVoidHtmlElementStartTagWithTrailingSolidus);
	}
	_processStartTag(e) {
		this.shouldProcessStartTagTokenInForeignContent(e) ? D_(this, e) : this._startTagOutsideForeignContent(e);
	}
	_startTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case $.INITIAL:
				bh(this, e);
				break;
			case $.BEFORE_HTML:
				xh(this, e);
				break;
			case $.BEFORE_HEAD:
				wh(this, e);
				break;
			case $.IN_HEAD:
				Dh(this, e);
				break;
			case $.IN_HEAD_NO_SCRIPT:
				jh(this, e);
				break;
			case $.AFTER_HEAD:
				Ph(this, e);
				break;
			case $.IN_BODY:
				vg(this, e);
				break;
			case $.IN_TABLE:
				Ug(this, e);
				break;
			case $.IN_TABLE_TEXT:
				Jg(this, e);
				break;
			case $.IN_CAPTION:
				Xg(this, e);
				break;
			case $.IN_COLUMN_GROUP:
				Qg(this, e);
				break;
			case $.IN_TABLE_BODY:
				t_(this, e);
				break;
			case $.IN_ROW:
				r_(this, e);
				break;
			case $.IN_CELL:
				a_(this, e);
				break;
			case $.IN_SELECT:
				s_(this, e);
				break;
			case $.IN_SELECT_IN_TABLE:
				l_(this, e);
				break;
			case $.IN_TEMPLATE:
				d_(this, e);
				break;
			case $.AFTER_BODY:
				m_(this, e);
				break;
			case $.IN_FRAMESET:
				__(this, e);
				break;
			case $.AFTER_FRAMESET:
				y_(this, e);
				break;
			case $.AFTER_AFTER_BODY:
				x_(this, e);
				break;
			case $.AFTER_AFTER_FRAMESET:
				C_(this, e);
				break;
			default:
		}
	}
	onEndTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this.currentNotInHTML ? O_(this, e) : this._endTagOutsideForeignContent(e);
	}
	_endTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case $.INITIAL:
				bh(this, e);
				break;
			case $.BEFORE_HTML:
				Sh(this, e);
				break;
			case $.BEFORE_HEAD:
				Th(this, e);
				break;
			case $.IN_HEAD:
				Oh(this, e);
				break;
			case $.IN_HEAD_NO_SCRIPT:
				Mh(this, e);
				break;
			case $.AFTER_HEAD:
				Fh(this, e);
				break;
			case $.IN_BODY:
				Ag(this, e);
				break;
			case $.TEXT:
				Mg(this, e);
				break;
			case $.IN_TABLE:
				Wg(this, e);
				break;
			case $.IN_TABLE_TEXT:
				Jg(this, e);
				break;
			case $.IN_CAPTION:
				Zg(this, e);
				break;
			case $.IN_COLUMN_GROUP:
				$g(this, e);
				break;
			case $.IN_TABLE_BODY:
				n_(this, e);
				break;
			case $.IN_ROW:
				i_(this, e);
				break;
			case $.IN_CELL:
				o_(this, e);
				break;
			case $.IN_SELECT:
				c_(this, e);
				break;
			case $.IN_SELECT_IN_TABLE:
				u_(this, e);
				break;
			case $.IN_TEMPLATE:
				f_(this, e);
				break;
			case $.AFTER_BODY:
				h_(this, e);
				break;
			case $.IN_FRAMESET:
				v_(this, e);
				break;
			case $.AFTER_FRAMESET:
				b_(this, e);
				break;
			case $.AFTER_AFTER_BODY:
				S_(this, e);
				break;
			default:
		}
	}
	onEof(e) {
		switch (this.insertionMode) {
			case $.INITIAL:
				bh(this, e);
				break;
			case $.BEFORE_HTML:
				Ch(this, e);
				break;
			case $.BEFORE_HEAD:
				Eh(this, e);
				break;
			case $.IN_HEAD:
				Ah(this, e);
				break;
			case $.IN_HEAD_NO_SCRIPT:
				Nh(this, e);
				break;
			case $.AFTER_HEAD:
				Ih(this, e);
				break;
			case $.IN_BODY:
			case $.IN_TABLE:
			case $.IN_CAPTION:
			case $.IN_COLUMN_GROUP:
			case $.IN_TABLE_BODY:
			case $.IN_ROW:
			case $.IN_CELL:
			case $.IN_SELECT:
			case $.IN_SELECT_IN_TABLE:
				jg(this, e);
				break;
			case $.TEXT:
				Ng(this, e);
				break;
			case $.IN_TABLE_TEXT:
				Jg(this, e);
				break;
			case $.IN_TEMPLATE:
				p_(this, e);
				break;
			case $.AFTER_BODY:
			case $.IN_FRAMESET:
			case $.AFTER_FRAMESET:
			case $.AFTER_AFTER_BODY:
			case $.AFTER_AFTER_FRAMESET:
				vh(this, e);
				break;
			default:
		}
	}
	onWhitespaceCharacter(e) {
		if (this.skipNextNewLine && (this.skipNextNewLine = !1, e.chars.charCodeAt(0) === W.LINE_FEED)) {
			if (e.chars.length === 1) return;
			e.chars = e.chars.substr(1);
		}
		if (this.tokenizer.inForeignNode) {
			this._insertCharacters(e);
			return;
		}
		switch (this.insertionMode) {
			case $.IN_HEAD:
			case $.IN_HEAD_NO_SCRIPT:
			case $.AFTER_HEAD:
			case $.TEXT:
			case $.IN_COLUMN_GROUP:
			case $.IN_SELECT:
			case $.IN_SELECT_IN_TABLE:
			case $.IN_FRAMESET:
			case $.AFTER_FRAMESET:
				this._insertCharacters(e);
				break;
			case $.IN_BODY:
			case $.IN_CAPTION:
			case $.IN_CELL:
			case $.IN_TEMPLATE:
			case $.AFTER_BODY:
			case $.AFTER_AFTER_BODY:
			case $.AFTER_AFTER_FRAMESET:
				Rh(this, e);
				break;
			case $.IN_TABLE:
			case $.IN_TABLE_BODY:
			case $.IN_ROW:
				Pg(this, e);
				break;
			case $.IN_TABLE_TEXT:
				Kg(this, e);
				break;
			default:
		}
	}
};
function ch(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
	return n ? e.openElements.contains(n.element) ? e.openElements.hasInScope(t.tagID, n.element) || (n = null) : (e.activeFormattingElements.removeEntry(n), n = null) : kg(e, t), n;
}
function lh(e, t) {
	let { openElements: n } = e, r = n._indexOf(t.element);
	for (let t = n.slotAbove(r); t !== -1; t = n.slotAbove(t)) if (e._isSpecialElement(n.items[t], n.tagIDs[t])) return t;
	return n.shortenToLength(r), e.activeFormattingElements.removeEntry(t), -1;
}
function uh(e, t, n) {
	let r = e.openElements.items[t], i = r, a = e.openElements.slotBelow(t), o = e.openElements.getCommonAncestor(n);
	for (let t = 0, s = a; e.openElements.items[s] !== n; t++, s = a) {
		let n = e.openElements.items[s];
		a = e.openElements.slotBelow(s);
		let c = e.activeFormattingElements.getElementEntry(n), l = c && t >= rh;
		!c || l ? (l && e.activeFormattingElements.removeEntry(c), e.openElements.removeAt(s)) : (n = dh(e, c, o), i === r && (e.activeFormattingElements.bookmark = c), e.treeAdapter.detachNode(i), e.treeAdapter.appendChild(n, i), i = n);
	}
	return i;
}
function dh(e, t, n) {
	let r = e.treeAdapter.getNamespaceURI(t.element), i = e._createElement(t.token.tagName, r, t.token.attrs, n);
	return e.openElements.replace(t.element, i), e.activeFormattingElements.replaceElement(t, i), i;
}
function fh(e, t, n) {
	let r = Bp(e.treeAdapter.getTagName(t));
	if (e._isElementCausesFosterParenting(r)) e._fosterParentElement(n);
	else {
		let i = e.treeAdapter.getNamespaceURI(t);
		r === Y.TEMPLATE && i === q.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, n);
	}
}
function ph(e, t, n) {
	let r = e.treeAdapter.getNamespaceURI(n.element), { token: i } = n, a = e._createElement(i.tagName, r, i.attrs, t);
	e._adoptNodes(t, a), e.treeAdapter.appendChild(t, a), e.activeFormattingElements.insertElementAfterBookmark(a, i), e.activeFormattingElements.removeEntry(n);
	let o = e.openElements._indexOf(n.element), s = e.openElements.slotAbove(o);
	for (; e.openElements.items[s] !== t;) s = e.openElements.slotAbove(s);
	e.openElements.replaceFormattingElement(o, s, a, i.tagID);
}
function mh(e, t) {
	let { current: n, currentTagId: r } = e.openElements;
	if (r === t.tagID && e.treeAdapter.getNamespaceURI(n) === q.HTML && !e.activeFormattingElements.getElementEntry(n)) {
		e.openElements.pop();
		return;
	}
	for (let n = 0; n < nh; n++) {
		let n = ch(e, t);
		if (!n) break;
		let r = lh(e, n);
		if (r === -1) break;
		let i = e.openElements.items[r];
		e.activeFormattingElements.bookmark = n;
		let a = uh(e, r, n.element), o = e.openElements.getCommonAncestor(n.element);
		e.treeAdapter.detachNode(a), o && fh(e, o, a), ph(e, i, n);
	}
}
function hh(e, t) {
	e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function gh(e, t) {
	e._appendCommentNode(t, e.openElements.items[0]);
}
function _h(e, t) {
	e._appendCommentNode(t, e.document);
}
function vh(e, t) {
	if (e.stopped = !0, t.location) {
		let n = e.fragmentContext ? 0 : 2;
		for (let r = e.openElements.stackTop; r >= n; r = e.openElements.slotBelow(r)) e._setEndLocation(e.openElements.items[r], t);
		if (!e.fragmentContext && e.openElements.stackTop >= 0) {
			let n = e.openElements.items[0], r = e.treeAdapter.getNodeSourceCodeLocation(n);
			if (r && !r.endTag && (e._setEndLocation(n, t), e.openElements.stackTop >= 1)) {
				let n = e.openElements.items[1], r = e.treeAdapter.getNodeSourceCodeLocation(n);
				r && !r.endTag && e._setEndLocation(n, t);
			}
		}
	}
}
function yh(e, t) {
	e._setDocumentType(t);
	let n = t.forceQuirks ? Rp.QUIRKS : Lm(t);
	Im(t) || e._err(t, G.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, n), e.insertionMode = $.BEFORE_HTML;
}
function bh(e, t) {
	e._err(t, G.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, Rp.QUIRKS), e.insertionMode = $.BEFORE_HTML, e._processToken(t);
}
function xh(e, t) {
	t.tagID === Y.HTML ? (e._insertElement(t, q.HTML), e.insertionMode = $.BEFORE_HEAD) : Ch(e, t);
}
function Sh(e, t) {
	let n = t.tagID;
	(n === Y.HTML || n === Y.HEAD || n === Y.BODY || n === Y.BR) && Ch(e, t);
}
function Ch(e, t) {
	e._insertFakeRootElement(), e.insertionMode = $.BEFORE_HEAD, e._processToken(t);
}
function wh(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.HEAD:
			e._insertElement(t, q.HTML), e.headElement = e.openElements.current, e.insertionMode = $.IN_HEAD;
			break;
		default: Eh(e, t);
	}
}
function Th(e, t) {
	let n = t.tagID;
	n === Y.HEAD || n === Y.BODY || n === Y.HTML || n === Y.BR ? Eh(e, t) : e._err(t, G.endTagWithoutMatchingOpenElement);
}
function Eh(e, t) {
	e._insertFakeElement(J.HEAD, Y.HEAD), e.headElement = e.openElements.current, e.insertionMode = $.IN_HEAD, e._processToken(t);
}
function Dh(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.BASE:
		case Y.BASEFONT:
		case Y.BGSOUND:
		case Y.LINK:
		case Y.META:
			e._appendElement(t, q.HTML), t.ackSelfClosing = !0;
			break;
		case Y.TITLE:
			e._switchToTextParsing(t, Q.RCDATA);
			break;
		case Y.NOSCRIPT:
			e.options.scriptingEnabled ? e._switchToTextParsing(t, Q.RAWTEXT) : (e._insertElement(t, q.HTML), e.insertionMode = $.IN_HEAD_NO_SCRIPT);
			break;
		case Y.NOFRAMES:
		case Y.STYLE:
			e._switchToTextParsing(t, Q.RAWTEXT);
			break;
		case Y.SCRIPT:
			e._switchToTextParsing(t, Q.SCRIPT_DATA);
			break;
		case Y.TEMPLATE:
			e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = $.IN_TEMPLATE, e.tmplInsertionModeStack.push($.IN_TEMPLATE);
			break;
		case Y.HEAD:
			e._err(t, G.misplacedStartTagForHeadElement);
			break;
		default: Ah(e, t);
	}
}
function Oh(e, t) {
	switch (t.tagID) {
		case Y.HEAD:
			e.openElements.pop(), e.insertionMode = $.AFTER_HEAD;
			break;
		case Y.BODY:
		case Y.BR:
		case Y.HTML:
			Ah(e, t);
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		default: e._err(t, G.endTagWithoutMatchingOpenElement);
	}
}
function kh(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== Y.TEMPLATE && e._err(t, G.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(Y.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.pop(), e._resetInsertionMode()) : e._err(t, G.endTagWithoutMatchingOpenElement);
}
function Ah(e, t) {
	e.openElements.pop(), e.insertionMode = $.AFTER_HEAD, e._processToken(t);
}
function jh(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.BASEFONT:
		case Y.BGSOUND:
		case Y.HEAD:
		case Y.LINK:
		case Y.META:
		case Y.NOFRAMES:
		case Y.STYLE:
			Dh(e, t);
			break;
		case Y.NOSCRIPT:
			e._err(t, G.nestedNoscriptInHead);
			break;
		default: Nh(e, t);
	}
}
function Mh(e, t) {
	switch (t.tagID) {
		case Y.NOSCRIPT:
			e.openElements.pop(), e.insertionMode = $.IN_HEAD;
			break;
		case Y.BR:
			Nh(e, t);
			break;
		default: e._err(t, G.endTagWithoutMatchingOpenElement);
	}
}
function Nh(e, t) {
	let n = t.type === K.EOF ? G.openElementsLeftAfterEof : G.disallowedContentInNoscriptInHead;
	e._err(t, n), e.openElements.pop(), e.insertionMode = $.IN_HEAD, e._processToken(t);
}
function Ph(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.BODY:
			e._insertElement(t, q.HTML), e.framesetOk = !1, e.insertionMode = $.IN_BODY;
			break;
		case Y.FRAMESET:
			e._insertElement(t, q.HTML), e.insertionMode = $.IN_FRAMESET;
			break;
		case Y.BASE:
		case Y.BASEFONT:
		case Y.BGSOUND:
		case Y.LINK:
		case Y.META:
		case Y.NOFRAMES:
		case Y.SCRIPT:
		case Y.STYLE:
		case Y.TEMPLATE:
		case Y.TITLE:
			e._err(t, G.abandonedHeadElementChild), e.openElements.push(e.headElement, Y.HEAD), Dh(e, t), e.openElements.remove(e.headElement);
			break;
		case Y.HEAD:
			e._err(t, G.misplacedStartTagForHeadElement);
			break;
		default: Ih(e, t);
	}
}
function Fh(e, t) {
	switch (t.tagID) {
		case Y.BODY:
		case Y.HTML:
		case Y.BR:
			Ih(e, t);
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		default: e._err(t, G.endTagWithoutMatchingOpenElement);
	}
}
function Ih(e, t) {
	e._insertFakeElement(J.BODY, Y.BODY), e.insertionMode = $.IN_BODY, Lh(e, t);
}
function Lh(e, t) {
	switch (t.type) {
		case K.CHARACTER:
			zh(e, t);
			break;
		case K.WHITESPACE_CHARACTER:
			Rh(e, t);
			break;
		case K.COMMENT:
			hh(e, t);
			break;
		case K.START_TAG:
			vg(e, t);
			break;
		case K.END_TAG:
			Ag(e, t);
			break;
		case K.EOF:
			jg(e, t);
			break;
		default:
	}
}
function Rh(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function zh(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function Bh(e, t) {
	e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Vh(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	n && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(n, t.attrs));
}
function Hh(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	e.framesetOk && n && (e.treeAdapter.detachNode(n), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_FRAMESET);
}
function Uh(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML);
}
function Wh(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && Hp.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, q.HTML);
}
function Gh(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function Kh(e, t) {
	let n = e.openElements.tmplCount > 0;
	(!e.formElement || n) && (e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML), n || (e.formElement = e.openElements.current));
}
function qh(e, t) {
	e.framesetOk = !1;
	let n = t.tagID === Y.LI ? e.openElements.indexOfTopmost(Y.LI) : Math.max(e.openElements.indexOfTopmost(Y.DD), e.openElements.indexOfTopmost(Y.DT));
	if (n !== -1 && !e.openElements.hasListItemBoundaryAbove(n)) {
		let t = e.openElements.tagIDs[n];
		e.openElements.generateImpliedEndTagsWithExclusion(t), e.openElements.popUntilTagNamePopped(t);
	}
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML);
}
function Jh(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML), e.tokenizer.state = Q.PLAINTEXT;
}
function Yh(e, t) {
	e.openElements.hasInScope(Y.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Y.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML), e.framesetOk = !1;
}
function Xh(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(J.A);
	n && (mh(e, t), e.openElements.remove(n.element), e.activeFormattingElements.removeEntry(n)), e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Zh(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Qh(e, t) {
	e._reconstructActiveFormattingElements(), e.openElements.hasInScope(Y.NOBR) && (mh(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, q.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function $h(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function eg(e, t) {
	e.treeAdapter.getDocumentMode(e.document) !== Rp.QUIRKS && e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._insertElement(t, q.HTML), e.framesetOk = !1, e.insertionMode = $.IN_TABLE;
}
function tg(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, q.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function ng(e) {
	let t = Hf(e, Lp.TYPE);
	return t != null && t.toLowerCase() === eh;
}
function rg(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, q.HTML), ng(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function ig(e, t) {
	e._appendElement(t, q.HTML), t.ackSelfClosing = !0;
}
function ag(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._appendElement(t, q.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function og(e, t) {
	t.tagName = J.IMG, t.tagID = Y.IMG, tg(e, t);
}
function sg(e, t) {
	e._insertElement(t, q.HTML), e.skipNextNewLine = !0, e.tokenizer.state = Q.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = $.TEXT;
}
function cg(e, t) {
	e.openElements.hasInButtonScope(Y.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, Q.RAWTEXT);
}
function lg(e, t) {
	e.framesetOk = !1, e._switchToTextParsing(t, Q.RAWTEXT);
}
function ug(e, t) {
	e._switchToTextParsing(t, Q.RAWTEXT);
}
function dg(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === $.IN_TABLE || e.insertionMode === $.IN_CAPTION || e.insertionMode === $.IN_TABLE_BODY || e.insertionMode === $.IN_ROW || e.insertionMode === $.IN_CELL ? $.IN_SELECT_IN_TABLE : $.IN_SELECT;
}
function fg(e, t) {
	e.openElements.currentTagId === Y.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML);
}
function pg(e, t) {
	e.openElements.hasInScope(Y.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, q.HTML);
}
function mg(e, t) {
	e.openElements.hasInScope(Y.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(Y.RTC), e._insertElement(t, q.HTML);
}
function hg(e, t) {
	e._reconstructActiveFormattingElements(), Km(t), Jm(t), t.selfClosing ? e._appendElement(t, q.MATHML) : e._insertElement(t, q.MATHML), t.ackSelfClosing = !0;
}
function gg(e, t) {
	e._reconstructActiveFormattingElements(), qm(t), Jm(t), t.selfClosing ? e._appendElement(t, q.SVG) : e._insertElement(t, q.SVG), t.ackSelfClosing = !0;
}
function _g(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, q.HTML);
}
function vg(e, t) {
	switch (t.tagID) {
		case Y.I:
		case Y.S:
		case Y.B:
		case Y.U:
		case Y.EM:
		case Y.TT:
		case Y.BIG:
		case Y.CODE:
		case Y.FONT:
		case Y.SMALL:
		case Y.STRIKE:
		case Y.STRONG:
			Zh(e, t);
			break;
		case Y.A:
			Xh(e, t);
			break;
		case Y.H1:
		case Y.H2:
		case Y.H3:
		case Y.H4:
		case Y.H5:
		case Y.H6:
			Wh(e, t);
			break;
		case Y.P:
		case Y.DL:
		case Y.OL:
		case Y.UL:
		case Y.DIV:
		case Y.DIR:
		case Y.NAV:
		case Y.MAIN:
		case Y.MENU:
		case Y.ASIDE:
		case Y.CENTER:
		case Y.FIGURE:
		case Y.FOOTER:
		case Y.HEADER:
		case Y.HGROUP:
		case Y.DIALOG:
		case Y.DETAILS:
		case Y.ADDRESS:
		case Y.ARTICLE:
		case Y.SEARCH:
		case Y.SECTION:
		case Y.SUMMARY:
		case Y.FIELDSET:
		case Y.BLOCKQUOTE:
		case Y.FIGCAPTION:
			Uh(e, t);
			break;
		case Y.LI:
		case Y.DD:
		case Y.DT:
			qh(e, t);
			break;
		case Y.BR:
		case Y.IMG:
		case Y.WBR:
		case Y.AREA:
		case Y.EMBED:
		case Y.KEYGEN:
			tg(e, t);
			break;
		case Y.HR:
			ag(e, t);
			break;
		case Y.RB:
		case Y.RTC:
			pg(e, t);
			break;
		case Y.RT:
		case Y.RP:
			mg(e, t);
			break;
		case Y.PRE:
		case Y.LISTING:
			Gh(e, t);
			break;
		case Y.XMP:
			cg(e, t);
			break;
		case Y.SVG:
			gg(e, t);
			break;
		case Y.HTML:
			Bh(e, t);
			break;
		case Y.BASE:
		case Y.LINK:
		case Y.META:
		case Y.STYLE:
		case Y.TITLE:
		case Y.SCRIPT:
		case Y.BGSOUND:
		case Y.BASEFONT:
		case Y.TEMPLATE:
			Dh(e, t);
			break;
		case Y.BODY:
			Vh(e, t);
			break;
		case Y.FORM:
			Kh(e, t);
			break;
		case Y.NOBR:
			Qh(e, t);
			break;
		case Y.MATH:
			hg(e, t);
			break;
		case Y.TABLE:
			eg(e, t);
			break;
		case Y.INPUT:
			rg(e, t);
			break;
		case Y.PARAM:
		case Y.TRACK:
		case Y.SOURCE:
			ig(e, t);
			break;
		case Y.IMAGE:
			og(e, t);
			break;
		case Y.BUTTON:
			Yh(e, t);
			break;
		case Y.APPLET:
		case Y.OBJECT:
		case Y.MARQUEE:
			$h(e, t);
			break;
		case Y.IFRAME:
			lg(e, t);
			break;
		case Y.SELECT:
			dg(e, t);
			break;
		case Y.OPTION:
		case Y.OPTGROUP:
			fg(e, t);
			break;
		case Y.NOEMBED:
		case Y.NOFRAMES:
			ug(e, t);
			break;
		case Y.FRAMESET:
			Hh(e, t);
			break;
		case Y.TEXTAREA:
			sg(e, t);
			break;
		case Y.NOSCRIPT:
			e.options.scriptingEnabled ? ug(e, t) : _g(e, t);
			break;
		case Y.PLAINTEXT:
			Jh(e, t);
			break;
		case Y.COL:
		case Y.TH:
		case Y.TD:
		case Y.TR:
		case Y.HEAD:
		case Y.FRAME:
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
		case Y.CAPTION:
		case Y.COLGROUP: break;
		default: _g(e, t);
	}
}
function yg(e, t) {
	if (e.openElements.hasInScope(Y.BODY) && (e.insertionMode = $.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
		let n = e.openElements.tryPeekProperlyNestedBodyElement();
		n && e._setEndLocation(n, t);
	}
}
function bg(e, t) {
	e.openElements.hasInScope(Y.BODY) && (e.insertionMode = $.AFTER_BODY, h_(e, t));
}
function xg(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n));
}
function Sg(e) {
	let t = e.openElements.tmplCount > 0, { formElement: n } = e;
	t || (e.formElement = null), (n || t) && e.openElements.hasInScope(Y.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(Y.FORM) : n && e.openElements.remove(n));
}
function Cg(e) {
	e.openElements.hasInButtonScope(Y.P) || e._insertFakeElement(J.P, Y.P), e._closePElement();
}
function wg(e) {
	e.openElements.hasInListItemScope(Y.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(Y.LI), e.openElements.popUntilTagNamePopped(Y.LI));
}
function Tg(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTagsWithExclusion(n), e.openElements.popUntilTagNamePopped(n));
}
function Eg(e) {
	e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function Dg(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker());
}
function Og(e) {
	e._reconstructActiveFormattingElements(), e._insertFakeElement(J.BR, Y.BR), e.openElements.pop(), e.framesetOk = !1;
}
function kg(e, t) {
	let n = t.tagID, r = n === Y.UNKNOWN ? e.openElements.indexOfTopmostByName(q.HTML, t.tagName) : e.openElements.indexOfTopmost(n);
	r > 0 && !e.openElements.hasSpecialElementAbove(r) && (e.openElements.generateImpliedEndTagsWithExclusion(n), e.openElements.stackTop >= r && e.openElements.shortenToLength(r));
}
function Ag(e, t) {
	switch (t.tagID) {
		case Y.A:
		case Y.B:
		case Y.I:
		case Y.S:
		case Y.U:
		case Y.EM:
		case Y.TT:
		case Y.BIG:
		case Y.CODE:
		case Y.FONT:
		case Y.NOBR:
		case Y.SMALL:
		case Y.STRIKE:
		case Y.STRONG:
			mh(e, t);
			break;
		case Y.P:
			Cg(e);
			break;
		case Y.DL:
		case Y.UL:
		case Y.OL:
		case Y.DIR:
		case Y.DIV:
		case Y.NAV:
		case Y.PRE:
		case Y.MAIN:
		case Y.MENU:
		case Y.ASIDE:
		case Y.BUTTON:
		case Y.CENTER:
		case Y.FIGURE:
		case Y.FOOTER:
		case Y.HEADER:
		case Y.HGROUP:
		case Y.DIALOG:
		case Y.ADDRESS:
		case Y.ARTICLE:
		case Y.DETAILS:
		case Y.SEARCH:
		case Y.SECTION:
		case Y.SUMMARY:
		case Y.LISTING:
		case Y.FIELDSET:
		case Y.BLOCKQUOTE:
		case Y.FIGCAPTION:
			xg(e, t);
			break;
		case Y.LI:
			wg(e);
			break;
		case Y.DD:
		case Y.DT:
			Tg(e, t);
			break;
		case Y.H1:
		case Y.H2:
		case Y.H3:
		case Y.H4:
		case Y.H5:
		case Y.H6:
			Eg(e);
			break;
		case Y.BR:
			Og(e);
			break;
		case Y.BODY:
			yg(e, t);
			break;
		case Y.HTML:
			bg(e, t);
			break;
		case Y.FORM:
			Sg(e);
			break;
		case Y.APPLET:
		case Y.OBJECT:
		case Y.MARQUEE:
			Dg(e, t);
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		default: kg(e, t);
	}
}
function jg(e, t) {
	e.tmplInsertionModeStack.length > 0 ? p_(e, t) : vh(e, t);
}
function Mg(e, t) {
	var n;
	t.tagID === Y.SCRIPT && ((n = e.scriptHandler) == null || n.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function Ng(e, t) {
	e._err(t, G.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function Pg(e, t) {
	if (e.openElements.currentTagId !== void 0 && ah.has(e.openElements.currentTagId)) switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = $.IN_TABLE_TEXT, t.type) {
		case K.CHARACTER:
			qg(e, t);
			break;
		case K.WHITESPACE_CHARACTER:
			Kg(e, t);
			break;
	}
	else Gg(e, t);
}
function Fg(e, t) {
	e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_CAPTION;
}
function Ig(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_COLUMN_GROUP;
}
function Lg(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(J.COLGROUP, Y.COLGROUP), e.insertionMode = $.IN_COLUMN_GROUP, Qg(e, t);
}
function Rg(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_TABLE_BODY;
}
function zg(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(J.TBODY, Y.TBODY), e.insertionMode = $.IN_TABLE_BODY, t_(e, t);
}
function Bg(e, t) {
	e.openElements.hasInTableScope(Y.TABLE) && (e.openElements.popUntilTagNamePopped(Y.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function Vg(e, t) {
	ng(t) ? e._appendElement(t, q.HTML) : Gg(e, t), t.ackSelfClosing = !0;
}
function Hg(e, t) {
	!e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, q.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function Ug(e, t) {
	switch (t.tagID) {
		case Y.TD:
		case Y.TH:
		case Y.TR:
			zg(e, t);
			break;
		case Y.STYLE:
		case Y.SCRIPT:
		case Y.TEMPLATE:
			Dh(e, t);
			break;
		case Y.COL:
			Lg(e, t);
			break;
		case Y.FORM:
			Hg(e, t);
			break;
		case Y.TABLE:
			Bg(e, t);
			break;
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
			Rg(e, t);
			break;
		case Y.INPUT:
			Vg(e, t);
			break;
		case Y.CAPTION:
			Fg(e, t);
			break;
		case Y.COLGROUP:
			Ig(e, t);
			break;
		default: Gg(e, t);
	}
}
function Wg(e, t) {
	switch (t.tagID) {
		case Y.TABLE:
			e.openElements.hasInTableScope(Y.TABLE) && (e.openElements.popUntilTagNamePopped(Y.TABLE), e._resetInsertionMode());
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		case Y.BODY:
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.HTML:
		case Y.TBODY:
		case Y.TD:
		case Y.TFOOT:
		case Y.TH:
		case Y.THEAD:
		case Y.TR: break;
		default: Gg(e, t);
	}
}
function Gg(e, t) {
	let n = e.fosterParentingEnabled;
	e.fosterParentingEnabled = !0, Lh(e, t), e.fosterParentingEnabled = n;
}
function Kg(e, t) {
	e.pendingCharacterTokens.push(t);
}
function qg(e, t) {
	e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function Jg(e, t) {
	let n = 0;
	if (e.hasNonWhitespacePendingCharacterToken) for (; n < e.pendingCharacterTokens.length; n++) Gg(e, e.pendingCharacterTokens[n]);
	else for (; n < e.pendingCharacterTokens.length; n++) e._insertCharacters(e.pendingCharacterTokens[n]);
	e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
var Yg = new Set([
	Y.CAPTION,
	Y.COL,
	Y.COLGROUP,
	Y.TBODY,
	Y.TD,
	Y.TFOOT,
	Y.TH,
	Y.THEAD,
	Y.TR
]);
function Xg(e, t) {
	let n = t.tagID;
	Yg.has(n) ? e.openElements.hasInTableScope(Y.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Y.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = $.IN_TABLE, Ug(e, t)) : vg(e, t);
}
function Zg(e, t) {
	let n = t.tagID;
	switch (n) {
		case Y.CAPTION:
		case Y.TABLE:
			e.openElements.hasInTableScope(Y.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Y.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = $.IN_TABLE, n === Y.TABLE && Wg(e, t));
			break;
		case Y.BODY:
		case Y.COL:
		case Y.COLGROUP:
		case Y.HTML:
		case Y.TBODY:
		case Y.TD:
		case Y.TFOOT:
		case Y.TH:
		case Y.THEAD:
		case Y.TR: break;
		default: Ag(e, t);
	}
}
function Qg(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.COL:
			e._appendElement(t, q.HTML), t.ackSelfClosing = !0;
			break;
		case Y.TEMPLATE:
			Dh(e, t);
			break;
		default: e_(e, t);
	}
}
function $g(e, t) {
	switch (t.tagID) {
		case Y.COLGROUP:
			e.openElements.currentTagId === Y.COLGROUP && (e.openElements.pop(), e.insertionMode = $.IN_TABLE);
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		case Y.COL: break;
		default: e_(e, t);
	}
}
function e_(e, t) {
	e.openElements.currentTagId === Y.COLGROUP && (e.openElements.pop(), e.insertionMode = $.IN_TABLE, e._processToken(t));
}
function t_(e, t) {
	switch (t.tagID) {
		case Y.TR:
			e.openElements.clearBackToTableBodyContext(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_ROW;
			break;
		case Y.TH:
		case Y.TD:
			e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(J.TR, Y.TR), e.insertionMode = $.IN_ROW, r_(e, t);
			break;
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE, Ug(e, t));
			break;
		default: Ug(e, t);
	}
}
function n_(e, t) {
	let n = t.tagID;
	switch (t.tagID) {
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
			e.openElements.hasInTableScope(n) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE);
			break;
		case Y.TABLE:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE, Wg(e, t));
			break;
		case Y.BODY:
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.HTML:
		case Y.TD:
		case Y.TH:
		case Y.TR: break;
		default: Wg(e, t);
	}
}
function r_(e, t) {
	switch (t.tagID) {
		case Y.TH:
		case Y.TD:
			e.openElements.clearBackToTableRowContext(), e._insertElement(t, q.HTML), e.insertionMode = $.IN_CELL, e.activeFormattingElements.insertMarker();
			break;
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
		case Y.TR:
			e.openElements.hasInTableScope(Y.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE_BODY, t_(e, t));
			break;
		default: Ug(e, t);
	}
}
function i_(e, t) {
	switch (t.tagID) {
		case Y.TR:
			e.openElements.hasInTableScope(Y.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE_BODY);
			break;
		case Y.TABLE:
			e.openElements.hasInTableScope(Y.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE_BODY, n_(e, t));
			break;
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
			(e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(Y.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = $.IN_TABLE_BODY, n_(e, t));
			break;
		case Y.BODY:
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.HTML:
		case Y.TD:
		case Y.TH: break;
		default: Wg(e, t);
	}
}
function a_(e, t) {
	let n = t.tagID;
	Yg.has(n) ? (e.openElements.hasInTableScope(Y.TD) || e.openElements.hasInTableScope(Y.TH)) && (e._closeTableCell(), r_(e, t)) : vg(e, t);
}
function o_(e, t) {
	let n = t.tagID;
	switch (n) {
		case Y.TD:
		case Y.TH:
			e.openElements.hasInTableScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = $.IN_ROW);
			break;
		case Y.TABLE:
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
		case Y.TR:
			e.openElements.hasInTableScope(n) && (e._closeTableCell(), i_(e, t));
			break;
		case Y.BODY:
		case Y.CAPTION:
		case Y.COL:
		case Y.COLGROUP:
		case Y.HTML: break;
		default: Ag(e, t);
	}
}
function s_(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.OPTION:
			e.openElements.currentTagId === Y.OPTION && e.openElements.pop(), e._insertElement(t, q.HTML);
			break;
		case Y.OPTGROUP:
			e.openElements.currentTagId === Y.OPTION && e.openElements.pop(), e.openElements.currentTagId === Y.OPTGROUP && e.openElements.pop(), e._insertElement(t, q.HTML);
			break;
		case Y.HR:
			e.openElements.currentTagId === Y.OPTION && e.openElements.pop(), e.openElements.currentTagId === Y.OPTGROUP && e.openElements.pop(), e._appendElement(t, q.HTML), t.ackSelfClosing = !0;
			break;
		case Y.INPUT:
		case Y.KEYGEN:
		case Y.TEXTAREA:
		case Y.SELECT:
			e.openElements.hasInSelectScope(Y.SELECT) && (e.openElements.popUntilTagNamePopped(Y.SELECT), e._resetInsertionMode(), t.tagID !== Y.SELECT && e._processStartTag(t));
			break;
		case Y.SCRIPT:
		case Y.TEMPLATE:
			Dh(e, t);
			break;
		default:
	}
}
function c_(e, t) {
	switch (t.tagID) {
		case Y.OPTGROUP:
			e.openElements.stackTop > 0 && e.openElements.currentTagId === Y.OPTION && e.openElements.tagIDs[e.openElements.slotBelow(e.openElements.stackTop)] === Y.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === Y.OPTGROUP && e.openElements.pop();
			break;
		case Y.OPTION:
			e.openElements.currentTagId === Y.OPTION && e.openElements.pop();
			break;
		case Y.SELECT:
			e.openElements.hasInSelectScope(Y.SELECT) && (e.openElements.popUntilTagNamePopped(Y.SELECT), e._resetInsertionMode());
			break;
		case Y.TEMPLATE:
			kh(e, t);
			break;
		default:
	}
}
function l_(e, t) {
	let n = t.tagID;
	n === Y.CAPTION || n === Y.TABLE || n === Y.TBODY || n === Y.TFOOT || n === Y.THEAD || n === Y.TR || n === Y.TD || n === Y.TH ? (e.openElements.popUntilTagNamePopped(Y.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : s_(e, t);
}
function u_(e, t) {
	let n = t.tagID;
	n === Y.CAPTION || n === Y.TABLE || n === Y.TBODY || n === Y.TFOOT || n === Y.THEAD || n === Y.TR || n === Y.TD || n === Y.TH ? e.openElements.hasInTableScope(n) && (e.openElements.popUntilTagNamePopped(Y.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : c_(e, t);
}
function d_(e, t) {
	switch (t.tagID) {
		case Y.BASE:
		case Y.BASEFONT:
		case Y.BGSOUND:
		case Y.LINK:
		case Y.META:
		case Y.NOFRAMES:
		case Y.SCRIPT:
		case Y.STYLE:
		case Y.TEMPLATE:
		case Y.TITLE:
			Dh(e, t);
			break;
		case Y.CAPTION:
		case Y.COLGROUP:
		case Y.TBODY:
		case Y.TFOOT:
		case Y.THEAD:
			e.tmplInsertionModeStack[e.tmplInsertionModeStack.length - 1] = $.IN_TABLE, e.insertionMode = $.IN_TABLE, Ug(e, t);
			break;
		case Y.COL:
			e.tmplInsertionModeStack[e.tmplInsertionModeStack.length - 1] = $.IN_COLUMN_GROUP, e.insertionMode = $.IN_COLUMN_GROUP, Qg(e, t);
			break;
		case Y.TR:
			e.tmplInsertionModeStack[e.tmplInsertionModeStack.length - 1] = $.IN_TABLE_BODY, e.insertionMode = $.IN_TABLE_BODY, t_(e, t);
			break;
		case Y.TD:
		case Y.TH:
			e.tmplInsertionModeStack[e.tmplInsertionModeStack.length - 1] = $.IN_ROW, e.insertionMode = $.IN_ROW, r_(e, t);
			break;
		default: e.tmplInsertionModeStack[e.tmplInsertionModeStack.length - 1] = $.IN_BODY, e.insertionMode = $.IN_BODY, vg(e, t);
	}
}
function f_(e, t) {
	t.tagID === Y.TEMPLATE && kh(e, t);
}
function p_(e, t) {
	if (e.openElements.tmplCount > 0) {
		do
			e.openElements.popUntilTagNamePopped(Y.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.pop();
		while (e.openElements.tmplCount > 0);
		e._resetInsertionMode(), e.onEof(t);
	} else vh(e, t);
}
function m_(e, t) {
	t.tagID === Y.HTML ? vg(e, t) : g_(e, t);
}
function h_(e, t) {
	if (t.tagID === Y.HTML) {
		if (e.fragmentContext || (e.insertionMode = $.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === Y.HTML) {
			e._setEndLocation(e.openElements.items[0], t);
			let n = e.openElements.items[1];
			n && !e.treeAdapter.getNodeSourceCodeLocation(n)?.endTag && e._setEndLocation(n, t);
		}
	} else g_(e, t);
}
function g_(e, t) {
	e.insertionMode = $.IN_BODY, Lh(e, t);
}
function __(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.FRAMESET:
			e._insertElement(t, q.HTML);
			break;
		case Y.FRAME:
			e._appendElement(t, q.HTML), t.ackSelfClosing = !0;
			break;
		case Y.NOFRAMES:
			Dh(e, t);
			break;
		default:
	}
}
function v_(e, t) {
	t.tagID === Y.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== Y.FRAMESET && (e.insertionMode = $.AFTER_FRAMESET));
}
function y_(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.NOFRAMES:
			Dh(e, t);
			break;
		default:
	}
}
function b_(e, t) {
	t.tagID === Y.HTML && (e.insertionMode = $.AFTER_AFTER_FRAMESET);
}
function x_(e, t) {
	t.tagID === Y.HTML ? vg(e, t) : S_(e, t);
}
function S_(e, t) {
	e.insertionMode = $.IN_BODY, Lh(e, t);
}
function C_(e, t) {
	switch (t.tagID) {
		case Y.HTML:
			vg(e, t);
			break;
		case Y.NOFRAMES:
			Dh(e, t);
			break;
		default:
	}
}
function w_(e, t) {
	t.chars = "�", e._insertCharacters(t);
}
function T_(e, t) {
	e._insertCharacters(t), e.framesetOk = !1;
}
function E_(e) {
	for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== q.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current);) e.openElements.pop();
}
function D_(e, t) {
	if (Gm(t)) E_(e), e._startTagOutsideForeignContent(t);
	else {
		let n = e._getAdjustedCurrentElement(), r = e.treeAdapter.getNamespaceURI(n);
		r === q.MATHML ? Km(t) : r === q.SVG && (Ym(t), qm(t)), Jm(t), t.selfClosing ? e._appendElement(t, r) : e._insertElement(t, r), t.ackSelfClosing = !0;
	}
}
function O_(e, t) {
	if (t.tagID === Y.P || t.tagID === Y.BR) {
		E_(e), e._endTagOutsideForeignContent(t);
		return;
	}
	if (e.openElements.stackTop === 0) return;
	let { tagName: n } = t, r = Um.get(n), i = e.fragmentContext ? e.treeAdapter.getNamespaceURI(e.fragmentContext) : q.HTML, a = Math.max(e.openElements.indexOfTopmostByName(q.SVG, n), e.openElements.indexOfTopmostByName(q.MATHML, n), r === void 0 ? -1 : e.openElements.indexOfTopmostByName(q.SVG, r), i === q.HTML || i === q.SVG || i === q.MATHML ? -1 : e.openElements.indexOfTopmostByName(i, n));
	a > e.openElements.indexOfTopmostHtmlElement() ? (t.tagName = e.treeAdapter.getTagName(e.openElements.items[a]), e.openElements.shortenToLength(a)) : e._endTagOutsideForeignContent(t);
}
new Set([
	J.AREA,
	J.BASE,
	J.BASEFONT,
	J.BGSOUND,
	J.BR,
	J.COL,
	J.EMBED,
	J.FRAME,
	J.HR,
	J.IMG,
	J.INPUT,
	J.KEYGEN,
	J.LINK,
	J.META,
	J.PARAM,
	J.SOURCE,
	J.TRACK,
	J.WBR
]);
//#endregion
//#region ../../node_modules/.bun/hast-util-raw@9.2.0/node_modules/hast-util-raw/lib/index.js
var k_ = /<(\/?)(iframe|noembed|noframes|plaintext|script|style|textarea|title|xmp)(?=[\t\n\f\r />])/gi, A_ = new Set([
	"mdxFlowExpression",
	"mdxJsxFlowElement",
	"mdxJsxTextElement",
	"mdxTextExpression",
	"mdxjsEsm"
]), j_ = {
	sourceCodeLocationInfo: !0,
	scriptingEnabled: !1
};
function M_(e, t) {
	let n = K_(e), r = vf("type", {
		handlers: {
			root: P_,
			element: F_,
			text: I_,
			comment: z_,
			doctype: L_,
			raw: B_
		},
		unknown: V_
	}), i = {
		parser: n ? new sh(j_) : sh.getFragmentParser(void 0, j_),
		handle(e) {
			r(e, i);
		},
		stitches: !1,
		options: t || {}
	};
	r(e, i), H_(i, wo());
	let a = lf(n ? i.parser.document : i.parser.getFragment(), { file: i.options.file });
	return i.stitches && td(a, "comment", function(e, t, n) {
		let r = e;
		if (r.value.stitch && n && t !== void 0) {
			let e = n.children;
			return e[t] = r.value.stitch, t;
		}
	}), a.type === "root" && a.children.length === 1 && a.children[0].type === e.type ? a.children[0] : a;
}
function N_(e, t) {
	let n = -1;
	/* istanbul ignore else - invalid nodes, see rehypejs/rehype-raw#7. */
	if (e) for (; ++n < e.length;) t.handle(e[n]);
}
function P_(e, t) {
	N_(e.children, t);
}
function F_(e, t) {
	W_(e, t), N_(e.children, t), G_(e, t);
}
function I_(e, t) {
	t.parser.tokenizer.state > 4 && (t.parser.tokenizer.state = 0), H_(t, wo(e));
	let n = q_(e), { value: r } = e, i = 0;
	for (; i < r.length;) {
		let e = Y_(r.charCodeAt(i)), a = i + 1;
		for (; a < r.length && Y_(r.charCodeAt(a)) === e;) a++;
		let o = {
			type: e,
			chars: r.slice(i, a),
			location: n
		};
		t.parser.currentToken = o, t.parser._processToken(t.parser.currentToken), i = a;
	}
}
function L_(e, t) {
	let n = {
		type: K.DOCTYPE,
		name: "html",
		forceQuirks: !1,
		publicId: "",
		systemId: "",
		location: q_(e)
	};
	H_(t, wo(e)), t.parser.currentToken = n, t.parser._processToken(t.parser.currentToken);
}
function R_(e, t) {
	t.stitches = !0;
	let n = J_(e);
	"children" in e && "children" in n && (n.children = M_({
		type: "root",
		children: e.children
	}, t.options).children), z_({
		type: "comment",
		value: { stitch: n }
	}, t);
}
function z_(e, t) {
	let n = e.value, r = {
		type: K.COMMENT,
		data: n,
		location: q_(e)
	};
	H_(t, wo(e)), t.parser.currentToken = r, t.parser._processToken(t.parser.currentToken);
}
function B_(e, t) {
	t.parser.tokenizer.flushCharacters(), t.parser.tokenizer.preprocessor.html = "", t.parser.tokenizer.preprocessor.pos = -1, t.parser.tokenizer.preprocessor.lastGapPos = -2, t.parser.tokenizer.preprocessor.gapStack = [], t.parser.tokenizer.preprocessor.skipNextNewLine = !1, t.parser.tokenizer.preprocessor.lastChunkWritten = !1, t.parser.tokenizer.preprocessor.endOfChunkHit = !1, t.parser.tokenizer.preprocessor.isEol = !1, U_(t, wo(e)), t.parser.tokenizer.write(t.options.tagfilter ? e.value.replace(k_, "&lt;$1$2") : e.value, !1), t.parser.tokenizer._runParsingLoop(), t.parser.tokenizer.state === 71 && (t.parser.tokenizer.preprocessor.pos = t.parser.tokenizer.preprocessor.html.length, t.parser.tokenizer.preprocessor.lastChunkWritten = !0, t.parser.tokenizer._stateCharacterReference(), t.parser.tokenizer.preprocessor.lastChunkWritten = !1, t.parser.tokenizer.preprocessor.endOfChunkHit = !1, t.parser.tokenizer.active = !0, t.parser.tokenizer._runParsingLoop());
}
function V_(e, t) {
	let n = e;
	if (t.options.passThrough && t.options.passThrough.includes(n.type)) R_(n, t);
	else {
		let e = "";
		throw A_.has(n.type) && (e = ". It looks like you are using MDX nodes with `hast-util-raw` (or `rehype-raw`). If you use this because you are using remark or rehype plugins that inject `'html'` nodes, then please raise an issue with that plugin, as its a bad and slow idea. If you use this because you are using markdown syntax, then you have to configure this utility (or plugin) to pass through these nodes (see `passThrough` in docs), but you can also migrate to use the MDX syntax"), Error("Cannot compile `" + n.type + "` node" + e);
	}
}
function H_(e, t) {
	e.parser.tokenizer.flushCharacters(), U_(e, t), e.parser.tokenizer.paused = !1, e.parser.tokenizer.inLoop = !1, e.parser.tokenizer.active = !1, e.parser.tokenizer.returnState = Q.DATA, e.parser.tokenizer.charRefCode = -1, e.parser.tokenizer.consumedAfterSnapshot = -1, e.parser.tokenizer.currentLocation = null, e.parser.tokenizer.currentCharacterToken = null, e.parser.tokenizer.currentToken = null, e.parser.tokenizer.currentAttr = {
		name: "",
		value: ""
	};
}
function U_(e, t) {
	if (t && t.offset !== void 0) {
		let n = {
			startLine: t.line,
			startCol: t.column,
			startOffset: t.offset,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		};
		e.parser.tokenizer.preprocessor.lineStartPos = -t.column + 1, e.parser.tokenizer.preprocessor.droppedBufferSize = t.offset, e.parser.tokenizer.preprocessor.line = t.line, e.parser.tokenizer.currentLocation = n;
	}
}
function W_(e, t) {
	if (t.parser.tokenizer.state === Q.PLAINTEXT) return;
	let n = e.tagName.toLowerCase();
	H_(t, wo(e));
	let { current: r } = t.parser.openElements, i = r && "namespaceURI" in r ? r.namespaceURI : ye.html;
	i === ye.html && n === "svg" && (i = ye.svg);
	let a = Sf({
		...e,
		children: []
	}, { space: i === ye.svg ? "svg" : "html" }), o = {
		type: K.START_TAG,
		tagName: n,
		tagID: Bp(n),
		selfClosing: !1,
		ackSelfClosing: !1,
		/* c8 ignore next */
		attrs: "attrs" in a ? a.attrs : [],
		location: q_(e)
	};
	t.parser.currentToken = o, t.parser._processToken(t.parser.currentToken), t.parser.tokenizer.lastStartTagName = n;
}
function G_(e, t) {
	let n = e.tagName.toLowerCase();
	if (!t.parser.tokenizer.inForeignNode && Mf.includes(n) || t.parser.tokenizer.state === Q.PLAINTEXT) return;
	H_(t, Co(e));
	let r = {
		type: K.END_TAG,
		tagName: n,
		tagID: Bp(n),
		selfClosing: !1,
		ackSelfClosing: !1,
		attrs: [],
		location: q_(e)
	};
	t.parser.currentToken = r, t.parser._processToken(t.parser.currentToken), n === t.parser.tokenizer.lastStartTagName && (t.parser.tokenizer.state === Q.RCDATA || t.parser.tokenizer.state === Q.RAWTEXT || t.parser.tokenizer.state === Q.SCRIPT_DATA) && (t.parser.tokenizer.state = Q.DATA);
}
function K_(e) {
	let t = e.type === "root" ? e.children[0] : e;
	return !!(t && (t.type === "doctype" || t.type === "element" && t.tagName.toLowerCase() === "html"));
}
function q_(e) {
	let t = wo(e) || {
		line: void 0,
		column: void 0,
		offset: void 0
	}, n = Co(e) || {
		line: void 0,
		column: void 0,
		offset: void 0
	};
	return {
		startLine: t.line,
		startCol: t.column,
		startOffset: t.offset,
		endLine: n.line,
		endCol: n.column,
		endOffset: n.offset
	};
}
function J_(e) {
	return Zu("children" in e ? {
		...e,
		children: []
	} : e);
}
function Y_(e) {
	return e === 9 || e === 10 || e === 12 || e === 13 || e === 32 ? K.WHITESPACE_CHARACTER : K.CHARACTER;
}
//#endregion
//#region ../../node_modules/.bun/rehype-raw@7.0.0/node_modules/rehype-raw/lib/index.js
function X_(e) {
	return function(t, n) {
		return M_(t, {
			...e,
			file: n
		});
	};
}
//#endregion
//#region ../../node_modules/.bun/hast-util-sanitize@5.0.2/node_modules/hast-util-sanitize/lib/schema.js
var Z_ = [
	"ariaDescribedBy",
	"ariaLabel",
	"ariaLabelledBy"
], Q_ = {
	ancestors: {
		tbody: ["table"],
		td: ["table"],
		th: ["table"],
		thead: ["table"],
		tfoot: ["table"],
		tr: ["table"]
	},
	attributes: {
		a: [
			...Z_,
			"dataFootnoteBackref",
			"dataFootnoteRef",
			["className", "data-footnote-backref"],
			"href"
		],
		blockquote: ["cite"],
		code: [["className", /^language-./]],
		del: ["cite"],
		div: ["itemScope", "itemType"],
		dl: [...Z_],
		h2: [["className", "sr-only"]],
		img: [
			...Z_,
			"longDesc",
			"src"
		],
		input: [["disabled", !0], ["type", "checkbox"]],
		ins: ["cite"],
		li: [["className", "task-list-item"]],
		ol: [...Z_, ["className", "contains-task-list"]],
		q: ["cite"],
		section: ["dataFootnotes", ["className", "footnotes"]],
		source: ["srcSet"],
		summary: [...Z_],
		table: [...Z_],
		ul: [...Z_, ["className", "contains-task-list"]],
		"*": /* @__PURE__ */ "abbr.accept.acceptCharset.accessKey.action.align.alt.axis.border.cellPadding.cellSpacing.char.charOff.charSet.checked.clear.colSpan.color.cols.compact.coords.dateTime.dir.encType.frame.hSpace.headers.height.hrefLang.htmlFor.id.isMap.itemProp.label.lang.maxLength.media.method.multiple.name.noHref.noShade.noWrap.open.prompt.readOnly.rev.rowSpan.rows.rules.scope.selected.shape.size.span.start.summary.tabIndex.title.useMap.vAlign.value.width".split(".")
	},
	clobber: [
		"ariaDescribedBy",
		"ariaLabelledBy",
		"id",
		"name"
	],
	clobberPrefix: "user-content-",
	protocols: {
		cite: ["http", "https"],
		href: [
			"http",
			"https",
			"irc",
			"ircs",
			"mailto",
			"xmpp"
		],
		longDesc: ["http", "https"],
		src: ["http", "https"]
	},
	required: { input: {
		disabled: !0,
		type: "checkbox"
	} },
	strip: ["script"],
	tagNames: /* @__PURE__ */ "a.b.blockquote.br.code.dd.del.details.div.dl.dt.em.h1.h2.h3.h4.h5.h6.hr.i.img.input.ins.kbd.li.ol.p.picture.pre.q.rp.rt.ruby.s.samp.section.source.span.strike.strong.sub.summary.sup.table.tbody.td.tfoot.th.thead.tr.tt.ul.var".split(".")
}, $_ = {}.hasOwnProperty;
function ev(e, t) {
	let n = {
		type: "root",
		children: []
	}, r = tv({
		schema: t ? {
			...Q_,
			...t
		} : Q_,
		stack: []
	}, e);
	return r && (Array.isArray(r) ? r.length === 1 ? n = r[0] : n.children = r : n = r), n;
}
function tv(e, t) {
	if (t && typeof t == "object") {
		let n = t;
		switch (typeof n.type == "string" ? n.type : "") {
			case "comment": return nv(e, n);
			case "doctype": return rv(e, n);
			case "element": return iv(e, n);
			case "root": return av(e, n);
			case "text": return ov(e, n);
			default:
		}
	}
}
function nv(e, t) {
	if (e.schema.allowComments) {
		let e = typeof t.value == "string" ? t.value : "", n = e.indexOf("-->"), r = {
			type: "comment",
			value: n < 0 ? e : e.slice(0, n)
		};
		return pv(r, t), r;
	}
}
function rv(e, t) {
	if (e.schema.allowDoctypes) {
		let e = { type: "doctype" };
		return pv(e, t), e;
	}
}
function iv(e, t) {
	let n = typeof t.tagName == "string" ? t.tagName : "";
	e.stack.push(n);
	let r = sv(e, t.children), i = cv(e, t.properties);
	e.stack.pop();
	let a = !1;
	if (n && n !== "*" && (!e.schema.tagNames || e.schema.tagNames.includes(n)) && (a = !0, e.schema.ancestors && $_.call(e.schema.ancestors, n))) {
		let t = e.schema.ancestors[n], r = -1;
		for (a = !1; ++r < t.length;) e.stack.includes(t[r]) && (a = !0);
	}
	if (!a) return e.schema.strip && !e.schema.strip.includes(n) ? r : void 0;
	let o = {
		type: "element",
		tagName: n,
		properties: i,
		children: r
	};
	return pv(o, t), o;
}
function av(e, t) {
	let n = {
		type: "root",
		children: sv(e, t.children)
	};
	return pv(n, t), n;
}
function ov(e, t) {
	let n = {
		type: "text",
		value: typeof t.value == "string" ? t.value : ""
	};
	return pv(n, t), n;
}
function sv(e, t) {
	let n = [];
	if (Array.isArray(t)) {
		let r = t, i = -1;
		for (; ++i < r.length;) {
			let t = tv(e, r[i]);
			t && (Array.isArray(t) ? n.push(...t) : n.push(t));
		}
	}
	return n;
}
function cv(e, t) {
	let n = e.stack[e.stack.length - 1], r = e.schema.attributes, i = e.schema.required, a = r && $_.call(r, n) ? r[n] : void 0, o = r && $_.call(r, "*") ? r["*"] : void 0, s = t && typeof t == "object" ? t : {}, c = {}, l;
	for (l in s) if ($_.call(s, l)) {
		let t = s[l], n = lv(e, mv(a, l), l, t);
		n ??= lv(e, mv(o, l), l, t), n != null && (c[l] = n);
	}
	if (i && $_.call(i, n)) {
		let e = i[n];
		for (l in e) $_.call(e, l) && !$_.call(c, l) && (c[l] = e[l]);
	}
	return c;
}
function lv(e, t, n, r) {
	return t ? Array.isArray(r) ? uv(e, t, n, r) : dv(e, t, n, r) : void 0;
}
function uv(e, t, n, r) {
	let i = -1, a = [];
	for (; ++i < r.length;) {
		let o = dv(e, t, n, r[i]);
		(typeof o == "number" || typeof o == "string") && a.push(o);
	}
	return a;
}
function dv(e, t, n, r) {
	if (!(typeof r != "boolean" && typeof r != "number" && typeof r != "string") && fv(e, n, r)) {
		if (typeof t == "object" && t.length > 1) {
			let e = !1, n = 0;
			for (; ++n < t.length;) {
				let i = t[n];
				if (i && typeof i == "object" && "flags" in i) {
					if (i.test(String(r))) {
						e = !0;
						break;
					}
				} else if (i === r) {
					e = !0;
					break;
				}
			}
			if (!e) return;
		}
		return e.schema.clobber && e.schema.clobberPrefix && e.schema.clobber.includes(n) ? e.schema.clobberPrefix + r : r;
	}
}
function fv(e, t, n) {
	let r = e.schema.protocols && $_.call(e.schema.protocols, t) ? e.schema.protocols[t] : void 0;
	if (!r || r.length === 0) return !0;
	let i = String(n), a = i.indexOf(":"), o = i.indexOf("?"), s = i.indexOf("#"), c = i.indexOf("/");
	if (a < 0 || c > -1 && a > c || o > -1 && a > o || s > -1 && a > s) return !0;
	let l = -1;
	for (; ++l < r.length;) {
		let e = r[l];
		if (a === e.length && i.slice(0, e.length) === e) return !0;
	}
	return !1;
}
function pv(e, t) {
	let n = Eo(t);
	t.data && (e.data = Zu(t.data)), n && (e.position = n);
}
function mv(e, t) {
	let n, r = -1;
	if (e) for (; ++r < e.length;) {
		let i = e[r], a = typeof i == "string" ? i : i[0];
		if (a === t) return i;
		a === "data*" && (n = i);
	}
	if (t.length > 4 && t.slice(0, 4).toLowerCase() === "data") return n;
}
//#endregion
//#region ../../node_modules/.bun/rehype-sanitize@6.0.0/node_modules/rehype-sanitize/lib/index.js
function hv(e) {
	return function(t) {
		return ev(t, e);
	};
}
//#endregion
//#region ../../node_modules/.bun/fault@2.0.1/node_modules/fault/index.js
var gv = /* @__PURE__ */ e((/* @__PURE__ */ n(((e, t) => {
	(function() {
		var e = t === void 0 ? function() {
			return this || (0, eval)("this");
		}() : t.exports = i;
		e.format = i, e.vsprintf = r, typeof console < "u" && typeof console.log == "function" && (e.printf = n);
		function n() {
			console.log(i.apply(null, arguments));
		}
		function r(e, t) {
			return i.apply(null, [e].concat(t));
		}
		function i(e) {
			for (var t = 1, n = [].slice.call(arguments), r = 0, i = e.length, a = "", o, s = !1, c, l, u = !1, d, f = function() {
				return n[t++];
			}, p = function() {
				for (var t = ""; /\d/.test(e[r]);) t += e[r++], o = e[r];
				return t.length > 0 ? parseInt(t) : null;
			}; r < i; ++r) if (o = e[r], s) switch (s = !1, o == "." ? (u = !1, o = e[++r]) : o == "0" && e[r + 1] == "." ? (u = !0, r += 2, o = e[r]) : u = !0, d = p(), o) {
				case "b":
					a += parseInt(f(), 10).toString(2);
					break;
				case "c":
					c = f(), typeof c == "string" || c instanceof String ? a += c : a += String.fromCharCode(parseInt(c, 10));
					break;
				case "d":
					a += parseInt(f(), 10);
					break;
				case "f":
					l = String(parseFloat(f()).toFixed(d || 6)), a += u ? l : l.replace(/^0/, "");
					break;
				case "j":
					a += JSON.stringify(f());
					break;
				case "o":
					a += "0" + parseInt(f(), 10).toString(8);
					break;
				case "s":
					a += f();
					break;
				case "x":
					a += "0x" + parseInt(f(), 10).toString(16);
					break;
				case "X":
					a += "0x" + parseInt(f(), 10).toString(16).toUpperCase();
					break;
				default:
					a += o;
					break;
			}
			else o === "%" ? s = !0 : a += o;
			return a;
		}
	})();
})))(), 1), _v = Object.assign(vv(Error), {
	eval: vv(EvalError),
	range: vv(RangeError),
	reference: vv(ReferenceError),
	syntax: vv(SyntaxError),
	type: vv(TypeError),
	uri: vv(URIError)
});
function vv(e) {
	return t.displayName = e.displayName || e.name, t;
	function t(t, ...n) {
		return new e(t && (0, gv.default)(t, ...n));
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-frontmatter@2.0.0/node_modules/micromark-extension-frontmatter/lib/to-matters.js
var yv = {}.hasOwnProperty, bv = {
	yaml: "-",
	toml: "+"
};
function xv(e) {
	let t = [], n = -1, r = Array.isArray(e) ? e : e ? [e] : ["yaml"];
	for (; ++n < r.length;) t[n] = Sv(r[n]);
	return t;
}
function Sv(e) {
	let t = e;
	if (typeof t == "string") {
		if (!yv.call(bv, t)) throw _v("Missing matter definition for `%s`", t);
		t = {
			type: t,
			marker: bv[t]
		};
	} else if (typeof t != "object") throw _v("Expected matter to be an object, not `%j`", t);
	if (!yv.call(t, "type")) throw _v("Missing `type` in matter `%j`", t);
	if (!yv.call(t, "fence") && !yv.call(t, "marker")) throw _v("Missing `marker` or `fence` in matter `%j`", t);
	return t;
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-frontmatter@2.0.0/node_modules/micromark-extension-frontmatter/lib/syntax.js
function Cv(e) {
	let t = xv(e), n = {}, r = -1;
	for (; ++r < t.length;) {
		let e = t[r], i = Tv(e, "open").charCodeAt(0), a = wv(e), o = n[i];
		Array.isArray(o) ? o.push(a) : n[i] = [a];
	}
	return { flow: n };
}
function wv(e) {
	let t = e.anywhere, n = e.type, r = n + "Fence", i = r + "Sequence", a = n + "Value", o = {
		tokenize: u,
		partial: !0
	}, s, c = 0;
	return {
		tokenize: l,
		concrete: !0
	};
	function l(l, u, d) {
		let f = this;
		return p;
		function p(a) {
			let o = f.now();
			return o.column === 1 && (o.line === 1 || t) && (s = Tv(e, "open"), c = 0, a === s.charCodeAt(c)) ? (l.enter(n), l.enter(r), l.enter(i), m(a)) : d(a);
		}
		function m(e) {
			return c === s.length ? (l.exit(i), H(e) ? (l.enter("whitespace"), h(e)) : g(e)) : e === s.charCodeAt(c++) ? (l.consume(e), m) : d(e);
		}
		function h(e) {
			return H(e) ? (l.consume(e), h) : (l.exit("whitespace"), g(e));
		}
		function g(t) {
			return B(t) ? (l.exit(r), l.enter("lineEnding"), l.consume(t), l.exit("lineEnding"), s = Tv(e, "close"), c = 0, l.attempt(o, b, _)) : d(t);
		}
		function _(e) {
			return e === null || B(e) ? y(e) : (l.enter(a), v(e));
		}
		function v(e) {
			return e === null || B(e) ? (l.exit(a), y(e)) : (l.consume(e), v);
		}
		function y(e) {
			return e === null ? d(e) : (l.enter("lineEnding"), l.consume(e), l.exit("lineEnding"), l.attempt(o, b, _));
		}
		function b(e) {
			return l.exit(n), u(e);
		}
	}
	function u(e, t, n) {
		let a = 0;
		return o;
		function o(t) {
			return t === s.charCodeAt(a) ? (e.enter(r), e.enter(i), c(t)) : n(t);
		}
		function c(t) {
			return a === s.length ? (e.exit(i), H(t) ? (e.enter("whitespace"), l(t)) : u(t)) : t === s.charCodeAt(a++) ? (e.consume(t), c) : n(t);
		}
		function l(t) {
			return H(t) ? (e.consume(t), l) : (e.exit("whitespace"), u(t));
		}
		function u(i) {
			return i === null || B(i) ? (e.exit(r), t(i)) : n(i);
		}
	}
}
function Tv(e, t) {
	return e.marker ? Ev(e.marker, t).repeat(3) : Ev(e.fence, t);
}
function Ev(e, t) {
	return typeof e == "string" ? e : e[t];
}
//#endregion
//#region ../../node_modules/.bun/escape-string-regexp@5.0.0/node_modules/escape-string-regexp/index.js
function Dv(e) {
	if (typeof e != "string") throw TypeError("Expected a string");
	return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-frontmatter@2.0.1/node_modules/mdast-util-frontmatter/lib/index.js
function Ov(e) {
	let t = xv(e), n = {}, r = {}, i = -1;
	for (; ++i < t.length;) {
		let e = t[i];
		n[e.type] = kv(e), r[e.type] = Av, r[e.type + "Value"] = jv;
	}
	return {
		enter: n,
		exit: r
	};
}
function kv(e) {
	return t;
	function t(t) {
		this.enter({
			type: e.type,
			value: ""
		}, t), this.buffer();
	}
}
function Av(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	"value" in n, this.exit(e), n.value = t.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, "");
}
function jv(e) {
	this.config.enter.data.call(this, e), this.config.exit.data.call(this, e);
}
function Mv(e) {
	let t = [], n = {}, r = xv(e), i = -1;
	for (; ++i < r.length;) {
		let e = r[i];
		n[e.type] = Nv(e);
		let a = Pv(e, "open");
		t.push({
			atBreak: !0,
			character: a.charAt(0),
			after: Dv(a.charAt(1))
		});
	}
	return {
		unsafe: t,
		handlers: n
	};
}
function Nv(e) {
	let t = Pv(e, "open"), n = Pv(e, "close");
	return r;
	function r(e) {
		return t + (e.value ? "\n" + e.value : "") + "\n" + n;
	}
}
function Pv(e, t) {
	return e.marker ? Fv(e.marker, t).repeat(3) : Fv(e.fence, t);
}
function Fv(e, t) {
	return typeof e == "string" ? e : e[t];
}
//#endregion
//#region ../../node_modules/.bun/remark-frontmatter@5.0.0/node_modules/remark-frontmatter/lib/index.js
var Iv = "yaml";
function Lv(e) {
	let t = this, n = e || Iv, r = t.data(), i = r.micromarkExtensions ||= [], a = r.fromMarkdownExtensions ||= [], o = r.toMarkdownExtensions ||= [];
	i.push(Cv(n)), a.push(Ov(n)), o.push(Mv(n));
}
//#endregion
//#region ../../node_modules/.bun/ccount@2.0.1/node_modules/ccount/index.js
function Rv(e, t) {
	let n = String(e);
	if (typeof t != "string") throw TypeError("Expected character");
	let r = 0, i = n.indexOf(t);
	for (; i !== -1;) r++, i = n.indexOf(t, i + t.length);
	return r;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-find-and-replace@3.0.4/node_modules/mdast-util-find-and-replace/lib/index.js
function zv(e, t, n) {
	let r = ge((n || {}).ignore || []), i = Bv(t), a = -1;
	for (; ++a < i.length;) le(e, o);
	function o(e, t, n) {
		if (e.type === "text" && typeof n == "number") return s(e, t, n);
		if (r(e, n, t[t.length - 1])) return pe;
	}
	function s(e, t, n) {
		let r = t[t.length - 1], o = i[a][0], s = i[a][1], c = 0, l = !1, u = [];
		o.lastIndex = 0;
		let d = o.exec(e.value);
		for (; d;) {
			let n = d.index, r = {
				index: d.index,
				input: d.input,
				stack: [...t, e]
			}, i = s(...d, r);
			if (typeof i == "string" && (i = i.length > 0 ? {
				type: "text",
				value: i
			} : void 0), i === !1) o.lastIndex = n + 1;
			else {
				if (c !== n && f({
					type: "text",
					value: e.value.slice(c, n)
				}), Array.isArray(i)) for (let e of i) f(e);
				else i && f(i);
				c = n + d[0].length, l = !0;
			}
			if (!o.global) break;
			d = o.exec(e.value);
		}
		return l ? (c < e.value.length && f({
			type: "text",
			value: e.value.slice(c)
		}), r.children.splice(n, 1, ...u)) : u = [e], n + u.length;
		function f(e) {
			let t = u[u.length - 1];
			t && t.type === "text" && e.type === "text" ? t.value += e.value : u.push(e);
		}
	}
}
function Bv(e) {
	if (!Array.isArray(e)) throw TypeError("Expected find and replace tuple or list of tuples");
	let t = [], n = !e[0] || Array.isArray(e[0]) ? e : [e], r = -1;
	for (; ++r < n.length;) {
		let e = n[r];
		t.push([Vv(e[0]), Hv(e[1])]);
	}
	return t;
}
function Vv(e) {
	return typeof e == "string" ? new RegExp(Dv(e), "g") : e;
}
function Hv(e) {
	return typeof e == "function" ? e : function() {
		return e;
	};
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm-autolink-literal@2.1.0/node_modules/mdast-util-gfm-autolink-literal/lib/index.js
var Uv = "phrasing", Wv = [
	"autolink",
	"link",
	"image",
	"label"
];
function Gv() {
	return {
		transforms: [$v],
		enter: {
			literalAutolink: qv,
			literalAutolinkEmail: Jv,
			literalAutolinkHttp: Jv,
			literalAutolinkWww: Jv
		},
		exit: {
			literalAutolink: Qv,
			literalAutolinkEmail: Zv,
			literalAutolinkHttp: Yv,
			literalAutolinkWww: Xv
		}
	};
}
function Kv() {
	return { unsafe: [
		{
			character: "@",
			before: "[+\\-.\\w]",
			after: "[\\-.\\w]",
			inConstruct: Uv,
			notInConstruct: Wv
		},
		{
			character: ".",
			before: "[Ww]",
			after: "[\\-.\\w]",
			inConstruct: Uv,
			notInConstruct: Wv
		},
		{
			character: ":",
			before: "[ps]",
			after: "\\/",
			inConstruct: Uv,
			notInConstruct: Wv
		}
	] };
}
function qv(e) {
	this.enter({
		type: "link",
		title: null,
		url: "",
		children: [],
		position: void 0
	}, e);
}
function Jv(e) {
	this.config.enter.autolinkProtocol.call(this, e);
}
function Yv(e) {
	this.config.exit.autolinkProtocol.call(this, e);
}
function Xv(e) {
	this.config.exit.data.call(this, e);
	let t = this.stack[this.stack.length - 1];
	t.type, t.url = "http://" + this.sliceSerialize(e);
}
function Zv(e) {
	this.config.exit.autolinkEmail.call(this, e);
}
function Qv(e) {
	this.exit(e);
}
function $v(e) {
	zv(e, [
		[/(?<![\da-z])(https?:\/\/|www(?=\.))([\w-]*\.[\w\-.]*)([^\t\n\r ]*)/gi, ey],
		[/(?<![\w+\-.@])xmpp:([\w+\-.]+)@([\w-]+(?:\.[\w-]+)+)(\/(?:[\w\-/]|\.(?=[\dA-Za-z]))*)?/g, ry],
		[/(?<![\w+\-.@])mailto:([\w+\-.]+)@([\w-]+(?:\.[\w-]+)+)/g, ny],
		[/(?<![\w+\-.]|(?:^|[^\d@A-Za-z])(?:mailto|xmpp):)([\w+\-.]+)@([\w-]+(?:\.[\w-]+)+)/g, ty]
	], { ignore: ["link", "linkReference"] });
}
function ey(e, t, n, r, i) {
	if (!oy(i)) return !1;
	let a = "";
	if (/^w/i.test(t) && (n = t + n, t = "", a = "http://"), ks(n.charCodeAt(0)) || !iy(n)) return !1;
	let o = ay(n + r), s = {
		type: "link",
		title: null,
		url: a + t + o[0],
		children: [{
			type: "text",
			value: t + o[0],
			position: void 0
		}],
		position: void 0
	};
	return o[1] ? [s, {
		type: "text",
		value: o[1],
		position: void 0
	}] : s;
}
function ty(e, t, n) {
	return /[\d\-_]$/.test(n) ? !1 : {
		type: "link",
		title: null,
		url: "mailto:" + t + "@" + n,
		children: [{
			type: "text",
			value: t + "@" + n,
			position: void 0
		}],
		position: void 0
	};
}
function ny(e, t, n) {
	if (/[\d\-_]$/.test(n)) return !1;
	let r = "mailto:" + t + "@" + n;
	return {
		type: "link",
		title: null,
		url: r,
		children: [{
			type: "text",
			value: r,
			position: void 0
		}],
		position: void 0
	};
}
function ry(e, t, n, r, i) {
	if (/[\d\-_]$/.test(n) || r && (!/[A-Za-z]$/.test(r) || i.input.charAt(i.index + e.length) === "@")) return !1;
	let a = "xmpp:" + t + "@" + n + (r || "");
	return {
		type: "link",
		title: null,
		url: a,
		children: [{
			type: "text",
			value: a,
			position: void 0
		}],
		position: void 0
	};
}
function iy(e) {
	let t = e.split(".");
	return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[\dA-Za-z]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[\dA-Za-z]/.test(t[t.length - 2])));
}
function ay(e) {
	let t = e.length;
	for (; t > 0;) {
		let n = e.charCodeAt(t - 1);
		if (n === 33 || n === 34 || n === 38 || n === 39 || n === 41 || n === 44 || n === 46 || n === 58 || n === 59 || n === 60 || n === 62 || n === 63 || n === 93 || n === 125) t--;
		else break;
	}
	if (t === e.length) return [e, void 0];
	let n = e.slice(t);
	e = e.slice(0, t);
	let r = n.indexOf(")"), i = Rv(e, "("), a = Rv(e, ")");
	for (; r !== -1 && i > a;) e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), a++;
	return [e, n];
}
function oy(e) {
	let t = e.input.charCodeAt(e.index - 1);
	return e.index === 0 || As(t) || ks(t);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm-footnote@2.1.0/node_modules/mdast-util-gfm-footnote/lib/index.js
gy.peek = hy;
function sy() {
	this.buffer();
}
function cy(e) {
	this.enter({
		type: "footnoteReference",
		identifier: "",
		label: ""
	}, e);
}
function ly() {
	this.buffer();
}
function uy(e) {
	this.enter({
		type: "footnoteDefinition",
		identifier: "",
		label: "",
		children: []
	}, e);
}
function dy(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = Cs(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function fy(e) {
	this.exit(e);
}
function py(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = Cs(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function my(e) {
	this.exit(e);
}
function hy() {
	return "[";
}
function gy(e, t, n, r) {
	let i = n.createTracker(r), a = i.move("[^"), o = n.enter("footnoteReference"), s = n.enter("reference");
	return a += i.move(n.safe(n.associationId(e), {
		after: "]",
		before: a
	})), s(), o(), a += i.move("]"), a;
}
function _y() {
	return {
		enter: {
			gfmFootnoteCallString: sy,
			gfmFootnoteCall: cy,
			gfmFootnoteDefinitionLabelString: ly,
			gfmFootnoteDefinition: uy
		},
		exit: {
			gfmFootnoteCallString: dy,
			gfmFootnoteCall: fy,
			gfmFootnoteDefinitionLabelString: py,
			gfmFootnoteDefinition: my
		}
	};
}
function vy(e) {
	let t = !1;
	return e && e.firstLineBlank && (t = !0), {
		handlers: {
			footnoteDefinition: n,
			footnoteReference: gy
		},
		unsafe: [{
			character: "[",
			inConstruct: [
				"label",
				"phrasing",
				"reference"
			]
		}]
	};
	function n(e, n, r, i) {
		let a = r.createTracker(i), o = a.move("[^"), s = r.enter("footnoteDefinition"), c = r.enter("label");
		return o += a.move(r.safe(r.associationId(e), {
			before: o,
			after: "]"
		})), c(), o += a.move("]:"), e.children && e.children.length > 0 && (a.shift(4), o += a.move((t ? "\n" : " ") + r.indentLines(r.containerFlow(e, a.current()), t ? by : yy))), s(), o;
	}
}
function yy(e, t, n) {
	return t === 0 ? e : by(e, t, n);
}
function by(e, t, n) {
	return (n ? "" : "    ") + e;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm-strikethrough@2.0.1/node_modules/mdast-util-gfm-strikethrough/lib/index.js
var xy = [
	"autolink",
	"destinationLiteral",
	"destinationRaw",
	"reference",
	"titleQuote",
	"titleApostrophe"
];
Ey.attention = Dy, Ey.peek = Oy;
function Sy() {
	return {
		canContainEols: ["delete"],
		enter: { strikethrough: wy },
		exit: { strikethrough: Ty }
	};
}
function Cy() {
	return {
		handlers: { delete: Ey },
		unsafe: [{
			character: "~",
			inConstruct: "phrasing",
			notInConstruct: xy
		}]
	};
}
function wy(e) {
	this.enter({
		type: "delete",
		children: [],
		position: void 0
	}, e);
}
function Ty(e) {
	this.exit(e);
}
function Ey(e, t, n, r) {
	let i = n.createTracker(r), a = n.stack.includes("strikethrough") ? "~" : "~~", o = n.enter("strikethrough"), s = i.move(a);
	return s += n.containerPhrasing(e, {
		...i.current(),
		before: s,
		after: "~"
	}), s += i.move(a), o(), s;
}
function Dy() {
	return {
		construct: "strikethrough",
		markers: ["~"],
		sizes: [2, 1]
	};
}
function Oy() {
	return "~";
}
//#endregion
//#region ../../node_modules/.bun/markdown-table@3.1.0/node_modules/markdown-table/index.js
function ky(e) {
	return e.length;
}
function Ay(e, t) {
	let n = t || {}, r = (n.align || []).concat(), i = n.stringLength || ky, a = [], o = [], s = [], c = [], l = 0, u = -1;
	for (; ++u < e.length;) {
		let t = [], r = [], a = -1;
		for (e[u].length > l && (l = e[u].length); ++a < e[u].length;) {
			let o = jy(e[u][a]);
			if (n.alignDelimiters !== !1) {
				let e = i(o);
				r[a] = e, (c[a] === void 0 || e > c[a]) && (c[a] = e);
			}
			t.push(o);
		}
		o[u] = t, s[u] = r;
	}
	let d = -1;
	if (typeof r == "object" && "length" in r) for (; ++d < l;) a[d] = My(r[d]);
	else {
		let e = My(r);
		for (; ++d < l;) a[d] = e;
	}
	d = -1;
	let f = [], p = [];
	for (; ++d < l;) {
		let e = a[d], t = "", r = "";
		e === 99 ? (t = ":", r = ":") : e === 108 ? t = ":" : e === 114 && (r = ":");
		let i = n.alignDelimiters === !1 ? 1 : Math.max(1, c[d] - t.length - r.length), o = t + "-".repeat(i) + r;
		n.alignDelimiters !== !1 && (i = t.length + i + r.length, i > c[d] && (c[d] = i), p[d] = i), f[d] = o;
	}
	o.splice(1, 0, f), s.splice(1, 0, p), u = -1;
	let m = [];
	for (; ++u < o.length;) {
		let e = o[u], t = s[u], r = n.fillRows === !1 ? Math.max(1, o[u === 1 ? 0 : u].length) : l;
		d = -1;
		let i = [];
		for (; ++d < r;) {
			let o = e[d] || "", s = "", l = "";
			if (n.alignDelimiters !== !1) {
				let e = c[d] - (t[d] || 0), n = a[d];
				if (n === 114) s = " ".repeat(e);
				else if (n === 99) {
					let t = e / 2;
					e % 2 ? (s = " ".repeat(t + .5), l = " ".repeat(t - .5)) : (s = " ".repeat(t), l = s);
				} else l = " ".repeat(e);
			}
			n.delimiterStart !== !1 && !d && i.push("|"), n.padding !== !1 && !(n.alignDelimiters === !1 && o === "") && (n.delimiterStart !== !1 || d) && i.push(" "), n.alignDelimiters !== !1 && i.push(s), i.push(o), n.alignDelimiters !== !1 && i.push(l), n.padding !== !1 && i.push(" "), (n.delimiterEnd !== !1 || d !== r - 1) && i.push("|");
		}
		m.push(n.delimiterEnd === !1 ? i.join("").replace(/ +$/, "") : i.join(""));
	}
	return m.join("\n");
}
function jy(e) {
	return e == null ? "" : String(e);
}
function My(e) {
	let t = typeof e == "string" ? e.codePointAt(0) : 0;
	return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-phrasing@4.1.0/node_modules/mdast-util-phrasing/lib/index.js
var Ny = ge([
	"break",
	"delete",
	"emphasis",
	"footnote",
	"footnoteReference",
	"image",
	"imageReference",
	"inlineCode",
	"inlineMath",
	"link",
	"linkReference",
	"mdxJsxTextElement",
	"mdxTextExpression",
	"strong",
	"text",
	"textDirective"
]);
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/blockquote.js
function Py(e, t, n, r) {
	let i = n.enter("blockquote"), a = n.createTracker(r);
	a.move("> "), a.shift(2);
	let o = n.indentLines(n.containerFlow(e, a.current()), Fy);
	return i(), o;
}
function Fy(e, t, n) {
	return ">" + (n ? "" : " ") + e;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/pattern-in-scope.js
function Iy(e, t) {
	return Ly(e, t.inConstruct, !0) && !Ly(e, t.notInConstruct, !1);
}
function Ly(e, t, n) {
	if (typeof t == "string" && (t = [t]), !t || t.length === 0) return n;
	let r = -1;
	for (; ++r < t.length;) if (e.includes(t[r])) return !0;
	return !1;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/break.js
function Ry(e, t, n, r) {
	let i = -1;
	for (; ++i < n.unsafe.length;) {
		let e = n.unsafe[i];
		if (e.character === "\n" && !e.before && !e.after && Iy(n.stack, e)) return /[\t ]/.test(r.before) ? "" : " ";
	}
	return "\\\n";
}
//#endregion
//#region ../../node_modules/.bun/longest-streak@3.1.0/node_modules/longest-streak/index.js
function zy(e, t) {
	let n = String(e), r = n.indexOf(t), i = r, a = 0, o = 0;
	if (typeof t != "string") throw TypeError("Expected substring");
	for (; r !== -1;) r === i ? ++a > o && (o = a) : a = 1, i = r + t.length, r = n.indexOf(t, i);
	return o;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/format-code-as-indented.js
function By(e, t) {
	return !!(t.options.fences === !1 && e.value && !e.lang && /[^\n\r ]/.test(e.value) && !/^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(e.value));
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-fence.js
function Vy(e) {
	let t = e.options.fence || "`";
	if (t !== "`" && t !== "~") throw Error("Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/code.js
function Hy(e, t, n, r) {
	let i = Vy(n), a = e.value || "";
	if (By(e, n)) {
		let e = n.enter("codeIndented"), t = n.indentLines(a, Uy);
		return e(), t;
	}
	let o = n.createTracker(r), s = i.repeat(Math.max(zy(a, i) + 1, 3)), c = n.enter("codeFenced"), l = i === "`" ? "GraveAccent" : "Tilde", u = o.move(s);
	if (e.lang) {
		let t = n.enter(`codeFencedLang${l}`);
		u += o.move(n.safe(e.lang, {
			before: u,
			after: " ",
			encode: ["`"],
			...o.current()
		})), t();
	}
	if (e.lang && e.meta) {
		let t = n.enter(`codeFencedMeta${l}`);
		u += o.move(" "), u += o.move(n.safe(e.meta, {
			before: u,
			after: "\n",
			encode: ["`"],
			...o.current()
		})), t();
	}
	return u += o.move("\n"), a && (u += o.move(a + "\n")), u += o.move(s), c(), u;
}
function Uy(e, t, n) {
	return (n ? "" : "    ") + e;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-quote.js
function Wy(e) {
	let t = e.options.quote || "\"";
	if (t !== "\"" && t !== "'") throw Error("Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/definition.js
function Gy(e, t, n, r) {
	let i = Wy(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("definition"), s = n.enter("label"), c = n.createTracker(r), l = c.move("[");
	return l += c.move(n.safe(n.associationId(e), {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]: "), s(), !e.url || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : "\n",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), o(), l;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-emphasis.js
function Ky(e) {
	let t = e.options.emphasis || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/character.js
function qy(e) {
	let t = e.codePointAt(0);
	return t === void 0 ? "" : String.fromCodePoint(t);
}
function Jy(e) {
	let t = e.codePointAt(e.length - 2);
	return t !== void 0 && t > 65535 ? e.slice(-2) : e.slice(-1);
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/encode-character-reference.js
function Yy(e) {
	return "&#x" + e.toString(16).toUpperCase() + ";";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/encode-info.js
function Xy(e, t, n) {
	let r = Hs(e), i = Hs(t);
	return r === void 0 ? i === void 0 ? n === "_" ? {
		inside: !0,
		outside: !0
	} : {
		inside: !1,
		outside: !1
	} : i === 1 ? {
		inside: !0,
		outside: !0
	} : {
		inside: !1,
		outside: !0
	} : r === 1 ? i === void 0 ? {
		inside: !1,
		outside: !1
	} : i === 1 ? {
		inside: !0,
		outside: !0
	} : {
		inside: !1,
		outside: !1
	} : i === void 0 ? {
		inside: !1,
		outside: !1
	} : i === 1 ? {
		inside: !0,
		outside: !1
	} : {
		inside: !1,
		outside: !1
	};
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/html-kind.js
function Zy(e) {
	if (e.charCodeAt(0) !== 60) return;
	let t = e.charCodeAt(1);
	if (t === 33) {
		let t = e.charCodeAt(2);
		return t === 45 ? 2 : t === 91 ? 5 : R(t) ? 4 : void 0;
	}
	if (t === 63) return 3;
	let n = t === 47, r = n ? 2 : 1, i = r, a = e.charCodeAt(i);
	if (!R(a)) return;
	for (; a === 45 || z(a);) a = e.charCodeAt(++i);
	let o = e.slice(r, i).toLowerCase();
	return !n && a !== 47 && Vc.includes(o) ? 1 : Bc.includes(o) ? 6 : 7;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/container-phrasing.js
var Qy = new Map([["*", !1], ["_", !0]]);
function $y(e, t, n) {
	let r = /* @__PURE__ */ new Set();
	for (let i of e) {
		let e = n.get(i);
		if (e && i.attention && t.some((e) => e.attention === i.attention)) for (let t of e.tokens) r.add(t.attention);
	}
	let i = [];
	for (let t of e) t.attention && r.delete(t.attention) && i.push(t.attention);
	return i.reverse(), i;
}
function eb(e, t, n) {
	let r = [], i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = 0;
	for (; o < e.length;) {
		if (!e[o].attention) {
			o++;
			continue;
		}
		let s = e[o].value.charAt(0), c = Qy.get(s), l = o + 1;
		for (; l < e.length && e[l].attention && e[l].value.charAt(0) === s;) l++;
		let u = o ? e[o - 1].value : t, d = Hs(u.charCodeAt(u.length - 1)), f = Hs((l < e.length ? e[l].value : n).charCodeAt(0)), p = !f || f === 2 && !!d, m = !d || d === 2 && !!f, h = {
			tokens: e.slice(o, l),
			markers: [],
			start: 0,
			end: 0,
			open: c ? p && (!!d || !m) : p,
			close: c ? m && (!!f || !p) : m,
			split: c !== void 0
		};
		for (let e of h.tokens) {
			i.set(e, [...h.tokens]), a.set(e, h);
			let t = e.value.length;
			for (; t--;) h.markers.push(e);
		}
		h.end = h.markers.length, r.push(h), o = l;
	}
	for (rb(r, i), o = -1; ++o < e.length;) {
		let t = i.get(e[o]);
		if (t) return {
			attention: $y(e, t, a),
			index: o
		};
	}
}
function tb(e, t) {
	let n = e[t ? 0 : e.length - 1];
	if (!n || n.attention) return;
	let r = t ? qy(n.value) : Jy(n.value), i = Yy(r.codePointAt(0));
	if (t) n.value = i + n.value.slice(r.length);
	else {
		let e = n.value.slice(0, n.value.length - r.length), t = 0;
		for (; e.charCodeAt(e.length - 1 - t) === 92;) t++;
		t % 2 && (e += "\\"), n.value = e + i;
	}
}
function nb(e, t, n, r, i) {
	for (let a of n.attention) {
		let o = t.get(a) || a.sequences[0];
		for (let s of a.sequences) {
			if (s === o) continue;
			let c = new Map(t);
			c.set(a, s);
			let l = lb(e, c, r, i), u = eb(l, r, i);
			if (!u || u.index > n.index) return {
				chosen: c,
				mistake: u,
				tokens: l
			};
		}
	}
}
function rb(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = r.tokens[0].value.charAt(0), i = n.get(e);
		i || (i = [], n.set(e, i));
		let a = r.close ? i.length : 0;
		for (; a-- && r.start < r.end;) {
			let e = i[a], n = e.end - e.start, o = r.end - r.start;
			if (r.split ? (e.close || r.open) && o % 3 && !((n + o) % 3) : n !== e.markers.length || n !== o) continue;
			let s = r.split ? n > 1 && o > 1 ? 2 : 1 : o, c = e.markers.slice(e.end - s, e.end), l = r.markers.slice(r.start, r.start + s), u = c[0], d = l[0];
			if (u === c[s - 1] && u.value.length === s && d === l[s - 1] && d.value.length === s && u.attention === d.attention) t.delete(u), t.delete(d);
			else {
				let e = [...new Set([...c, ...l])];
				for (let n of e) {
					let r = t.get(n);
					r && r.push(...e);
				}
			}
			e.end -= s, r.start += s, e.start === e.end && i.splice(a, 1), a = i.length;
		}
		r.open && r.start < r.end && i.push(r);
	}
}
function ib(e, t, n) {
	if (t.length === 0) throw Error("Cannot serialize `" + e + "` as attention without markers, expected one or more markers");
	if (n.length === 0) throw Error("Cannot serialize `" + e + "` as attention without sizes, expected one or more sizes");
	for (let t of n) if (!Number.isSafeInteger(t) || t < 1) throw Error("Cannot serialize `" + e + "` as attention with `" + t + "` as size, expected positive integer");
	let r = [];
	for (let i of t) {
		if (i.length !== 1) throw Error("Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected a single ascii character");
		if (!Os(i.charCodeAt(0))) throw Error("Cannot serialize `" + e + "` as attention with `" + i + "` as marker, expected ascii punctuation");
		for (let e of n) r.push(i.repeat(e));
	}
	return r;
}
function ab(e, t, n) {
	let r = t.indexStack, i = e.children || [], a = [], o = -1, s = n.before;
	r.push(-1);
	let c = t.createTracker(n);
	for (; ++o < i.length;) {
		let l = i[o], u;
		if (r[r.length - 1] = o, o + 1 < i.length) {
			let n = t.handle.handlers[i[o + 1].type];
			n && n.peek && (n = n.peek), u = n ? qy(n(i[o + 1], e, t, {
				before: "",
				after: "",
				...c.current()
			})) : "";
		} else u = n.after;
		let d = a[a.length - 1];
		typeof d == "string" && (s === "\r" || s === "\n") && l.type === "html" && Zy(l.value) !== 7 && (a[a.length - 1] = d.replace(/(\r?\n|\r)$/, " "), s = " ", c = t.createTracker(n), c.move(ub(a, n.before, n.after)));
		let f = t.handle.handlers[l.type];
		if (f && f.attention) {
			let e = ob(l, f.attention, t, c);
			if (!e) continue;
			a.push(e), s = Jy(e.sequences[0]);
		} else {
			let n = t.handle(l, e, t, {
				...c.current(),
				after: u,
				before: s
			});
			if (!n) continue;
			c.move(n), a.push(n), s = Jy(n);
		}
	}
	return r.pop(), a;
}
function ob(e, t, n, r) {
	let { construct: i, markers: a, sizes: o } = t(e, n), s = ib(e.type, a, o), c = s[0], l = n.enter(i), u = n.createTracker(r.current());
	u.move(c);
	let d = ab(e, n, {
		...u.current(),
		before: c,
		after: c
	});
	if (l(), d.length !== 0) return r.move(c), r.move(ub(d, c, c)), r.move(c), {
		children: d,
		sequences: s
	};
}
function sb(e, t, n, r) {
	let i = lb(e, t, n, r), a = eb(i, n, r);
	for (; a;) {
		let o = nb(e, t, a, n, r);
		if (!o) return;
		t = o.chosen, i = o.tokens, a = o.mistake;
	}
	return i;
}
function cb(e, t, n, r) {
	let i = n, a = -1;
	for (; ++a < e.length;) {
		let o = e[a];
		if (typeof o == "string") {
			i = "";
			continue;
		}
		let s = a === e.length - 1 ? r : "", c = o.sequences.find(function(t) {
			let r = t.charAt(0);
			return r !== i.charAt(0) && r !== s.charAt(0) || e.length === 1 && Qy.has(r) && t.length > n.length;
		}) || o.sequences[0];
		c !== o.sequences[0] && t.set(o, c), cb(o.children, t, c, c), i = c;
	}
}
function lb(e, t, n, r) {
	let i = [], a, o = Jy(n), s = -1;
	for (; ++s < e.length;) {
		let n = e[s];
		if (typeof n == "string") {
			let e = {
				value: n,
				attention: void 0
			};
			a && a === qy(n) && tb([e], !0), a = void 0, i.push(e), e.value && (o = Jy(e.value));
			continue;
		}
		let c = t.get(n) || n.sequences[0], l = c.charAt(0), u = e[s + 1], d = o, f = qy(u === void 0 ? r : typeof u == "string" ? u : t.get(u) || u.sequences[0]), p = lb(n.children, t, c, c), m = p[0].value, h = Xy(d.charCodeAt(d.length - 1), m.charCodeAt(0), l);
		h.inside && tb(p, !0);
		let g = Jy(p[p.length - 1].value), _ = Xy(f.charCodeAt(0), g.charCodeAt(g.length - 1), l);
		_.inside && tb(p, !1), h.outside && d !== "\n" && d !== "\r" && tb(i, !1), _.outside && (a = f), i.push({
			value: c,
			attention: n
		}, ...p, {
			value: c,
			attention: n
		}), o = c.charAt(c.length - 1);
	}
	return i;
}
function ub(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	cb(e, r, t, n);
	let i = (r.size > 0 ? sb(e, r, t, n) : void 0) || sb(e, /* @__PURE__ */ new Map(), t, n) || lb(e, /* @__PURE__ */ new Map(), t, n), a = "";
	for (let e of i) a += e.value;
	return a;
}
db.attention = fb, db.peek = pb;
function db(e, t, n, r) {
	let i = n.enter("phrasing"), a = ob(e, fb, n, n.createTracker(r)), o = a ? ub([a], r.before, r.after) : "";
	return i(), o;
}
function fb(e, t) {
	return {
		construct: "emphasis",
		markers: Ky(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [1]
	};
}
function pb(e, t, n) {
	return n.options.emphasis || "*";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/format-heading-as-setext.js
function mb(e, t) {
	let n = !1;
	return td(e, function(e) {
		if ("value" in e && /\r?\n|\r/.test(e.value) || e.type === "break") return n = !0, !1;
	}), !!((!e.depth || e.depth < 3) && us(e) && (t.options.setext || n));
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/heading.js
function hb(e, t, n, r) {
	let i = Math.max(Math.min(6, e.depth || 1), 1), a = n.createTracker(r);
	if (mb(e, n)) {
		let t = n.enter("headingSetext"), r = n.enter("phrasing"), o = n.containerPhrasing(e, {
			...a.current(),
			before: "\n",
			after: "\n"
		});
		return r(), t(), o + "\n" + (i === 1 ? "=" : "-").repeat(o.length - (Math.max(o.lastIndexOf("\r"), o.lastIndexOf("\n")) + 1));
	}
	let o = "#".repeat(i), s = n.enter("headingAtx"), c = n.enter("phrasing");
	a.move(o + " ");
	let l = n.containerPhrasing(e, {
		before: "# ",
		after: "\n",
		...a.current()
	}), u = l.charCodeAt(0);
	return (u === 9 || u === 32) && (l = Yy(u) + l.slice(1)), l = l ? o + " " + l : o, n.options.closeAtx && (l += " " + o), c(), s(), l;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/html.js
gb.peek = _b;
function gb(e) {
	return e.value || "";
}
function _b() {
	return "<";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/image.js
vb.peek = yb;
function vb(e, t, n, r) {
	let i = Wy(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("image"), s = n.enter("label"), c = n.createTracker(r), l = c.move("![");
	return l += c.move(n.safe(e.alt, {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]("), s(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : ")",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), l += c.move(")"), o(), l;
}
function yb() {
	return "!";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/image-reference.js
bb.peek = xb;
function bb(e, t, n, r) {
	let i = e.referenceType, a = n.enter("imageReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("!["), l = n.safe(e.alt, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function xb() {
	return "!";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/inline-code.js
Sb.peek = Cb;
function Sb(e, t, n) {
	let r = e.value || "", i = "`", a = -1;
	for (; RegExp("(^|[^`])" + i + "([^`]|$)").test(r);) i += "`";
	for (/[^\n\r ]/.test(r) && (/^[\n\r ]/.test(r) && /[\n\r ]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++a < n.unsafe.length;) {
		let e = n.unsafe[a], t = n.compilePattern(e);
		if (!e.atBreak) continue;
		let i;
		for (; i = t.exec(r);) {
			let e = i.index;
			r.charCodeAt(e) === 10 && r.charCodeAt(e - 1) === 13 && e--, r = r.slice(0, e) + " " + r.slice(i.index + 1);
		}
	}
	return i + r + i;
}
function Cb() {
	return "`";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/format-link-as-autolink.js
function wb(e, t) {
	let n = us(e);
	return !!(!t.options.resourceLink && e.url && !e.title && e.children && e.children.length === 1 && e.children[0].type === "text" && (n === e.url || "mailto:" + n === e.url) && /^[a-z][+\-.a-z]+:/i.test(e.url) && !/[\0- <>\u007F]/.test(e.url));
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/link.js
Tb.peek = Eb;
function Tb(e, t, n, r) {
	let i = Wy(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.createTracker(r);
	if (wb(e, n)) {
		let t = n.stack;
		n.stack = t.filter(function(e) {
			return e !== "phrasing";
		});
		let r = n.enter("autolink"), i = o.move("<");
		return i += o.move(n.containerPhrasing(e, {
			before: i,
			after: ">",
			...o.current()
		})), i += o.move(">"), r(), n.stack = t, i;
	}
	let s = n.enter("link"), c = n.enter("label"), l = o.move("["), u = n.containerPhrasing(e, {
		before: l,
		after: "](",
		...o.current()
	});
	l += o.move(u), c(), l += o.move("](");
	let d = /[\0- \u007F]/.test(e.url), f = r.before.charAt(r.before.length - 1), p = e.title || void 0;
	if (!p && !d && (f === "\n" || f === "\r")) {
		let e = 0;
		for (; e < u.length && u.charCodeAt(e) !== 93;) e += u.charCodeAt(e) === 92 ? 2 : 1;
		u.charCodeAt(e + 1) === 58 && (p = "");
	}
	return !e.url && typeof p == "string" || d ? (c = n.enter("destinationLiteral"), l += o.move("<"), l += o.move(n.safe(e.url, {
		before: l,
		after: ">",
		...o.current()
	})), l += o.move(">")) : (c = n.enter("destinationRaw"), l += o.move(n.safe(e.url, {
		before: l,
		after: typeof p == "string" ? " " : ")",
		...o.current()
	}))), c(), typeof p == "string" && (c = n.enter(`title${a}`), l += o.move(" " + i), l += o.move(n.safe(p, {
		before: l,
		after: i,
		...o.current()
	})), l += o.move(i), c()), l += o.move(")"), s(), l;
}
function Eb(e, t, n) {
	return wb(e, n) ? "<" : "[";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/link-reference.js
Db.peek = Ob;
function Db(e, t, n, r) {
	let i = e.referenceType, a = n.enter("linkReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("["), l = n.containerPhrasing(e, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function Ob() {
	return "[";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-bullet.js
function kb(e) {
	let t = e.options.bullet || "*";
	if (t !== "*" && t !== "+" && t !== "-") throw Error("Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-bullet-other.js
function Ab(e) {
	let t = kb(e), n = e.options.bulletOther;
	if (!n) return t === "*" ? "-" : "*";
	if (n !== "*" && n !== "+" && n !== "-") throw Error("Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
	if (n === t) throw Error("Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different");
	return n;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-bullet-ordered.js
function jb(e) {
	let t = e.options.bulletOrdered || ".";
	if (t !== "." && t !== ")") throw Error("Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-rule.js
function Mb(e) {
	let t = e.options.rule || "*";
	if (t !== "*" && t !== "-" && t !== "_") throw Error("Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/list.js
function Nb(e, t, n, r) {
	let i = n.enter("list"), a = n.bulletCurrent, o = e.ordered ? jb(n) : kb(n), s = e.ordered ? o === "." ? ")" : "." : Ab(n), c = t && n.bulletLastUsed ? o === n.bulletLastUsed : !1;
	if (!e.ordered) {
		let t = e.children ? e.children[0] : void 0;
		if ((o === "*" || o === "-") && t && (!t.children || !t.children[0]) && n.stack[n.stack.length - 1] === "list" && n.stack[n.stack.length - 2] === "listItem" && n.stack[n.stack.length - 3] === "list" && n.stack[n.stack.length - 4] === "listItem" && n.indexStack[n.indexStack.length - 1] === 0 && n.indexStack[n.indexStack.length - 2] === 0 && n.indexStack[n.indexStack.length - 3] === 0 && (c = !0), Mb(n) === o && t) {
			let t = -1;
			for (; ++t < e.children.length;) {
				let n = e.children[t];
				if (n && n.type === "listItem" && n.children && n.children[0] && n.children[0].type === "thematicBreak") {
					c = !0;
					break;
				}
			}
		}
	}
	c && (o = s), n.bulletCurrent = o;
	let l = n.containerFlow(e, r);
	return n.bulletLastUsed = o, n.bulletCurrent = a, i(), l;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-list-item-indent.js
function Pb(e) {
	let t = e.options.listItemIndent || "one";
	if (t !== "tab" && t !== "one" && t !== "mixed") throw Error("Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/list-item.js
function Fb(e, t, n, r) {
	let i = Pb(n), a = n.bulletCurrent || kb(n);
	t && t.type === "list" && t.ordered && (a = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === !1 ? 0 : t.children.indexOf(e)) + a);
	let o = a.length + 1;
	(i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (o = Math.ceil(o / 4) * 4);
	let s = n.createTracker(r);
	s.move(a + " ".repeat(o - a.length)), s.shift(o);
	let c = n.enter("listItem"), l = n.indentLines(n.containerFlow(e, s.current()), u);
	return c(), l;
	function u(e, t, n) {
		return t ? (n ? "" : " ".repeat(o)) + e : (n ? a : a + " ".repeat(o - a.length)) + e;
	}
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/paragraph.js
function Ib(e, t, n, r) {
	let i = n.enter("paragraph"), a = n.enter("phrasing"), o = n.containerPhrasing(e, r);
	return a(), i(), o;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/root.js
function Lb(e, t, n, r) {
	if (!e.children.some(function(e) {
		return Ny(e);
	})) return n.containerFlow(e, r);
	let i = n.enter("phrasing"), a = n.containerPhrasing(e, r);
	return i(), a;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-strong.js
function Rb(e) {
	let t = e.options.strong || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`");
	return t;
}
zb.attention = Bb, zb.peek = Vb;
function zb(e, t, n, r) {
	let i = n.enter("phrasing"), a = ob(e, Bb, n, n.createTracker(r)), o = a ? ub([a], r.before, r.after) : "";
	return i(), o;
}
function Bb(e, t) {
	return {
		construct: "strong",
		markers: Rb(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [2]
	};
}
function Vb(e, t, n) {
	return n.options.strong || "*";
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/text.js
function Hb(e, t, n, r) {
	/* c8 ignore next -- parent always passed */
	let i = t ? t.children : [], a = n.indexStack[n.indexStack.length - 1];
	return n.safe(e.value, {
		...r,
		afterNode: i[a + 1],
		beforeNode: i[a - 1]
	});
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/util/check-rule-repetition.js
function Ub(e) {
	let t = e.options.ruleRepetition || 3;
	if (t < 3) throw Error("Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more");
	return t;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/thematic-break.js
function Wb(e, t, n) {
	let r = (Mb(n) + (n.options.ruleSpaces ? " " : "")).repeat(Ub(n));
	return n.options.ruleSpaces ? r.slice(0, -1) : r;
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-to-markdown@2.2.3/node_modules/mdast-util-to-markdown/lib/handle/index.js
var Gb = {
	blockquote: Py,
	break: Ry,
	code: Hy,
	definition: Gy,
	emphasis: db,
	hardBreak: Ry,
	heading: hb,
	html: gb,
	image: vb,
	imageReference: bb,
	inlineCode: Sb,
	link: Tb,
	linkReference: Db,
	list: Nb,
	listItem: Fb,
	paragraph: Ib,
	root: Lb,
	strong: zb,
	text: Hb,
	thematicBreak: Wb
};
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm-table@2.0.1/node_modules/mdast-util-gfm-table/lib/index.js
function Kb() {
	return {
		enter: {
			table: qb,
			tableData: Zb,
			tableHeader: Zb,
			tableRow: Yb
		},
		exit: {
			codeText: Qb,
			table: Jb,
			tableData: Xb,
			tableHeader: Xb,
			tableRow: Xb
		}
	};
}
function qb(e) {
	let t = e._align;
	this.enter({
		type: "table",
		align: t.map(function(e) {
			return e === "none" ? null : e;
		}),
		children: [],
		position: void 0
	}, e), this.data.inTable = !0;
}
function Jb(e) {
	this.exit(e), this.data.inTable = void 0;
}
function Yb(e) {
	this.enter({
		type: "tableRow",
		children: [],
		position: void 0
	}, e);
}
function Xb(e) {
	this.exit(e);
}
function Zb(e) {
	this.enter({
		type: "tableCell",
		children: [],
		position: void 0
	}, e);
}
function Qb(e) {
	let t = this.resume();
	this.data.inTable && (t = t.replace(/\\([\\|])/g, $b));
	let n = this.stack[this.stack.length - 1];
	n.type, n.value = t, this.exit(e);
}
function $b(e, t) {
	return t === "|" ? t : e;
}
function ex(e) {
	let { tableCellPadding: t, tablePipeAlign: n, stringLength: r } = e || {}, i = t ? " " : "|";
	return {
		handlers: {
			inlineCode: d,
			table: a,
			tableCell: s,
			tableRow: o
		},
		join: [tx],
		unsafe: [
			{
				character: "\r",
				inConstruct: "tableCell"
			},
			{
				character: "\n",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: "|",
				after: "[	 :-]"
			},
			{
				character: "|",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: ":",
				after: "-"
			},
			{
				atBreak: !0,
				character: "-",
				after: "[:|-]"
			}
		]
	};
	function a(e, t, n, r) {
		let i = l(e, n, r), a = i[0];
		if (a) {
			let t = e.align ? e.align.length : 0, n = -1;
			if (!t) for (; ++n < i.length;) i[n].length > t && (t = i[n].length);
			for (; a.length < t;) a.push("");
		}
		return c(i, e.align);
	}
	function o(e, t, n, r) {
		let i = c([u(e, n, r)]);
		return i.slice(0, i.indexOf("\n"));
	}
	function s(e, t, n, r) {
		let a = n.enter("tableCell"), o = n.enter("phrasing"), s = n.containerPhrasing(e, {
			...r,
			before: i,
			after: i
		});
		return o(), a(), s;
	}
	function c(e, i) {
		return Ay(e, {
			align: i,
			alignDelimiters: n,
			fillRows: !1,
			padding: t,
			stringLength: r
		});
	}
	function l(e, t, n) {
		let { children: r } = e, i = -1, a = [], o = t.enter("table");
		for (; ++i < r.length;) a[i] = u(r[i], t, n);
		return o(), a;
	}
	function u(e, t, n) {
		let { children: r } = e, i = -1, a = [], o = t.enter("tableRow");
		for (; ++i < r.length;) a[i] = s(r[i], e, t, n);
		return o(), a;
	}
	function d(e, t, n) {
		let r = Gb.inlineCode(e, t, n);
		if (!n.stack.includes("tableCell")) return r;
		let i = [], a = 0, o = r.indexOf("|");
		for (; o !== -1;) {
			let e = o;
			for (; e > a && r.charCodeAt(e - 1) === 92;) e--;
			i.push(r.slice(a, o)), (o - e) % 2 == 0 && i.push("\\"), a = o, o = r.indexOf("|", o + 1);
		}
		return i.push(r.slice(a)), i.join("");
	}
}
function tx(e, t, n, r) {
	if (e.type === "table" && n.type === "listItem" && n.spread === !1 && (t.type === "definition" || t.type === "heading" && nx(t, r) || t.type === "paragraph" || t.type === "table")) return 1;
}
function nx(e, t) {
	let n = !1;
	return td(e, function(e) {
		if (e.type === "break" || "value" in e && /\r?\n|\r/.test(e.value)) return n = !0, !1;
	}), !!((!e.depth || e.depth < 3) && us(e) && (t.options.setext || n));
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm-task-list-item@2.0.1/node_modules/mdast-util-gfm-task-list-item/lib/index.js
function rx() {
	return { exit: {
		taskListCheckValueChecked: ax,
		taskListCheckValueUnchecked: ax,
		paragraph: ox
	} };
}
function ix() {
	return {
		handlers: { paragraph: sx },
		join: [cx]
	};
}
function ax(e) {
	let t = this.stack[this.stack.length - 2];
	t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function ox(e) {
	let t = this.stack[this.stack.length - 2];
	if (t && t.type === "listItem" && typeof t.checked == "boolean") {
		let e = this.stack[this.stack.length - 1];
		e.type;
		let n = e.children[0];
		if (n && n.type === "text") {
			let r = t.children, i = -1, a;
			for (; ++i < r.length;) {
				let e = r[i];
				if (e.type === "paragraph") {
					a = e;
					break;
				}
			}
			a === e && (n.value = n.value.slice(1), n.value.length === 0 ? e.children.shift() : e.position && n.position && typeof n.position.start.offset == "number" && (n.position.start.column++, n.position.start.offset++, e.position.start = { ...n.position.start }));
		}
	}
	this.exit(e);
}
function sx(e, t, n, r) {
	if (!t || t.type !== "listItem" || lx(t) !== e) return Gb.paragraph(e, t, n, r);
	let i = "[" + (t.checked ? "x" : " ") + "] ", a = n.createTracker(r);
	return a.move(i), i + Gb.paragraph(e.children.length > 0 ? e : {
		type: "paragraph",
		children: [{
			type: "text",
			value: " "
		}]
	}, t, n, {
		...r,
		...a.current()
	});
}
function cx(e, t, n) {
	if (!(e.type === "definition" && n.type === "listItem")) return;
	let r = lx(n);
	if (r && n.children.indexOf(e) < n.children.indexOf(r)) return 0;
}
function lx(e) {
	if (typeof e.checked == "boolean") for (let t of e.children) {
		if (t.type === "paragraph") return t;
		if (t.type !== "definition") return;
	}
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-gfm@3.1.0/node_modules/mdast-util-gfm/lib/index.js
function ux() {
	return [
		Gv(),
		_y(),
		Sy(),
		Kb(),
		rx()
	];
}
function dx(e) {
	return { extensions: [
		Kv(),
		vy(e),
		Cy(),
		ex(e),
		ix()
	] };
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-autolink-literal@2.1.0/node_modules/micromark-extension-gfm-autolink-literal/lib/syntax.js
var fx = {
	tokenize: Ex,
	partial: !0
}, px = {
	tokenize: Dx,
	partial: !0
}, mx = {
	tokenize: Ox,
	partial: !0
}, hx = {
	tokenize: kx,
	partial: !0
}, gx = {
	tokenize: Ax,
	partial: !0
}, _x = {
	name: "wwwAutolink",
	tokenize: wx,
	previous: jx
}, vx = {
	name: "protocolAutolink",
	tokenize: Tx,
	previous: Mx
}, yx = {
	name: "emailAutolink",
	tokenize: Cx,
	previous: Nx
}, bx = {};
function xx() {
	return { text: bx };
}
for (var Sx = 48; Sx < 123;) bx[Sx] = yx, Sx++, Sx === 58 ? Sx = 65 : Sx === 91 && (Sx = 97);
bx[43] = yx, bx[45] = yx, bx[46] = yx, bx[95] = yx, bx[72] = [yx, vx], bx[104] = [yx, vx], bx[87] = [yx, _x], bx[119] = [yx, _x];
function Cx(e, t, n) {
	let r = this, i, a;
	return o;
	function o(t) {
		return !Px(t) || !Nx.call(r, r.previous) || Fx(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), s(t));
	}
	function s(t) {
		return Px(t) ? (e.consume(t), s) : t === 64 ? (e.consume(t), c) : n(t);
	}
	function c(t) {
		return t === 46 ? e.check(gx, u, l)(t) : t === 45 || t === 95 || z(t) ? (a = !0, e.consume(t), c) : u(t);
	}
	function l(t) {
		return e.consume(t), i = !0, c;
	}
	function u(o) {
		return a && i && R(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(o)) : n(o);
	}
}
function wx(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t !== 87 && t !== 119 || !jx.call(r, r.previous) || Fx(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(fx, e.attempt(px, e.attempt(mx, a), n), n)(t));
	}
	function a(n) {
		return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(n);
	}
}
function Tx(e, t, n) {
	let r = this, i = "", a = !1;
	return o;
	function o(t) {
		return (t === 72 || t === 104) && Mx.call(r, r.previous) && !Fx(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(t), e.consume(t), s) : n(t);
	}
	function s(t) {
		if (R(t) && i.length < 5) return i += String.fromCodePoint(t), e.consume(t), s;
		if (t === 58) {
			let n = i.toLowerCase();
			if (n === "http" || n === "https") return e.consume(t), c;
		}
		return n(t);
	}
	function c(t) {
		return t === 47 ? (e.consume(t), a ? l : (a = !0, c)) : n(t);
	}
	function l(t) {
		return t === null || Ts(t) || V(t) || As(t) || ks(t) ? n(t) : e.attempt(px, e.attempt(mx, u), n)(t);
	}
	function u(n) {
		return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(n);
	}
}
function Ex(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return (t === 87 || t === 119) && r < 3 ? (r++, e.consume(t), i) : t === 46 && r === 3 ? (e.consume(t), a) : n(t);
	}
	function a(e) {
		return e === null ? n(e) : t(e);
	}
}
function Dx(e, t, n) {
	let r, i, a;
	return o;
	function o(t) {
		return t === 46 || t === 95 ? e.check(hx, c, s)(t) : t === null || V(t) || As(t) || t !== 45 && ks(t) ? c(t) : (a = !0, e.consume(t), o);
	}
	function s(t) {
		return t === 95 ? r = !0 : (i = r, r = void 0), e.consume(t), o;
	}
	function c(e) {
		return i || r || !a ? n(e) : t(e);
	}
}
function Ox(e, t) {
	let n = 0, r = 0;
	return i;
	function i(o) {
		return o === 40 ? (n++, e.consume(o), i) : o === 41 && r < n ? a(o) : o === 33 || o === 34 || o === 38 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 60 || o === 63 || o === 93 || o === 95 || o === 126 ? e.check(hx, t, a)(o) : o === null || V(o) || As(o) ? t(o) : (e.consume(o), i);
	}
	function a(t) {
		return t === 41 && r++, e.consume(t), i;
	}
}
function kx(e, t, n) {
	return r;
	function r(o) {
		return o === 33 || o === 34 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 63 || o === 95 || o === 126 ? (e.consume(o), r) : o === 38 ? (e.consume(o), a) : o === 93 ? (e.consume(o), i) : o === 60 || o === null || V(o) || As(o) ? t(o) : n(o);
	}
	function i(e) {
		return e === null || e === 40 || e === 91 || V(e) || As(e) ? t(e) : r(e);
	}
	function a(e) {
		return R(e) ? o(e) : n(e);
	}
	function o(t) {
		return t === 59 ? (e.consume(t), r) : R(t) ? (e.consume(t), o) : n(t);
	}
}
function Ax(e, t, n) {
	return r;
	function r(t) {
		return e.consume(t), i;
	}
	function i(e) {
		return z(e) ? n(e) : t(e);
	}
}
function jx(e) {
	return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || V(e);
}
function Mx(e) {
	return !R(e);
}
function Nx(e) {
	return !(e === 47 || Px(e));
}
function Px(e) {
	return e === 43 || e === 45 || e === 46 || e === 95 || z(e);
}
function Fx(e) {
	let t = e.length, n = !1;
	for (; t--;) {
		let r = e[t][1];
		if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
			n = !0;
			break;
		}
		if (r._gfmAutolinkLiteralWalkedInto) {
			n = !1;
			break;
		}
	}
	return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-footnote@2.1.0/node_modules/micromark-extension-gfm-footnote/lib/syntax.js
var Ix = {
	tokenize: Wx,
	partial: !0
};
function Lx() {
	return {
		document: { 91: {
			name: "gfmFootnoteDefinition",
			tokenize: Vx,
			continuation: { tokenize: Hx },
			exit: Ux
		} },
		text: {
			91: {
				name: "gfmFootnoteCall",
				tokenize: Bx
			},
			93: {
				name: "gfmPotentialFootnoteCall",
				add: "after",
				tokenize: Rx,
				resolveTo: zx
			}
		}
	};
}
function Rx(e, t, n) {
	let r = this, i = r.events.length, a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), o;
	for (; i--;) {
		let e = r.events[i][1];
		if (e.type === "labelImage") {
			o = e;
			break;
		}
		if (e.type === "gfmFootnoteCall" || e.type === "labelLink" || e.type === "label" || e.type === "image" || e.type === "link") break;
	}
	return s;
	function s(i) {
		if (!o || !o._balanced) return n(i);
		let s = Cs(r.sliceSerialize({
			start: o.end,
			end: r.now()
		}));
		return s.codePointAt(0) !== 94 || !a.includes(s.slice(1)) ? n(i) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(i), e.exit("gfmFootnoteCallLabelMarker"), t(i));
	}
}
function zx(e, t) {
	let n = e.length;
	for (; n--;) if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
		e[n][1];
		break;
	}
	e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
	let r = {
		type: "gfmFootnoteCall",
		start: Object.assign({}, e[n + 3][1].start),
		end: Object.assign({}, e[e.length - 1][1].end)
	}, i = {
		type: "gfmFootnoteCallMarker",
		start: Object.assign({}, e[n + 3][1].end),
		end: Object.assign({}, e[n + 3][1].end)
	};
	i.end.column++, i.end.offset++, i.end._bufferIndex++;
	let a = {
		type: "gfmFootnoteCallString",
		start: Object.assign({}, i.end),
		end: Object.assign({}, e[e.length - 1][1].start)
	}, o = {
		type: "chunkString",
		contentType: "string",
		start: Object.assign({}, a.start),
		end: Object.assign({}, a.end)
	}, s = [
		e[n + 1],
		e[n + 2],
		[
			"enter",
			r,
			t
		],
		e[n + 3],
		e[n + 4],
		[
			"enter",
			i,
			t
		],
		[
			"exit",
			i,
			t
		],
		[
			"enter",
			a,
			t
		],
		[
			"enter",
			o,
			t
		],
		[
			"exit",
			o,
			t
		],
		[
			"exit",
			a,
			t
		],
		e[e.length - 2],
		e[e.length - 1],
		[
			"exit",
			r,
			t
		]
	];
	return e.splice(n, e.length - n + 1, ...s), e;
}
function Bx(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a = 0, o;
	return s;
	function s(t) {
		return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(t), e.exit("gfmFootnoteCallLabelMarker"), c;
	}
	function c(t) {
		return t === 94 ? (e.enter("gfmFootnoteCallMarker"), e.consume(t), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", l) : n(t);
	}
	function l(s) {
		if (a > 999 || s === 93 && !o || s === null || s === 91 || V(s)) return n(s);
		if (s === 93) {
			e.exit("chunkString");
			let a = e.exit("gfmFootnoteCallString");
			return i.includes(Cs(r.sliceSerialize(a))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(s), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(s);
		}
		return V(s) || (o = !0), a++, e.consume(s), s === 92 ? u : l;
	}
	function u(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), a++, l) : l(t);
	}
}
function Vx(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a, o = 0, s;
	return c;
	function c(t) {
		return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), l;
	}
	function l(t) {
		return t === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", u) : n(t);
	}
	function u(t) {
		if (o > 999 || t === 93 && !s || t === null || t === 91 || V(t)) return n(t);
		if (t === 93) {
			e.exit("chunkString");
			let n = e.exit("gfmFootnoteDefinitionLabelString");
			return a = Cs(r.sliceSerialize(n)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), f;
		}
		return V(t) || (s = !0), o++, e.consume(t), t === 92 ? d : u;
	}
	function d(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), o++, u) : u(t);
	}
	function f(t) {
		return t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), i.includes(a) || i.push(a), U(e, p, "gfmFootnoteDefinitionWhitespace")) : n(t);
	}
	function p(e) {
		return t(e);
	}
}
function Hx(e, t, n) {
	return e.check(Xs, t, e.attempt(Ix, t, n));
}
function Ux(e) {
	e.exit("gfmFootnoteDefinition");
}
function Wx(e, t, n) {
	let r = this;
	return U(e, i, "gfmFootnoteDefinitionIndent", 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "gfmFootnoteDefinitionIndent" && i[2].sliceSerialize(i[1], !0).length === 4 ? t(e) : n(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-strikethrough@2.1.0/node_modules/micromark-extension-gfm-strikethrough/lib/syntax.js
function Gx(e) {
	let t = (e || {}).singleTilde, n = {
		name: "strikethrough",
		tokenize: i,
		resolveAll: r
	};
	return t ??= !0, {
		text: { 126: n },
		insideSpan: { null: [n] },
		attentionMarkers: { null: [126] }
	};
	function r(e, t) {
		let n = -1;
		for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "strikethroughSequenceTemporary" && e[n][1]._close) {
			let r = n;
			for (; r--;) if (e[r][0] === "exit" && e[r][1].type === "strikethroughSequenceTemporary" && e[r][1]._open && e[n][1].end.offset - e[n][1].start.offset === e[r][1].end.offset - e[r][1].start.offset) {
				e[n][1].type = "strikethroughSequence", e[r][1].type = "strikethroughSequence";
				let i = {
					type: "strikethrough",
					start: Object.assign({}, e[r][1].start),
					end: Object.assign({}, e[n][1].end)
				}, a = {
					type: "strikethroughText",
					start: Object.assign({}, e[r][1].end),
					end: Object.assign({}, e[n][1].start)
				}, o = [
					[
						"enter",
						i,
						t
					],
					[
						"enter",
						e[r][1],
						t
					],
					[
						"exit",
						e[r][1],
						t
					],
					[
						"enter",
						a,
						t
					]
				], s = t.parser.constructs.insideSpan.null;
				s && gs(o, o.length, 0, Us(s, e.slice(r + 1, n), t)), gs(o, o.length, 0, [
					[
						"exit",
						a,
						t
					],
					[
						"enter",
						e[n][1],
						t
					],
					[
						"exit",
						e[n][1],
						t
					],
					[
						"exit",
						i,
						t
					]
				]), gs(e, r - 1, n - r + 3, o), n = r + o.length - 2;
				break;
			}
		}
		for (n = -1; ++n < e.length;) e[n][1].type === "strikethroughSequenceTemporary" && (e[n][1].type = "data");
		return e;
	}
	function i(e, n, r) {
		let i = this.previous, a = this.events, o = 0;
		return s;
		function s(t) {
			return i === 126 && a[a.length - 1][1].type !== "characterEscape" ? r(t) : (e.enter("strikethroughSequenceTemporary"), c(t));
		}
		function c(a) {
			let s = Hs(i);
			if (a === 126) return o > 1 ? r(a) : (e.consume(a), o++, c);
			if (o < 2 && !t) return r(a);
			let l = e.exit("strikethroughSequenceTemporary"), u = Hs(a);
			return l._open = !u || u === 2 && !!s, l._close = !s || s === 2 && !!u, n(a);
		}
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-table@2.1.2/node_modules/micromark-extension-gfm-table/lib/edit-map.js
var Kx = class {
	constructor() {
		this.map = [], this.index = /* @__PURE__ */ new Map();
	}
	add(e, t, n) {
		qx(this, e, t, n);
	}
	consume(e) {
		/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function qx(e, t, n, r) {
	/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
	if (n === 0 && r.length === 0) return;
	let i = e.index.get(t);
	if (i) {
		i[1] += n, i[2].push(...r);
		return;
	}
	let a = [
		t,
		n,
		r
	];
	e.map.push(a), e.index.set(t, a);
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-table@2.1.2/node_modules/micromark-extension-gfm-table/lib/infer.js
function Jx(e, t) {
	let n = !1, r = [];
	for (; t < e.length;) {
		let i = e[t];
		if (n) {
			if (i[0] === "enter") i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
			else if (i[1].type === "tableContent") {
				if (e[t - 1][1].type === "tableDelimiterMarker") {
					let e = r.length - 1;
					r[e] = r[e] === "left" ? "center" : "right";
				}
			} else if (i[1].type === "tableDelimiterRow") break;
		} else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = !0);
		t += 1;
	}
	return r;
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-table@2.1.2/node_modules/micromark-extension-gfm-table/lib/syntax.js
function Yx() {
	return { flow: { null: {
		name: "table",
		tokenize: Xx,
		resolveAll: Zx
	} } };
}
function Xx(e, t, n) {
	let r = this, i = 0, a = 0, o;
	return s;
	function s(e) {
		let t = r.events.length - 1;
		for (; t > -1;) {
			let { type: e } = r.events[t][1];
			if (e === "lineEnding" || e === "linePrefix") t--;
			else break;
		}
		let i = t > -1 ? r.events[t][1].type : null, a = i === "tableHead" || i === "tableRow" ? S : c;
		return a === S && r.parser.lazy[r.now().line] ? n(e) : a(e);
	}
	function c(t) {
		return e.enter("tableHead"), e.enter("tableRow"), l(t);
	}
	function l(e) {
		return e === 124 ? u(e) : (o = !0, a += 1, u(e));
	}
	function u(t) {
		return t === null ? n(t) : B(t) ? a > 1 ? (a = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), p) : n(t) : H(t) ? U(e, u, "whitespace")(t) : (a += 1, o && (o = !1, i += 1), t === 124 ? (e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), o = !0, u) : (e.enter("data"), d(t)));
	}
	function d(t) {
		return t === null || t === 124 || V(t) ? (e.exit("data"), u(t)) : (e.consume(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 92 || t === 124 ? (e.consume(t), d) : d(t);
	}
	function p(t) {
		return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(t) : (e.enter("tableDelimiterRow"), o = !1, H(t) ? U(e, m, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : m(t));
	}
	function m(t) {
		return t === 45 || t === 58 ? g(t) : t === 124 ? (o = !0, e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), h) : x(t);
	}
	function h(t) {
		return H(t) ? U(e, g, "whitespace")(t) : g(t);
	}
	function g(t) {
		return t === 58 ? (a += 1, o = !0, e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), _) : t === 45 ? (a += 1, _(t)) : t === null || B(t) ? b(t) : x(t);
	}
	function _(t) {
		return t === 45 ? (e.enter("tableDelimiterFiller"), v(t)) : x(t);
	}
	function v(t) {
		return t === 45 ? (e.consume(t), v) : t === 58 ? (o = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), y) : (e.exit("tableDelimiterFiller"), y(t));
	}
	function y(t) {
		return H(t) ? U(e, b, "whitespace")(t) : b(t);
	}
	function b(n) {
		return n === 124 ? m(n) : n === null || B(n) ? !o || i !== a ? x(n) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(n)) : x(n);
	}
	function x(e) {
		return n(e);
	}
	function S(t) {
		return e.enter("tableRow"), C(t);
	}
	function C(n) {
		return n === 124 ? (e.enter("tableCellDivider"), e.consume(n), e.exit("tableCellDivider"), C) : n === null || B(n) ? (e.exit("tableRow"), t(n)) : H(n) ? U(e, C, "whitespace")(n) : (e.enter("data"), w(n));
	}
	function w(t) {
		return t === null || t === 124 || V(t) ? (e.exit("data"), C(t)) : (e.consume(t), t === 92 ? T : w);
	}
	function T(t) {
		return t === 92 || t === 124 ? (e.consume(t), w) : w(t);
	}
}
function Zx(e, t) {
	let n = -1, r = !0, i = 0, a = [
		0,
		0,
		0,
		0
	], o = [
		0,
		0,
		0,
		0
	], s = !1, c = 0, l, u, d, f = new Kx();
	for (; ++n < e.length;) {
		let p = e[n], m = p[1];
		p[0] === "enter" ? m.type === "tableHead" ? (s = !1, c !== 0 && ($x(f, t, c, l, u), u = void 0, c = 0), l = {
			type: "table",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			l,
			t
		]])) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (r = !0, d = void 0, a = [
			0,
			0,
			0,
			0
		], o = [
			0,
			n + 1,
			0,
			0
		], s && (s = !1, u = {
			type: "tableBody",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			u,
			t
		]])), i = m.type === "tableDelimiterRow" ? 2 : u ? 3 : 1) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") ? (r = !1, o[2] === 0 && (a[1] !== 0 && (o[0] = o[1], d = Qx(f, t, a, i, void 0, d), a = [
			0,
			0,
			0,
			0
		]), o[2] = n)) : m.type === "tableCellDivider" && (r ? r = !1 : (a[1] !== 0 && (o[0] = o[1], d = Qx(f, t, a, i, void 0, d)), a = o, o = [
			a[1],
			n,
			0,
			0
		])) : m.type === "tableHead" ? (s = !0, c = n) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (c = n, a[1] === 0 ? o[1] !== 0 && (d = Qx(f, t, o, i, n, d)) : (o[0] = o[1], d = Qx(f, t, a, i, n, d)), i = 0) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") && (o[3] = n);
	}
	for (c !== 0 && $x(f, t, c, l, u), f.consume(t.events), n = -1; ++n < t.events.length;) {
		let e = t.events[n];
		e[0] === "enter" && e[1].type === "table" && (e[1]._align = Jx(t.events, n));
	}
	return e;
}
function Qx(e, t, n, r, i, a) {
	let o = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData";
	n[0] !== 0 && (a.end = Object.assign({}, eS(t.events, n[0])), e.add(n[0], 0, [[
		"exit",
		a,
		t
	]]));
	let s = eS(t.events, n[1]);
	if (a = {
		type: o,
		start: Object.assign({}, s),
		end: Object.assign({}, s)
	}, e.add(n[1], 0, [[
		"enter",
		a,
		t
	]]), n[2] !== 0) {
		let i = eS(t.events, n[2]), a = eS(t.events, n[3]), o = {
			type: "tableContent",
			start: Object.assign({}, i),
			end: Object.assign({}, a)
		};
		if (e.add(n[2], 0, [[
			"enter",
			o,
			t
		]]), r !== 2) {
			let r = t.events[n[2]], i = t.events[n[3]];
			if (r[1].end = Object.assign({}, i[1].end), r[1].type = "chunkText", r[1].contentType = "text", n[3] > n[2] + 1) {
				let t = n[2] + 1, r = n[3] - n[2] - 1;
				e.add(t, r, []);
			}
		}
		e.add(n[3] + 1, 0, [[
			"exit",
			o,
			t
		]]);
	}
	return i !== void 0 && (a.end = Object.assign({}, eS(t.events, i)), e.add(i, 0, [[
		"exit",
		a,
		t
	]]), a = void 0), a;
}
function $x(e, t, n, r, i) {
	let a = [], o = eS(t.events, n);
	i && (i.end = Object.assign({}, o), a.push([
		"exit",
		i,
		t
	])), r.end = Object.assign({}, o), a.push([
		"exit",
		r,
		t
	]), e.add(n + 1, 0, a);
}
function eS(e, t) {
	let n = e[t], r = n[0] === "enter" ? "start" : "end";
	return n[1][r];
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm-task-list-item@2.1.0/node_modules/micromark-extension-gfm-task-list-item/lib/syntax.js
var tS = {
	name: "tasklistCheck",
	tokenize: rS
};
function nS() {
	return { text: { 91: tS } };
}
function rS(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? n(t) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), a);
	}
	function a(t) {
		return V(t) ? (e.enter("taskListCheckValueUnchecked"), e.consume(t), e.exit("taskListCheckValueUnchecked"), o) : t === 88 || t === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(t), e.exit("taskListCheckValueChecked"), o) : n(t);
	}
	function o(t) {
		return t === 93 ? (e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), s) : n(t);
	}
	function s(r) {
		return B(r) ? t(r) : H(r) ? e.check({ tokenize: iS }, t, n)(r) : n(r);
	}
}
function iS(e, t, n) {
	return U(e, r, "whitespace");
	function r(e) {
		return e === null ? n(e) : t(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-gfm@3.0.0/node_modules/micromark-extension-gfm/index.js
function aS(e) {
	return ys([
		xx(),
		Lx(),
		Gx(e),
		Yx(),
		nS()
	]);
}
//#endregion
//#region ../../node_modules/.bun/remark-gfm@4.0.1/node_modules/remark-gfm/lib/index.js
var oS = {};
function sS(e) {
	let t = this, n = e || oS, r = t.data(), i = r.micromarkExtensions ||= [], a = r.fromMarkdownExtensions ||= [], o = r.toMarkdownExtensions ||= [];
	i.push(aS(n)), a.push(ux()), o.push(dx(n));
}
//#endregion
//#region ../../node_modules/.bun/mdast-util-math@3.0.0/node_modules/mdast-util-math/lib/index.js
function cS() {
	return {
		enter: {
			mathFlow: e,
			mathFlowFenceMeta: t,
			mathText: a
		},
		exit: {
			mathFlow: i,
			mathFlowFence: r,
			mathFlowFenceMeta: n,
			mathFlowValue: s,
			mathText: o,
			mathTextData: s
		}
	};
	function e(e) {
		this.enter({
			type: "math",
			meta: null,
			value: "",
			data: {
				hName: "pre",
				hChildren: [{
					type: "element",
					tagName: "code",
					properties: { className: ["language-math", "math-display"] },
					children: []
				}]
			}
		}, e);
	}
	function t() {
		this.buffer();
	}
	function n() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.type, t.meta = e;
	}
	function r() {
		this.data.mathFlowInside || (this.buffer(), this.data.mathFlowInside = !0);
	}
	function i(e) {
		let t = this.resume().replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), n = this.stack[this.stack.length - 1];
		n.type, this.exit(e), n.value = t;
		let r = n.data.hChildren[0];
		r.type, r.tagName, r.children.push({
			type: "text",
			value: t
		}), this.data.mathFlowInside = void 0;
	}
	function a(e) {
		this.enter({
			type: "inlineMath",
			value: "",
			data: {
				hName: "code",
				hProperties: { className: ["language-math", "math-inline"] },
				hChildren: []
			}
		}, e), this.buffer();
	}
	function o(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.type, this.exit(e), n.value = t, n.data.hChildren.push({
			type: "text",
			value: t
		});
	}
	function s(e) {
		this.config.enter.data.call(this, e), this.config.exit.data.call(this, e);
	}
}
function lS(e) {
	let t = (e || {}).singleDollarTextMath;
	return t ??= !0, r.peek = i, {
		unsafe: [
			{
				character: "\r",
				inConstruct: "mathFlowMeta"
			},
			{
				character: "\n",
				inConstruct: "mathFlowMeta"
			},
			{
				character: "$",
				after: t ? void 0 : "\\$",
				inConstruct: "phrasing"
			},
			{
				character: "$",
				inConstruct: "mathFlowMeta"
			},
			{
				atBreak: !0,
				character: "$",
				after: "\\$"
			}
		],
		handlers: {
			math: n,
			inlineMath: r
		}
	};
	function n(e, t, n, r) {
		let i = e.value || "", a = n.createTracker(r), o = "$".repeat(Math.max(zy(i, "$") + 1, 2)), s = n.enter("mathFlow"), c = a.move(o);
		if (e.meta) {
			let t = n.enter("mathFlowMeta");
			c += a.move(n.safe(e.meta, {
				after: "\n",
				before: c,
				encode: ["$"],
				...a.current()
			})), t();
		}
		return c += a.move("\n"), i && (c += a.move(i + "\n")), c += a.move(o), s(), c;
	}
	function r(e, n, r) {
		let i = e.value || "", a = 1;
		for (t || a++; RegExp("(^|[^$])" + "\\$".repeat(a) + "([^$]|$)").test(i);) a++;
		let o = "$".repeat(a);
		/[^ \r\n]/.test(i) && (/^[ \r\n]/.test(i) && /[ \r\n]$/.test(i) || /^\$|\$$/.test(i)) && (i = " " + i + " ");
		let s = -1;
		for (; ++s < r.unsafe.length;) {
			let e = r.unsafe[s];
			if (!e.atBreak) continue;
			let t = r.compilePattern(e), n;
			for (; n = t.exec(i);) {
				let e = n.index;
				i.codePointAt(e) === 10 && i.codePointAt(e - 1) === 13 && e--, i = i.slice(0, e) + " " + i.slice(n.index + 1);
			}
		}
		return o + i + o;
	}
	function i() {
		return "$";
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-math@3.1.0/node_modules/micromark-extension-math/lib/math-flow.js
var uS = {
	tokenize: fS,
	concrete: !0,
	name: "mathFlow"
}, dS = {
	tokenize: pS,
	partial: !0
};
function fS(e, t, n) {
	let r = this, i = r.events[r.events.length - 1], a = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
	return s;
	function s(t) {
		return e.enter("mathFlow"), e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"), c(t);
	}
	function c(t) {
		return t === 36 ? (e.consume(t), o++, c) : o < 2 ? n(t) : (e.exit("mathFlowFenceSequence"), U(e, l, "whitespace")(t));
	}
	function l(t) {
		return t === null || B(t) ? d(t) : (e.enter("mathFlowFenceMeta"), e.enter("chunkString", { contentType: "string" }), u(t));
	}
	function u(t) {
		return t === null || B(t) ? (e.exit("chunkString"), e.exit("mathFlowFenceMeta"), d(t)) : t === 36 ? n(t) : (e.consume(t), u);
	}
	function d(n) {
		return e.exit("mathFlowFence"), r.interrupt ? t(n) : e.attempt(dS, f, g)(n);
	}
	function f(t) {
		return e.attempt({
			tokenize: _,
			partial: !0
		}, g, p)(t);
	}
	function p(t) {
		return (a ? U(e, m, "linePrefix", a + 1) : m)(t);
	}
	function m(t) {
		return t === null ? g(t) : B(t) ? e.attempt(dS, f, g)(t) : (e.enter("mathFlowValue"), h(t));
	}
	function h(t) {
		return t === null || B(t) ? (e.exit("mathFlowValue"), m(t)) : (e.consume(t), h);
	}
	function g(n) {
		return e.exit("mathFlow"), t(n);
	}
	function _(e, t, n) {
		let i = 0;
		return U(e, a, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
		function a(t) {
			return e.enter("mathFlowFence"), e.enter("mathFlowFenceSequence"), s(t);
		}
		function s(t) {
			return t === 36 ? (i++, e.consume(t), s) : i < o ? n(t) : (e.exit("mathFlowFenceSequence"), U(e, c, "whitespace")(t));
		}
		function c(r) {
			return r === null || B(r) ? (e.exit("mathFlowFence"), t(r)) : n(r);
		}
	}
}
function pS(e, t, n) {
	let r = this;
	return i;
	function i(n) {
		return n === null ? t(n) : (e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), a);
	}
	function a(e) {
		return r.parser.lazy[r.now().line] ? n(e) : t(e);
	}
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-math@3.1.0/node_modules/micromark-extension-math/lib/math-text.js
function mS(e) {
	let t = (e || {}).singleDollarTextMath;
	return t ??= !0, {
		tokenize: n,
		resolve: hS,
		previous: gS,
		name: "mathText"
	};
	function n(e, n, r) {
		let i = 0, a, o;
		return s;
		function s(t) {
			return e.enter("mathText"), e.enter("mathTextSequence"), c(t);
		}
		function c(n) {
			return n === 36 ? (e.consume(n), i++, c) : i < 2 && !t ? r(n) : (e.exit("mathTextSequence"), l(n));
		}
		function l(t) {
			return t === null ? r(t) : t === 36 ? (o = e.enter("mathTextSequence"), a = 0, d(t)) : t === 32 ? (e.enter("space"), e.consume(t), e.exit("space"), l) : B(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), l) : (e.enter("mathTextData"), u(t));
		}
		function u(t) {
			return t === null || t === 32 || t === 36 || B(t) ? (e.exit("mathTextData"), l(t)) : (e.consume(t), u);
		}
		function d(t) {
			return t === 36 ? (e.consume(t), a++, d) : a === i ? (e.exit("mathTextSequence"), e.exit("mathText"), n(t)) : (o.type = "mathTextData", u(t));
		}
	}
}
function hS(e) {
	let t = e.length - 4, n = 3, r, i;
	if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
		for (r = n; ++r < t;) if (e[r][1].type === "mathTextData") {
			e[t][1].type = "mathTextPadding", e[n][1].type = "mathTextPadding", n += 2, t -= 2;
			break;
		}
	}
	for (r = n - 1, t++; ++r <= t;) i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "mathTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
	return e;
}
function gS(e) {
	return e !== 36 || this.events[this.events.length - 1][1].type === "characterEscape";
}
//#endregion
//#region ../../node_modules/.bun/micromark-extension-math@3.1.0/node_modules/micromark-extension-math/lib/syntax.js
function _S(e) {
	return {
		flow: { 36: uS },
		text: { 36: mS(e) }
	};
}
//#endregion
//#region ../../node_modules/.bun/remark-math@6.0.0/node_modules/remark-math/lib/index.js
var vS = {};
function yS(e) {
	let t = this, n = e || vS, r = t.data(), i = r.micromarkExtensions ||= [], a = r.fromMarkdownExtensions ||= [], o = r.toMarkdownExtensions ||= [];
	i.push(_S(n)), a.push(cS()), o.push(lS(n));
}
//#endregion
//#region ../../packages/design-library/src/utils/async-once.ts
function bS(e) {
	let t = null, n = null;
	return {
		peek: () => t,
		load: () => (n ??= e().then((e) => (t = e, e), (e) => {
			throw n = null, e;
		}), n)
	};
}
//#endregion
//#region ../../packages/design-library/src/utils/markdown-blocks.ts
var xS = /^ {0,3}(`{3,}|~{3,})/, SS = /^ {0,3}(\${2,})[^$]*$/, CS = /^ {0,3}(`{3,}|~{3,}|\${2,})[ \t]*$/, wS = /^[ \t]*$/, TS = /^[ \t]/, ES = /^ {0,3}(?:[-+*]|\d{1,9}[.)])(?:[ \t]|$)/;
function DS(e, t) {
	let n = CS.exec(e);
	if (n === null) return !1;
	let r = n[1];
	return r[0] === t.marker[0] && r.length >= t.marker.length;
}
function OS(e) {
	let t = xS.exec(e) ?? SS.exec(e);
	return t === null ? null : { marker: t[1] };
}
function kS(e) {
	let t = [], n = 0, r = !1, i = !1, a = null, o = !1, s = 0;
	for (; s < e.length;) {
		let c = e.indexOf("\n", s), l = c === -1 ? e.length : c + 1, u = e.slice(s, c === -1 ? e.length : c);
		if (u.endsWith("\r") && (u = u.slice(0, -1)), a !== null) DS(u, a) && (a = null), o = !1;
		else if (wS.test(u)) o = !0;
		else {
			let c = ES.test(u);
			o && r && !TS.test(u) && !(i && c) && (t.push(e.slice(n, s)), n = s, i = !1), o = !1, r = !0, c && (i = !0), a = OS(u);
		}
		s = l;
	}
	return n < e.length && t.push(e.slice(n)), t;
}
function AS(e, t) {
	if (e.length === 0) return {
		content: e,
		blocks: []
	};
	if (t !== void 0 && t.blocks.length > 0 && e.startsWith(t.content)) {
		let n = t.blocks.slice(0, -1), r = t.blocks[t.blocks.length - 1], i = t.content.length - r.length;
		return {
			content: e,
			blocks: [...n, ...kS(e.slice(i))]
		};
	}
	return {
		content: e,
		blocks: kS(e)
	};
}
//#endregion
//#region ../../packages/design-library/src/utils/selection-clipboard.ts
var jS = {
	a: ["href"],
	img: ["src", "alt"],
	input: [
		"type",
		"checked",
		"disabled"
	],
	ol: ["start"],
	li: ["value"],
	td: ["colspan", "rowspan"],
	th: ["colspan", "rowspan"]
};
function MS(e) {
	return e.hasAttribute("data-copy-control") || e.hasAttribute("data-code-block-header") || e.hasAttribute("data-copy-exclude") || e.getAttribute("aria-hidden") === "true";
}
var NS = "img, input, svg, video, audio, canvas, iframe", PS = "iframe, object, embed", FS = new Set([
	"ARTICLE",
	"ASIDE",
	"DIV",
	"FIGURE",
	"FOOTER",
	"HEADER",
	"P",
	"SECTION",
	"SPAN"
]);
function IS(e) {
	return FS.has(e.tagName) && e.textContent?.trim() === "" && e.querySelector(`br, hr, ${NS}`) === null;
}
function LS(e) {
	for (let t of Array.from(e.querySelectorAll("*"))) MS(t) && t.remove();
	for (let t of Array.from(e.querySelectorAll(PS))) t.remove();
	for (let t of Array.from(e.querySelectorAll("*")).reverse()) IS(t) && t.remove();
}
function RS(e) {
	for (let t of Array.from(e.querySelectorAll("button"))) {
		let e = t.parentNode;
		if (e) {
			for (; t.firstChild;) e.insertBefore(t.firstChild, t);
			e.removeChild(t);
		}
	}
}
function zS(e) {
	for (let t of Array.from(e.querySelectorAll("*"))) {
		let e = jS[t.tagName.toLowerCase()] ?? [];
		for (let n of Array.from(t.getAttributeNames())) e.includes(n) || t.removeAttribute(n);
	}
}
var BS = {
	H1: 1,
	H2: 2,
	H3: 3,
	H4: 4,
	H5: 5,
	H6: 6
}, VS = new Set([
	"ARTICLE",
	"ASIDE",
	"BLOCKQUOTE",
	"DIV",
	"FIGURE",
	"FOOTER",
	"H1",
	"H2",
	"H3",
	"H4",
	"H5",
	"H6",
	"HEADER",
	"HR",
	"LI",
	"MAIN",
	"OL",
	"P",
	"PRE",
	"SECTION",
	"TABLE",
	"TR",
	"UL"
]);
function HS(e) {
	return e.nodeType === e.ELEMENT_NODE;
}
function US(e) {
	let t = [], n = "", r = () => {
		let e = n.replace(/[ \t]{2,}/g, " ").replace(/[ \t]+$/gm, "").trim();
		e !== "" && t.push({
			tag: "P",
			text: e
		}), n = "";
	};
	for (let i of Array.from(e.childNodes)) {
		if (HS(i) && VS.has(i.tagName)) {
			r();
			let e = qS(i);
			e !== "" && t.push({
				tag: i.tagName,
				text: e
			});
			continue;
		}
		n += sC(i);
	}
	return r(), t;
}
function WS(e) {
	return e.map((e) => e.text).join("\n\n");
}
function GS(e) {
	return WS(US(e));
}
function KS(e) {
	return GS(e).replace(/\s*\n\s*/g, " ").trim();
}
function qS(e) {
	let t = e.tagName;
	if (t === "HR") return "---";
	if (t === "PRE") return $S(e);
	if (t === "TABLE") return rC(e);
	if (t === "TR") return iC(nC(e));
	if (t === "UL" || t === "OL") return YS(e);
	if (t === "LI") return QS(e, "- ");
	if (t === "BLOCKQUOTE") return JS(GS(e));
	let n = BS[t];
	if (n !== void 0) {
		let t = KS(e);
		return t === "" ? "" : `${"#".repeat(n)} ${t}`;
	}
	return GS(e);
}
function JS(e) {
	return e.split("\n").map((e) => e === "" ? ">" : `> ${e}`).join("\n");
}
function YS(e) {
	let t = e.tagName === "OL", n = Number.parseInt(e.getAttribute("start") ?? "1", 10), r = Array.from(e.children).filter((e) => e.tagName === "LI"), i = Number.isNaN(n) ? 1 : n;
	return r.map((e) => {
		if (!t) return QS(e, "- ");
		let n = XS(e, i);
		return i = n + 1, QS(e, `${n}. `);
	}).join("\n");
}
function XS(e, t) {
	let n = Number.parseInt(e.getAttribute("value") ?? "", 10);
	return Number.isNaN(n) ? t : n;
}
function ZS(e) {
	let t = Array.from(e.children).find((e) => e.tagName === "INPUT" && e.getAttribute("type") === "checkbox");
	return t ? t.checked || t.hasAttribute("checked") ? "[x] " : "[ ] " : "";
}
function QS(e, t) {
	let n = `${t}${ZS(e)}`, r = US(e), i = "";
	r.forEach((e, t) => {
		t > 0 && (i += e.tag === "UL" || e.tag === "OL" ? "\n" : "\n\n"), i += e.text;
	});
	let a = " ".repeat(t.length);
	return i.split("\n").map((e, t) => t === 0 ? `${n}${e}` : e === "" ? "" : `${a}${e}`).join("\n");
}
function $S(e) {
	let t = e.querySelector("code"), n = t ? eC(t) : "", r = ((t ?? e).textContent ?? "").replace(/\n+$/, ""), i = "`".repeat(Math.max(3, tC(r) + 1));
	return `${i}${n}\n${r}\n${i}`;
}
function eC(e) {
	let t = /(?:^|\s)language-([\w+#.-]+)/.exec(e.getAttribute("class") ?? "");
	return t ? t[1] : "";
}
function tC(e) {
	let t = 0;
	for (let n of e.matchAll(/`+/g)) t = Math.max(t, n[0].length);
	return t;
}
function nC(e) {
	return Array.from(e.children).filter((e) => e.tagName === "TD" || e.tagName === "TH");
}
function rC(e) {
	let t = Array.from(e.querySelectorAll("tr")).map(nC);
	if (t.length === 0) return "";
	let n = Math.max(...t.map((e) => e.length)), r = [iC(t[0], n), `| ${Array.from({ length: n }, () => "---").join(" | ")} |`];
	for (let e of t.slice(1)) r.push(iC(e, n));
	return r.join("\n");
}
function iC(e, t = e.length) {
	return `| ${Array.from({ length: Math.max(t, e.length) }, (t, n) => e[n] ? aC(e[n]) : "").join(" | ")} |`;
}
function aC(e) {
	return KS(e).replace(/\|/g, "\\|");
}
var oC = {
	em: !1,
	strong: !1
};
function sC(e, t = oC) {
	if (e.nodeType === e.TEXT_NODE) return (e.textContent ?? "").replace(/\s+/g, " ");
	if (!HS(e)) return "";
	let n = e.tagName;
	if (n === "BR") return "\n";
	if (n === "IMG") return `![${e.getAttribute("alt") ?? ""}](${e.getAttribute("src") ?? ""})`;
	if (n === "STRONG" || n === "B") {
		let n = cC(e, {
			...t,
			strong: !0
		});
		return n.trim() === "" ? n : uC(n, t.strong ? "__" : "**");
	}
	if (n === "EM" || n === "I") {
		let n = cC(e, {
			...t,
			em: !0
		});
		return n.trim() === "" ? n : uC(n, t.em ? "*" : "_");
	}
	let r = cC(e, t);
	return n === "CODE" ? dC(r) : r.trim() === "" ? r : n === "DEL" || n === "S" || n === "STRIKE" ? uC(r, "~~") : n === "A" ? fC(e, r) : r;
}
function cC(e, t = oC) {
	return Array.from(e.childNodes).map((e) => sC(e, t)).join("");
}
function lC(e) {
	let t = /^(\s*)([\s\S]*?)(\s*)$/.exec(e);
	return t ? [
		t[1],
		t[2],
		t[3]
	] : [
		"",
		e,
		""
	];
}
function uC(e, t) {
	let [n, r, i] = lC(e);
	return `${n}${t}${r}${t}${i}`;
}
function dC(e) {
	let [t, n, r] = lC(e);
	if (n === "") return e;
	let i = "`".repeat(tC(n) + 1), a = n.startsWith("`") || n.endsWith("`") ? " " : "";
	return `${t}${i}${a}${n}${a}${i}${r}`;
}
function fC(e, t) {
	let n = e.getAttribute("href") ?? "", [r, i, a] = lC(t);
	return n === "" || n === i ? t : `${r}[${i}](${n})${a}`;
}
function pC(e, t) {
	let n = t.ownerDocument.defaultView?.getSelection();
	if (!n) return !1;
	let r = hC(n, t);
	if (!r) return !1;
	let i = _C(r, t.ownerDocument);
	return i.html === "" && i.text === "" ? !1 : (e.setData("text/html", i.html), e.setData("text/plain", i.text), !0);
}
function mC(e) {
	return LS(e), e.textContent?.trim() === "" && e.querySelector(NS) === null;
}
function hC(e, t) {
	if (e.rangeCount === 0 || e.isCollapsed) return null;
	let n = t.ownerDocument;
	if (!n) return null;
	let r = n.createRange();
	r.selectNodeContents(t);
	let i = [];
	for (let t = 0; t < e.rangeCount; t++) {
		let n = e.getRangeAt(t), a = n.cloneRange();
		a.setEnd(r.startContainer, r.startOffset);
		let o = n.cloneRange();
		if (o.setStart(r.endContainer, r.endOffset), !mC(a.cloneContents()) || !mC(o.cloneContents())) return null;
		let s = n.cloneRange();
		s.compareBoundaryPoints(s.START_TO_START, r) < 0 && s.setStart(r.startContainer, r.startOffset), s.compareBoundaryPoints(s.END_TO_END, r) > 0 && s.setEnd(r.endContainer, r.endOffset), s.collapsed || i.push(s);
	}
	return i.length > 0 ? i : null;
}
function gC(e, t) {
	let n = t.createElement("div");
	for (let t of e) n.appendChild(t.cloneContents());
	return LS(n), RS(n), n;
}
function _C(e, t) {
	let n = gC(e, t);
	zS(n);
	let r = gC(e, t);
	return {
		html: n.innerHTML,
		text: GS(r).trim()
	};
}
//#endregion
//#region ../../packages/design-library/src/components/markdown-message.tsx
var vC = bS(async () => {
	let [e] = await Promise.all([import("./rehype-katex-y6E4H9HI.js"), Promise.resolve({              })]);
	return e.default;
});
function yC(e) {
	let [t, n] = Me(() => vC.peek());
	return De(() => {
		if (!e || t !== null) return;
		let r = !1;
		return vC.load().then((e) => {
			r || n(() => e);
		}, () => {}), () => {
			r = !0;
		};
	}, [e, t]), e ? t : null;
}
var bC = 400, xC = v("mx-0 mt-0 mb-3 flex w-full items-center gap-3 rounded-md bg-[var(--surface-sunken)] px-3 py-2.5 text-body-small-lighter text-[var(--content-secondary)] last:mb-0"), SC = "w-0.5 shrink-0 self-stretch rounded-full bg-[var(--content-tertiary)]", CC = "min-w-0 flex-1 [&_p]:mb-0", wC = "rounded bg-stone-100 px-1 py-0.5 font-mono text-body-small-lighter dark:bg-moss-800";
function TC({ onClick: e, copied: t }) {
	return /* @__PURE__ */ F("button", {
		type: "button",
		onClick: e,
		title: t ? "Copied!" : "Copy",
		"data-reveal": "",
		"data-copy-control": "",
		className: "flex h-6 w-6 cursor-pointer items-center justify-center rounded-md bg-stone-200/80 text-[var(--content-tertiary)] hover:bg-stone-300 hover:text-[var(--content-secondary)] dark:bg-moss-600/80 dark:hover:bg-moss-500 dark:hover:text-stone-200",
		children: /* @__PURE__ */ I("div", {
			className: "relative h-3.5 w-3.5",
			children: [/* @__PURE__ */ F(i, { className: v("absolute inset-0 h-3.5 w-3.5 text-[var(--system-positive-strong)] transition-opacity duration-150 ease-out", t ? "opacity-100" : "opacity-0") }), /* @__PURE__ */ F(Le, { className: v("absolute inset-0 h-3.5 w-3.5 transition-opacity duration-150 ease-out", t ? "opacity-0" : "opacity-100") })]
		})
	});
}
function EC({ children: e }) {
	let [t, n] = Me(!1), r = je(null), i = je(null);
	De(() => () => {
		r.current && clearTimeout(r.current);
	}, []);
	let a = xe.toArray(e).find((e) => Ce(e) && e.props.className?.startsWith("language-")), o = Ce(a) ? a.props.className?.replace("language-", "") : void 0, s = Te(() => {
		let e = i.current?.textContent ?? "";
		navigator.clipboard.writeText(e).then(() => {
			n(!0), r.current && clearTimeout(r.current), r.current = setTimeout(() => {
				n(!1), r.current = null;
			}, 1500);
		}).catch(() => {});
	}, []);
	return /* @__PURE__ */ I("div", {
		"data-reveal-row": "",
		className: "relative mb-2 overflow-hidden rounded-md bg-stone-100 last:mb-0 dark:bg-moss-800",
		children: [
			o && /* @__PURE__ */ I("div", {
				"data-code-block-header": "",
				className: "flex items-center justify-between px-3 pt-2",
				children: [/* @__PURE__ */ F("span", {
					className: "font-mono text-xs font-medium uppercase text-[var(--content-tertiary)]",
					children: o
				}), /* @__PURE__ */ F(TC, {
					onClick: s,
					copied: t
				})]
			}),
			/* @__PURE__ */ F("pre", {
				ref: i,
				"data-owns-horizontal-scroll": "",
				className: "overflow-auto p-3",
				style: { maxHeight: bC },
				children: e
			}),
			!o && /* @__PURE__ */ F("div", {
				className: "absolute right-2 top-2",
				children: /* @__PURE__ */ F(TC, {
					onClick: s,
					copied: t
				})
			})
		]
	});
}
function DC({ href: e, children: t }) {
	return /* @__PURE__ */ F("a", {
		href: e,
		target: "_blank",
		rel: "noopener noreferrer",
		"data-slot": "text-link",
		className: ce(),
		children: t
	});
}
var OC = /\p{Emoji_Presentation}/u, kC = /\p{Extended_Pictographic}/u, AC = "️", jC = "︎";
function MC(e) {
	return e.includes(AC) ? !0 : e.includes(jC) ? !1 : OC.test(e);
}
var NC = typeof Intl < "u" && "Segmenter" in Intl ? new Intl.Segmenter(void 0, { granularity: "grapheme" }) : null;
function PC(e) {
	if (!kC.test(e) && !e.includes(AC) || !NC) return e;
	let t = [], n = "", r = !1, i = 0, a = () => {
		n &&= (t.push(r ? /* @__PURE__ */ F("span", {
			style: { fontStyle: "normal" },
			children: n
		}, i++) : n), "");
	};
	for (let { segment: t } of NC.segment(e)) {
		let e = MC(t);
		n && e !== r && a(), r = e, n += t;
	}
	return a(), t.length === 1 && typeof t[0] == "string" ? t[0] : t;
}
function FC(e) {
	return typeof e == "string" ? PC(e) : xe.map(e, (e) => typeof e == "string" ? PC(e) : e);
}
function IC(e, t, n = !1) {
	return {
		p: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("p", {
			...n,
			className: "mb-6 last:mb-0",
			children: t
		}),
		h1: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h1", {
			...n,
			className: "mb-2 mt-4 text-title-large [--text-title-large-line-height:32px] first:mt-0",
			children: t
		}),
		h2: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h2", {
			...n,
			className: "mb-2 mt-4 text-title-medium [--text-title-medium-line-height:28px] first:mt-0",
			children: t
		}),
		h3: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h3", {
			...n,
			className: "mb-2 mt-3 text-title-small [--text-title-small-line-height:22px] first:mt-0",
			children: t
		}),
		ul: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("ul", {
			...n,
			className: "mb-2 list-disc pl-5 last:mb-0",
			children: t
		}),
		ol: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("ol", {
			...n,
			className: "mb-2 list-decimal pl-5 last:mb-0",
			children: t
		}),
		h4: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h4", {
			...n,
			className: "mb-1 mt-3 text-body-medium-default first:mt-0",
			children: t
		}),
		h5: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h5", {
			...n,
			className: "mb-1 mt-2 text-body-small-default [--text-body-small-default-line-height:18px] first:mt-0",
			children: t
		}),
		h6: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("h6", {
			...n,
			className: "mb-1 mt-2 text-body-small-default [--text-body-small-default-line-height:18px] text-[var(--content-secondary)] first:mt-0",
			children: t
		}),
		li: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("li", {
			...n,
			className: "mb-0.5",
			children: t
		}),
		a: ({ href: t, children: n }) => /* @__PURE__ */ F(e, {
			href: t,
			children: n
		}),
		code: ({ className: e, children: t, ...n }) => e?.startsWith("language-") ? /* @__PURE__ */ F("code", {
			className: v("block w-max min-w-full font-mono text-body-small-lighter", e),
			...n,
			children: t
		}) : /* @__PURE__ */ F("code", {
			className: wC,
			children: t
		}),
		pre: ({ children: e }) => /* @__PURE__ */ F(EC, { children: e }),
		em: ({ children: e }) => /* @__PURE__ */ F("em", { children: FC(e) }),
		blockquote: ({ children: e }) => /* @__PURE__ */ I("blockquote", {
			className: xC,
			children: [/* @__PURE__ */ F("span", {
				"aria-hidden": "true",
				className: SC
			}), /* @__PURE__ */ F("div", {
				className: CC,
				children: e
			})]
		}),
		table: ({ children: e }) => /* @__PURE__ */ F("div", {
			"data-owns-horizontal-scroll": "",
			className: "mb-2 overflow-x-auto last:mb-0",
			children: /* @__PURE__ */ F("table", {
				className: "min-w-full border-collapse text-body-small-lighter",
				children: e
			})
		}),
		thead: ({ children: e }) => /* @__PURE__ */ F("thead", {
			className: "bg-[var(--surface-sunken)]",
			children: e
		}),
		th: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("th", {
			...n,
			className: "border border-stone-200 px-2 py-1 text-left font-semibold [&_code]:whitespace-pre-wrap [&_code]:break-words [&_code]:box-decoration-clone dark:border-moss-600",
			children: t
		}),
		td: ({ node: e, children: t, ...n }) => /* @__PURE__ */ F("td", {
			...n,
			className: "border border-stone-200 px-2 py-1 [&_code]:whitespace-pre-wrap [&_code]:break-words [&_code]:box-decoration-clone dark:border-moss-600",
			children: t
		}),
		hr: () => /* @__PURE__ */ F("hr", { className: "my-3 border-[var(--border-subtle)]" }),
		img: ({ node: e, src: r, alt: i, ...a }) => {
			let o = typeof r == "string" ? r : "", s = typeof i == "string" ? i : "";
			if (t) return /* @__PURE__ */ F(t, {
				src: o,
				alt: s
			});
			let c = !o || o.startsWith("/") || o.startsWith("data:") || o.startsWith("blob:") || o.startsWith(".");
			return n || c ? /* @__PURE__ */ F("img", {
				...a,
				src: o,
				alt: s,
				className: "my-1 max-w-full rounded"
			}) : /* @__PURE__ */ I("span", {
				className: "inline-flex items-center gap-1 rounded bg-stone-100 px-1.5 py-0.5 text-body-small-default text-stone-500 dark:bg-moss-800 dark:text-stone-400",
				children: [
					"🔗 External image not rendered (",
					s || o,
					")"
				]
			});
		}
	};
}
var LC = /\$(\d[\d,]*(?:\.\d+)?(?:bn|tn|trn|[KMBT])?\+?)(?=$|[\s).,;:!?%"'’\]}/–—-]|&)/gi, RC = Bd().use(au).use(sS), zC = new Set(["text"]), BC = new Set([
	"inlineCode",
	"code",
	"html"
]);
function VC(e, t) {
	let n = [], r = (e) => {
		if (t.has(e.type)) {
			let t = e.position?.start.offset, r = e.position?.end.offset;
			typeof t == "number" && typeof r == "number" && n.push([t, r]);
			return;
		}
		if (Array.isArray(e.children)) for (let t of e.children) r(t);
	};
	return r(e), n;
}
function HC(e) {
	return VC(RC.parse(e), zC);
}
function UC(e, t, n) {
	let r = "", i = 0;
	for (let [a, o] of t) a < i || (r += e.slice(i, a), r += n(e.slice(a, o), a), i = o);
	return r += e.slice(i), r;
}
function WC(e) {
	if (!/\$\d/.test(e)) return e;
	let t = HC(e);
	return t.length === 0 ? e : UC(e, t, (t, n) => t.replace(LC, (r, i, a) => {
		let o = a > 0 ? t[a - 1] : n > 0 ? e[n - 1] : "";
		return o === "$" || o === "\\" ? r : `\\$${i}`;
	}));
}
function GC(e) {
	if (!e.includes("\n")) return e;
	let t = HC(e);
	return t.length === 0 ? e : UC(e, t, (e) => e.replace(/\n/g, "  \n"));
}
var KC = [{
	open: "\\[",
	close: "\\]",
	dollars: "$$"
}, {
	open: "\\(",
	close: "\\)",
	dollars: "$"
}];
function qC(e, t) {
	let n = 0, r = e.length - 1;
	for (; n <= r;) {
		let i = n + r >> 1, [a, o] = e[i];
		if (t < a) r = i - 1;
		else if (t >= o) n = i + 1;
		else return t + 2 <= o;
	}
	return !1;
}
function JC(e, t, n, r) {
	for (let i = t; i < e.length; i += 1) if (e[i] === "\\") {
		if (e.startsWith(n, i) && r(i)) return i;
		if (KC.some((t) => e.startsWith(t.open, i)) && r(i)) return -1;
		i += 1;
	}
	return -1;
}
function YC(e) {
	if (!e.includes("\\[") && !e.includes("\\(")) return e;
	let t = RC.parse(e), n = VC(t, zC);
	if (n.length === 0) return e;
	let r = VC(t, BC), i = (e) => qC(n, e), a = "", o = 0, s = 0;
	for (; s < e.length;) {
		if (e[s] !== "\\") {
			s += 1;
			continue;
		}
		let t = KC.find((t) => e.startsWith(t.open, s));
		if (!t || !i(s)) {
			s += 2;
			continue;
		}
		let n = JC(e, s + t.open.length, t.close, i), c = n === -1 ? "" : e.slice(s + t.open.length, n);
		if (!c.trim() || /\n[ \t]*\n/.test(c)) {
			s += 2;
			continue;
		}
		if (r.some(([e, t]) => e < n && t > s)) {
			s += 2;
			continue;
		}
		a += e.slice(o, s), a += `${t.dollars}${c}${t.dollars}`, o = n + t.close.length, s = o;
	}
	return a + e.slice(o);
}
function XC(e) {
	return {
		type: "math",
		value: e,
		data: {
			hName: "pre",
			hChildren: [{
				type: "element",
				tagName: "code",
				properties: { className: ["language-math", "math-display"] },
				children: [{
					type: "text",
					value: e
				}]
			}]
		}
	};
}
function ZC(e) {
	return e.type === "break" ? !0 : e.type === "text" && (e.value ?? "").trim() === "";
}
function QC() {
	return (e, t) => {
		let n = String(t), r = (e) => {
			let t = e.position?.start.offset;
			return e.type === "inlineMath" && typeof t == "number" && n.startsWith("$$", t);
		}, i = (e) => {
			let t = [], n = [], i = () => {
				for (; n.length > 0 && ZC(n[0]);) n.shift();
				for (; n.length > 0 && ZC(n[n.length - 1]);) n.pop();
				n.length > 0 && t.push({
					type: "paragraph",
					children: n
				}), n = [];
			};
			for (let a of e.children) r(a) ? (i(), t.push(XC(a.value ?? ""))) : n.push(a);
			return i(), t;
		}, a = (e) => {
			if (!Array.isArray(e.children)) return;
			let t = [], n = !1;
			for (let a of e.children) {
				let e = a;
				e.type === "paragraph" && Array.isArray(e.children) && e.children.some(r) ? (t.push(...i(e)), n = !0) : t.push(a);
			}
			n && (e.children = t);
			for (let t of e.children) a(t);
		};
		a(e);
	};
}
var $C = /^\s{0,3}(\d{1,9})[.)]/;
function ew() {
	return (e, t) => {
		let n = String(t), r = (e) => {
			if (e.type === "list" && e.ordered && Array.isArray(e.children)) {
				let t = e.start ?? 1;
				for (let r of e.children) {
					let e = r, i = e.position?.start.offset, a = t;
					if (typeof i == "number") {
						let e = $C.exec(n.slice(i, i + 16));
						e && (a = Number(e[1]));
					}
					a !== t && (e.data ??= {}, e.data.hProperties ??= {}, e.data.hProperties.value = a), t = a + 1;
				}
			}
			if (Array.isArray(e.children)) for (let t of e.children) r(t);
		};
		r(e);
	};
}
function tw(e) {
	e.clipboardData && pC(e.clipboardData, e.currentTarget) && e.preventDefault();
}
var nw = [
	sS,
	yS,
	ew,
	QC
], rw = [Lv, ["yaml"]], iw = [sS, ew];
function aw({ content: e, hardLineBreaks: t, components: n, rehypePlugins: r, urlTransform: i, remarkPlugins: a, math: o }) {
	return /* @__PURE__ */ F(ef, {
		remarkPlugins: a,
		rehypePlugins: r,
		components: n,
		urlTransform: i,
		children: Ae(() => {
			if (!o) return t ? GC(e) : e;
			let n = WC(e);
			return YC(t ? GC(n) : n);
		}, [
			e,
			t,
			o
		])
	});
}
var ow = we(aw);
function sw(e) {
	let t = je(null), n = AS(e, t.current ?? void 0);
	return t.current = n, n.blocks;
}
function cw({ content: e, className: t, hardLineBreaks: n, linkComponent: r, imageComponent: i, urlTransform: a, extraRehypePlugins: o, extraComponents: s, incremental: c = !1, parseHtml: l = !1, remoteImages: u = !1, math: d = !0, frontmatter: f = "content" }) {
	let p = sw(c ? e : ""), m = Ae(() => [...d ? nw : iw, ...f === "metadata" ? [rw] : []], [d, f]), h = r ?? DC, g = Ae(() => ({
		...IC(h, i, u),
		...s
	}), [
		h,
		i,
		s,
		u
	]), _ = yC(d && (e.includes("$") || e.includes("\\(") || e.includes("\\["))), y = Ae(() => [
		...l ? [X_, hv] : [],
		..._ === null ? [] : [_],
		...o ?? []
	], [
		l,
		_,
		o
	]);
	return /* @__PURE__ */ F("div", {
		"data-slot": "markdown-message",
		className: v("text-chat text-[var(--content-default)]", t),
		onCopy: tw,
		children: c ? p.map((e, t) => /* @__PURE__ */ F(ow, {
			content: e,
			hardLineBreaks: n,
			components: g,
			rehypePlugins: y,
			urlTransform: a,
			remarkPlugins: m,
			math: d
		}, t)) : /* @__PURE__ */ F(ow, {
			content: e,
			hardLineBreaks: n,
			components: g,
			rehypePlugins: y,
			urlTransform: a,
			remarkPlugins: m,
			math: d
		})
	});
}
//#endregion
//#region ../../packages/design-library/src/components/side-menu/side-menu.tsx
var lw = Se({
	collapsed: !1,
	contentCollapsed: !1,
	variant: "rail"
});
function uw() {
	return Ee(lw);
}
function dw(e) {
	return e.variant === "rail" && e.contentCollapsed;
}
function fw(e) {
	return e.variant === "rail" && e.collapsed;
}
var pw = {
	"--side-menu-tile-size": "36px",
	"--side-menu-collapsed-inset": "8px"
}, mw = {
	...pw,
	"--side-menu-tile-size": "44px",
	"--side-menu-inset": "12px"
}, hw = [
	"flex flex-col",
	"bg-[var(--surface-overlay)]",
	"text-[color:var(--content-default)]",
	"overflow-hidden"
].join(" "), gw = "border border-[var(--border-base)]", _w = "pt-4 px-2 pb-2", vw = [
	gw,
	"w-[230px]",
	"rounded-[12px]",
	_w
].join(" "), yw = [
	gw,
	"box-content w-[var(--side-menu-tile-size)]",
	"rounded-[12px]",
	"pt-4 px-[var(--side-menu-collapsed-inset)] pb-2"
].join(" "), bw = [
	gw,
	"rounded-[12px]",
	_w
].join(" "), xw = [
	"w-full",
	"rounded-none",
	"p-[var(--side-menu-inset)]",
	"bg-transparent"
].join(" "), Sw = 150, Cw = "transition-[width,padding] duration-[150ms] ease-in-out";
function ww(e, t, n) {
	return e === "overlay" ? xw : v(t ? yw : n ? bw : vw, Cw);
}
function Tw({ ariaLabel: e, collapsed: t = !1, variant: n = "rail", width: r, onWidthChange: i, minWidth: a = 220, maxWidth: o = 400, className: s, children: c, ref: l, style: u, ...d }) {
	let f = n === "overlay" ? !1 : t, p = n === "rail" && i != null, m = p && !f && r != null, [h, g] = Me(f);
	!f && h && g(!1), De(() => {
		if (!f) return;
		let e = setTimeout(() => g(!0), Sw);
		return () => clearTimeout(e);
	}, [f]);
	let _ = je(null), y = Ae(() => Pa(_, l), [l]), { handleProps: b, isResizing: x, paneId: S } = qa({
		side: "start",
		defaultSize: r ?? a,
		minSize: a,
		maxSize: o,
		label: "Resize sidebar",
		paneId: d.id,
		paneRef: _,
		onSizeCommit: i
	}), C = n === "overlay" ? mw : pw, w = p && !f && r != null ? {
		...C,
		...u,
		width: r
	} : {
		...C,
		...u
	};
	return /* @__PURE__ */ F(lw, {
		value: {
			collapsed: f,
			contentCollapsed: h,
			variant: n
		},
		children: /* @__PURE__ */ I("nav", {
			ref: y,
			"data-slot": "side-menu",
			role: "navigation",
			"aria-label": e,
			className: v(hw, m && "relative", ww(n, f, p), x && "transition-none", s),
			style: w,
			...d,
			id: S,
			children: [c, m ? /* @__PURE__ */ F(Ja, {
				...b,
				className: "absolute right-0 top-0 bottom-0 z-10 w-[6px] group/resize",
				children: /* @__PURE__ */ F("div", { className: "pointer-events-none absolute right-0 top-2 bottom-2 w-[2px] rounded-full bg-[var(--content-tertiary)] opacity-0 transition-opacity group-hover/resize:opacity-100 group-focus-visible/resize:opacity-100" })
			}) : null]
		})
	});
}
function Ew({ className: e, children: t, ref: n, ...r }) {
	return /* @__PURE__ */ F("div", {
		ref: n,
		"data-slot": "side-menu-header",
		className: v("flex flex-col gap-2", e),
		...r,
		children: t
	});
}
function Dw({ className: e, children: t, ref: n, ...r }) {
	return /* @__PURE__ */ F("div", {
		ref: n,
		"data-slot": "side-menu-body",
		className: v("flex flex-1 flex-col gap-3 overflow-y-auto overflow-x-hidden", e),
		...r,
		children: t
	});
}
function Ow({ className: e, children: t, ref: n, ...r }) {
	return /* @__PURE__ */ F("div", {
		ref: n,
		"data-slot": "side-menu-footer",
		className: v("mt-auto flex flex-col gap-2 pt-2", e),
		...r,
		children: t
	});
}
function kw({ className: e, ref: t, ...n }) {
	return /* @__PURE__ */ F("hr", {
		ref: t,
		"data-slot": "side-menu-separator",
		className: v("my-1 h-px w-full border-0 bg-[var(--border-base)]", e),
		...n
	});
}
function Aw(e) {
	let t = v("flex shrink-0 items-center rounded-[6px]", "h-[var(--side-menu-tile-size)] max-md:h-auto", e.className);
	if (e.asChild === !0) {
		let { asChild: n, className: r, children: i, ref: a, ...o } = e;
		return /* @__PURE__ */ F(_, {
			ref: a,
			"data-slot": "side-menu-section-header",
			className: t,
			...o,
			children: i
		});
	}
	let { asChild: n, className: r, ref: i, ...a } = e;
	return /* @__PURE__ */ F("div", {
		ref: i,
		"data-slot": "side-menu-section-header",
		className: t,
		...a
	});
}
function jw({ title: e, actions: t, className: n, children: r, ref: i, ...a }) {
	let o = dw(uw());
	return /* @__PURE__ */ I("div", {
		ref: i,
		"data-slot": "side-menu-section",
		className: v("flex flex-col gap-2", n),
		...a,
		children: [!o && (e || t) ? /* @__PURE__ */ I("div", {
			className: "flex h-[30px] items-center justify-between px-[6px]",
			children: [e ? /* @__PURE__ */ F(ae, {
				variant: "body-medium-default",
				as: "span",
				className: "text-[color:var(--content-tertiary)]",
				children: e
			}) : /* @__PURE__ */ F("span", {}), t ? /* @__PURE__ */ F("div", {
				className: "flex items-center gap-[4px]",
				children: t
			}) : null]
		}) : null, r]
	});
}
function Mw({ className: e, children: t, ref: n, ...r }) {
	return dw(uw()) ? null : /* @__PURE__ */ F("ul", {
		ref: n,
		"data-slot": "side-menu-sub-list",
		className: v("flex flex-col gap-[4px] list-none p-0 m-0", e),
		...r,
		children: t
	});
}
function Nw({ icon: e, indent: t, active: n, collapsed: r, disabled: i }) {
	return t ? /* @__PURE__ */ F("span", {
		"aria-hidden": !0,
		className: "inline-block h-[14px] w-[14px] shrink-0"
	}) : e ? typeof e == "string" ? /* @__PURE__ */ F("span", {
		"aria-hidden": !0,
		className: v("inline-flex h-[14px] w-[14px] shrink-0 items-center justify-center text-[14px] leading-none", r ? "mx-auto" : void 0),
		children: e
	}) : /* @__PURE__ */ F(e, {
		size: 14,
		"aria-hidden": !0,
		className: v("shrink-0", i ? "text-[color:var(--content-disabled)]" : n ? "text-[color:var(--content-default)]" : "text-[color:var(--content-tertiary)]", r ? "mx-auto" : void 0)
	}) : null;
}
function Pw({ children: e }) {
	return /* @__PURE__ */ F("span", {
		className: v("inline-flex items-center justify-center", "px-[4px] py-[2px] rounded-[4px]", "bg-[var(--surface-base)]", "text-label-small-default", "text-[color:var(--content-tertiary)]"),
		children: e
	});
}
function Fw({ icon: e, label: t, showCollapsedTooltip: n = !1, tooltip: r, badge: i, shape: a = "default", indicator: o, disabled: s = !1, trailingIcon: c, trailingIconClassName: l, indent: u = !1, active: d = !1, emphasized: f = !1, size: p = "default", onSelect: m, href: h, className: g, tabIndex: _, ref: y, ...b }) {
	let x = uw(), S = a === "tile" ? fw(x) : dw(x), C = S && a === "tile", w = C ? "size-[var(--side-menu-tile-size)] mx-auto rounded-full bg-[var(--panel-item-bg,var(--surface-lift))]" : "h-[30px] w-full max-md:h-auto rounded-[6px]", T = s ? "cursor-default text-[color:var(--content-disabled)]" : d ? v("cursor-pointer text-[color:var(--content-emphasised)]", C ? "bg-[var(--panel-item-active,var(--panel-item-bg,var(--surface-active)))]" : "bg-[var(--surface-active)]") : v("cursor-pointer", C ? "hover:bg-[var(--panel-item-hover,var(--surface-active))]" : "hover:bg-[var(--surface-hover)]", f ? "text-[color:var(--content-emphasised)]" : "text-[color:var(--content-secondary)]"), E = v("group relative flex items-center", w, "outline-none keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)]", "select-none", "transition-colors", "gap-[6px] p-[6px]", S ? "justify-center" : "justify-start", p === "compact" ? "text-body-small-default max-md:text-body-large-default" : v("text-body-medium-lighter max-md:text-body-large-default", !C && "max-md:py-3"), T, g), D = S ? null : /* @__PURE__ */ F("span", {
		className: "min-w-0 flex-1 truncate text-left text-optical-center",
		children: t
	}), O = S || !i ? null : /* @__PURE__ */ F(Pw, { children: i }), k = S || !c ? null : /* @__PURE__ */ F(c, {
		size: 14,
		"aria-hidden": !0,
		className: v("shrink-0 text-[color:var(--content-tertiary)]", l)
	}), A = /* @__PURE__ */ F(Nw, {
		icon: e,
		indent: u,
		active: d,
		collapsed: S,
		disabled: s
	}), j = S ? o : null, M = r ?? (n ? t : void 0), N = S && M != null, ee = S && !N ? t : void 0, ne = d ? "page" : void 0, re = S ? t : void 0, ie = (e) => N ? /* @__PURE__ */ F(te, {
		content: M,
		side: "right",
		children: e
	}) : e;
	if (h) {
		let { onClick: e, ...t } = b;
		return ie(/* @__PURE__ */ I("a", {
			ref: y,
			"data-slot": "side-menu-item",
			href: s ? void 0 : h,
			title: ee,
			"aria-current": ne,
			"aria-label": re,
			className: E,
			onClick: (t) => {
				if (s) {
					t.preventDefault();
					return;
				}
				e?.(t), t.defaultPrevented || m?.();
			},
			...t,
			"aria-disabled": s || void 0,
			tabIndex: s ? -1 : _,
			children: [
				A,
				D,
				O,
				k,
				j
			]
		}));
	}
	let { onClick: ae, onKeyDown: oe, ...se } = b;
	return ie(/* @__PURE__ */ I("button", {
		ref: y,
		"data-slot": "side-menu-item",
		type: "button",
		title: ee,
		"aria-current": ne,
		"aria-label": re,
		className: E,
		onClick: (e) => {
			if (s) {
				e.preventDefault();
				return;
			}
			ae?.(e), e.defaultPrevented || m?.();
		},
		onKeyDown: oe,
		...se,
		"aria-disabled": s || void 0,
		tabIndex: s ? -1 : _,
		children: [
			A,
			D,
			O,
			k,
			j
		]
	}));
}
var Iw = Tw;
Iw.Header = Ew, Iw.Body = Dw, Iw.Footer = Ow, Iw.Section = jw, Iw.SectionHeader = Aw, Iw.SubList = Mw, Iw.Item = Fw, Iw.Separator = kw, y([
	"group/disclosure-trigger inline-flex w-fit max-w-full items-center gap-1 rounded-sm text-left",
	"cursor-pointer select-none transition-colors",
	"text-[color:var(--content-secondary)] hover:text-[color:var(--content-default)]",
	"outline-none keyboard-focus:ring-2 keyboard-focus:ring-[var(--ring)]",
	"disabled:cursor-not-allowed disabled:text-[color:var(--content-disabled)]"
].join(" "), {
	variants: {
		size: {
			small: "text-body-small-default",
			medium: "text-body-medium-default"
		},
		fullWidth: {
			true: "w-full",
			false: ""
		}
	},
	defaultVariants: {
		size: "small",
		fullWidth: !1
	}
}), Se(null);
//#endregion
//#region ../../packages/design-library/src/components/searchable-select.tsx
var Lw = 280, Rw = 12, zw = 4, Bw = 10, Vw = 163, Hw = zw + Bw + Rw;
Hw + Lw, Hw + Vw;
//#endregion
export { Fe as a, Le as i, $a as n, ya as r, cw as t };
