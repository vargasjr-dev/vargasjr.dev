"use client";
import { a as e, c as t, d as n, i as r, n as i, o as a, r as o, s, u as c } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n as l, t as u } from "./loader-circle-Ch7lYSrj.js";
import { t as d } from "./arrow-left-Cq7kfIgc.js";
import { n as f, r as p, t as m } from "./retire-assistant-kQPSXcqh.js";
import { g as h, h as g, r as _ } from "./confirm-dialog-DH3yi6Nk.js";
import { t as v } from "./rotate-ccw-B-fMJOWC.js";
import { i as y, n as b, r as x, s as S, t as C } from "./create-selectors-CR7eHVH6.js";
import { o as w } from "./dist-CB0DYkRa.js";
import { t as T } from "./electron-bridge-VOSuV45z.js";
import { n as E, r as D } from "./request-Dbjf-LtL.js";
import { l as O, n as ee, p as k, r as te } from "./schemas-D8_brjAQ.js";
import { _ as ne, g as re, h as A, i as ie, r as j, s as ae, t as oe, v as se } from "./i18n-BRf-wfgm.js";
import { t as ce } from "./organization-DMy3nLTu.js";
import { n as M, t as le } from "./api-DnMWUBLS.js";
import { n as N, r as ue, s as de, t as fe } from "./assistant-selection-ZCXVlG5B.js";
import { r as pe, t as P } from "./button-BrPHE1Q9.js";
import { r as me } from "./es2015-B_BDkut6.js";
import { t as he } from "./capture-error-DAZY091e.js";
import { n as F } from "./routes-DW44XTQk.js";
import { a as ge, i as _e, r as ve, t as ye } from "./avatar-random-De_AuTlf.js";
import { t as be } from "./is-electron-CTF8PPHw.js";
import { a as xe, c as Se, f as Ce, h as we, i as Te, l as Ee, o as De, p as Oe, t as I, u as ke } from "./proxy-I7qEXaVt.js";
import { t as Ae } from "./describe-error-DsSgTDeO.js";
import { a as je, i as Me, n as Ne, r as Pe } from "./resolve-assistant-g0zYJ1Fn.js";
import { t as Fe } from "./auth-store-Bx-RKZJ9.js";
import { r as Ie } from "./consent-persistence-C5xQGklP.js";
import { createContext as Le, useContext as Re, useEffect as L, useId as ze, useLayoutEffect as R, useMemo as z, useRef as B, useState as V, useSyncExternalStore as Be } from "react";
import { Fragment as Ve, jsx as H, jsxs as U } from "react/jsx-runtime";
var W = l("arrow-right", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "m12 5 7 7-7 7",
	key: "xquz4c"
}]]), He = l("dices", [
	["rect", {
		width: "12",
		height: "12",
		x: "2",
		y: "10",
		rx: "2",
		ry: "2",
		key: "6agr2n"
	}],
	["path", {
		d: "m17.92 14 3.5-3.5a2.24 2.24 0 0 0 0-3l-5-4.92a2.24 2.24 0 0 0-3 0L10 6",
		key: "1o487t"
	}],
	["path", {
		d: "M6 18h.01",
		key: "uhywen"
	}],
	["path", {
		d: "M10 14h.01",
		key: "ssrbsk"
	}],
	["path", {
		d: "M15 6h.01",
		key: "cblpky"
	}],
	["path", {
		d: "M18 9h.01",
		key: "2061c0"
	}]
]), Ue = l("pencil", [["path", {
	d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
	key: "1a8usu"
}], ["path", {
	d: "m15 5 4 4",
	key: "1mk7zo"
}]]), We = l("volume-2", [
	["path", {
		d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
		key: "uqj9uw"
	}],
	["path", {
		d: "M16 9a5 5 0 0 1 0 6",
		key: "1q6k2b"
	}],
	["path", {
		d: "M19.364 18.364a9 9 0 0 0 0-12.728",
		key: "ijwkga"
	}]
]);
//#endregion
//#region src/assistant/create-cloud-assistant.ts
async function Ge(e) {
	let t = await le(e);
	return t.ok ? (de(t.data.id), {
		ok: !0,
		id: t.data.id
	}) : {
		ok: !1,
		error: t.error.detail
	};
}
//#endregion
//#region src/components/create-assistant-dialog.tsx
function Ke({ open: e, onClose: t, onCreated: n }) {
	let { t: r } = j(), [i, a] = V(""), [o, s] = V(!1), c = async () => {
		s(!0);
		let e = await Ge(i.trim() || void 0);
		if (s(!1), e.ok) {
			h.success(r("createAssistantDialog.toastSuccess")), a(""), n?.(e.id), t();
			return;
		}
		h.error(e.error);
	};
	return /* @__PURE__ */ H(_.Root, {
		open: e,
		onOpenChange: (e) => {
			!e && !o && t();
		},
		children: /* @__PURE__ */ U(_.Content, {
			size: "sm",
			children: [
				/* @__PURE__ */ U(_.Header, { children: [/* @__PURE__ */ H(_.Title, { children: r("createAssistantDialog.title") }), /* @__PURE__ */ H(_.Description, { children: r("createAssistantDialog.description") })] }),
				/* @__PURE__ */ H(_.Body, { children: /* @__PURE__ */ H(me, {
					value: i,
					onChange: (e) => a(e.target.value),
					placeholder: r("createAssistantDialog.namePlaceholder"),
					autoFocus: !0,
					disabled: o,
					onKeyDown: (e) => {
						e.key === "Enter" && !o && c();
					}
				}) }),
				/* @__PURE__ */ U(_.Footer, { children: [/* @__PURE__ */ H(P, {
					variant: "outlined",
					onClick: t,
					disabled: o,
					children: r("createAssistantDialog.cancel")
				}), /* @__PURE__ */ H(P, {
					variant: "primary",
					onClick: () => void c(),
					disabled: o,
					loading: o,
					children: r("createAssistantDialog.create")
				})] })
			]
		})
	});
}
//#endregion
//#region src/lib/chunk-errors.ts
function qe(e) {
	if (!(e instanceof Error)) return !1;
	if (e.name === "ChunkLoadError") return !0;
	let t = e.message;
	return t.includes("Failed to fetch dynamically imported module") || t.includes("Importing a module script failed") || t.includes("error loading dynamically imported module") || t.includes("Loading chunk");
}
//#endregion
//#region src/components/route-error-boundary.tsx
function G() {
	let e = c(), { t } = j();
	if (qe(e)) return /* @__PURE__ */ U("div", {
		"data-slot": "route-error-boundary",
		"data-variant": "chunk-fail",
		role: "alert",
		className: "flex h-full min-h-[200px] flex-col items-center justify-center gap-3 p-6 text-center",
		children: [
			/* @__PURE__ */ H(u, {
				className: "size-6 text-[var(--content-tertiary)]",
				"aria-hidden": !0
			}),
			/* @__PURE__ */ H("p", {
				className: "max-w-md text-body-medium-lighter text-[var(--content-secondary)]",
				children: t("routeErrorBoundary.chunkFailBody")
			}),
			/* @__PURE__ */ H(P, {
				variant: "ghost",
				size: "compact",
				leftIcon: /* @__PURE__ */ H(v, {}),
				onClick: () => window.location.reload(),
				children: t("routeErrorBoundary.reload")
			})
		]
	});
	let n = a(e) ? e.status : void 0;
	return /* @__PURE__ */ U("div", {
		"data-slot": "route-error-boundary",
		"data-variant": "full-page",
		className: "flex min-h-svh flex-col items-center justify-center gap-4 bg-[var(--surface-base)] p-6 text-center",
		children: [
			/* @__PURE__ */ H("h1", {
				className: "text-2xl font-semibold text-[var(--content-emphasised)]",
				children: n === 404 ? "Page not found" : "Something went wrong"
			}),
			/* @__PURE__ */ H("p", {
				className: "max-w-md text-[var(--content-secondary)]",
				children: n === 404 ? "The page you requested doesn't exist." : "An unexpected error occurred. Try reloading the page."
			}),
			/* @__PURE__ */ H(P, {
				variant: "primary",
				onClick: () => window.location.reload(),
				children: t("routeErrorBoundary.reload")
			})
		]
	});
}
//#endregion
//#region src/components/root-hydrate-fallback.tsx
function K() {
	let { t: e } = j();
	return /* @__PURE__ */ H("div", {
		"data-slot": "root-hydrate-fallback",
		className: "flex min-h-svh items-center justify-center",
		role: "status",
		"aria-label": e("rootHydrateFallback.loadingAria"),
		children: /* @__PURE__ */ H(u, { className: "size-6 animate-spin text-[var(--content-tertiary)]" })
	});
}
//#endregion
//#region src/runtime/cadet-commands.ts
function Je(e) {
	let t = B(e);
	R(() => {
		t.current = e;
	}), L(() => {
		let e = T();
		if (e) return e.commands.on((e) => {
			t.current[e.kind]?.(e);
		});
	}, []);
}
var q = {
	open: !1,
	initialAddress: null,
	guidanceKind: null,
	deepLinkDrainSettled: !1
}, Ye = /* @__PURE__ */ new Set();
function Xe(e) {
	return Ye.add(e), () => Ye.delete(e);
}
function Ze(e) {
	q = {
		...q,
		...e
	};
	for (let e of Ye) e();
}
var Qe = {
	openConnectDialog(e) {
		Ze({
			open: !0,
			initialAddress: e?.initialAddress ?? null,
			guidanceKind: e?.guidanceKind ?? null
		});
	},
	closeConnectDialog() {
		Ze({
			open: !1,
			initialAddress: null,
			guidanceKind: null
		});
	},
	markDeepLinkDrainSettled() {
		Ze({ deepLinkDrainSettled: !0 });
	}
};
function J(e) {
	return Be(Xe, () => e(q), () => e(q));
}
var $e = Object.assign(J, {
	getState: () => ({
		...q,
		...Qe
	}),
	...Qe,
	use: {
		open: () => J((e) => e.open),
		initialAddress: () => J((e) => e.initialAddress),
		guidanceKind: () => J((e) => e.guidanceKind),
		deepLinkDrainSettled: () => J((e) => e.deepLinkDrainSettled)
	}
});
//#endregion
//#region src/runtime/deep-links.ts
function et() {
	let e = t(), n = B(e);
	R(() => {
		n.current = e;
	}), L(() => {
		let e = T(), t = (e) => {
			if (e.kind !== "connect") return;
			let t = ue(e.url ?? null, e.code ?? null);
			$e.getState().openConnectDialog(t === null ? { guidanceKind: e.legacy ? "legacy" : "generic" } : { initialAddress: t }), n.current(F.account.selectAssistant);
		}, r = e?.deepLinks?.onLink(t) ?? (() => void 0), i = !1;
		return (e?.deepLinks?.drain() ?? Promise.resolve([])).then((e) => {
			if (!i) for (let n of e) t(n);
		}).catch((e) => {
			he(e, {
				context: "deep_link_drain",
				level: "warning"
			});
		}).finally(() => {
			$e.getState().markDeepLinkDrainSettled();
		}), () => {
			i = !0, r();
		};
	}, []);
}
//#endregion
//#region src/runtime/main-window.ts
async function tt(e) {
	await T()?.mainWindow.setOnboarding(e);
}
//#endregion
//#region src/hooks/use-onboarding-window-size.ts
var nt = [
	"/assistant/onboarding/",
	"/assistant/welcome",
	"/assistant/review-terms",
	"/account"
];
function rt(e) {
	return nt.some((t) => e.startsWith(t));
}
function it() {
	let { pathname: e } = s(), t = rt(e);
	L(() => {
		tt(t);
	}, [t]);
}
//#endregion
//#region src/domains/account/account-layout.tsx
function at() {
	return it(), /* @__PURE__ */ H(o, {});
}
//#endregion
//#region src/domains/account/account-route.tsx
function ot() {
	let [e] = n(), t = e.toString();
	return /* @__PURE__ */ H(i, {
		to: `${F.account.oauth.complete}${t ? `?${t}` : ""}`,
		replace: !0
	});
}
var st = {
	path: "/account",
	ErrorBoundary: G,
	HydrateFallback: K,
	children: [{
		ErrorBoundary: G,
		children: [
			{
				Component: at,
				children: [
					{
						index: !0,
						lazy: { Component: () => import("./account-page-BfZeLzaR.js").then((e) => e.AccountPage) }
					},
					{
						path: "assistants/:assistantId?",
						lazy: { Component: () => import("./assistants-page-D4zWwZgC.js").then((e) => e.AssistantsPage) }
					},
					{
						path: "doctor",
						lazy: { Component: () => import("./doctor-page-BJ_H0532.js").then((e) => e.DoctorPage) }
					},
					{
						path: "login",
						lazy: { Component: () => import("./login-page-D8H6W_M2.js").then((e) => e.LoginPage) }
					},
					{
						path: "signup",
						lazy: { Component: () => import("./signup-page-C-lbDXwI.js").then((e) => e.SignupPage) }
					},
					{
						path: "pair",
						ErrorBoundary: G,
						HydrateFallback: K,
						lazy: { Component: () => import("./pairing-page-CtxKn0lT.js").then((e) => e.PairingPage) }
					},
					{
						path: "onboarding/welcome",
						lazy: { Component: () => import("./welcome-screen-GVhovLHS.js").then((e) => e.WelcomeScreen) }
					},
					{
						path: "onboarding/start",
						lazy: { Component: () => import("./start-screen-hBjB5w9I.js").then((e) => e.StartScreen) }
					},
					{
						path: "onboarding/hosting",
						lazy: { Component: () => import("./hosting-screen--YLDEPbx.js").then((e) => e.HostingScreen) }
					},
					{
						path: "onboarding/api-key",
						lazy: { Component: () => import("./api-key-screen-DM4Pjq-Q.js").then((e) => e.ApiKeyScreen) }
					},
					{
						path: "onboarding/hatching",
						lazy: { Component: () => import("./hatching-screen-CpsjXPrS.js").then((e) => e.HatchingScreen) }
					},
					{
						path: "provider/callback",
						lazy: { Component: () => import("./provider-callback-page-bM3_C9ki.js").then((e) => e.ProviderCallbackPage) }
					},
					{
						path: "provider/signup",
						lazy: { Component: () => import("./provider-signup-page-e6uNzrUD.js").then((e) => e.ProviderSignupPage) }
					},
					{
						path: "password/reset",
						lazy: { Component: () => import("./password-reset-page-uC_PYcj8.js").then((e) => e.PasswordResetPage) }
					},
					{
						path: "password/reset/key/:key",
						lazy: { Component: () => import("./password-reset-page-uC_PYcj8.js").then((e) => e.PasswordResetPage) }
					}
				]
			},
			{
				path: "oauth/popup-complete",
				lazy: { Component: () => import("./oauth-popup-complete-page-C8IXOXWK.js").then((e) => e.OAuthPopupCompletePage) }
			},
			{
				path: "oauth/complete",
				lazy: { Component: () => import("./oauth-complete-page-B-_x-kiE.js").then((e) => e.OAuthCompletePage) }
			},
			{
				path: "oauth/desktop-complete",
				Component: ot
			},
			{
				path: "cloud-callback",
				lazy: { Component: () => import("./cloud-loopback-page-DH-iaB5p.js").then((e) => e.CloudLoopbackPage) }
			},
			{
				path: "select-assistant",
				lazy: { Component: () => import("./select-assistant-screen-WNo3Z568.js").then((e) => e.SelectAssistantScreen) }
			}
		]
	}]
}, ct = "firstRunScope";
//#endregion
//#region src/domains/onboarding/lets-chat-kickoff.ts
function lt(e) {
	return `id \`scope_${e}\`, \`data: {"${ct}": "${e}"}\``;
}
function ut(e) {
	let t = e?.trim();
	return `You're about to begin your first conversation.${t ? `\nYour name is ${t} — introduce yourself as ${t}.` : ""}
Respond with a warm and engaging greeting. Be interesting, be real. This is your chance to get to know and impress the user.
End the greeting text with one short question asking where they'd like to start, phrased so nothing feels off the table (e.g. "…or is there anything else on your mind entirely?").
Then call the \`ui_show\` tool exactly once: \`surface_type: "choice"\`, \`data.selectionMode: "single"\`, no \`title\` (or a very short one), and exactly three options in this order:
1. ${lt("work")} — a concrete offer grounded in their work or role from your Onboarding Context (occupation, daily tools, work-related research findings).
2. ${lt("personal")} — a concrete offer grounded in their hobbies, interests, or personal research findings.
3. ${lt("both")} — an "all of the above" invitation.
An option's title becomes the user's visible reply bubble when they tap it, so every title must read naturally in the user's voice — imperative or neutral, six words or fewer (e.g. "Help me plan my next ride", never "I can plan your next ride"). Titles only: never set \`description\` on any option — the three options must scan in a single glance, and your greeting text already carries the color.
These options are conversation starters, not a menu: never imply the user is limited to them, and your closing question itself must invite free-form answers.
After the \`ui_show\` result comes back, stop — output no further text. If \`ui_show\` errors or is unavailable, just end with the text question alone; the user will type. Do not set \`await_action\` or \`persistent\`.
Keep it short! For this opening greeting only, don't use \`recall\`, don't read any files, and make no tool calls other than that single \`ui_show\`. (This applies to the greeting alone; use your tools normally for everything the user asks afterward.)`;
}
//#endregion
//#region src/domains/onboarding/prechat.ts
var dt = "onboarding.prechat.pendingContext";
function ft() {
	try {
		return globalThis.sessionStorage ?? null;
	} catch {
		return null;
	}
}
function pt(e) {
	let t = ft();
	if (t !== null) try {
		t.removeItem(dt), t.setItem(dt, JSON.stringify(e));
	} catch {}
}
var mt = "onboarding.prechat.assistantName";
function ht(e) {
	let t = e.trim();
	if (!t) return;
	let n = ft();
	if (n !== null) try {
		n.setItem(mt, t);
	} catch {}
}
//#endregion
//#region src/utils/typed-storage.ts
function gt(e) {
	if (typeof window > "u") return null;
	try {
		return localStorage.getItem(e);
	} catch {
		return null;
	}
}
function _t(e) {
	let t = /* @__PURE__ */ new Map(), n = {
		has: (e) => t.has(e),
		get: (e) => t.get(e),
		drop: (e) => t.delete(e),
		scope: e,
		clear: () => t.clear(),
		write(e, n, r, i) {
			t.delete(e), !ne(n, i) && (t.set(e, r), A(n, i));
		}
	};
	return vt.push(n), n;
}
var vt = [], yt = "";
function bt(e) {
	let { key: t, scope: n, parse: r, serialize: i, fallback: a } = e, o, s = a, c = _t(n);
	function l() {
		if (c.has(yt)) return c.get(yt);
		let e = gt(t);
		if (e === o) return s;
		if (o = e, e === null) return s = a, a;
		try {
			let t = r(e);
			s = t === null ? a : t;
		} catch {
			s = a;
		}
		return s;
	}
	function u(e) {
		c.write(yt, t, e, i(e));
	}
	function d() {
		c.drop(yt), re(t);
	}
	function f(e) {
		return se(t, e);
	}
	function p() {
		return l();
	}
	function m() {
		return a;
	}
	function h() {
		return Be(f, p, m);
	}
	return {
		load: l,
		save: u,
		remove: d,
		key: t,
		scope: n,
		subscribe: f,
		useValue: h
	};
}
//#endregion
//#region src/domains/onboarding/onboarded-assistant-record.ts
function xt(e) {
	let t = JSON.parse(e);
	if (!t || typeof t != "object" || Array.isArray(t)) return null;
	let n = {};
	for (let [e, r] of Object.entries(t)) typeof r == "string" && r && (n[e] = r);
	return n;
}
var St = bt({
	key: "device:onboarded_assistants",
	scope: "device",
	parse: xt,
	serialize: JSON.stringify,
	fallback: {}
});
function Ct(e, t = (/* @__PURE__ */ new Date()).toISOString()) {
	let n = St.load();
	n[e] || St.save({
		...n,
		[e]: t
	});
}
St.key;
//#endregion
//#region src/hooks/use-is-mobile.ts
var wt = "(max-width: 767px)";
function Tt() {
	return x(wt);
}
//#endregion
//#region src/utils/avatar-wave-ribbon.ts
var Et = 1.3;
function Dt(e, t) {
	return Math.max(t, e * Et);
}
function Ot(e, t, n) {
	let r = Dt(t, n);
	return e.map((e) => ({
		x: e.fx * t,
		y: e.fy * n,
		w: e.fw * t,
		s: e.fs * r
	}));
}
function kt(e) {
	let t = e;
	return () => {
		t |= 0, t = t + 1831565813 | 0;
		let e = Math.imul(t ^ t >>> 15, 1 | t);
		return e = e + Math.imul(e ^ e >>> 7, 61 | e) ^ e, ((e ^ e >>> 14) >>> 0) / 4294967296;
	};
}
function At(e, t, n = Infinity) {
	let r = kt(t), i = (e) => (r() * 2 - 1) * e, a = [];
	for (let t = 0; t < e.length - 1; t++) {
		let o = e[t], s = e[t + 1];
		if (!o || !s) continue;
		let c = s.x - o.x, l = s.y - o.y, u = Math.hypot(c, l);
		if (u === 0) continue;
		let d = l / u, f = -c / u, p = 0, m = 0;
		for (; p < u;) {
			let e = p / u, t = o.x + c * e, h = o.y + l * e, g = o.w + (s.w - o.w) * e, _ = o.s + (s.s - o.s) * e, v = Math.max(1, Math.round(g / (_ * .95))), y = g / v, b = m % 2 == 0 ? 0 : y * .5;
			for (let e = 0; e < v; e++) {
				let o = (e - (v - 1) / 2) * y + b + i(_ * .12);
				a.push({
					x: t + d * o + i(_ * .08),
					y: h + f * o + i(_ * .08),
					size: Math.min(n, _ * (.85 + r() * .3)),
					rotate: i(10)
				});
			}
			p += _ * .85 + 4, m++;
		}
	}
	return a;
}
//#endregion
//#region src/utils/avatar-sprite.ts
function jt(e, t, n, r, i) {
	let a = e.bodyShapes[t], o = e.eyeStyles[n], s = e.colors[r];
	if (!a || !o || !s) return null;
	let c = Math.min(2, window.devicePixelRatio || 1), l = document.createElement("canvas");
	l.width = Math.max(2, Math.ceil(i * c)), l.height = l.width;
	let u = l.getContext("2d");
	if (!u) return null;
	u.scale(c, c);
	let d = a.viewBox, f = Math.min(i / d.width, i / d.height), p = (i - d.width * f) / 2, m = (i - d.height * f) / 2;
	u.save(), u.translate(p, m), u.scale(f, f), u.fillStyle = s.hex, u.fill(new Path2D(a.svgPath)), u.restore();
	let h = e.faceCenterOverrides.find((e) => e.bodyShape === a.id && e.eyeStyle === o.id), g = h ? h.faceCenter : a.faceCenter, _ = o.sourceViewBox, v = Math.min(d.width / _.width, d.height / _.height);
	u.save(), u.translate(f * (g.x - o.eyeCenter.x * v) + p, f * (g.y - o.eyeCenter.y * v) + m), u.scale(f * v, f * v);
	for (let e of o.paths) u.fillStyle = e.color, u.fill(new Path2D(e.svgPath));
	return u.restore(), l;
}
//#endregion
//#region src/utils/use-bundled-avatar-components.ts
var Y = null, X = null, Z = /* @__PURE__ */ new Set(), Mt = 3e3, Nt = !1;
function Pt() {
	return Y ? Promise.resolve(Y) : X || (X = import("./avatar-bundled-components-CpiqHPhk.js").then((e) => {
		Y = e.BUNDLED_COMPONENTS, X = null;
		for (let e of Z) e();
		return Y;
	}).catch((e) => {
		throw X = null, !Nt && Z.size > 0 && (Nt = !0, setTimeout(() => {
			!Y && Z.size > 0 && Pt().catch(() => {});
		}, Mt)), e;
	}), X);
}
function Q() {
	let [, e] = V(0);
	return L(() => {
		if (Y) return;
		let t = !1, n = () => {
			t || e((e) => e + 1);
		};
		return Z.add(n), Pt().catch(() => {}), () => {
			t = !0, Z.delete(n);
		};
	}, []), Y;
}
//#endregion
//#region src/components/avatar/avatar-wave.tsx
var Ft = 620, It = 900, Lt = 20260807, Rt = 165, zt = [
	{
		x: 330,
		y: -70,
		w: 26,
		s: 13
	},
	{
		x: 420,
		y: 20,
		w: 40,
		s: 18
	},
	{
		x: 482,
		y: 115,
		w: 62,
		s: 25
	},
	{
		x: 458,
		y: 215,
		w: 96,
		s: 34
	},
	{
		x: 368,
		y: 298,
		w: 140,
		s: 45
	},
	{
		x: 258,
		y: 372,
		w: 196,
		s: 57
	},
	{
		x: 208,
		y: 462,
		w: 262,
		s: 70
	},
	{
		x: 262,
		y: 556,
		w: 340,
		s: 84
	},
	{
		x: 352,
		y: 642,
		w: 430,
		s: 98
	},
	{
		x: 372,
		y: 730,
		w: 530,
		s: 112
	},
	{
		x: 340,
		y: 822,
		w: 620,
		s: 124
	},
	{
		x: 360,
		y: 912,
		w: 700,
		s: 132
	},
	{
		x: 380,
		y: 1002,
		w: 760,
		s: 140
	}
], Bt = [
	{
		fx: .11,
		fy: -.15,
		fw: .05,
		fs: .0112
	},
	{
		fx: .115,
		fy: -.06,
		fw: .055,
		fs: .0126
	},
	{
		fx: .14,
		fy: .012,
		fw: .062,
		fs: .0142
	},
	{
		fx: .21,
		fy: .055,
		fw: .07,
		fs: .016
	},
	{
		fx: .34,
		fy: .072,
		fw: .077,
		fs: .0178
	},
	{
		fx: .51,
		fy: .072,
		fw: .084,
		fs: .0195
	},
	{
		fx: .7,
		fy: .08,
		fw: .091,
		fs: .0212
	},
	{
		fx: .89,
		fy: .112,
		fw: .1,
		fs: .023
	},
	{
		fx: 1.05,
		fy: .174,
		fw: .114,
		fs: .026
	},
	{
		fx: 1.15,
		fy: .28,
		fw: .142,
		fs: .0316
	},
	{
		fx: 1.19,
		fy: .4,
		fw: .18,
		fs: .0392
	},
	{
		fx: 1.14,
		fy: .55,
		fw: .228,
		fs: .0476
	},
	{
		fx: .98,
		fy: .702,
		fw: .325,
		fs: .0586
	},
	{
		fx: .74,
		fy: .796,
		fw: .51,
		fs: .0724
	},
	{
		fx: .58,
		fy: .866,
		fw: .84,
		fs: .0874
	},
	{
		fx: .52,
		fy: .93,
		fw: 1.16,
		fs: .1004
	},
	{
		fx: .5,
		fy: .998,
		fw: 1.48,
		fs: .1124
	},
	{
		fx: .5,
		fy: 1.07,
		fw: 1.8,
		fs: .1224
	}
], Vt = .135, Ht = "(min-height: 600px)", Ut = 170, Wt = 70, Gt = 2, Kt = 5, qt = 17, Jt = .972, Yt = .84, Xt = 70, Zt = .06, Qt = .85, $t = .12, en = .74, tn = 8, nn = 550, rn = 12, an = 55, on = 1900, sn = 1600, cn = 1e3 / 60, ln = 3, un = .9, dn = 8, fn = !1;
function pn({ className: e = "", entrance: t = !1, variant: n = "column" }) {
	let r = Q(), i = B(null);
	return L(() => {
		let e = i.current;
		if (!e || !r) return;
		let a = e.getContext("2d");
		if (!a) return;
		let o = window.matchMedia("(prefers-reduced-motion: reduce)").matches, s = t && !o && !fn;
		s && (fn = !0);
		let c = 0, l = 0, u = [], d = 0, f = 0, p = {
			x: 0,
			y: 0,
			vx: 0,
			vy: 0,
			active: !1
		}, m = null, h = /* @__PURE__ */ new Map(), g = (e, t, n, i) => {
			let a = Math.max(1, Math.round(i / dn)) * dn, o = `${e}-${t}-${n}-${a}`, s = h.get(o);
			if (s !== void 0) return s;
			let c = jt(r, e, t, n, a);
			return h.set(o, c), c;
		}, _ = () => {
			let t = e.getBoundingClientRect();
			if (t.width === 0 || t.height === 0 || Math.abs(t.width - c) < 1 && Math.abs(t.height - l) < 1) return;
			c = t.width, l = t.height;
			let i = Math.min(2, window.devicePixelRatio || 1);
			e.width = Math.round(c * i), e.height = Math.round(l * i), a.setTransform(i, 0, 0, i, 0, 0);
			let o = n === "wrap", s = o ? 1 : Math.max(c / Ft, l / It), f = o ? 0 : (l - It * s) / 2, p = o ? At(Ot(Bt, c, l), Lt, Dt(c, l) * Vt) : At(zt, Lt, Rt), m = (e) => Math.min(an, Math.max(rn, on / e)), h = p.reduce((e, t) => e + m(t.size), 0), _ = h > 0 ? sn / h : 0, v = kt(Lt + 1), y = -1, b = 0;
			u = p.map((e) => {
				let t = Math.floor(v() * r.colors.length);
				t === y && (t = (t + 1) % r.colors.length), y = t;
				let n = Math.floor(v() * r.bodyShapes.length), i = Math.floor(v() * r.eyeStyles.length), a = e.size * s, o = {
					hx: 0 + e.x * s,
					hy: f + e.y * s,
					px: a,
					rotate: e.rotate * Math.PI / 180,
					phase: v() * Math.PI * 2,
					pourDelay: b,
					dx: 0,
					dy: 0,
					vx: 0,
					vy: 0,
					disturbed: !1,
					flying: !1,
					fade: 1,
					sprite: g(n, i, t, a)
				};
				return b += m(e.size) * _, o;
			}), d === 0 && (d = performance.now());
		}, v = (e, t) => {
			let n = e.hx + e.dx, r = e.hy + e.dy;
			if (e.flying) {
				let n = Jt ** +t;
				e.vx *= n, e.vy *= n, e.dx += e.vx * t, e.dy += e.vy * t;
				let r = e.px / 2, i = r, a = c - r, o = r, s = l - r, u = e.hx + e.dx, d = e.hy + e.dy;
				a > i && (u < i ? (e.dx = i - e.hx, e.vx = Math.abs(e.vx) * Yt) : u > a && (e.dx = a - e.hx, e.vx = -Math.abs(e.vx) * Yt)), s > o && (d < o ? (e.dy = o - e.hy, e.vy = Math.abs(e.vy) * Yt) : d > s && (e.dy = s - e.hy, e.vy = -Math.abs(e.vy) * Yt)), Math.hypot(e.vx, e.vy) < .7 && (e.flying = !1);
				return;
			}
			if (e.disturbed) {
				let n = Qt ** +t;
				e.vx = (e.vx - e.dx * Zt * t) * n, e.dx += e.vx * t, e.vy = (e.vy - e.dy * Zt * t) * n, e.dy += e.vy * t, Math.hypot(e.dx, e.dy) < 2 && Math.hypot(e.vx, e.vy) < .25 && (e.disturbed = !1);
				return;
			}
			let i = 0, a = 0;
			if (p.active) {
				let o = n - p.x, s = r - p.y, c = Math.hypot(o, s) || 1;
				if (c < Ut) {
					let n = 1 - c / Ut;
					i = o / c * n ** 1.4 * Wt, a = s / c * n ** 1.4 * Wt, e.vx += p.vx * n * Gt * t, e.vy += p.vy * n * Gt * t;
					let r = Math.hypot(e.vx, e.vy);
					if (r > qt && (e.vx = e.vx / r * qt, e.vy = e.vy / r * qt), r > Kt) {
						e.flying = !0, e.disturbed = !0;
						return;
					}
				}
			}
			let o = i !== 0 || a !== 0, s = (o ? $t : Zt) * t, u = (o ? en : Qt) ** +t;
			e.vx = (e.vx + (i - e.dx) * s) * u, e.dx += e.vx * t, e.vy = (e.vy + (a - e.dy) * s) * u, e.dy += e.vy * t, Math.hypot(e.dx, e.dy) > Xt && (e.disturbed = !0);
		}, y = (e) => {
			let t = f ? Math.min(ln, (e - f) / cn) : 1;
			if (f = e, !o) {
				let e = un ** +t;
				p.vx *= e, p.vy *= e;
			}
			a.clearRect(0, 0, c, l);
			for (let n of u) {
				let r = n.sprite;
				if (!r) continue;
				let i = 1, c = 1, l = 0;
				if (!o) {
					if (s) {
						let t = e - d - n.pourDelay;
						if (t < 0) continue;
						let r = Math.min(1, t / nn);
						if (r < 1) {
							let e = 1 + 2.2 * (r - 1) ** 3 + 1.2 * (r - 1) ** 2;
							i = .3 + .7 * Math.min(1.04, e + .04 * Math.sin(r * Math.PI)), c = Math.min(1, r * 2.2), l = (1 - r) * -60;
						}
					}
					v(n, t);
					let r = Math.hypot(n.dx, n.dy), a = n.flying ? .88 : r > 20 ? .92 : 1;
					n.fade += (a - n.fade) * Math.min(1, .08 * t);
				}
				let u = o ? 0 : Math.sin(e * .001 + n.phase) * 1.4, f = o ? 0 : Math.sin(e * 8e-4 + n.phase * 2) * .025, p = n.px * i;
				a.save(), a.translate(n.hx + n.dx, n.hy + n.dy + u + l), a.rotate(n.rotate + f), a.globalAlpha = n.fade * c, a.drawImage(r, -p / 2, -p / 2, p, p), a.restore();
			}
		};
		_();
		let b = new ResizeObserver(() => {
			_(), o && y(performance.now());
		});
		b.observe(e);
		let x = 0;
		if (o) y(performance.now());
		else {
			let e = (t) => {
				y(t), x = requestAnimationFrame(e);
			};
			x = requestAnimationFrame(e);
		}
		let S = (t, n) => {
			let r = performance.now();
			if (m) {
				let e = Math.max(1, r - m.t), i = p.vx * .5 + (t - m.x) / e * .5, a = p.vy * .5 + (n - m.y) / e * .5, o = Math.hypot(i, a);
				o > tn && (i = i / o * tn, a = a / o * tn), p.vx = i, p.vy = a;
			}
			m = {
				x: t,
				y: n,
				t: r
			};
			let i = e.getBoundingClientRect();
			p.x = t - i.left, p.y = n - i.top, p.active = !0;
		}, C = (e) => S(e.clientX, e.clientY), w = (e) => {
			let t = e.touches[0];
			t && S(t.clientX, t.clientY);
		}, T = () => {
			p.active = !1, p.vx = 0, p.vy = 0, m = null;
		};
		return o || (window.addEventListener("mousemove", C, { passive: !0 }), window.addEventListener("mouseout", T), window.addEventListener("touchmove", w, { passive: !0 }), window.addEventListener("touchend", T), window.addEventListener("touchcancel", T)), () => {
			cancelAnimationFrame(x), b.disconnect(), window.removeEventListener("mousemove", C), window.removeEventListener("mouseout", T), window.removeEventListener("touchmove", w), window.removeEventListener("touchend", T), window.removeEventListener("touchcancel", T);
		};
	}, [
		r,
		t,
		n
	]), /* @__PURE__ */ H("canvas", {
		ref: i,
		"aria-hidden": "true",
		className: `pointer-events-none block h-full w-full ${e}`
	});
}
//#endregion
//#region src/components/avatar/creature-footer.tsx
function mn({ className: e = "" }) {
	return /* @__PURE__ */ H("div", {
		"aria-hidden": "true",
		className: `pointer-events-none fixed bottom-0 left-0 right-0 flex justify-center overflow-hidden ${e}`,
		children: /* @__PURE__ */ H("img", {
			src: we("/login-background-characters.svg"),
			alt: "",
			width: 1200,
			height: 180,
			className: "w-full max-w-[900px] object-cover object-bottom"
		})
	});
}
//#endregion
//#region src/components/onboarding-layout.tsx
function hn({ children: e, showCreatureFooter: t = !0, avatarWave: n = "none", animateAvatarWaveIn: r = !1 }) {
	let [i, a] = V(null), o = Tt(), s = x(Ht), c = be(), l = n !== "none" && !o && !c, u = n === "around" && o && s && !c, d = /* @__PURE__ */ H("div", {
		className: "flex-1 overflow-y-auto",
		children: /* @__PURE__ */ H(pe, {
			container: i,
			children: e
		})
	});
	return /* @__PURE__ */ U("div", {
		className: "relative isolate flex h-full flex-col bg-[var(--surface-base)]",
		children: [
			u && /* @__PURE__ */ H(pn, {
				variant: "wrap",
				entrance: r,
				className: "fixed inset-0 -z-10"
			}),
			l ? /* @__PURE__ */ U("div", {
				className: "flex min-h-0 flex-1",
				children: [d, /* @__PURE__ */ H("div", {
					className: "relative w-[46%] lg:w-1/2",
					children: /* @__PURE__ */ H(pn, {
						className: "absolute inset-0",
						entrance: r
					})
				})]
			}) : d,
			t && !l && !u && /* @__PURE__ */ H(mn, {}),
			/* @__PURE__ */ H("div", { ref: a })
		]
	});
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs
function gn() {
	!xe.current && Te();
	let [e] = V(De.current);
	return e;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/animation/hooks/animation-controls.mjs
function _n(e) {
	e.values.forEach((e) => e.stop());
}
function vn(e, t) {
	[...t].reverse().forEach((n) => {
		let r = e.getVariant(n);
		r && Ee(e, r), e.variantChildren && e.variantChildren.forEach((e) => {
			vn(e, t);
		});
	});
}
function yn(e, t) {
	if (Array.isArray(t)) return vn(e, t);
	if (typeof t == "string") return vn(e, [t]);
	Ee(e, t);
}
function bn() {
	let e = !1, t = /* @__PURE__ */ new Set(), n = {
		subscribe(e) {
			return t.add(e), () => void t.delete(e);
		},
		start(n, r) {
			ke(e, "controls.start() should only be called after a component has mounted. Consider calling within a useEffect hook.");
			let i = [];
			return t.forEach((e) => {
				i.push(Se(e, n, { transitionOverride: r }));
			}), Promise.all(i);
		},
		set(n) {
			return ke(e, "controls.set() should only be called after a component has mounted. Consider calling within a useEffect hook."), t.forEach((e) => {
				yn(e, n);
			});
		},
		stop() {
			t.forEach((e) => {
				_n(e);
			});
		},
		mount() {
			return e = !0, () => {
				e = !1, n.stop();
			};
		}
	};
	return n;
}
//#endregion
//#region ../../node_modules/.bun/framer-motion@12.43.0+d0e719b86e9808b5/node_modules/framer-motion/dist/es/animation/hooks/use-animation.mjs
function xn() {
	let e = Oe(bn);
	return Ce(e.mount, []), e;
}
//#endregion
//#region src/components/avatar/animated-avatar.tsx
function Sn(e, t) {
	return e + Math.random() * (t - e);
}
function Cn(e) {
	let t = [], n = /-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/gi, r;
	for (; (r = n.exec(e)) !== null;) t.push(parseFloat(r[0]));
	return t;
}
function wn(e) {
	let t = 0, n = 0, r = 0;
	for (let i = 0; i < e.length - 1; i += 2) t += e[i], n += e[i + 1], r++;
	return r > 0 ? {
		x: t / r,
		y: n / r
	} : {
		x: 0,
		y: 0
	};
}
function Tn(e, t, n, r, i) {
	let a = r * 1.1, o = 0;
	return e.replace(/-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/gi, () => {
		let e = o;
		o++;
		let r = t[e], s = e % 2 == 0, c = s ? n.x : n.y, l = s ? e + 1 : e - 1, u = l >= 0 && l < t.length ? t[l] : c, d = s ? r : u, f = Math.atan2((s ? u : r) - n.y, d - n.x), p = 1 + (Math.sin(f * 2 + a) * .7 + Math.sin(f * 3 - a * .5) * .3) * i;
		return (c + (r - c) * p).toFixed(3);
	});
}
function En(e, t, n) {
	let r = Cn(e), i = wn(r), a = [e];
	for (let o = 1; o < t; o++) a.push(Tn(e, r, i, o, n));
	return a;
}
function Dn(e) {
	let { components: t, traits: n } = e, r = _e(t, n.bodyShape, n.eyeStyle, n.color);
	return !r || !r.eyeStyle ? null : /* @__PURE__ */ H(On, {
		...e,
		bodyShape: r.bodyShape,
		eyeStyle: r.eyeStyle,
		color: r.color
	});
}
function On({ components: e, size: t, isAssistantBusy: n = !1, attentive: r = !1, breathe: i = !0, bodyShape: a, eyeStyle: o, color: s }) {
	let c = gn(), { bodyTransform: l, eyeTransform: u } = ve(a, o, e, t), d = o.sourceViewBox, f = a.viewBox, p = Math.min(t / f.width, t / f.height), m = (t - f.width * p) / 2, h = (t - f.height * p) / 2, g = Math.min(f.width / d.width, f.height / d.height), _ = e.faceCenterOverrides.find((e) => e.bodyShape === a.id && e.eyeStyle === o.id), v = _ ? _.faceCenter : a.faceCenter, y = v.x - o.eyeCenter.x * g, b = v.y - o.eyeCenter.y * g, x = p * (y + o.eyeCenter.x * g) + m, S = p * (b + o.eyeCenter.y * g) + h, C = z(() => n ? En(a.svgPath, 16, .06) : [a.svgPath], [a.svgPath, n]), [w, T] = V(!1), [E, D] = V(0), O = B(null);
	L(() => {
		if (c || n) {
			T(!1);
			return;
		}
		let e = !1;
		function t() {
			return setTimeout(() => {
				e || (T(!0), setTimeout(() => {
					e || (T(!1), Math.random() < .2 ? setTimeout(() => {
						e || (T(!0), setTimeout(() => {
							e || (T(!1), t());
						}, 150));
					}, 200) : t());
				}, 150));
			}, Sn(3e3, 7e3));
		}
		let r = t();
		return () => {
			e = !0, clearTimeout(r);
		};
	}, [c, n]), L(() => {
		if (c || n) {
			D(0);
			return;
		}
		let e = !1;
		function t() {
			return setTimeout(() => {
				e || (D((Math.random() < .5 ? -1 : 1) * Sn(1, 2)), setTimeout(() => {
					e || (D(0), t());
				}, 200));
			}, Sn(8e3, 15e3));
		}
		let r = t();
		return () => {
			e = !0, clearTimeout(r);
		};
	}, [c, n]), L(() => {
		let e = O.current;
		if (!e) return;
		let t = C[0] ?? a.svgPath;
		if (!n || c || C.length <= 1) {
			e.setAttribute("d", t);
			return;
		}
		let r = 0, i = setInterval(() => {
			r = (r + 1) % C.length;
			let t = C[r];
			t && e.setAttribute("d", t);
		}, 150);
		return () => {
			clearInterval(i), e.setAttribute("d", t);
		};
	}, [
		n,
		c,
		C,
		a.svgPath
	]);
	let ee = t / 2, k = t / 2, te = c ? "none" : n ? "avatar-morph-scale 2.4s ease-in-out infinite, avatar-morph-rotate 3s ease-in-out infinite" : i ? "avatar-breathe-kf 4s ease-in-out infinite" : "none", ne = n ? 0 : E, re = w && !n, A = C[0] ?? a.svgPath;
	return /* @__PURE__ */ U("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: t,
		height: t,
		viewBox: `0 0 ${t} ${t}`,
		"data-busy": n ? "true" : void 0,
		style: {
			animation: te,
			transformOrigin: "center",
			overflow: "visible"
		},
		children: [/* @__PURE__ */ H("g", {
			style: {
				transform: `rotate(${ne}deg)`,
				transformOrigin: `${ee}px ${k}px`,
				transition: ne === 0 ? "transform 0.3s ease-out" : "transform 0.2s ease-in-out"
			},
			children: /* @__PURE__ */ H("path", {
				ref: O,
				d: A,
				fill: s.hex,
				transform: l,
				style: { transition: n ? "d 0.3s ease-in-out" : "none" }
			})
		}), /* @__PURE__ */ H("g", {
			style: {
				transform: re ? "scaleY(0.1)" : r ? "scale(1.12, 1.22)" : "scaleY(1)",
				transformOrigin: `${x}px ${S}px`,
				transition: "transform 0.15s ease-in-out"
			},
			children: o.paths.map((e, t) => /* @__PURE__ */ H("path", {
				d: e.svgPath,
				fill: e.color,
				transform: u
			}, t))
		})]
	});
}
//#endregion
//#region src/hooks/use-element-size.ts
var kn = {
	w: 1280,
	h: 800
};
function An() {
	return typeof window > "u" ? kn : {
		w: window.innerWidth,
		h: window.innerHeight
	};
}
var jn = kn, Mn = /* @__PURE__ */ new Set();
function Nn() {
	for (let e of Mn) e();
}
function Pn(e) {
	return Mn.size === 0 && window.addEventListener("resize", Nn), Mn.add(e), () => {
		Mn.delete(e), Mn.size === 0 && window.removeEventListener("resize", Nn);
	};
}
function Fn() {
	let e = An();
	return (e.w !== jn.w || e.h !== jn.h) && (jn = e), jn;
}
function In() {
	return kn;
}
var Ln = () => () => {};
function Rn(e = !0) {
	return Be(e ? Pn : Ln, Fn, In);
}
function zn() {
	let [e, t] = V(null), [n, r] = V(() => An());
	return R(() => {
		if (!e) return;
		let t = () => {
			let t = e.getBoundingClientRect();
			r((e) => e.w === t.width && e.h === t.height ? e : {
				w: t.width,
				h: t.height
			});
		};
		t();
		let n = new ResizeObserver(t);
		return n.observe(e), () => n.disconnect();
	}, [e]), {
		ref: t,
		size: n
	};
}
//#endregion
//#region src/domains/onboarding/hooks/use-onboarding-stage-size.tsx
var Bn = Le(null);
function Vn({ size: e, children: t }) {
	return /* @__PURE__ */ H(Bn.Provider, {
		value: e,
		children: t
	});
}
function Hn() {
	let e = Re(Bn), t = Rn(!e);
	return e ?? t;
}
//#endregion
//#region src/domains/onboarding/components/onboarding-character-stage.tsx
var Un = {
	x: .5,
	y: .43
}, Wn = [
	-8,
	6,
	9,
	0,
	7,
	-6,
	5,
	0,
	-7,
	4,
	-5,
	6
];
function Gn(e) {
	return Wn[e % Wn.length] ?? 0;
}
var Kn = [
	1,
	0,
	1,
	0,
	1,
	0,
	1,
	0,
	1,
	0,
	0
], qn = [.72, 1], Jn = [.4, 1], Yn = [10, 20], Xn = 50, Zn = { 6: 1.1 };
function Qn(e) {
	return (qn[Kn[e] ?? 1] ?? 1) * (Zn[e] ?? 1);
}
function $n(e) {
	return Jn[Kn[e] ?? 1] ?? 1;
}
function er(e) {
	return Yn[Kn[e] ?? 1] ?? 20;
}
function tr(e, t) {
	return Math.round(Math.max(130, Math.min(Math.min(e, t) * .4, 420)));
}
function nr(e, t) {
	return Math.round(Math.max(110, Math.min(Math.min(e, t) * .21, 205)));
}
function rr(e, t, n) {
	let r = n * .4, i = n * .48;
	return [
		{
			x: i,
			y: i
		},
		{
			x: e * .3,
			y: r - t * .03
		},
		{
			x: e * .72,
			y: r - t * .1
		},
		{
			x: e - i,
			y: i
		},
		{
			x: e - r,
			y: t * .72
		},
		{
			x: e - i,
			y: t - i
		},
		{
			x: i,
			y: t - i
		},
		{
			x: r,
			y: t * .5
		},
		{
			x: e - r,
			y: t * .3
		},
		{
			x: e * .28,
			y: t - r + t * .05
		},
		{
			x: e * .77,
			y: t - r
		}
	];
}
function ir(e, t, n, r, i) {
	let a = e.x - t, o = e.y - n, s = Math.hypot(a, o) || 1, c = Math.max(r, i);
	return {
		x: e.x + a / s * c,
		y: e.y + o / s * c
	};
}
function ar({ components: e, characters: t, centerChar: n, edgeOrder: r, entering: i, exiting: a, onEnterComplete: o, onSelectChar: s }) {
	let { w: c, h: l } = Hn(), u = gn(), d = c < 640, f = new Set([
		4,
		7,
		8,
		9,
		10
	]), p = (e) => d && f.has(e), m = tr(c, l), h = m / 2, g = m / 2, _ = nr(c, l) / m, v = nr(c, l), y = z(() => {
		let e = /* @__PURE__ */ new Map();
		return r.forEach((t, n) => e.set(t, n)), e;
	}, [r]), b = Un.x * c, x = Un.y * l, S = b - h, C = x - h, w = z(() => rr(c, l, g), [
		c,
		l,
		g
	]);
	return /* @__PURE__ */ U("div", {
		"aria-hidden": "true",
		className: "pointer-events-none absolute inset-0 z-0 overflow-hidden",
		children: [/* @__PURE__ */ H("div", {
			className: "absolute rounded-[50%] bg-[var(--aux-black,#000)] opacity-20 blur-md",
			style: {
				width: v * .62,
				height: 16,
				left: b - v * .31,
				top: x + v * .4
			}
		}), t.map((t, r) => {
			let d = r === n, f = !u && i?.char === r, g = !u && a?.char === r;
			if (f) {
				let n = w[i.fromSlot], a = ir(n, b, x, c, l), s = Qn(i.fromSlot), u = $n(i.fromSlot);
				return /* @__PURE__ */ H(I.div, {
					className: "absolute left-0 top-0",
					style: {
						width: m,
						height: m,
						zIndex: Xn
					},
					initial: !1,
					animate: {
						x: [
							n.x - h,
							a.x - h,
							a.x - h,
							S,
							S,
							S
						],
						y: [
							n.y - h,
							a.y - h,
							a.y - h,
							C,
							C,
							C
						],
						scale: [
							s,
							s,
							s,
							_ * .7,
							_ * 1.08,
							_
						],
						opacity: [
							u,
							u,
							0,
							0,
							1,
							1
						]
					},
					transition: {
						duration: .85,
						times: [
							0,
							.28,
							.34,
							.42,
							.72,
							1
						],
						ease: [
							"easeIn",
							"linear",
							"linear",
							"easeOut",
							"easeOut"
						]
					},
					onAnimationComplete: () => o(r),
					children: /* @__PURE__ */ H(Dn, {
						components: e,
						traits: t,
						size: m
					})
				}, r);
			}
			if (g) {
				if (p(a.toSlot)) return null;
				let n = w[a.toSlot], i = ir(n, b, x, c, l), o = Qn(a.toSlot), s = $n(a.toSlot);
				return /* @__PURE__ */ H(I.div, {
					className: "absolute left-0 top-0",
					style: {
						width: m,
						height: m,
						zIndex: er(a.toSlot)
					},
					initial: !1,
					animate: {
						x: [
							S,
							S,
							i.x - h,
							i.x - h,
							n.x - h,
							n.x - h
						],
						y: [
							C,
							C,
							i.y - h,
							i.y - h,
							n.y - h,
							n.y - h
						],
						scale: [
							_,
							_ * .6,
							o,
							o,
							o * 1.1,
							o
						],
						opacity: [
							1,
							0,
							0,
							s,
							s,
							s
						]
					},
					transition: {
						duration: .85,
						times: [
							0,
							.28,
							.34,
							.45,
							.78,
							1
						],
						ease: [
							"easeIn",
							"linear",
							"linear",
							"easeOut",
							"easeOut"
						]
					},
					children: /* @__PURE__ */ H("div", {
						style: { transform: `rotate(${Gn(a.toSlot)}deg)` },
						children: /* @__PURE__ */ H(Dn, {
							components: e,
							traits: t,
							size: m,
							breathe: !1
						})
					})
				}, r);
			}
			let v = y.get(r) ?? 0;
			if (!d && p(v)) return null;
			let T = d ? {
				x: b,
				y: x
			} : w[v];
			return /* @__PURE__ */ H(I.div, {
				className: `absolute left-0 top-0 ${d ? "" : "pointer-events-auto cursor-pointer"}`,
				style: {
					width: m,
					height: m,
					zIndex: d ? Xn : er(v)
				},
				initial: !1,
				animate: {
					x: T.x - h,
					y: T.y - h,
					scale: d ? _ : Qn(v),
					opacity: d ? 1 : $n(v)
				},
				transition: u ? { duration: 0 } : {
					type: "spring",
					stiffness: 230,
					damping: 26
				},
				onClick: d ? void 0 : () => s(r),
				children: /* @__PURE__ */ H("div", {
					style: { transform: d ? void 0 : `rotate(${Gn(y.get(r) ?? 0)}deg)` },
					children: /* @__PURE__ */ H(Dn, {
						components: e,
						traits: t,
						size: m,
						breathe: d
					})
				})
			}, r);
		})]
	});
}
//#endregion
//#region src/domains/onboarding/onboarding-avatar-pool-store.ts
var or = [
	{
		bodyShape: "urchin",
		eyeStyle: "goofy",
		color: "teal"
	},
	{
		bodyShape: "blob",
		eyeStyle: "grumpy",
		color: "purple"
	},
	{
		bodyShape: "star",
		eyeStyle: "surprised",
		color: "orange"
	},
	{
		bodyShape: "blob",
		eyeStyle: "gentle",
		color: "pink"
	},
	{
		bodyShape: "ninja",
		eyeStyle: "angry",
		color: "yellow"
	},
	{
		bodyShape: "urchin",
		eyeStyle: "curious",
		color: "pink"
	},
	{
		bodyShape: "burst",
		eyeStyle: "quirky",
		color: "orange"
	},
	{
		bodyShape: "ghost",
		eyeStyle: "bashful",
		color: "green"
	},
	{
		bodyShape: "sprout",
		eyeStyle: "dazed",
		color: "orange"
	},
	{
		bodyShape: "star",
		eyeStyle: "goofy",
		color: "teal"
	},
	{
		bodyShape: "flower",
		eyeStyle: "angry",
		color: "pink"
	},
	{
		bodyShape: "cloud",
		eyeStyle: "curious",
		color: "yellow"
	}
], $ = C(b((e, t) => ({
	characters: [],
	selectedIndex: 0,
	ensureGenerated: (n, r = Math.random) => {
		t().characters.length > 0 || e({
			characters: or,
			selectedIndex: sr(or.length, r)
		});
	},
	setCharacterTraits: (t, n) => e((e) => ({ characters: e.characters.map((e, r) => r === t ? n : e) })),
	setSelectedIndex: (t) => e({ selectedIndex: t }),
	selectNext: () => e((e) => ({ selectedIndex: e.characters.length === 0 ? 0 : (e.selectedIndex + 1) % e.characters.length })),
	selectPrev: () => e((e) => ({ selectedIndex: e.characters.length === 0 ? 0 : (e.selectedIndex - 1 + e.characters.length) % e.characters.length }))
})));
function sr(e, t = Math.random) {
	return e <= 0 ? 0 : Math.floor(t() * e);
}
//#endregion
//#region src/domains/onboarding/components/onboarding-edge-characters.tsx
function cr() {
	let e = Q(), t = $.use.characters(), n = $.use.ensureGenerated(), r = gn(), { w: i, h: a } = Rn();
	L(() => {
		e && n(e);
	}, [e, n]);
	let o = tr(i, a), s = z(() => rr(i, a, o / 2), [
		i,
		a,
		o
	]), c = i < 640, l = new Set([
		4,
		7,
		8,
		9,
		10
	]);
	return !e || t.length === 0 ? null : /* @__PURE__ */ H("div", {
		"aria-hidden": "true",
		className: "pointer-events-none fixed inset-0 z-0 overflow-hidden",
		children: t.map((t, n) => {
			if (n === 0) return null;
			let i = n - 1;
			if (c && l.has(i)) return null;
			let a = s[i];
			if (!a) return null;
			let u = Wn[i % Wn.length] ?? 0, d = o * Qn(i), f = $n(i), p = er(i);
			return /* @__PURE__ */ H("div", {
				className: "absolute",
				style: {
					left: a.x - d / 2,
					top: a.y - d / 2,
					width: d,
					height: d,
					zIndex: p,
					animation: r ? void 0 : `character-pop-in 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) ${.1 + n * .05}s both`
				},
				children: /* @__PURE__ */ H("div", {
					style: {
						opacity: f,
						transform: `rotate(${u}deg)`
					},
					children: /* @__PURE__ */ H(Dn, {
						components: e,
						traits: t,
						size: d,
						breathe: !1
					})
				})
			}, n);
		})
	});
}
//#endregion
//#region src/domains/onboarding/onboarding-step-layout.ts
var lr = "absolute left-1/2 top-[30%] z-10 flex w-full -translate-x-1/2 flex-col items-center gap-8 px-6 text-center", ur = "touch-mobile:text-[16px]", dr = "#17191C", fr = C(b((e) => ({
	surface: null,
	transition: null,
	owner: null,
	setSurface: (t, n = null, r = null) => e((e) => e.surface === t && e.transition === n && e.owner === r ? e : {
		surface: t,
		transition: n,
		owner: r
	})
}))), pr = {
	linear: "linear",
	easeIn: "ease-in",
	easeOut: "ease-out",
	easeInOut: "ease-in-out"
};
function mr({ duration: e, delay: t = 0, ease: n = "easeOut" }) {
	let r = `${e}s ${pr[n]}`;
	return t > 0 ? `${r} ${t}s` : r;
}
function hr(e, t = null) {
	let n = fr.use.setSurface(), r = ze(), i = B(null);
	R(() => {
		if (e === null) return;
		let a = i.current !== null && i.current !== e;
		i.current = e, n(e, a ? t : null, r);
	}, [
		e,
		t,
		r,
		n
	]), R(() => () => {
		fr.getState().owner === r && n(null);
	}, [r, n]);
}
//#endregion
//#region src/domains/onboarding/screens/research-onboarding-screen.tsx
function gr(e, t) {
	return {
		animation: `fadeInUp 0.4s ease-out ${e}s both`,
		...t == null ? {} : {
			position: "relative",
			zIndex: t
		}
	};
}
function _r({ initialFirstName: e = "", onSubmit: t, onSkip: n }) {
	let { t: r } = j("onboarding");
	hr(dr);
	let [i, a] = V(e), o = i.trim().length > 0;
	function s() {
		o && t({ firstName: i });
	}
	return /* @__PURE__ */ H("div", {
		"data-theme": "dark",
		className: "h-full",
		children: /* @__PURE__ */ U(hn, {
			showCreatureFooter: !1,
			children: [
				/* @__PURE__ */ H(cr, {}),
				/* @__PURE__ */ U("form", {
					className: "relative z-10 mx-auto flex min-h-screen w-full max-w-sm flex-col items-center justify-center px-6 py-16 text-[var(--content-default)]",
					onSubmit: (e) => {
						e.preventDefault(), s();
					},
					children: [
						/* @__PURE__ */ H("h1", {
							className: "text-center font-serif text-[2.75rem] leading-[1.05] tracking-tight",
							style: gr(.05),
							children: r("researchOnboardingScreen.title")
						}),
						/* @__PURE__ */ H("div", {
							className: "mt-10 flex w-full flex-col gap-5",
							children: /* @__PURE__ */ H("div", {
								style: gr(.12, 40),
								children: /* @__PURE__ */ H(me, {
									label: r("researchOnboardingScreen.firstNameLabel"),
									placeholder: r("researchOnboardingScreen.firstNamePlaceholder"),
									value: i,
									onChange: (e) => a(e.target.value),
									className: ur,
									autoFocus: !0,
									required: !0,
									fullWidth: !0
								})
							})
						}),
						/* @__PURE__ */ H("div", {
							className: "mt-10 w-full",
							style: gr(.5),
							children: /* @__PURE__ */ H(P, {
								type: "submit",
								variant: "primary",
								size: "large",
								rightIcon: /* @__PURE__ */ H(W, { size: 16 }),
								fullWidth: !0,
								disabled: !o,
								children: r("actions.continue")
							})
						})
					]
				}),
				/* @__PURE__ */ H("button", {
					type: "button",
					onClick: n,
					className: "fixed right-6 bottom-6 text-body-small text-[var(--content-tertiary)] transition-colors hover:text-[var(--content-secondary)]",
					style: gr(.6),
					children: r("researchOnboardingScreen.skip")
				})
			]
		})
	});
}
//#endregion
//#region src/components/avatar/peeking-eyes.tsx
var vr = .25, yr = .46, br = .3, xr = .85, Sr = .4, Cr = 14, wr = 8;
function Tr({ art: e, stage: t, entrance: n = !1, entranceDelay: r = 0, restSinkFraction: i = 0, bumpNonce: a }) {
	let o = gn(), { w: s, h: c } = t, [l, u] = V({
		x: 0,
		y: 0
	});
	L(() => {
		if (o) return;
		let e = (e) => {
			u({
				x: (e.clientX / window.innerWidth - .5) * 2,
				y: (e.clientY / window.innerHeight - .5) * 2
			});
		};
		return window.addEventListener("mousemove", e), () => window.removeEventListener("mousemove", e);
	}, [o]);
	let d = n && !o, f = xn();
	L(() => {
		(a ?? 0) > 0 && !o && f.start({
			y: [
				0,
				-34,
				8,
				0
			],
			transition: {
				duration: .45,
				ease: "easeOut"
			}
		});
	}, [
		a,
		o,
		f
	]);
	let [p, m] = V(!1), [h, g] = V(!n);
	if (L(() => {
		if (o || !h) return;
		let e = !1, t, r = (n) => {
			e || (m(!0), t = setTimeout(() => {
				e || (m(!1), t = setTimeout(n, 140));
			}, 140));
		}, i = () => {
			t = setTimeout(() => r(i), 2500 + Math.random() * 4e3);
		};
		return n ? r(() => r(i)) : i(), () => {
			e = !0, clearTimeout(t);
		};
	}, [
		o,
		h,
		n
	]), s === 0 || c === 0) return null;
	let _ = s * xr, v = Math.min(Math.min(s, c) * br, _ * e.bbox.h / e.bbox.w), y = v * e.bbox.w / e.bbox.h, b = (s - y) / 2, x = c - (1 - vr) * v + c * i, S = Sr * c - (x + v / 2), C = (yr - vr) * v, w = e.bbox.x + e.bbox.w / 2, T = e.bbox.y + e.bbox.h / 2, E = /* @__PURE__ */ H("div", {
		style: {
			transform: `translate(${l.x * Cr}px, ${l.y * wr}px)`,
			transition: "transform 0.5s cubic-bezier(0.22, 1, 0.36, 1)"
		},
		children: /* @__PURE__ */ H("svg", {
			viewBox: `${e.bbox.x} ${e.bbox.y} ${e.bbox.w} ${e.bbox.h}`,
			width: y,
			height: v,
			style: {
				overflow: "visible",
				display: "block"
			},
			children: /* @__PURE__ */ H("g", {
				style: {
					transform: p ? "scaleY(0.1)" : "scaleY(1)",
					transformOrigin: `${w}px ${T}px`,
					transition: "transform 0.14s ease-in-out"
				},
				children: e.paths.map((e, t) => /* @__PURE__ */ H("path", {
					d: e.svgPath,
					fill: e.color
				}, t))
			})
		})
	});
	return /* @__PURE__ */ H(I.div, {
		"aria-hidden": "true",
		className: "pointer-events-none absolute z-[2]",
		style: {
			left: b,
			top: x,
			width: y,
			height: v,
			transformOrigin: "center"
		},
		initial: d ? {
			y: S,
			scale: .35
		} : !1,
		animate: d ? {
			y: [
				S,
				C,
				0
			],
			scale: [
				.35,
				1,
				1
			]
		} : {
			y: 0,
			scale: 1
		},
		transition: d ? {
			duration: 1,
			delay: r,
			times: [
				0,
				.7,
				1
			],
			ease: "easeInOut"
		} : { duration: 0 },
		onAnimationComplete: () => g(!0),
		children: a === void 0 ? E : /* @__PURE__ */ H(I.div, {
			animate: f,
			children: E
		})
	});
}
br * (1 - vr);
//#endregion
//#region src/utils/eye-bbox.ts
var Er = /-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/gi, Dr = /[MmLlHhVvCcSsQqTtAaZz][^MmLlHhVvCcSsQqTtAaZz]*/g;
function Or(e) {
	let t = Infinity, n = Infinity, r = -Infinity, i = -Infinity, a = 0, o = 0, s = (e, a) => {
		e < t && (t = e), a < n && (n = a), e > r && (r = e), a > i && (i = a);
	}, c = e.match(Dr) ?? [];
	for (let e of c) {
		let t = e[0], n = t.toUpperCase();
		if (n === "Z") continue;
		let r = t !== n, i = (e.slice(1).match(Er) ?? []).map(Number);
		if (n === "H") for (let e of i) a = r ? a + e : e, s(a, o);
		else if (n === "V") for (let e of i) o = r ? o + e : e, s(a, o);
		else if (n === "A") for (let e = 0; e + 7 <= i.length; e += 7) {
			let t = i[e + 5], n = i[e + 6];
			a = r ? a + t : t, o = r ? o + n : n, s(a, o);
		}
		else {
			let e = a, t = o;
			for (let n = 0; n + 2 <= i.length; n += 2) {
				let c = r ? e + i[n] : i[n], l = r ? t + i[n + 1] : i[n + 1];
				s(c, l), n + 2 >= i.length - i.length % 2 && (a = c, o = l);
			}
		}
	}
	return t === Infinity ? {
		x: 0,
		y: 0,
		w: 0,
		h: 0
	} : {
		x: t,
		y: n,
		w: r - t,
		h: i - n
	};
}
function kr(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y)), r = Math.max(...e.map((e) => e.x + e.w)), i = Math.max(...e.map((e) => e.y + e.h));
	return {
		x: t,
		y: n,
		w: r - t,
		h: i - n
	};
}
//#endregion
//#region src/domains/onboarding/components/onboarding-peeking-eyes.tsx
var Ar = .05;
function jr({ entrance: e = !1, entranceDelay: t = 0, bumpNonce: n = 0 }) {
	let r = Q(), i = $.use.characters(), a = $.use.selectedIndex(), o = Hn(), s = i.length > 0 ? i[a] : void 0, c = z(() => {
		if (!r || !s) return null;
		let e = r.eyeStyles.find((e) => e.id === s.eyeStyle);
		return e ? {
			paths: e.paths,
			bbox: kr(e.paths.map((e) => Or(e.svgPath)))
		} : null;
	}, [r, s]);
	return c ? /* @__PURE__ */ H(Tr, {
		art: c,
		stage: o,
		entrance: e,
		entranceDelay: t,
		restSinkFraction: Ar,
		bumpNonce: n
	}) : null;
}
//#endregion
//#region src/domains/onboarding/components/onboarding-stage.tsx
function Mr({ className: e, surface: t = dr, surfaceTransition: n, children: r }) {
	let { ref: i, size: a } = zn();
	return hr(t, n ?? null), /* @__PURE__ */ H("div", {
		ref: i,
		"data-theme": "dark",
		className: w("relative h-full overflow-hidden", e),
		children: /* @__PURE__ */ H(Vn, {
			size: a,
			children: r
		})
	});
}
//#endregion
//#region src/utils/avatar-tone.ts
var Nr = "#1A1A1A", Pr = "#FFFFFF";
function Fr(e) {
	let t = /^#?([0-9a-f]{6})$/i.exec(e);
	if (!t) return 0;
	let n = parseInt(t[1], 16), r = n >> 16 & 255, i = n >> 8 & 255, a = n & 255;
	return (r * 299 + i * 587 + a * 114) / 1e3 / 255;
}
function Ir(e, t) {
	let n = /^#?([0-9a-f]{6})$/i.exec(e);
	if (!n) return e;
	let r = parseInt(n[1], 16), i = (e) => Math.max(0, Math.min(255, Math.round((r >> e & 255) * t)));
	return `#${(1 << 24 | i(16) << 16 | i(8) << 8 | i(0)).toString(16).slice(1)}`;
}
function Lr(e, t, n) {
	let r = /^#?([0-9a-f]{6})$/i.exec(e), i = /^#?([0-9a-f]{6})$/i.exec(t);
	if (!r || !i) return e;
	let a = Math.max(0, Math.min(1, n)), o = parseInt(r[1], 16), s = parseInt(i[1], 16), c = (e) => Math.round((o >> e & 255) * (1 - a) + (s >> e & 255) * a);
	return `#${(1 << 24 | c(16) << 16 | c(8) << 8 | c(0)).toString(16).slice(1)}`;
}
function Rr(e) {
	let t = /^#?([0-9a-f]{6})$/i.exec(e);
	if (!t) return 0;
	let n = parseInt(t[1], 16), r = (e) => {
		let t = (n >> e & 255) / 255;
		return t <= .04045 ? t / 12.92 : ((t + .055) / 1.055) ** 2.4;
	};
	return .2126 * r(16) + .7152 * r(8) + .0722 * r(0);
}
function zr(e, t) {
	let [n, r] = [Rr(e), Rr(t)].sort((e, t) => t - e);
	return (n + .05) / (r + .05);
}
function Br(e) {
	return zr(Nr, e) > zr(Pr, e) ? Nr : Pr;
}
var Vr = 4.5;
(1.05 / Vr - .05 + (Vr * (Rr(Nr) + .05) - .05)) / 2;
function Hr(e) {
	let t = Fr(e) > .6;
	return {
		bg: e,
		isLight: t,
		fg: t ? Nr : Pr,
		fgDeep: Ir(e, .6),
		fgMuted: t ? "rgba(0,0,0,0.6)" : "rgba(255,255,255,0.65)",
		wash: t ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.12)",
		bubbleBg: t ? "rgba(0,0,0,0.10)" : "rgba(255,255,255,0.16)",
		bubbleFg: Br(t ? Lr(e, "#000000", .1) : Lr(e, "#ffffff", .16))
	};
}
//#endregion
//#region src/domains/onboarding/onboarding-tone.ts
function Ur() {
	let e = Q(), t = $.use.characters(), n = $.use.selectedIndex();
	return z(() => {
		let r = t[n], i = e?.colors.find((e) => e.id === r?.color)?.hex;
		return Hr(i ?? "var(--surface-base)");
	}, [
		e,
		t,
		n
	]);
}
//#endregion
//#region src/domains/onboarding/components/onboarding-top-bar.tsx
function Wr({ onBack: e, onNext: t, tone: n }) {
	let { t: r } = j("onboarding"), i = Ur(), a = n ? n === "dark" ? "#1A1A1A" : "#FFFFFF" : i.fg, o = `color-mix(in srgb, ${a} 10%, transparent)`, s = `color-mix(in srgb, ${a} 18%, transparent)`;
	return /* @__PURE__ */ U("div", {
		className: "absolute left-4 top-6 z-10 flex items-center gap-3",
		children: [/* @__PURE__ */ H("button", {
			type: "button",
			onClick: e,
			"aria-label": r("actions.back"),
			className: "flex cursor-pointer h-10 w-10 items-center justify-center rounded-full transition-colors duration-150",
			style: {
				color: a,
				backgroundColor: o
			},
			onMouseEnter: (e) => e.currentTarget.style.backgroundColor = s,
			onMouseLeave: (e) => e.currentTarget.style.backgroundColor = o,
			children: /* @__PURE__ */ H(d, { className: "h-4 w-4" })
		}), t ? /* @__PURE__ */ H("button", {
			type: "button",
			onClick: t,
			"aria-label": r("actions.forward"),
			className: "flex cursor-pointer h-10 w-10 items-center justify-center rounded-full transition-colors duration-150",
			style: {
				color: a,
				backgroundColor: o
			},
			onMouseEnter: (e) => e.currentTarget.style.backgroundColor = s,
			onMouseLeave: (e) => e.currentTarget.style.backgroundColor = o,
			children: /* @__PURE__ */ H(W, { className: "h-4 w-4" })
		}) : null]
	});
}
//#endregion
//#region src/domains/onboarding/hooks/use-entrance-failsafe.ts
function Gr(e = Kr) {
	let [t, n] = V(!1);
	return L(() => {
		let t = setTimeout(() => n(!0), e);
		return () => clearTimeout(t);
	}, [e]), t;
}
var Kr = 3e3, qr = 200, Jr = 40;
function Yr({ art: e, reduce: t }) {
	let { w: n, h: r } = Hn(), i = 1.25 * Math.max(n, r), a = i * e.body.viewBox.height / e.body.viewBox.width, o = (n - i) / 2, s = (r - a) / 2, c = qr / i, l = (Jr / 100 - .5) * r;
	return /* @__PURE__ */ H(I.svg, {
		"aria-hidden": "true",
		className: "pointer-events-none absolute z-[1]",
		viewBox: `0 0 ${e.body.viewBox.width} ${e.body.viewBox.height}`,
		width: i,
		height: a,
		style: {
			left: o,
			top: s,
			transformOrigin: "center"
		},
		initial: t ? !1 : {
			scale: c,
			y: l
		},
		animate: {
			scale: 1,
			y: 0
		},
		transition: t ? { duration: 0 } : {
			type: "spring",
			stiffness: 78,
			damping: 18,
			mass: 1
		},
		children: /* @__PURE__ */ H("path", {
			d: e.body.svgPath,
			fill: e.color
		})
	});
}
var Xr = {
	duration: .6,
	delay: .35
}, Zr = mr(Xr);
function Qr({ firstName: e, assistantName: t, onContinue: n, onBack: r, onForward: i }) {
	let { t: a } = j("onboarding"), o = Q(), s = $.use.characters(), c = $.use.selectedIndex(), l = gn(), u = Ur(), d = Gr(), f = s.length > 0 ? s[c] : void 0, p = z(() => {
		if (!o || !f) return null;
		let e = o.bodyShapes.find((e) => e.id === f.bodyShape), t = o.colors.find((e) => e.id === f.color);
		return !e || !t ? null : {
			body: e,
			color: t.hex
		};
	}, [o, f]), [m, h] = V(!1);
	L(() => {
		if (!p || l) return;
		let e = 0, t = requestAnimationFrame(() => {
			e = requestAnimationFrame(() => h(!0));
		});
		return () => {
			cancelAnimationFrame(t), cancelAnimationFrame(e);
		};
	}, [p, l]);
	let g = !!l || m, _ = e.trim(), v = t?.trim() ?? "", y = _ ? a("introductionScreen.greetingNamed", { name: _ }) : a("introductionScreen.greeting"), b = v ? a("introductionScreen.introNamed", { name: v }) : a("introductionScreen.intro"), x = !l && !d && p != null;
	return /* @__PURE__ */ U(Mr, {
		className: "bg-[var(--surface-base)]",
		surface: g ? p?.color : dr,
		surfaceTransition: m ? Zr : void 0,
		children: [
			p && /* @__PURE__ */ H(I.div, {
				className: "absolute inset-0 z-0",
				style: { backgroundColor: p.color },
				initial: l ? !1 : { opacity: 0 },
				animate: { opacity: +!!g },
				transition: l ? { duration: 0 } : Xr
			}),
			p && /* @__PURE__ */ H(Yr, {
				art: p,
				reduce: l === !0
			}),
			p && /* @__PURE__ */ H(jr, { entrance: !0 }),
			/* @__PURE__ */ H(I.div, {
				initial: x ? { opacity: 0 } : !1,
				animate: { opacity: 1 },
				transition: x ? {
					duration: .4,
					delay: 1
				} : { duration: 0 },
				children: /* @__PURE__ */ H(Wr, {
					onBack: r,
					onNext: i
				})
			}),
			/* @__PURE__ */ U("div", {
				className: lr,
				children: [/* @__PURE__ */ U(I.h1, {
					className: "text-center leading-[1.15] max-md:leading-[1.25]",
					style: { fontFamily: "var(--font-serif)" },
					initial: x ? {
						scale: .9,
						opacity: 0
					} : !1,
					animate: {
						scale: 1,
						opacity: 1
					},
					transition: x ? {
						type: "spring",
						stiffness: 260,
						damping: 11,
						delay: 1
					} : { duration: 0 },
					children: [/* @__PURE__ */ H("span", {
						className: "block text-[clamp(2.5rem,6vw,5rem)]",
						style: { color: u.fgDeep },
						children: y
					}), /* @__PURE__ */ H("span", {
						className: "block text-[clamp(2.5rem,6vw,5rem)]",
						style: { color: u.fg },
						children: b
					})]
				}), /* @__PURE__ */ H(I.div, {
					initial: x ? {
						opacity: 0,
						y: 8
					} : !1,
					animate: {
						opacity: 1,
						y: 0
					},
					transition: x ? {
						duration: .4,
						delay: 1.15
					} : { duration: 0 },
					children: /* @__PURE__ */ H(P, {
						type: "button",
						variant: "primary",
						size: "large",
						rightIcon: /* @__PURE__ */ H(W, { size: 16 }),
						onClick: n,
						className: "w-[234px]",
						children: a("actions.continue")
					})
				})]
			})
		]
	});
}
//#endregion
//#region src/components/speech/use-voice-sample-preview.ts
function $r() {
	let [e, t] = V(null), n = B(null), r = B(0), i = () => {
		r.current++, n.current?.pause(), n.current = null, t(null);
	};
	L(() => () => {
		r.current++, n.current?.pause(), n.current = null;
	}, []);
	function a(e) {
		if (!e.sampleUrl) return;
		n.current?.pause();
		let i = ++r.current, a = new Audio(e.sampleUrl);
		n.current = a, t(e.model);
		let o = () => {
			r.current === i && t(null);
		};
		a.onended = o, a.onerror = o, a.play().catch(() => {
			r.current === i && (h.error(oe("useVoiceSamplePreview.playFailed")), t(null));
		});
	}
	return {
		previewingModel: e,
		play: a,
		stop: i
	};
}
//#endregion
//#region src/domains/onboarding/onboarding-avatar-voices.ts
var ei = [
	"EXAVITQu4vr4xnSDxMaL",
	"onwK4e9ZLuTAKqWW03F9",
	"TX3LPaxmHKxFdv7VOQHJ",
	"aura-2-helena-en",
	"pNInz6obpgDQGcFmaJgB",
	"aura-2-luna-en",
	"IKne3meq5aSn9XLyUdCD",
	"aura-2-pandora-en",
	"aura-2-apollo-en",
	"aura-2-thalia-en",
	"Xb7hH8MSUJpSbSDYk0k2",
	"aura-2-theia-en"
];
function ti(e, t) {
	if (t.length === 0) return null;
	let n = ei[e % ei.length];
	return t.find((e) => e.model === n) ?? t[e % t.length] ?? null;
}
//#endregion
//#region src/domains/onboarding/prechat-names.ts
var ni = [
	{
		id: "grounded",
		label: "Grounded",
		descriptor: "Calm and precise",
		tagline: "Measured. No filler.",
		names: [
			"Penn",
			"Sage",
			"Atlas",
			"Orion",
			"Reed",
			"Quill"
		]
	},
	{
		id: "warm",
		label: "Warm",
		descriptor: "Warm and easy",
		tagline: "Friendly and casual.",
		names: [
			"Kit",
			"Remy",
			"Wren",
			"Milo",
			"Fenn",
			"Cleo"
		]
	},
	{
		id: "energetic",
		label: "Energetic",
		descriptor: "Fast and direct",
		tagline: "Brief. To the point.",
		names: [
			"Nova",
			"Ember",
			"Cade",
			"Lark",
			"Vela",
			"Ziggy"
		]
	},
	{
		id: "poetic",
		label: "Poetic",
		descriptor: "Quiet and observant",
		tagline: "Listens, then replies.",
		names: [
			"Luna",
			"Iris",
			"Vesper",
			"Lyra",
			"Juno",
			"Ada"
		]
	}
];
function ri() {
	return ni.flatMap((e) => e.names);
}
function ii(e = {}) {
	let t = ri(), n = e.random ?? Math.random, r = e.exclude ? t.filter((t) => t !== e.exclude) : t, i = r.length > 0 ? r : t;
	return i[Math.floor(n() * i.length)] ?? t[0] ?? "";
}
//#endregion
//#region src/lib/tts/use-cloud-voices.ts
var ai = "/v1/cloud-speech/tts/voices/", oi = O({
	voices: te(O({
		model: k(),
		label: k(),
		description: k(),
		sampleUrl: k(),
		source: k()
	})).optional(),
	defaultModel: k().nullable().optional()
});
function si(e = {}) {
	let t = y({
		queryKey: [
			"cloud-speech",
			"tts",
			"voices"
		],
		queryFn: async () => {
			let e = await ce();
			if (!e.ok) return null;
			let t = await E(ai, oi, { organizationId: e.data });
			return t.ok ? t.data : null;
		},
		enabled: e.enabled ?? !0,
		staleTime: 6e4,
		retry: !1
	});
	return {
		voices: t.data?.voices ?? [],
		defaultModel: t.data?.defaultModel ?? null,
		fetched: t.data != null,
		loading: t.isLoading
	};
}
//#endregion
//#region src/domains/onboarding/screens/give-me-a-face-screen.tsx
function ci(e, t) {
	let n = [];
	for (let r = 0; r < e; r++) r !== t && n.push(r);
	return {
		centerChar: t,
		edgeOrder: n
	};
}
function li({ onContinue: e, onBack: t, initialName: n, onForward: r, canAuditionVoice: i = !0 }) {
	let { t: a } = j("onboarding"), o = Q(), s = $.use.characters(), c = $.use.ensureGenerated(), l = $.use.selectedIndex(), f = $.use.setSelectedIndex(), p = $.use.setCharacterTraits();
	L(() => {
		o && c(o);
	}, [o, c]);
	let m = s.length, h = n?.trim() ?? "", [g, _] = V(null), [v, y] = V(() => h || ii()), [b, x] = V(!1), C = B(h.length > 0), w = B(null), [T, E] = V(null);
	L(() => {
		m > 0 && g === null && _(ci(m, l));
	}, [
		m,
		l,
		g
	]), L(() => {
		g && f(g.centerChar);
	}, [g, f]);
	let D = g?.centerChar;
	L(() => {
		b && (w.current?.focus(), w.current?.select());
	}, [b]);
	let { voices: O, loading: ee } = si({ enabled: i }), k = z(() => D == null ? null : ti(D, O), [D, O]), { previewingModel: te, play: ne, stop: re } = $r(), A = k !== null && te === k.model, ie = !k && ee;
	function ae() {
		if (k) {
			if (A) {
				re();
				return;
			}
			ne(k);
		}
	}
	function oe(e) {
		if (!g || e === g.centerChar) return;
		let t = g.edgeOrder.indexOf(e);
		if (t < 0) return;
		re();
		let n = [...g.edgeOrder];
		n[t] = g.centerChar, E({
			entering: {
				char: e,
				fromSlot: t
			},
			exiting: {
				char: g.centerChar,
				toSlot: t
			}
		}), _({
			centerChar: e,
			edgeOrder: n
		});
	}
	let se = () => g && oe((g.centerChar + 1) % m), ce = () => g && oe((g.centerChar - 1 + m) % m), M = z(() => g ? s[g.centerChar] : void 0, [g, s]), le = !!o && !!g && !!M;
	function N() {
		M && e({
			traits: M,
			name: v.trim(),
			voiceModel: k?.model ?? null,
			naming: { source: C.current ? "custom" : "randomized" }
		});
	}
	function ue() {
		if (C.current = !0, y((e) => ii({ exclude: e })), o && g && M) {
			let e = ye(o);
			for (; e.bodyShape === M.bodyShape && e.eyeStyle === M.eyeStyle && e.color === M.color;) e = ye(o);
			p(g.centerChar, e);
		}
	}
	let de = "pointer-events-auto z-10 flex cursor-pointer h-10 w-10 items-center justify-center rounded-full bg-[color-mix(in_srgb,var(--content-default)_10%,transparent)] text-[var(--content-default)] transition-colors duration-150 hover:bg-[color-mix(in_srgb,var(--content-default)_18%,transparent)]";
	return /* @__PURE__ */ U(Mr, {
		className: "bg-[var(--surface-base)] text-[var(--content-default)]",
		children: [
			le && /* @__PURE__ */ H(ar, {
				components: o,
				characters: s,
				centerChar: g.centerChar,
				edgeOrder: g.edgeOrder,
				entering: T?.entering ?? null,
				exiting: T?.exiting ?? null,
				onEnterComplete: (e) => E((t) => t?.entering.char === e ? null : t),
				onSelectChar: oe
			}),
			/* @__PURE__ */ H(Wr, {
				tone: "light",
				onBack: t,
				onNext: r ? N : void 0
			}),
			/* @__PURE__ */ H("h1", {
				className: "absolute left-1/2 top-[22%] z-10 -translate-x-1/2 whitespace-nowrap text-center text-[2.6rem] leading-none max-md:w-[90vw] max-md:whitespace-normal max-md:text-[2.08rem]",
				style: {
					fontFamily: "var(--font-serif)",
					animation: "fadeInUp 0.4s ease-out both"
				},
				children: a("giveMeAFaceScreen.title")
			}),
			/* @__PURE__ */ H("button", {
				type: "button",
				"aria-label": a("giveMeAFaceScreen.previousCharacter"),
				onClick: ce,
				className: `absolute left-[calc(50%-170px)] top-[43%] -translate-y-1/2 ${de}`,
				children: /* @__PURE__ */ H(d, { className: "h-4 w-4" })
			}),
			/* @__PURE__ */ H("button", {
				type: "button",
				"aria-label": a("giveMeAFaceScreen.nextCharacter"),
				onClick: se,
				className: `absolute right-[calc(50%-170px)] top-[43%] -translate-y-1/2 ${de}`,
				children: /* @__PURE__ */ H(W, { className: "h-4 w-4" })
			}),
			/* @__PURE__ */ U("div", {
				className: "absolute left-1/2 top-[58%] z-10 flex -translate-x-1/2 flex-col items-center gap-10 max-md:top-[54%]",
				children: [/* @__PURE__ */ U("div", {
					className: "flex flex-col items-center gap-4",
					children: [b ? /* @__PURE__ */ H("input", {
						ref: w,
						value: v,
						onChange: (e) => {
							C.current = !0, y(e.target.value);
						},
						onBlur: () => x(!1),
						onKeyDown: (e) => {
							e.key === "Enter" && (e.preventDefault(), x(!1));
						},
						placeholder: a("giveMeAFaceScreen.namePlaceholder"),
						"aria-label": a("giveMeAFaceScreen.nameAriaLabel"),
						className: "w-[234px] rounded-2xl border border-[var(--border-element)] bg-transparent px-4 py-2.5 text-center text-lg text-[var(--content-default)] placeholder:text-[var(--content-tertiary)] outline-none transition-colors duration-150 focus:border-[var(--border-active)]"
					}) : /* @__PURE__ */ U("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ U("button", {
							type: "button",
							onClick: () => x(!0),
							"aria-label": a("giveMeAFaceScreen.editName"),
							className: "flex cursor-pointer items-center gap-2.5",
							children: [/* @__PURE__ */ H("span", {
								className: `text-2xl font-medium ${v ? "text-[var(--content-default)]" : "text-[var(--content-tertiary)]"}`,
								children: v || a("giveMeAFaceScreen.namePlaceholder")
							}), /* @__PURE__ */ H(Ue, { className: "h-5 w-5 text-[var(--content-tertiary)]" })]
						}), /* @__PURE__ */ H("button", {
							type: "button",
							onClick: ue,
							"aria-label": a("giveMeAFaceScreen.shuffle"),
							title: a("giveMeAFaceScreen.shuffle"),
							className: "cursor-pointer text-[var(--content-tertiary)] transition-[transform,color] duration-300 hover:rotate-180 hover:text-[var(--content-default)]",
							children: /* @__PURE__ */ H(He, { className: "h-5 w-5" })
						})]
					}), i && /* @__PURE__ */ U("button", {
						type: "button",
						onClick: ae,
						disabled: !k,
						title: a("giveMeAFaceScreen.hearVoice"),
						"aria-label": a(A ? "giveMeAFaceScreen.stopVoice" : "giveMeAFaceScreen.hearVoice"),
						"aria-busy": ie,
						className: `flex cursor-pointer items-center gap-2 rounded-full border border-[color-mix(in_srgb,var(--content-default)_22%,transparent)] px-4 py-2 text-sm text-[var(--content-default)] transition-colors duration-150 hover:bg-[color-mix(in_srgb,var(--content-default)_10%,transparent)] disabled:cursor-default ${ie ? "disabled:opacity-70" : "disabled:opacity-40"}`,
						children: [ie ? /* @__PURE__ */ H(u, { className: "h-4 w-4 animate-spin" }) : H(A ? S : We, { className: "h-4 w-4" }), a("giveMeAFaceScreen.hearVoice")]
					})]
				}), /* @__PURE__ */ H(P, {
					type: "button",
					variant: "primary",
					size: "large",
					rightIcon: /* @__PURE__ */ H(W, { size: 16 }),
					disabled: !le,
					onClick: N,
					className: "w-[234px]",
					children: a("actions.continue")
				})]
			})
		]
	});
}
//#endregion
//#region src/domains/onboarding/pages/onboarding-flow-route.tsx
async function ui(e, t) {
	if (!t) return;
	let n = await ce();
	n.ok && await D(`/v1/assistants/${encodeURIComponent(e)}/config`, ee(), { services: { tts: { providers: { cadet: { model: t } } } } }, { organizationId: n.data }).catch(() => void 0);
}
function di() {
	let e = t(), n = N(s().state)?.id, [r, i] = V("form"), [a, o] = V(null), [c, l] = V(null);
	function u() {
		i((e) => e === "face" ? "intro" : e === "intro" ? "form" : e);
	}
	function d() {
		if (!a) return;
		let t = a.firstName.trim(), r = c?.name.trim() || void 0;
		pt({
			tools: [],
			tasks: [],
			tone: "grounded",
			...t ? { userName: t } : {},
			initialMessage: ut(r),
			initialMessageHidden: !0,
			...r ? { assistantName: r } : {}
		}), r && ht(r), n && (Ct(n), c && ge(n, c.traits).then(() => ui(n, c.voiceModel))), e(`${F.assistant}?onboarding=1`, { replace: !0 });
	}
	return r === "form" ? /* @__PURE__ */ H(hn, {
		avatarWave: "none",
		children: /* @__PURE__ */ H(_r, {
			onSubmit: (e) => {
				o(e), i("intro");
			},
			onSkip: () => {
				n && Ct(n), e(F.assistant, { replace: !0 });
			}
		})
	}) : r === "intro" && a ? /* @__PURE__ */ H(hn, {
		avatarWave: "none",
		children: /* @__PURE__ */ H(Qr, {
			firstName: a.firstName.trim(),
			assistantName: c?.name.trim() || void 0,
			onContinue: () => i("face"),
			onBack: u
		})
	}) : r === "face" && a ? /* @__PURE__ */ H(hn, {
		avatarWave: "none",
		children: /* @__PURE__ */ H(li, {
			initialName: c?.name,
			onContinue: (e) => {
				l(e), d();
			},
			onBack: u
		})
	}) : null;
}
//#endregion
//#region src/domains/consent/consent-route.tsx
var fi = {
	path: "/account/consent",
	ErrorBoundary: G,
	HydrateFallback: K,
	lazy: { Component: () => import("./review-terms-screen-kPBT942K.js").then((e) => e.ReviewTermsScreen) }
};
//#endregion
//#region src/assistant/use-assistant-request.ts
function pi({ apiBaseUrl: e = "/", assistantId: t }) {
	let [n, r] = V(0), i = JSON.stringify([
		e,
		t,
		n
	]), [a, o] = V();
	return L(() => {
		let n = new AbortController(), r = (e) => o({
			key: i,
			state: e
		});
		r({ status: "loading" });
		let a = window.location.origin, s = setTimeout(() => {
			console.error(`Assistant request timed out after 10s (apiBaseUrl ${e}, origin ${a}, assistantId ${t ?? "none"})`), n.abort(), r({ status: "error" });
		}, 1e4);
		return Promise.resolve().then(() => {
			if (!n.signal.aborted) return Ne({
				apiBaseUrl: e,
				assistantId: t,
				signal: n.signal
			});
		}).then((e) => {
			if (n.signal.aborted) return;
			clearTimeout(s);
			let t = Me.safeParse(e);
			if (!t.success) {
				console.error("Assistant resolution did not match the contract:", t.error.message), r({ status: "error" });
				return;
			}
			r(t.data);
		}, (i) => {
			n.signal.aborted || (console.error(`Assistant request failed: ${Ae(i)} (apiBaseUrl ${e}, origin ${a}, assistantId ${t ?? "none"})`), clearTimeout(s), r({ status: "error" }));
		}), () => {
			clearTimeout(s), n.abort();
		};
	}, [
		e,
		t,
		n,
		i
	]), {
		state: a?.key === i ? a.state : { status: "loading" },
		retry: () => r((e) => e + 1)
	};
}
//#endregion
//#region src/runtime/assistant-status.ts
function mi(e) {
	if (e.status === "error") return "error";
	switch (e.status) {
		case "unauthenticated": return "authFailed";
		case "ready": return "idle";
		default: return "disconnected";
	}
}
function hi(e) {
	T()?.status?.setConnection(e);
}
//#endregion
//#region src/hooks/use-electron-status-sync.ts
function gi(e) {
	L(() => {
		hi(mi(e));
	}, [e]), L(() => () => hi("disconnected"), []);
}
//#endregion
//#region src/shell/assistant-frame.tsx
var _i = "/web";
function vi(e) {
	return new URL(`${_i}${e ?? `${location.pathname}${location.search}${location.hash}`}`, window.location.origin).href;
}
function yi({ onNavigate: e, title: t, path: n }) {
	let r = B(null), [i] = V(() => vi(n)), a = B(i), o = z(() => window.location.origin, []);
	return L(() => {
		let t = (t) => {
			if (t.source !== r.current?.contentWindow || t.origin !== o) return;
			let n = Pe.safeParse(t.data);
			if (!n.success) return;
			let i = n.data.path;
			i !== a.current && (!i.startsWith(`${_i}/`) || i.includes("\\") || i.split(/[?#]/)[0].split("/").some((e) => e === "." || e === "..") || (a.current = i, e(i.slice(4) || "/", { replace: n.data.nav === "replace" })));
		};
		return window.addEventListener("message", t), () => window.removeEventListener("message", t);
	}, [o, e]), L(() => {
		let t = (t) => {
			if (t.source !== r.current?.contentWindow || t.origin !== o) return;
			let n = je.safeParse(t.data);
			if (!n.success) return;
			let i = n.data.path;
			!i.startsWith("/account/") || i.includes("\\") || e(i, { replace: !1 });
		};
		return window.addEventListener("message", t), () => window.removeEventListener("message", t);
	}, [o, e]), L(() => {
		let e = vi(n);
		e !== a.current && (a.current = e, r.current?.contentWindow?.postMessage({
			source: "mycadet-web-parent-nav",
			path: e
		}, o));
	}, [n, o]), /* @__PURE__ */ H("iframe", {
		ref: r,
		src: i,
		onLoad: () => r.current?.contentWindow?.postMessage({
			source: "mycadet-web-parent-nav",
			path: a.current
		}, o),
		title: t,
		sandbox: "allow-scripts allow-same-origin allow-forms allow-popups",
		allow: "microphone; camera; clipboard-write",
		style: {
			width: "100%",
			height: "100%",
			minHeight: "100dvh",
			border: 0
		}
	});
}
//#endregion
//#region src/app-shell.tsx
function bi(e) {
	return /* @__PURE__ */ H(ie, { children: /* @__PURE__ */ H(wi, { ...e }, e.assistantId) });
}
var xi = {
	borderRadius: 8,
	border: "none",
	padding: "10px 20px",
	fontSize: 14,
	fontWeight: 600,
	background: "var(--primary-base, #FDFDFC)",
	color: "var(--content-inset, #17191C)",
	cursor: "pointer"
}, Si = {
	borderRadius: 8,
	border: "1px solid var(--content-tertiary, #8D99A5)",
	padding: "8px 16px",
	fontSize: 13,
	background: "transparent",
	color: "inherit",
	cursor: "pointer"
};
function Ci(e) {
	return typeof e != "object" || !e ? null : "reason" in e && typeof e.reason == "string" ? e.reason : "detail" in e && typeof e.detail == "string" ? e.detail : null;
}
function wi({ apiBaseUrl: e = "/", framePath: t, assistantId: n, onNavigate: r, title: i }) {
	let { t: a } = j("account"), [o, s] = V(!1), [c, l] = V(null), { state: u, retry: d } = pi({
		apiBaseUrl: e,
		assistantId: n
	});
	gi(u);
	let f = u.status === "selection" || u.status === "empty", p = B(!1);
	L(() => {
		f && !p.current && (p.current = !0, r(F.account.selectAssistant, { replace: !0 }));
	}, [f, r]);
	async function m() {
		if (!(!n || o)) {
			s(!0), l(null);
			try {
				let t = new URL(e, window.location.origin);
				t.pathname = t.pathname.replace(/\/*$/, "/");
				let r = await fetch(new URL(`v1/assistants/${encodeURIComponent(n)}/wake/`, t), {
					method: "POST",
					credentials: "include"
				});
				if (r.ok) {
					s(!1), d();
					return;
				}
				l(Ci(await r.json().catch(() => null)) ?? a("appShell.wakeFailed"));
			} catch {
				l(a("appShell.wakeFailed"));
			}
			s(!1);
		}
	}
	if (u.status === "unauthenticated") return /* @__PURE__ */ H(Ei, { onNavigate: r });
	if (u.status !== "ready") return /* @__PURE__ */ U("div", {
		role: u.status === "notReady" || u.status === "error" ? "alert" : "status",
		style: {
			minHeight: "100svh",
			display: "flex",
			flexDirection: "column",
			alignItems: "center",
			justifyContent: "center",
			gap: 12,
			padding: 24,
			textAlign: "center"
		},
		children: [u.status === "notReady" ? /* @__PURE__ */ H(Ti, {
			wakePending: o,
			wakeReason: c,
			onWake: m
		}) : u.status === "error" ? /* @__PURE__ */ H(Di, {}) : /* @__PURE__ */ H("p", {
			style: { margin: 0 },
			children: a(`appShell.${u.status}`)
		}), (u.status === "error" || u.status === "unavailable") && /* @__PURE__ */ U("div", {
			style: {
				display: "flex",
				gap: 8
			},
			children: [/* @__PURE__ */ H("button", {
				type: "button",
				onClick: d,
				style: Si,
				children: a("appShell.retry")
			}), /* @__PURE__ */ H("button", {
				type: "button",
				onClick: () => r(F.account.selectAssistant, { replace: !1 }),
				style: Si,
				children: a("appShell.switchAssistant")
			})]
		})]
	});
	let h = u.assistant;
	return /* @__PURE__ */ H(yi, {
		path: t,
		onNavigate: r,
		title: i ?? a("appShell.title")
	}, `${h.id}:${h.version}`);
}
function Ti({ wakePending: e, wakeReason: t, onWake: n }) {
	let { t: r } = j("account");
	return /* @__PURE__ */ U(Ve, { children: [
		/* @__PURE__ */ H(p, {
			size: 28,
			"aria-hidden": "true"
		}),
		/* @__PURE__ */ H("h1", {
			style: {
				margin: 0,
				fontSize: 20,
				fontWeight: 600
			},
			children: r("appShell.notReadyTitle")
		}),
		/* @__PURE__ */ H("p", {
			style: {
				margin: 0,
				maxWidth: 420,
				opacity: .7,
				lineHeight: 1.5
			},
			children: r("appShell.notReadyBody")
		}),
		t !== null && /* @__PURE__ */ H("p", {
			style: {
				margin: 0,
				maxWidth: 420,
				fontSize: 13,
				opacity: .6,
				lineHeight: 1.5
			},
			children: t
		}),
		/* @__PURE__ */ H("button", {
			type: "button",
			onClick: n,
			disabled: e,
			style: {
				...xi,
				opacity: e ? .6 : 1
			},
			children: r(e ? "appShell.waking" : "appShell.wake")
		})
	] });
}
function Ei({ onNavigate: e }) {
	let t = B(!1);
	return L(() => {
		t.current || (t.current = !0, e(F.account.pair, { replace: !0 }));
	}, [e]), null;
}
function Di() {
	let { t: e } = j("account");
	return /* @__PURE__ */ U(Ve, { children: [
		/* @__PURE__ */ H(p, {
			size: 28,
			"aria-hidden": "true"
		}),
		/* @__PURE__ */ H("h1", {
			style: {
				margin: 0,
				fontSize: 20,
				fontWeight: 600
			},
			children: e("appShell.errorTitle")
		}),
		/* @__PURE__ */ H("p", {
			style: {
				margin: 0,
				maxWidth: 420,
				opacity: .7,
				lineHeight: 1.5
			},
			children: e("appShell.errorBody")
		})
	] });
}
//#endregion
//#region src/domains/consent/use-consent-gate.ts
function Oi() {
	let e = Fe.use.user(), t = Fe((e) => `${e.sessionStatus}:${e.cloudSession}`);
	return z(() => {
		let [n, r] = t.split(":"), i = n !== "initializing" && r !== "unknown", a = r === "present", o = e?.id ?? null;
		return {
			settled: i,
			hasCloudSession: a,
			userId: o,
			currency: i && a && o ? Ie(o) : null
		};
	}, [t, e?.id]);
}
//#endregion
//#region src/shell/assistant-page.tsx
function ki() {
	j();
	let e = s(), n = t(), r = N(e.state), a = Oi();
	if (a.settled && a.hasCloudSession && (!a.currency?.hasConsentRecord || !a.currency.tos || !a.currency.privacy)) {
		let t = encodeURIComponent(`${e.pathname}${e.search}${e.hash}`);
		return /* @__PURE__ */ H(i, {
			to: `${F.account.consent}?returnTo=${t}`,
			replace: !0
		});
	}
	return /* @__PURE__ */ H(bi, {
		framePath: `${e.pathname}${e.search}${e.hash}`,
		assistantId: r?.id,
		apiBaseUrl: r?.apiBase,
		onNavigate: (t, r) => {
			n(t, {
				...r,
				state: e.state
			});
		}
	});
}
//#endregion
//#region src/standalone.tsx
function Ai() {
	let [e, n] = V(!1), [r, i] = V(null), [a, c] = V(!1), [l, u] = V(null), d = t(), p = s(), { t: _ } = j("account"), v = (e) => {
		(async () => {
			let t = await M(), n = t.ok ? t.data.find((t) => t.id === e) : void 0;
			if (n) {
				d(F.assistant, { state: fe(n.id) });
				return;
			}
			h.error(_("appShell.assistantSwitchFailed")), d(F.account.selectAssistant);
		})();
	};
	Je({
		createAssistant: () => n(!0),
		selectAssistant: (e) => {
			e.kind === "selectAssistant" && v(e.assistantId);
		},
		retireAssistant: (e) => {
			e.kind === "retireAssistant" && i(e.assistantId);
		},
		rePair: () => {
			let e = N(p.state)?.id;
			e && v(e);
		}
	});
	let y = async () => {
		if (!r || a) return;
		c(!0), u(null);
		let e = await m(r);
		if (c(!1), !e.ok) {
			u(e.error || "Failed to retire assistant.");
			return;
		}
		i(null), d(F.account.selectAssistant);
	};
	return et(), /* @__PURE__ */ U(Ve, { children: [
		/* @__PURE__ */ H(Ke, {
			open: e,
			onClose: () => n(!1)
		}),
		/* @__PURE__ */ H(g, {}),
		/* @__PURE__ */ H(f, {
			open: r !== null,
			error: l,
			isPending: a,
			onConfirm: () => void y(),
			onCancel: () => {
				a || (i(null), u(null));
			}
		}),
		/* @__PURE__ */ H(o, {})
	] });
}
function ji(t = "/") {
	return e([{
		Component: Ai,
		ErrorBoundary: G,
		HydrateFallback: K,
		children: [
			st,
			fi,
			{
				path: "/about",
				HydrateFallback: K,
				lazy: { Component: () => import("./about-page-DLNNvHiz.js").then((e) => e.AboutPage) }
			},
			{
				path: "/",
				lazy: { Component: () => import("./welcome-screen-GVhovLHS.js").then((e) => e.WelcomeScreen) }
			},
			{
				path: F.onboarding.research,
				Component: di
			},
			{
				path: "/assistant/*",
				Component: ki
			},
			{
				path: "/logout",
				lazy: { Component: () => import("./logout-page-CrgAsb0n.js").then((e) => e.LogoutPage) }
			}
		]
	}], {
		basename: t,
		future: { v8_middleware: !0 }
	});
}
//#endregion
//#region src/embedded.tsx
function Mi({ basename: e = "/" }) {
	let [t, n] = V();
	return L(() => {
		let t = !0, r;
		return ae().then(() => {
			t && (r = ji(e), n(r));
		}), () => {
			t = !1, r?.dispose();
		};
	}, [e]), t ? /* @__PURE__ */ H(r, { router: t }) : null;
}
//#endregion
export { Mi as EmbeddedApp };
