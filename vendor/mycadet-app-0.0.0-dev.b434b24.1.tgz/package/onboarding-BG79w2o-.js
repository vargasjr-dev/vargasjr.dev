//#region src/i18n/locales/ru/onboarding.json
var e = {
	continue: "Продолжить",
	back: "Назад",
	forward: "Вперёд",
	cancel: "Отмена",
	add: "Добавить",
	adding: "Добавление…",
	tryAgain: "Попробовать снова",
	remove: "Убрать {value}",
	downloadMacOSApp: "Скачать приложение для macOS",
	downloadWindowsApp: "Скачать приложение для Windows",
	claim: "Забрать"
}, t = {
	addOption: "Добавить «{value}»",
	enterHint: "↵ Enter",
	freeTextHint: "Ввод своего варианта и ↵, чтобы добавить"
}, n = { ariaLabel: "Шаг {current} из {total}" }, r = {
	greetingNamed: "Привет, {name}!",
	greeting: "Привет!",
	introNamed: "Я {name}, новый ИИ-ассистент.",
	intro: "Я новый ИИ-ассистент."
}, i = {
	setupLine: "ИИ, который только отвечает на вопросы, уже знаком.",
	helpLine: "Чем больше я помогаю,",
	punchLine: "Я другой.",
	betterLine: "тем лучше я становлюсь,",
	lessLine: "и тем меньше работы остаётся."
}, a = {
	title: "Создание характера",
	lockedBody: "Характер зафиксирован; чтобы что-то ещё поменять, сообщение ассистенту",
	axisAriaLabel: "От {left} до {right}",
	axes: {
		companionCoworker: {
			left: "Компаньон",
			right: "Коллега"
		},
		genzBoomer: {
			left: "Gen Z",
			right: "Baby Boomer"
		},
		executeCollaborate: {
			left: "Самостоятельный",
			right: "Совместный"
		},
		playfulSerious: {
			left: "Игривый",
			right: "Серьёзный"
		},
		politeUnfiltered: {
			left: "Вежливый",
			right: "Без фильтра"
		}
	}
}, o = {
	title: "Лицо и имя",
	previousCharacter: "Предыдущий персонаж",
	nextCharacter: "Следующий персонаж",
	namePlaceholder: "Как зовут ассистента",
	nameAriaLabel: "Имя ассистента",
	editName: "Изменить имя",
	shuffle: "Случайные имя и внешность",
	hearVoice: "Послушай мой голос",
	stopVoice: "Остановить образец голоса"
}, s = { title: "Вот начальный объём использования,<br></br> чтобы начать." }, c = {
	title: "Начало.",
	firstNameLabel: "Имя",
	firstNamePlaceholder: "Имя",
	skip: "Пропустить настройку"
}, l = {
	titleNamed: "{name} уже запущен и работает",
	title: "Ассистент уже запущен и работает",
	bodyNamed: "Общая история уже есть: характер, воспоминания и прошлые диалоги. Повторная настройка перезапишет то, кем сейчас является {name}.",
	body: "Уже есть общая история: характер, воспоминания и прошлые диалоги. Повторная настройка перезапишет то, кем сейчас является ассистент.",
	keepNamed: "Оставить {name} и начать диалог",
	keep: "Оставить ассистента и начать диалог",
	redoNamed: "Начать заново и собрать характер {name} снова",
	redo: "Начать заново и собрать характер заново"
}, u = {
	searching: "Поиск в интернете…",
	readingProfiles: "Читаю публичные профили…",
	skimming: "Просматриваю главное…",
	connectingDots: "Соединяю точки…",
	piecing: "Собираю картину…",
	almostThere: "Почти готово…"
}, d = {
	updatingPersonality: "Обновляю характер…",
	findingVoice: "Ищу свой голос…",
	gettingIntoCharacter: "Вхожу в роль…",
	almostThere: "Почти готово…"
}, f = {
	title: "Вот что удалось найти",
	bodyLoadingWithClaims: "Ещё проверяю остальное. Просмотр по мере появления.",
	bodyReadyWithClaims: "Я поискал в интернете. Смело убирай всё, что неправда.",
	bodyLoadingEmpty: "Ещё собираю это вместе…",
	removeClaim: "Убрать «{claim}»",
	notMe: "Это не я",
	stillSearching: "Ещё ищу…"
}, p = {
	title: "Вот с чего можно начать",
	pickOne: "Выбор одного, чтобы сразу включиться, или своё начало. <skip>Перейти к диалогу</skip>",
	loading: "Собираю несколько идей…",
	alreadySetUp: "Уже настроен {count, plural, one {плагин} few {плагина} many {плагинов} other {плагина}} <plugins></plugins> для работы",
	listAnd: " и ",
	listCommaAnd: " и ",
	listComma: ", ",
	fallbacks: {
		brief: {
			suggestion: "Соберу короткий бриф о новостях в этой сфере",
			prompt: "Сделай короткий бриф: что нового в моей сфере прямо сейчас."
		},
		weekly: {
			suggestion: "Буду присылать еженедельный бриф по новостям в этой области",
			prompt: "Настройка еженедельного брифа по новостям в моей области."
		},
		week: {
			suggestion: "Помогу взять неделю под контроль",
			prompt: "Помоги взять мою неделю под контроль."
		},
		draft: {
			suggestion: "Набросаю текст по нескольким черновым заметкам",
			prompt: "Набросай текст по нескольким черновым заметкам, которые я дам."
		}
	}
}, m = {
	genericFailure: "Что-то пошло не так. Повторите попытку.",
	signupClosed: "К сожалению, Cadet сейчас не принимает новые регистрации. Попробуйте снова позже.",
	providerSignup: "К этому входу ещё не привязан аккаунт Cadet. Сначала регистрация, потом вход.",
	loginIncomplete: "Чтобы закончить вход, аккаунту нужен ещё один шаг. Войдите в веб-версию и повторите попытку.",
	desktopUpdateRequired: "Эта версия приложения Cadet для компьютера не может войти. Обновите приложение и повторите попытку."
}, h = {
	genericFailure: "Что-то пошло не так",
	localFallbackPitch: "Начало сегодня с локальным ассистентом"
}, g = {
	actions: e,
	onboardingAutocomplete: t,
	stepIndicator: n,
	introductionScreen: r,
	pitchStep: i,
	createPersonalityStep: a,
	giveMeAFaceScreen: o,
	integrationStep: s,
	researchOnboardingScreen: c,
	existingAssistantStep: l,
	lookingYouUpStep: u,
	finishingUpStep: d,
	researchResultsStep: f,
	suggestionsStep: p,
	authErrors: m,
	hatchingScreen: h
};
//#endregion
export { e as actions, m as authErrors, a as createPersonalityStep, g as default, l as existingAssistantStep, d as finishingUpStep, o as giveMeAFaceScreen, h as hatchingScreen, s as integrationStep, r as introductionScreen, u as lookingYouUpStep, t as onboardingAutocomplete, i as pitchStep, c as researchOnboardingScreen, f as researchResultsStep, n as stepIndicator, p as suggestionsStep };
