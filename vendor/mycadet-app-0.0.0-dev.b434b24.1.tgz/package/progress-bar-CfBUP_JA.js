import { o as e } from "./dist-CB0DYkRa.js";
import { jsx as t } from "react/jsx-runtime";
//#region ../../packages/design-library/src/components/progress-bar.tsx
function n(e) {
	return Number.isNaN(e) || e < 0 ? 0 : e > 1 ? 1 : e;
}
function r({ value: r, "aria-label": i, className: a, fillColor: o, height: s = 6, ref: c }) {
	let l = r == null ? null : n(r) * 100;
	return /* @__PURE__ */ t("div", {
		ref: c,
		role: "progressbar",
		"aria-label": i,
		"aria-valuenow": l == null ? void 0 : Math.round(l),
		"aria-valuemin": 0,
		"aria-valuemax": 100,
		"data-slot": "progress-bar",
		className: e("rounded-full overflow-hidden bg-[var(--surface-lift)]", a),
		style: { height: s },
		children: l == null ? /* @__PURE__ */ t("div", {
			"data-slot": "progress-bar-fill",
			className: "h-full w-2/5 bg-[var(--content-default)] rounded-full motion-safe:animate-progress-indeterminate motion-reduce:w-full motion-reduce:opacity-40",
			style: { backgroundColor: o }
		}) : /* @__PURE__ */ t("div", {
			"data-slot": "progress-bar-fill",
			className: "h-full bg-[var(--content-default)] rounded-full",
			style: {
				width: `${l}%`,
				backgroundColor: o,
				transition: "width 400ms cubic-bezier(0.22, 1, 0.36, 1)"
			}
		})
	});
}
//#endregion
export { r as t };
