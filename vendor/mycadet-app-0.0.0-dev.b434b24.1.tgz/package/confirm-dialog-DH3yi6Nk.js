import { n as e } from "./loader-circle-Ch7lYSrj.js";
import { n as t, t as n } from "./circle-check-CBLio8rp.js";
import { o as r } from "./dist-CB0DYkRa.js";
import { A as i, C as a, E as o, O as s, S as c, T as l, a as u, i as d, j as f, k as p, o as m, s as ee, t as h, w as g } from "./button-BrPHE1Q9.js";
import { t as _ } from "./typography-DAhYh88V.js";
import { n as v, t as te } from "./es2015-B_BDkut6.js";
import * as y from "react";
import b, { createContext as x, useContext as S, useRef as C } from "react";
import ne from "react-dom";
import { Fragment as w, jsx as T, jsxs as E } from "react/jsx-runtime";
var D = e("info", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M12 16v-4",
		key: "1dtifu"
	}],
	["path", {
		d: "M12 8h.01",
		key: "e9boi3"
	}]
]), O = e("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), k = e("x", [["path", {
	d: "M18 6 6 18",
	key: "1bl5f8"
}], ["path", {
	d: "m6 6 12 12",
	key: "d8bk6v"
}]]);
//#endregion
//#region ../../node_modules/.bun/sonner@2.0.7+d0e719b86e9808b5/node_modules/sonner/dist/index.mjs
function A(e) {
	if (!e || typeof document > "u") return;
	let t = document.head || document.getElementsByTagName("head")[0], n = document.createElement("style");
	n.type = "text/css", t.appendChild(n), n.styleSheet ? n.styleSheet.cssText = e : n.appendChild(document.createTextNode(e));
}
var j = (e) => {
	switch (e) {
		case "success": return N;
		case "info": return F;
		case "warning": return P;
		case "error": return ie;
		default: return null;
	}
}, M = Array(12).fill(0), re = ({ visible: e, className: t }) => /* @__PURE__ */ b.createElement("div", {
	className: ["sonner-loading-wrapper", t].filter(Boolean).join(" "),
	"data-visible": e
}, /* @__PURE__ */ b.createElement("div", { className: "sonner-spinner" }, M.map((e, t) => /* @__PURE__ */ b.createElement("div", {
	className: "sonner-loading-bar",
	key: `spinner-bar-${t}`
})))), N = /* @__PURE__ */ b.createElement("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 20 20",
	fill: "currentColor",
	height: "20",
	width: "20"
}, /* @__PURE__ */ b.createElement("path", {
	fillRule: "evenodd",
	d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z",
	clipRule: "evenodd"
})), P = /* @__PURE__ */ b.createElement("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 24 24",
	fill: "currentColor",
	height: "20",
	width: "20"
}, /* @__PURE__ */ b.createElement("path", {
	fillRule: "evenodd",
	d: "M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003zM12 8.25a.75.75 0 01.75.75v3.75a.75.75 0 01-1.5 0V9a.75.75 0 01.75-.75zm0 8.25a.75.75 0 100-1.5.75.75 0 000 1.5z",
	clipRule: "evenodd"
})), F = /* @__PURE__ */ b.createElement("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 20 20",
	fill: "currentColor",
	height: "20",
	width: "20"
}, /* @__PURE__ */ b.createElement("path", {
	fillRule: "evenodd",
	d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z",
	clipRule: "evenodd"
})), ie = /* @__PURE__ */ b.createElement("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	viewBox: "0 0 20 20",
	fill: "currentColor",
	height: "20",
	width: "20"
}, /* @__PURE__ */ b.createElement("path", {
	fillRule: "evenodd",
	d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-5a.75.75 0 01.75.75v4.5a.75.75 0 01-1.5 0v-4.5A.75.75 0 0110 5zm0 10a1 1 0 100-2 1 1 0 000 2z",
	clipRule: "evenodd"
})), ae = /* @__PURE__ */ b.createElement("svg", {
	xmlns: "http://www.w3.org/2000/svg",
	width: "12",
	height: "12",
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: "1.5",
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, /* @__PURE__ */ b.createElement("line", {
	x1: "18",
	y1: "6",
	x2: "6",
	y2: "18"
}), /* @__PURE__ */ b.createElement("line", {
	x1: "6",
	y1: "6",
	x2: "18",
	y2: "18"
})), oe = () => {
	let [e, t] = b.useState(document.hidden);
	return b.useEffect(() => {
		let e = () => {
			t(document.hidden);
		};
		return document.addEventListener("visibilitychange", e), () => window.removeEventListener("visibilitychange", e);
	}, []), e;
}, I = 1, L = new class {
	constructor() {
		this.subscribe = (e) => (this.subscribers.push(e), () => {
			let t = this.subscribers.indexOf(e);
			this.subscribers.splice(t, 1);
		}), this.publish = (e) => {
			this.subscribers.forEach((t) => t(e));
		}, this.addToast = (e) => {
			this.publish(e), this.toasts = [...this.toasts, e];
		}, this.create = (e) => {
			let { message: t, ...n } = e, r = typeof e?.id == "number" || e.id?.length > 0 ? e.id : I++, i = this.toasts.find((e) => e.id === r), a = e.dismissible === void 0 ? !0 : e.dismissible;
			return this.dismissedToasts.has(r) && this.dismissedToasts.delete(r), i ? this.toasts = this.toasts.map((n) => n.id === r ? (this.publish({
				...n,
				...e,
				id: r,
				title: t
			}), {
				...n,
				...e,
				id: r,
				dismissible: a,
				title: t
			}) : n) : this.addToast({
				title: t,
				...n,
				dismissible: a,
				id: r
			}), r;
		}, this.dismiss = (e) => (e ? (this.dismissedToasts.add(e), requestAnimationFrame(() => this.subscribers.forEach((t) => t({
			id: e,
			dismiss: !0
		})))) : this.toasts.forEach((e) => {
			this.subscribers.forEach((t) => t({
				id: e.id,
				dismiss: !0
			}));
		}), e), this.message = (e, t) => this.create({
			...t,
			message: e
		}), this.error = (e, t) => this.create({
			...t,
			message: e,
			type: "error"
		}), this.success = (e, t) => this.create({
			...t,
			type: "success",
			message: e
		}), this.info = (e, t) => this.create({
			...t,
			type: "info",
			message: e
		}), this.warning = (e, t) => this.create({
			...t,
			type: "warning",
			message: e
		}), this.loading = (e, t) => this.create({
			...t,
			type: "loading",
			message: e
		}), this.promise = (e, t) => {
			if (!t) return;
			let n;
			t.loading !== void 0 && (n = this.create({
				...t,
				promise: e,
				type: "loading",
				message: t.loading,
				description: typeof t.description == "function" ? void 0 : t.description
			}));
			let r = Promise.resolve(e instanceof Function ? e() : e), i = n !== void 0, a, o = r.then(async (e) => {
				if (a = ["resolve", e], b.isValidElement(e)) i = !1, this.create({
					id: n,
					type: "default",
					message: e
				});
				else if (ce(e) && !e.ok) {
					i = !1;
					let r = typeof t.error == "function" ? await t.error(`HTTP error! status: ${e.status}`) : t.error, a = typeof t.description == "function" ? await t.description(`HTTP error! status: ${e.status}`) : t.description, o = typeof r == "object" && !b.isValidElement(r) ? r : { message: r };
					this.create({
						id: n,
						type: "error",
						description: a,
						...o
					});
				} else if (e instanceof Error) {
					i = !1;
					let r = typeof t.error == "function" ? await t.error(e) : t.error, a = typeof t.description == "function" ? await t.description(e) : t.description, o = typeof r == "object" && !b.isValidElement(r) ? r : { message: r };
					this.create({
						id: n,
						type: "error",
						description: a,
						...o
					});
				} else if (t.success !== void 0) {
					i = !1;
					let r = typeof t.success == "function" ? await t.success(e) : t.success, a = typeof t.description == "function" ? await t.description(e) : t.description, o = typeof r == "object" && !b.isValidElement(r) ? r : { message: r };
					this.create({
						id: n,
						type: "success",
						description: a,
						...o
					});
				}
			}).catch(async (e) => {
				if (a = ["reject", e], t.error !== void 0) {
					i = !1;
					let r = typeof t.error == "function" ? await t.error(e) : t.error, a = typeof t.description == "function" ? await t.description(e) : t.description, o = typeof r == "object" && !b.isValidElement(r) ? r : { message: r };
					this.create({
						id: n,
						type: "error",
						description: a,
						...o
					});
				}
			}).finally(() => {
				i && (this.dismiss(n), n = void 0), t.finally == null || t.finally.call(t);
			}), s = () => new Promise((e, t) => o.then(() => a[0] === "reject" ? t(a[1]) : e(a[1])).catch(t));
			return typeof n != "string" && typeof n != "number" ? { unwrap: s } : Object.assign(n, { unwrap: s });
		}, this.custom = (e, t) => {
			let n = t?.id || I++;
			return this.create({
				jsx: e(n),
				id: n,
				...t
			}), n;
		}, this.getActiveToasts = () => this.toasts.filter((e) => !this.dismissedToasts.has(e.id)), this.subscribers = [], this.toasts = [], this.dismissedToasts = /* @__PURE__ */ new Set();
	}
}(), se = (e, t) => {
	let n = t?.id || I++;
	return L.addToast({
		title: e,
		...t,
		id: n
	}), n;
}, ce = (e) => e && typeof e == "object" && "ok" in e && typeof e.ok == "boolean" && "status" in e && typeof e.status == "number", R = Object.assign(se, {
	success: L.success,
	info: L.info,
	warning: L.warning,
	error: L.error,
	custom: L.custom,
	message: L.message,
	promise: L.promise,
	dismiss: L.dismiss,
	loading: L.loading
}, {
	getHistory: () => L.toasts,
	getToasts: () => L.getActiveToasts()
});
A("[data-sonner-toaster][dir=ltr],html[dir=ltr]{--toast-icon-margin-start:-3px;--toast-icon-margin-end:4px;--toast-svg-margin-start:-1px;--toast-svg-margin-end:0px;--toast-button-margin-start:auto;--toast-button-margin-end:0;--toast-close-button-start:0;--toast-close-button-end:unset;--toast-close-button-transform:translate(-35%, -35%)}[data-sonner-toaster][dir=rtl],html[dir=rtl]{--toast-icon-margin-start:4px;--toast-icon-margin-end:-3px;--toast-svg-margin-start:0px;--toast-svg-margin-end:-1px;--toast-button-margin-start:0;--toast-button-margin-end:auto;--toast-close-button-start:unset;--toast-close-button-end:0;--toast-close-button-transform:translate(35%, -35%)}[data-sonner-toaster]{position:fixed;width:var(--width);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;--gray1:hsl(0, 0%, 99%);--gray2:hsl(0, 0%, 97.3%);--gray3:hsl(0, 0%, 95.1%);--gray4:hsl(0, 0%, 93%);--gray5:hsl(0, 0%, 90.9%);--gray6:hsl(0, 0%, 88.7%);--gray7:hsl(0, 0%, 85.8%);--gray8:hsl(0, 0%, 78%);--gray9:hsl(0, 0%, 56.1%);--gray10:hsl(0, 0%, 52.3%);--gray11:hsl(0, 0%, 43.5%);--gray12:hsl(0, 0%, 9%);--border-radius:8px;box-sizing:border-box;padding:0;margin:0;list-style:none;outline:0;z-index:999999999;transition:transform .4s ease}@media (hover:none) and (pointer:coarse){[data-sonner-toaster][data-lifted=true]{transform:none}}[data-sonner-toaster][data-x-position=right]{right:var(--offset-right)}[data-sonner-toaster][data-x-position=left]{left:var(--offset-left)}[data-sonner-toaster][data-x-position=center]{left:50%;transform:translateX(-50%)}[data-sonner-toaster][data-y-position=top]{top:var(--offset-top)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--offset-bottom)}[data-sonner-toast]{--y:translateY(100%);--lift-amount:calc(var(--lift) * var(--gap));z-index:var(--z-index);position:absolute;opacity:0;transform:var(--y);touch-action:none;transition:transform .4s,opacity .4s,height .4s,box-shadow .2s;box-sizing:border-box;outline:0;overflow-wrap:anywhere}[data-sonner-toast][data-styled=true]{padding:16px;background:var(--normal-bg);border:1px solid var(--normal-border);color:var(--normal-text);border-radius:var(--border-radius);box-shadow:0 4px 12px rgba(0,0,0,.1);width:var(--width);font-size:13px;display:flex;align-items:center;gap:6px}[data-sonner-toast]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-y-position=top]{top:0;--y:translateY(-100%);--lift:1;--lift-amount:calc(1 * var(--gap))}[data-sonner-toast][data-y-position=bottom]{bottom:0;--y:translateY(100%);--lift:-1;--lift-amount:calc(var(--lift) * var(--gap))}[data-sonner-toast][data-styled=true] [data-description]{font-weight:400;line-height:1.4;color:#3f3f3f}[data-rich-colors=true][data-sonner-toast][data-styled=true] [data-description]{color:inherit}[data-sonner-toaster][data-sonner-theme=dark] [data-description]{color:#e8e8e8}[data-sonner-toast][data-styled=true] [data-title]{font-weight:500;line-height:1.5;color:inherit}[data-sonner-toast][data-styled=true] [data-icon]{display:flex;height:16px;width:16px;position:relative;justify-content:flex-start;align-items:center;flex-shrink:0;margin-left:var(--toast-icon-margin-start);margin-right:var(--toast-icon-margin-end)}[data-sonner-toast][data-promise=true] [data-icon]>svg{opacity:0;transform:scale(.8);transform-origin:center;animation:sonner-fade-in .3s ease forwards}[data-sonner-toast][data-styled=true] [data-icon]>*{flex-shrink:0}[data-sonner-toast][data-styled=true] [data-icon] svg{margin-left:var(--toast-svg-margin-start);margin-right:var(--toast-svg-margin-end)}[data-sonner-toast][data-styled=true] [data-content]{display:flex;flex-direction:column;gap:2px}[data-sonner-toast][data-styled=true] [data-button]{border-radius:4px;padding-left:8px;padding-right:8px;height:24px;font-size:12px;color:var(--normal-bg);background:var(--normal-text);margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end);border:none;font-weight:500;cursor:pointer;outline:0;display:flex;align-items:center;flex-shrink:0;transition:opacity .4s,box-shadow .2s}[data-sonner-toast][data-styled=true] [data-button]:focus-visible{box-shadow:0 0 0 2px rgba(0,0,0,.4)}[data-sonner-toast][data-styled=true] [data-button]:first-of-type{margin-left:var(--toast-button-margin-start);margin-right:var(--toast-button-margin-end)}[data-sonner-toast][data-styled=true] [data-cancel]{color:var(--normal-text);background:rgba(0,0,0,.08)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-styled=true] [data-cancel]{background:rgba(255,255,255,.3)}[data-sonner-toast][data-styled=true] [data-close-button]{position:absolute;left:var(--toast-close-button-start);right:var(--toast-close-button-end);top:0;height:20px;width:20px;display:flex;justify-content:center;align-items:center;padding:0;color:var(--gray12);background:var(--normal-bg);border:1px solid var(--gray4);transform:var(--toast-close-button-transform);border-radius:50%;cursor:pointer;z-index:1;transition:opacity .1s,background .2s,border-color .2s}[data-sonner-toast][data-styled=true] [data-close-button]:focus-visible{box-shadow:0 4px 12px rgba(0,0,0,.1),0 0 0 2px rgba(0,0,0,.2)}[data-sonner-toast][data-styled=true] [data-disabled=true]{cursor:not-allowed}[data-sonner-toast][data-styled=true]:hover [data-close-button]:hover{background:var(--gray2);border-color:var(--gray5)}[data-sonner-toast][data-swiping=true]::before{content:'';position:absolute;left:-100%;right:-100%;height:100%;z-index:-1}[data-sonner-toast][data-y-position=top][data-swiping=true]::before{bottom:50%;transform:scaleY(3) translateY(50%)}[data-sonner-toast][data-y-position=bottom][data-swiping=true]::before{top:50%;transform:scaleY(3) translateY(-50%)}[data-sonner-toast][data-swiping=false][data-removed=true]::before{content:'';position:absolute;inset:0;transform:scaleY(2)}[data-sonner-toast][data-expanded=true]::after{content:'';position:absolute;left:0;height:calc(var(--gap) + 1px);bottom:100%;width:100%}[data-sonner-toast][data-mounted=true]{--y:translateY(0);opacity:1}[data-sonner-toast][data-expanded=false][data-front=false]{--scale:var(--toasts-before) * 0.05 + 1;--y:translateY(calc(var(--lift-amount) * var(--toasts-before))) scale(calc(-1 * var(--scale)));height:var(--front-toast-height)}[data-sonner-toast]>*{transition:opacity .4s}[data-sonner-toast][data-x-position=right]{right:0}[data-sonner-toast][data-x-position=left]{left:0}[data-sonner-toast][data-expanded=false][data-front=false][data-styled=true]>*{opacity:0}[data-sonner-toast][data-visible=false]{opacity:0;pointer-events:none}[data-sonner-toast][data-mounted=true][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset)));height:var(--initial-height)}[data-sonner-toast][data-removed=true][data-front=true][data-swipe-out=false]{--y:translateY(calc(var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=true]{--y:translateY(calc(var(--lift) * var(--offset) + var(--lift) * -100%));opacity:0}[data-sonner-toast][data-removed=true][data-front=false][data-swipe-out=false][data-expanded=false]{--y:translateY(40%);opacity:0;transition:transform .5s,opacity .2s}[data-sonner-toast][data-removed=true][data-front=false]::before{height:calc(var(--initial-height) + 20%)}[data-sonner-toast][data-swiping=true]{transform:var(--y) translateY(var(--swipe-amount-y,0)) translateX(var(--swipe-amount-x,0));transition:none}[data-sonner-toast][data-swiped=true]{user-select:none}[data-sonner-toast][data-swipe-out=true][data-y-position=bottom],[data-sonner-toast][data-swipe-out=true][data-y-position=top]{animation-duration:.2s;animation-timing-function:ease-out;animation-fill-mode:forwards}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=left]{animation-name:swipe-out-left}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=right]{animation-name:swipe-out-right}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=up]{animation-name:swipe-out-up}[data-sonner-toast][data-swipe-out=true][data-swipe-direction=down]{animation-name:swipe-out-down}@keyframes swipe-out-left{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) - 100%));opacity:0}}@keyframes swipe-out-right{from{transform:var(--y) translateX(var(--swipe-amount-x));opacity:1}to{transform:var(--y) translateX(calc(var(--swipe-amount-x) + 100%));opacity:0}}@keyframes swipe-out-up{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) - 100%));opacity:0}}@keyframes swipe-out-down{from{transform:var(--y) translateY(var(--swipe-amount-y));opacity:1}to{transform:var(--y) translateY(calc(var(--swipe-amount-y) + 100%));opacity:0}}@media (max-width:600px){[data-sonner-toaster]{position:fixed;right:var(--mobile-offset-right);left:var(--mobile-offset-left);width:100%}[data-sonner-toaster][dir=rtl]{left:calc(var(--mobile-offset-left) * -1)}[data-sonner-toaster] [data-sonner-toast]{left:0;right:0;width:calc(100% - var(--mobile-offset-left) * 2)}[data-sonner-toaster][data-x-position=left]{left:var(--mobile-offset-left)}[data-sonner-toaster][data-y-position=bottom]{bottom:var(--mobile-offset-bottom)}[data-sonner-toaster][data-y-position=top]{top:var(--mobile-offset-top)}[data-sonner-toaster][data-x-position=center]{left:var(--mobile-offset-left);right:var(--mobile-offset-right);transform:none}}[data-sonner-toaster][data-sonner-theme=light]{--normal-bg:#fff;--normal-border:var(--gray4);--normal-text:var(--gray12);--success-bg:hsl(143, 85%, 96%);--success-border:hsl(145, 92%, 87%);--success-text:hsl(140, 100%, 27%);--info-bg:hsl(208, 100%, 97%);--info-border:hsl(221, 91%, 93%);--info-text:hsl(210, 92%, 45%);--warning-bg:hsl(49, 100%, 97%);--warning-border:hsl(49, 91%, 84%);--warning-text:hsl(31, 92%, 45%);--error-bg:hsl(359, 100%, 97%);--error-border:hsl(359, 100%, 94%);--error-text:hsl(360, 100%, 45%)}[data-sonner-toaster][data-sonner-theme=light] [data-sonner-toast][data-invert=true]{--normal-bg:#000;--normal-border:hsl(0, 0%, 20%);--normal-text:var(--gray1)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast][data-invert=true]{--normal-bg:#fff;--normal-border:var(--gray3);--normal-text:var(--gray12)}[data-sonner-toaster][data-sonner-theme=dark]{--normal-bg:#000;--normal-bg-hover:hsl(0, 0%, 12%);--normal-border:hsl(0, 0%, 20%);--normal-border-hover:hsl(0, 0%, 25%);--normal-text:var(--gray1);--success-bg:hsl(150, 100%, 6%);--success-border:hsl(147, 100%, 12%);--success-text:hsl(150, 86%, 65%);--info-bg:hsl(215, 100%, 6%);--info-border:hsl(223, 43%, 17%);--info-text:hsl(216, 87%, 65%);--warning-bg:hsl(64, 100%, 6%);--warning-border:hsl(60, 100%, 9%);--warning-text:hsl(46, 87%, 65%);--error-bg:hsl(358, 76%, 10%);--error-border:hsl(357, 89%, 16%);--error-text:hsl(358, 100%, 81%)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]{background:var(--normal-bg);border-color:var(--normal-border);color:var(--normal-text)}[data-sonner-toaster][data-sonner-theme=dark] [data-sonner-toast] [data-close-button]:hover{background:var(--normal-bg-hover);border-color:var(--normal-border-hover)}[data-rich-colors=true][data-sonner-toast][data-type=success]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=success] [data-close-button]{background:var(--success-bg);border-color:var(--success-border);color:var(--success-text)}[data-rich-colors=true][data-sonner-toast][data-type=info]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=info] [data-close-button]{background:var(--info-bg);border-color:var(--info-border);color:var(--info-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=warning] [data-close-button]{background:var(--warning-bg);border-color:var(--warning-border);color:var(--warning-text)}[data-rich-colors=true][data-sonner-toast][data-type=error]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}[data-rich-colors=true][data-sonner-toast][data-type=error] [data-close-button]{background:var(--error-bg);border-color:var(--error-border);color:var(--error-text)}.sonner-loading-wrapper{--size:16px;height:var(--size);width:var(--size);position:absolute;inset:0;z-index:10}.sonner-loading-wrapper[data-visible=false]{transform-origin:center;animation:sonner-fade-out .2s ease forwards}.sonner-spinner{position:relative;top:50%;left:50%;height:var(--size);width:var(--size)}.sonner-loading-bar{animation:sonner-spin 1.2s linear infinite;background:var(--gray11);border-radius:6px;height:8%;left:-10%;position:absolute;top:-3.9%;width:24%}.sonner-loading-bar:first-child{animation-delay:-1.2s;transform:rotate(.0001deg) translate(146%)}.sonner-loading-bar:nth-child(2){animation-delay:-1.1s;transform:rotate(30deg) translate(146%)}.sonner-loading-bar:nth-child(3){animation-delay:-1s;transform:rotate(60deg) translate(146%)}.sonner-loading-bar:nth-child(4){animation-delay:-.9s;transform:rotate(90deg) translate(146%)}.sonner-loading-bar:nth-child(5){animation-delay:-.8s;transform:rotate(120deg) translate(146%)}.sonner-loading-bar:nth-child(6){animation-delay:-.7s;transform:rotate(150deg) translate(146%)}.sonner-loading-bar:nth-child(7){animation-delay:-.6s;transform:rotate(180deg) translate(146%)}.sonner-loading-bar:nth-child(8){animation-delay:-.5s;transform:rotate(210deg) translate(146%)}.sonner-loading-bar:nth-child(9){animation-delay:-.4s;transform:rotate(240deg) translate(146%)}.sonner-loading-bar:nth-child(10){animation-delay:-.3s;transform:rotate(270deg) translate(146%)}.sonner-loading-bar:nth-child(11){animation-delay:-.2s;transform:rotate(300deg) translate(146%)}.sonner-loading-bar:nth-child(12){animation-delay:-.1s;transform:rotate(330deg) translate(146%)}@keyframes sonner-fade-in{0%{opacity:0;transform:scale(.8)}100%{opacity:1;transform:scale(1)}}@keyframes sonner-fade-out{0%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(.8)}}@keyframes sonner-spin{0%{opacity:1}100%{opacity:.15}}@media (prefers-reduced-motion){.sonner-loading-bar,[data-sonner-toast],[data-sonner-toast]>*{transition:none!important;animation:none!important}}.sonner-loader{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);transform-origin:center;transition:opacity .2s,transform .2s}.sonner-loader[data-visible=false]{opacity:0;transform:scale(.8) translate(-50%,-50%)}");
function le(e) {
	return e.label !== void 0;
}
var ue = 3, z = "24px", de = "16px", fe = 4e3, B = 356, pe = 14, me = 45, he = 200;
function V(...e) {
	return e.filter(Boolean).join(" ");
}
function ge(e) {
	let [t, n] = e.split("-"), r = [];
	return t && r.push(t), n && r.push(n), r;
}
var _e = (e) => {
	let { invert: t, toast: n, unstyled: r, interacting: i, setHeights: a, visibleToasts: o, heights: s, index: c, toasts: l, expanded: u, removeToast: d, defaultRichColors: f, closeButton: p, style: m, cancelButtonStyle: ee, actionButtonStyle: h, className: g = "", descriptionClassName: _ = "", duration: v, position: te, gap: y, expandByDefault: x, classNames: S, icons: C, closeButtonAriaLabel: ne = "Close toast" } = e, [w, T] = b.useState(null), [E, D] = b.useState(null), [O, k] = b.useState(!1), [A, M] = b.useState(!1), [N, P] = b.useState(!1), [F, ie] = b.useState(!1), [I, L] = b.useState(!1), [se, ce] = b.useState(0), [R, ue] = b.useState(0), z = b.useRef(n.duration || v || fe), de = b.useRef(null), B = b.useRef(null), pe = c === 0, _e = c + 1 <= o, H = n.type, U = n.dismissible !== !1, ve = n.className || "", ye = n.descriptionClassName || "", W = b.useMemo(() => s.findIndex((e) => e.toastId === n.id) || 0, [s, n.id]), be = b.useMemo(() => n.closeButton ?? p, [n.closeButton, p]), xe = b.useMemo(() => n.duration || v || fe, [n.duration, v]), G = b.useRef(0), K = b.useRef(0), Se = b.useRef(0), q = b.useRef(null), [Ce, we] = te.split("-"), Te = b.useMemo(() => s.reduce((e, t, n) => n >= W ? e : e + t.height, 0), [s, W]), Ee = oe(), De = n.invert || t, Oe = H === "loading";
	K.current = b.useMemo(() => W * y + Te, [W, Te]), b.useEffect(() => {
		z.current = xe;
	}, [xe]), b.useEffect(() => {
		k(!0);
	}, []), b.useEffect(() => {
		let e = B.current;
		if (e) {
			let t = e.getBoundingClientRect().height;
			return ue(t), a((e) => [{
				toastId: n.id,
				height: t,
				position: n.position
			}, ...e]), () => a((e) => e.filter((e) => e.toastId !== n.id));
		}
	}, [a, n.id]), b.useLayoutEffect(() => {
		if (!O) return;
		let e = B.current, t = e.style.height;
		e.style.height = "auto";
		let r = e.getBoundingClientRect().height;
		e.style.height = t, ue(r), a((e) => e.find((e) => e.toastId === n.id) ? e.map((e) => e.toastId === n.id ? {
			...e,
			height: r
		} : e) : [{
			toastId: n.id,
			height: r,
			position: n.position
		}, ...e]);
	}, [
		O,
		n.title,
		n.description,
		a,
		n.id,
		n.jsx,
		n.action,
		n.cancel
	]);
	let J = b.useCallback(() => {
		M(!0), ce(K.current), a((e) => e.filter((e) => e.toastId !== n.id)), setTimeout(() => {
			d(n);
		}, he);
	}, [
		n,
		d,
		a,
		K
	]);
	b.useEffect(() => {
		if (n.promise && H === "loading" || n.duration === Infinity || n.type === "loading") return;
		let e;
		return u || i || Ee ? (() => {
			if (Se.current < G.current) {
				let e = (/* @__PURE__ */ new Date()).getTime() - G.current;
				z.current -= e;
			}
			Se.current = (/* @__PURE__ */ new Date()).getTime();
		})() : z.current !== Infinity && (G.current = (/* @__PURE__ */ new Date()).getTime(), e = setTimeout(() => {
			n.onAutoClose == null || n.onAutoClose.call(n, n), J();
		}, z.current)), () => clearTimeout(e);
	}, [
		u,
		i,
		n,
		H,
		Ee,
		J
	]), b.useEffect(() => {
		n.delete && (J(), n.onDismiss == null || n.onDismiss.call(n, n));
	}, [J, n.delete]);
	function ke() {
		return C?.loading ? /* @__PURE__ */ b.createElement("div", {
			className: V(S?.loader, n?.classNames?.loader, "sonner-loader"),
			"data-visible": H === "loading"
		}, C.loading) : /* @__PURE__ */ b.createElement(re, {
			className: V(S?.loader, n?.classNames?.loader),
			visible: H === "loading"
		});
	}
	let Ae = n.icon || C?.[H] || j(H);
	return /* @__PURE__ */ b.createElement("li", {
		tabIndex: 0,
		ref: B,
		className: V(g, ve, S?.toast, n?.classNames?.toast, S?.default, S?.[H], n?.classNames?.[H]),
		"data-sonner-toast": "",
		"data-rich-colors": n.richColors ?? f,
		"data-styled": !(n.jsx || n.unstyled || r),
		"data-mounted": O,
		"data-promise": !!n.promise,
		"data-swiped": I,
		"data-removed": A,
		"data-visible": _e,
		"data-y-position": Ce,
		"data-x-position": we,
		"data-index": c,
		"data-front": pe,
		"data-swiping": N,
		"data-dismissible": U,
		"data-type": H,
		"data-invert": De,
		"data-swipe-out": F,
		"data-swipe-direction": E,
		"data-expanded": !!(u || x && O),
		"data-testid": n.testId,
		style: {
			"--index": c,
			"--toasts-before": c,
			"--z-index": l.length - c,
			"--offset": `${A ? se : K.current}px`,
			"--initial-height": x ? "auto" : `${R}px`,
			...m,
			...n.style
		},
		onDragEnd: () => {
			P(!1), T(null), q.current = null;
		},
		onPointerDown: (e) => {
			e.button !== 2 && (Oe || !U || (de.current = /* @__PURE__ */ new Date(), ce(K.current), e.target.setPointerCapture(e.pointerId), e.target.tagName !== "BUTTON" && (P(!0), q.current = {
				x: e.clientX,
				y: e.clientY
			})));
		},
		onPointerUp: () => {
			if (F || !U) return;
			q.current = null;
			let e = Number(B.current?.style.getPropertyValue("--swipe-amount-x").replace("px", "") || 0), t = Number(B.current?.style.getPropertyValue("--swipe-amount-y").replace("px", "") || 0), r = (/* @__PURE__ */ new Date()).getTime() - de.current?.getTime(), i = w === "x" ? e : t, a = Math.abs(i) / r;
			if (Math.abs(i) >= me || a > .11) {
				ce(K.current), n.onDismiss == null || n.onDismiss.call(n, n), D(w === "x" ? e > 0 ? "right" : "left" : t > 0 ? "down" : "up"), J(), ie(!0);
				return;
			} else {
				var o, s;
				(o = B.current) == null || o.style.setProperty("--swipe-amount-x", "0px"), (s = B.current) == null || s.style.setProperty("--swipe-amount-y", "0px");
			}
			L(!1), P(!1), T(null);
		},
		onPointerMove: (t) => {
			var n, r;
			if (!q.current || !U || window.getSelection()?.toString().length > 0) return;
			let i = t.clientY - q.current.y, a = t.clientX - q.current.x, o = e.swipeDirections ?? ge(te);
			!w && (Math.abs(a) > 1 || Math.abs(i) > 1) && T(Math.abs(a) > Math.abs(i) ? "x" : "y");
			let s = {
				x: 0,
				y: 0
			}, c = (e) => 1 / (1.5 + Math.abs(e) / 20);
			if (w === "y") {
				if (o.includes("top") || o.includes("bottom")) if (o.includes("top") && i < 0 || o.includes("bottom") && i > 0) s.y = i;
				else {
					let e = i * c(i);
					s.y = Math.abs(e) < Math.abs(i) ? e : i;
				}
			} else if (w === "x" && (o.includes("left") || o.includes("right"))) if (o.includes("left") && a < 0 || o.includes("right") && a > 0) s.x = a;
			else {
				let e = a * c(a);
				s.x = Math.abs(e) < Math.abs(a) ? e : a;
			}
			(Math.abs(s.x) > 0 || Math.abs(s.y) > 0) && L(!0), (n = B.current) == null || n.style.setProperty("--swipe-amount-x", `${s.x}px`), (r = B.current) == null || r.style.setProperty("--swipe-amount-y", `${s.y}px`);
		}
	}, be && !n.jsx && H !== "loading" ? /* @__PURE__ */ b.createElement("button", {
		"aria-label": ne,
		"data-disabled": Oe,
		"data-close-button": !0,
		onClick: Oe || !U ? () => {} : () => {
			J(), n.onDismiss == null || n.onDismiss.call(n, n);
		},
		className: V(S?.closeButton, n?.classNames?.closeButton)
	}, C?.close ?? ae) : null, (H || n.icon || n.promise) && n.icon !== null && (C?.[H] !== null || n.icon) ? /* @__PURE__ */ b.createElement("div", {
		"data-icon": "",
		className: V(S?.icon, n?.classNames?.icon)
	}, n.promise || n.type === "loading" && !n.icon ? n.icon || ke() : null, n.type === "loading" ? null : Ae) : null, /* @__PURE__ */ b.createElement("div", {
		"data-content": "",
		className: V(S?.content, n?.classNames?.content)
	}, /* @__PURE__ */ b.createElement("div", {
		"data-title": "",
		className: V(S?.title, n?.classNames?.title)
	}, n.jsx ? n.jsx : typeof n.title == "function" ? n.title() : n.title), n.description ? /* @__PURE__ */ b.createElement("div", {
		"data-description": "",
		className: V(_, ye, S?.description, n?.classNames?.description)
	}, typeof n.description == "function" ? n.description() : n.description) : null), /* @__PURE__ */ b.isValidElement(n.cancel) ? n.cancel : n.cancel && le(n.cancel) ? /* @__PURE__ */ b.createElement("button", {
		"data-button": !0,
		"data-cancel": !0,
		style: n.cancelButtonStyle || ee,
		onClick: (e) => {
			le(n.cancel) && U && (n.cancel.onClick == null || n.cancel.onClick.call(n.cancel, e), J());
		},
		className: V(S?.cancelButton, n?.classNames?.cancelButton)
	}, n.cancel.label) : null, /* @__PURE__ */ b.isValidElement(n.action) ? n.action : n.action && le(n.action) ? /* @__PURE__ */ b.createElement("button", {
		"data-button": !0,
		"data-action": !0,
		style: n.actionButtonStyle || h,
		onClick: (e) => {
			le(n.action) && (n.action.onClick == null || n.action.onClick.call(n.action, e), !e.defaultPrevented && J());
		},
		className: V(S?.actionButton, n?.classNames?.actionButton)
	}, n.action.label) : null);
};
function H() {
	if (typeof window > "u" || typeof document > "u") return "ltr";
	let e = document.documentElement.getAttribute("dir");
	return e === "auto" || !e ? window.getComputedStyle(document.documentElement).direction : e;
}
function U(e, t) {
	let n = {};
	return [e, t].forEach((e, t) => {
		let r = t === 1, i = r ? "--mobile-offset" : "--offset", a = r ? de : z;
		function o(e) {
			[
				"top",
				"right",
				"bottom",
				"left"
			].forEach((t) => {
				n[`${i}-${t}`] = typeof e == "number" ? `${e}px` : e;
			});
		}
		typeof e == "number" || typeof e == "string" ? o(e) : typeof e == "object" ? [
			"top",
			"right",
			"bottom",
			"left"
		].forEach((t) => {
			e[t] === void 0 ? n[`${i}-${t}`] = a : n[`${i}-${t}`] = typeof e[t] == "number" ? `${e[t]}px` : e[t];
		}) : o(a);
	}), n;
}
var ve = /* @__PURE__ */ b.forwardRef(function(e, t) {
	let { id: n, invert: r, position: i = "bottom-right", hotkey: a = ["altKey", "KeyT"], expand: o, closeButton: s, className: c, offset: l, mobileOffset: u, theme: d = "light", richColors: f, duration: p, style: m, visibleToasts: ee = ue, toastOptions: h, dir: g = H(), gap: _ = pe, icons: v, containerAriaLabel: te = "Notifications" } = e, [y, x] = b.useState([]), S = b.useMemo(() => n ? y.filter((e) => e.toasterId === n) : y.filter((e) => !e.toasterId), [y, n]), C = b.useMemo(() => Array.from(new Set([i].concat(S.filter((e) => e.position).map((e) => e.position)))), [S, i]), [w, T] = b.useState([]), [E, D] = b.useState(!1), [O, k] = b.useState(!1), [A, j] = b.useState(d === "system" ? typeof window < "u" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light" : d), M = b.useRef(null), re = a.join("+").replace(/Key/g, "").replace(/Digit/g, ""), N = b.useRef(null), P = b.useRef(!1), F = b.useCallback((e) => {
		x((t) => (t.find((t) => t.id === e.id)?.delete || L.dismiss(e.id), t.filter(({ id: t }) => t !== e.id)));
	}, []);
	return b.useEffect(() => L.subscribe((e) => {
		if (e.dismiss) {
			requestAnimationFrame(() => {
				x((t) => t.map((t) => t.id === e.id ? {
					...t,
					delete: !0
				} : t));
			});
			return;
		}
		setTimeout(() => {
			ne.flushSync(() => {
				x((t) => {
					let n = t.findIndex((t) => t.id === e.id);
					return n === -1 ? [e, ...t] : [
						...t.slice(0, n),
						{
							...t[n],
							...e
						},
						...t.slice(n + 1)
					];
				});
			});
		});
	}), [y]), b.useEffect(() => {
		if (d !== "system") {
			j(d);
			return;
		}
		if (d === "system" && (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? j("dark") : j("light")), typeof window > "u") return;
		let e = window.matchMedia("(prefers-color-scheme: dark)");
		try {
			e.addEventListener("change", ({ matches: e }) => {
				j(e ? "dark" : "light");
			});
		} catch {
			e.addListener(({ matches: e }) => {
				try {
					j(e ? "dark" : "light");
				} catch (e) {
					console.error(e);
				}
			});
		}
	}, [d]), b.useEffect(() => {
		y.length <= 1 && D(!1);
	}, [y]), b.useEffect(() => {
		let e = (e) => {
			if (a.every((t) => e[t] || e.code === t)) {
				var t;
				D(!0), (t = M.current) == null || t.focus();
			}
			e.code === "Escape" && (document.activeElement === M.current || M.current?.contains(document.activeElement)) && D(!1);
		};
		return document.addEventListener("keydown", e), () => document.removeEventListener("keydown", e);
	}, [a]), b.useEffect(() => {
		if (M.current) return () => {
			N.current && (N.current.focus({ preventScroll: !0 }), N.current = null, P.current = !1);
		};
	}, [M.current]), /* @__PURE__ */ b.createElement("section", {
		ref: t,
		"aria-label": `${te} ${re}`,
		tabIndex: -1,
		"aria-live": "polite",
		"aria-relevant": "additions text",
		"aria-atomic": "false",
		suppressHydrationWarning: !0
	}, C.map((t, n) => {
		let [i, a] = t.split("-");
		return S.length ? /* @__PURE__ */ b.createElement("ol", {
			key: t,
			dir: g === "auto" ? H() : g,
			tabIndex: -1,
			ref: M,
			className: c,
			"data-sonner-toaster": !0,
			"data-sonner-theme": A,
			"data-y-position": i,
			"data-x-position": a,
			style: {
				"--front-toast-height": `${w[0]?.height || 0}px`,
				"--width": `${B}px`,
				"--gap": `${_}px`,
				...m,
				...U(l, u)
			},
			onBlur: (e) => {
				P.current && !e.currentTarget.contains(e.relatedTarget) && (P.current = !1, N.current &&= (N.current.focus({ preventScroll: !0 }), null));
			},
			onFocus: (e) => {
				e.target instanceof HTMLElement && e.target.dataset.dismissible === "false" || P.current || (P.current = !0, N.current = e.relatedTarget);
			},
			onMouseEnter: () => D(!0),
			onMouseMove: () => D(!0),
			onMouseLeave: () => {
				O || D(!1);
			},
			onDragEnd: () => D(!1),
			onPointerDown: (e) => {
				e.target instanceof HTMLElement && e.target.dataset.dismissible === "false" || k(!0);
			},
			onPointerUp: () => k(!1)
		}, S.filter((e) => !e.position && n === 0 || e.position === t).map((n, i) => /* @__PURE__ */ b.createElement(_e, {
			key: n.id,
			icons: v,
			index: i,
			toast: n,
			defaultRichColors: f,
			duration: h?.duration ?? p,
			className: h?.className,
			descriptionClassName: h?.descriptionClassName,
			invert: r,
			visibleToasts: ee,
			closeButton: h?.closeButton ?? s,
			interacting: O,
			position: t,
			style: h?.style,
			unstyled: h?.unstyled,
			classNames: h?.classNames,
			cancelButtonStyle: h?.cancelButtonStyle,
			actionButtonStyle: h?.actionButtonStyle,
			closeButtonAriaLabel: h?.closeButtonAriaLabel,
			removeToast: F,
			toasts: S.filter((e) => e.position == n.position),
			heights: w.filter((e) => e.position == n.position),
			setHeights: T,
			expandByDefault: o,
			gap: _,
			expanded: E,
			swipeDirections: e.swipeDirections
		}))) : null;
	}));
}), ye = new Set(["error", "warning"]);
function W(e, r) {
	let i = r === "strong";
	switch (e) {
		case "success": return i ? {
			container: "bg-[var(--system-positive-strong)] border-transparent text-white",
			iconElement: /* @__PURE__ */ T(n, { className: "h-4 w-4" })
		} : {
			container: "bg-[var(--system-positive-weak)] border-transparent text-[var(--system-positive-strong)]",
			iconElement: /* @__PURE__ */ T(n, { className: "h-4 w-4" })
		};
		case "error": return i ? {
			container: "bg-[var(--system-negative-strong)] border-transparent text-white",
			iconElement: /* @__PURE__ */ T(t, { className: "h-4 w-4" })
		} : {
			container: "bg-[var(--system-negative-weak)] border-transparent text-[var(--system-negative-strong)]",
			iconElement: /* @__PURE__ */ T(t, { className: "h-4 w-4" })
		};
		case "warning": return i ? {
			container: "bg-[var(--system-mid-strong)] border-transparent text-white",
			iconElement: /* @__PURE__ */ T(D, { className: "h-4 w-4" })
		} : {
			container: "bg-[var(--system-mid-weak)] border-transparent text-[var(--system-mid-strong)]",
			iconElement: /* @__PURE__ */ T(D, { className: "h-4 w-4" })
		};
		case "info": return i ? {
			container: "bg-[var(--content-secondary)] border-transparent text-white",
			iconElement: /* @__PURE__ */ T(D, { className: "h-4 w-4" })
		} : {
			container: "bg-[var(--surface-overlay)] border-transparent text-[var(--content-default)]",
			iconElement: /* @__PURE__ */ T(D, { className: "h-4 w-4" })
		};
		default: return {
			container: "bg-[var(--surface-lift)] border-transparent text-[var(--content-default)]",
			iconElement: null
		};
	}
}
function be({ message: e, variant: t = "default", tone: n = "weak", options: i, onDismiss: a }) {
	let o = W(t, n);
	return /* @__PURE__ */ E("div", {
		role: ye.has(t) ? "alert" : "status",
		"data-slot": "toast",
		className: r("flex w-full max-h-[300px] items-start gap-3 rounded-lg border p-3 shadow-lg", o.container),
		children: [
			o.iconElement ? /* @__PURE__ */ T("span", {
				className: "mt-0.5 shrink-0",
				children: o.iconElement
			}) : null,
			/* @__PURE__ */ E("div", {
				className: "min-w-0 flex-1 space-y-1",
				children: [
					/* @__PURE__ */ T("p", {
						className: "text-body-medium-default",
						children: e
					}),
					i?.description ? /* @__PURE__ */ T("p", {
						className: "text-body-small-default opacity-70",
						children: i.description
					}) : null,
					i?.action ? /* @__PURE__ */ T("button", {
						type: "button",
						onClick: () => {
							i.action?.onClick(), a();
						},
						className: "mt-1.5 cursor-pointer bg-transparent text-body-small-default underline underline-offset-2 hover:no-underline",
						children: i.action.label
					}) : null
				]
			}),
			/* @__PURE__ */ T("button", {
				type: "button",
				onClick: a,
				"aria-label": "Close",
				className: "shrink-0 cursor-pointer rounded bg-transparent p-0.5 opacity-50 transition-opacity hover:opacity-100",
				children: /* @__PURE__ */ T(k, {
					className: "h-3.5 w-3.5",
					strokeWidth: 2
				})
			})
		]
	});
}
var xe = 0;
function G() {
	return `toast-${++xe}`;
}
function K(e, t = "default", n) {
	let r = n?.id ?? G(), i = n?.tone ?? "weak";
	return R.custom(() => /* @__PURE__ */ T(be, {
		message: e,
		variant: t,
		tone: i,
		options: n,
		onDismiss: () => R.dismiss(r)
	}), {
		duration: n?.duration,
		id: r
	});
}
var Se = Object.assign((e, t) => K(e, "default", t), {
	info: (e, t) => K(e, "info", t),
	warning: (e, t) => K(e, "warning", t),
	error: (e, t) => K(e, "error", t),
	success: (e, t) => K(e, "success", t),
	custom: (e, t) => R.custom(e, {
		...t,
		id: t?.id ?? G()
	}),
	dismiss: (e) => R.dismiss(e)
});
function q() {
	return /* @__PURE__ */ T("div", {
		"data-slot": "toaster",
		children: /* @__PURE__ */ T(ve, {
			position: "bottom-center",
			offset: "24px",
			mobileOffset: {
				left: 0,
				right: 0,
				bottom: "calc(24px + var(--safe-area-inset-bottom, env(safe-area-inset-bottom, 0px)))"
			},
			toastOptions: {
				unstyled: !0,
				style: {
					width: "356px",
					maxWidth: "calc(100vw - 32px)",
					marginInline: "auto"
				}
			}
		})
	});
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-focus-scope@1.1.11+07ecf1aa3bcbed22/node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var Ce = "focusScope.autoFocusOnMount", we = "focusScope.autoFocusOnUnmount", Te = {
	bubbles: !1,
	cancelable: !0
}, Ee = "FocusScope", De = y.forwardRef((e, t) => {
	let { loop: n = !1, trapped: r = !1, onMountAutoFocus: a, onUnmountAutoFocus: s, ...c } = e, [u, d] = y.useState(null), f = l(a), p = l(s), m = y.useRef(null), ee = i(t, d), h = y.useRef({
		paused: !1,
		pause() {
			this.paused = !0;
		},
		resume() {
			this.paused = !1;
		}
	}).current;
	y.useEffect(() => {
		if (r) {
			let e = function(e) {
				if (h.paused || !u) return;
				let t = e.target;
				u.contains(t) ? m.current = t : Y(m.current, { select: !0 });
			}, t = function(e) {
				if (h.paused || !u) return;
				let t = e.relatedTarget;
				t !== null && (u.contains(t) || Y(m.current, { select: !0 }));
			}, n = function(e) {
				if (document.activeElement === document.body) for (let t of e) t.removedNodes.length > 0 && Y(u);
			};
			document.addEventListener("focusin", e), document.addEventListener("focusout", t);
			let r = new MutationObserver(n);
			return u && r.observe(u, {
				childList: !0,
				subtree: !0
			}), () => {
				document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), r.disconnect();
			};
		}
	}, [
		r,
		u,
		h.paused
	]), y.useEffect(() => {
		if (u) {
			Ne.add(h);
			let e = document.activeElement;
			if (!u.contains(e)) {
				let t = new CustomEvent(Ce, Te);
				u.addEventListener(Ce, f), u.dispatchEvent(t), t.defaultPrevented || (Oe(Ie(ke(u)), { select: !0 }), document.activeElement === e && Y(u));
			}
			return () => {
				u.removeEventListener(Ce, f), setTimeout(() => {
					let t = new CustomEvent(we, Te);
					u.addEventListener(we, p), u.dispatchEvent(t), t.defaultPrevented || Y(e ?? document.body, { select: !0 }), u.removeEventListener(we, p), Ne.remove(h);
				}, 0);
			};
		}
	}, [
		u,
		f,
		p,
		h
	]);
	let g = y.useCallback((e) => {
		if (!n && !r || h.paused) return;
		let t = e.key === "Tab" && !e.altKey && !e.ctrlKey && !e.metaKey, i = document.activeElement;
		if (t && i) {
			let t = e.currentTarget, [r, a] = J(t);
			r && a ? !e.shiftKey && i === a ? (e.preventDefault(), n && Y(r, { select: !0 })) : e.shiftKey && i === r && (e.preventDefault(), n && Y(a, { select: !0 })) : i === t && e.preventDefault();
		}
	}, [
		n,
		r,
		h.paused
	]);
	return /* @__PURE__ */ T(o.div, {
		tabIndex: -1,
		...c,
		ref: ee,
		onKeyDown: g
	});
});
De.displayName = Ee;
function Oe(e, { select: t = !1 } = {}) {
	let n = document.activeElement;
	for (let r of e) if (Y(r, { select: t }), document.activeElement !== n) return;
}
function J(e) {
	let t = ke(e);
	return [Ae(t, e), Ae(t.reverse(), e)];
}
function ke(e) {
	let t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: (e) => {
		let t = e.tagName === "INPUT" && e.type === "hidden";
		return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	} });
	for (; n.nextNode();) t.push(n.currentNode);
	return t;
}
function Ae(e, t) {
	for (let n of e) if (!je(n, { upTo: t })) return n;
}
function je(e, { upTo: t }) {
	if (getComputedStyle(e).visibility === "hidden") return !0;
	for (; e;) {
		if (t !== void 0 && e === t) return !1;
		if (getComputedStyle(e).display === "none") return !0;
		e = e.parentElement;
	}
	return !1;
}
function Me(e) {
	return e instanceof HTMLInputElement && "select" in e;
}
function Y(e, { select: t = !1 } = {}) {
	if (e && e.focus) {
		let n = document.activeElement;
		e.focus({ preventScroll: !0 }), e !== n && Me(e) && t && e.select();
	}
}
var Ne = Pe();
function Pe() {
	let e = [];
	return {
		add(t) {
			let n = e[0];
			t !== n && n?.pause(), e = Fe(e, t), e.unshift(t);
		},
		remove(t) {
			e = Fe(e, t), e[0]?.resume();
		}
	};
}
function Fe(e, t) {
	let n = [...e], r = n.indexOf(t);
	return r !== -1 && n.splice(r, 1), n;
}
function Ie(e) {
	return e.filter((e) => e.tagName !== "A");
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-focus-guards@1.1.4+bf264c7668a20073/node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var Le = 0, X = null;
function Re() {
	y.useEffect(() => {
		X ||= {
			start: ze(),
			end: ze()
		};
		let { start: e, end: t } = X;
		return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), Le++, () => {
			Le === 1 && (X?.start.remove(), X?.end.remove(), X = null), Le = Math.max(0, Le - 1);
		};
	}, []);
}
function ze() {
	let e = document.createElement("span");
	return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
//#endregion
//#region ../../node_modules/.bun/@radix-ui+react-dialog@1.1.18+07ecf1aa3bcbed22/node_modules/@radix-ui/react-dialog/dist/index.mjs
var Be = "Dialog", [Ve, He] = p(Be), [Ue, Z] = Ve(Be), We = (e) => {
	let { __scopeDialog: t, children: n, open: r, defaultOpen: i, onOpenChange: a, modal: o = !0 } = e, s = y.useRef(null), l = y.useRef(null), [d, f] = u({
		prop: r,
		defaultProp: i ?? !1,
		onChange: a,
		caller: Be
	});
	return /* @__PURE__ */ T(Ue, {
		scope: t,
		triggerRef: s,
		contentRef: l,
		contentId: c(),
		titleId: c(),
		descriptionId: c(),
		open: d,
		onOpenChange: f,
		onOpenToggle: y.useCallback(() => f((e) => !e), [f]),
		modal: o,
		children: n
	});
};
We.displayName = Be;
var Ge = "DialogTrigger", Ke = y.forwardRef((e, t) => {
	let { __scopeDialog: n, ...r } = e, a = Z(Ge, n), s = i(t, a.triggerRef);
	return /* @__PURE__ */ T(o.button, {
		type: "button",
		"aria-haspopup": "dialog",
		"aria-expanded": a.open,
		"aria-controls": a.open ? a.contentId : void 0,
		"data-state": dt(a.open),
		...r,
		ref: s,
		onClick: f(e.onClick, a.onOpenToggle)
	});
});
Ke.displayName = Ge;
var qe = "DialogPortal", [Je, Ye] = Ve(qe, { forceMount: void 0 }), Xe = (e) => {
	let { __scopeDialog: t, forceMount: n, children: r, container: i } = e, a = Z(qe, t);
	return /* @__PURE__ */ T(Je, {
		scope: t,
		forceMount: n,
		children: y.Children.map(r, (e) => /* @__PURE__ */ T(m, {
			present: n || a.open,
			children: /* @__PURE__ */ T(ee, {
				asChild: !0,
				container: i,
				children: e
			})
		}))
	});
};
Xe.displayName = qe;
var Ze = "DialogOverlay", Qe = y.forwardRef((e, t) => {
	let n = Ye(Ze, e.__scopeDialog), { forceMount: r = n.forceMount, ...i } = e, a = Z(Ze, e.__scopeDialog);
	return a.modal ? /* @__PURE__ */ T(m, {
		present: r || a.open,
		children: /* @__PURE__ */ T(et, {
			...i,
			ref: t
		})
	}) : null;
});
Qe.displayName = Ze;
var $e = s("DialogOverlay.RemoveScroll"), et = y.forwardRef((e, t) => {
	let { __scopeDialog: n, ...r } = e, a = Z(Ze, n), s = i(t, g());
	return /* @__PURE__ */ T(v, {
		as: $e,
		allowPinchZoom: !0,
		shards: [a.contentRef],
		children: /* @__PURE__ */ T(o.div, {
			"data-state": dt(a.open),
			...r,
			ref: s,
			style: {
				pointerEvents: "auto",
				...r.style
			}
		})
	});
}), Q = "DialogContent", tt = y.forwardRef((e, t) => {
	let n = Ye(Q, e.__scopeDialog), { forceMount: r = n.forceMount, ...i } = e, a = Z(Q, e.__scopeDialog);
	return /* @__PURE__ */ T(m, {
		present: r || a.open,
		children: a.modal ? /* @__PURE__ */ T(nt, {
			...i,
			ref: t
		}) : /* @__PURE__ */ T(rt, {
			...i,
			ref: t
		})
	});
});
tt.displayName = Q;
var nt = y.forwardRef((e, t) => {
	let n = Z(Q, e.__scopeDialog), r = y.useRef(null), a = i(t, n.contentRef, r);
	return y.useEffect(() => {
		let e = r.current;
		if (e) return te(e);
	}, []), /* @__PURE__ */ T(it, {
		...e,
		ref: a,
		trapFocus: n.open,
		disableOutsidePointerEvents: n.open,
		onCloseAutoFocus: f(e.onCloseAutoFocus, (e) => {
			e.preventDefault(), n.triggerRef.current?.focus();
		}),
		onPointerDownOutside: f(e.onPointerDownOutside, (e) => {
			let t = e.detail.originalEvent, n = t.button === 0 && t.ctrlKey === !0;
			(t.button === 2 || n) && e.preventDefault();
		}),
		onFocusOutside: f(e.onFocusOutside, (e) => e.preventDefault())
	});
}), rt = y.forwardRef((e, t) => {
	let n = Z(Q, e.__scopeDialog), r = y.useRef(!1), i = y.useRef(!1);
	return /* @__PURE__ */ T(it, {
		...e,
		ref: t,
		trapFocus: !1,
		disableOutsidePointerEvents: !1,
		onCloseAutoFocus: (t) => {
			e.onCloseAutoFocus?.(t), t.defaultPrevented || (r.current || n.triggerRef.current?.focus(), t.preventDefault()), r.current = !1, i.current = !1;
		},
		onInteractOutside: (t) => {
			e.onInteractOutside?.(t), t.defaultPrevented || (r.current = !0, t.detail.originalEvent.type === "pointerdown" && (i.current = !0));
			let a = t.target;
			n.triggerRef.current?.contains(a) && t.preventDefault(), t.detail.originalEvent.type === "focusin" && i.current && t.preventDefault();
		}
	});
}), it = y.forwardRef((e, t) => {
	let { __scopeDialog: n, trapFocus: r, onOpenAutoFocus: i, onCloseAutoFocus: o, ...s } = e, c = Z(Q, n);
	return Re(), /* @__PURE__ */ T(w, { children: /* @__PURE__ */ T(De, {
		asChild: !0,
		loop: !0,
		trapped: r,
		onMountAutoFocus: i,
		onUnmountAutoFocus: o,
		children: /* @__PURE__ */ T(a, {
			role: "dialog",
			id: c.contentId,
			"aria-describedby": c.descriptionId,
			"aria-labelledby": c.titleId,
			"data-state": dt(c.open),
			...s,
			ref: t,
			deferPointerDownOutside: !0,
			onDismiss: () => c.onOpenChange(!1)
		})
	}) });
}), at = "DialogTitle", ot = y.forwardRef((e, t) => {
	let { __scopeDialog: n, ...r } = e, i = Z(at, n);
	return /* @__PURE__ */ T(o.h2, {
		id: i.titleId,
		...r,
		ref: t
	});
});
ot.displayName = at;
var st = "DialogDescription", ct = y.forwardRef((e, t) => {
	let { __scopeDialog: n, ...r } = e, i = Z(st, n);
	return /* @__PURE__ */ T(o.p, {
		id: i.descriptionId,
		...r,
		ref: t
	});
});
ct.displayName = st;
var lt = "DialogClose", ut = y.forwardRef((e, t) => {
	let { __scopeDialog: n, ...r } = e, i = Z(lt, n);
	return /* @__PURE__ */ T(o.button, {
		type: "button",
		...r,
		ref: t,
		onClick: f(e.onClick, () => i.onOpenChange(!1))
	});
});
ut.displayName = lt;
function dt(e) {
	return e ? "open" : "closed";
}
//#endregion
//#region ../../packages/design-library/src/utils/overlay-dismiss.ts
function ft(e) {
	return e.target === e.currentTarget;
}
function pt({ onDismiss: e, enabled: t = !0 }) {
	let n = C({
		pressed: !1,
		released: !1
	});
	return {
		onPointerDown: (e) => {
			n.current = {
				pressed: ft(e),
				released: !1
			};
		},
		onPointerUp: (e) => {
			n.current.released = ft(e);
		},
		onClick: (r) => {
			let { pressed: i, released: a } = n.current;
			n.current = {
				pressed: !1,
				released: !1
			}, !(!t || !i || !a) && ft(r) && e?.();
		}
	};
}
//#endregion
//#region ../../packages/design-library/src/components/modal.tsx
var mt = x({}), ht = {
	sm: "max-w-[400px]",
	md: "max-w-[560px]",
	lg: "max-w-[800px]",
	xl: "max-w-[1100px]"
};
function gt({ onOpenChange: e, ...t }) {
	return /* @__PURE__ */ T(mt, {
		value: { onOpenChange: e },
		children: /* @__PURE__ */ T(We, {
			onOpenChange: e,
			...t
		})
	});
}
function _t(e) {
	return /* @__PURE__ */ T(Ke, {
		"data-slot": "modal-trigger",
		...e
	});
}
function vt({ size: e = "md", hideCloseButton: t = !1, closeLabel: n = "Close", overlayClassName: i, dismissOnOverlayClick: a = !0, className: o, children: s, onInteractOutside: c, ref: l, ...u }) {
	let f = d(), { onOpenChange: p } = S(mt), m = pt({
		enabled: a,
		onDismiss: () => p?.(!1)
	});
	return /* @__PURE__ */ T(Xe, {
		container: f ?? void 0,
		children: /* @__PURE__ */ T(Qe, {
			"data-slot": "modal-overlay",
			className: r("fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4", i),
			...m,
			children: /* @__PURE__ */ E(tt, {
				ref: l,
				"data-slot": "modal-content",
				onInteractOutside: (e) => {
					c?.(e), e.preventDefault();
				},
				className: r("relative flex max-h-[calc(100vh-2rem)] w-full flex-col rounded-xl border shadow-xl", ht[e], "bg-[var(--surface-lift)] border-[var(--border-base)]", "focus:outline-none", o),
				...u,
				children: [s, t ? null : /* @__PURE__ */ T(ut, {
					asChild: !0,
					children: /* @__PURE__ */ T("button", {
						type: "button",
						"aria-label": n,
						className: "absolute top-3 right-3 flex h-6 w-6 cursor-pointer items-center justify-center rounded bg-transparent text-[var(--content-secondary)] transition-colors hover:text-[var(--content-default)]",
						children: /* @__PURE__ */ T(k, { className: "h-4 w-4" })
					})
				})]
			})
		})
	});
}
function yt({ className: e, children: t, ref: n, ...i }) {
	return /* @__PURE__ */ T(ot, {
		ref: n,
		"data-slot": "modal-title",
		className: r("text-title-medium text-[var(--content-emphasised)]", e),
		...i,
		children: /* @__PURE__ */ T("span", {
			className: "min-w-0 truncate leading-snug",
			children: t
		})
	});
}
function bt({ className: e, children: t, ref: n, ...i }) {
	return /* @__PURE__ */ T(ct, {
		ref: n,
		"data-slot": "modal-description",
		className: r("mt-0.5 whitespace-pre-line text-body-small-default text-[var(--content-tertiary)]", e),
		...i,
		children: t
	});
}
function xt(e) {
	return /* @__PURE__ */ T(ut, {
		"data-slot": "modal-close",
		...e
	});
}
function St({ icon: e, className: t, children: n, ...i }) {
	return /* @__PURE__ */ E("div", {
		"data-slot": "modal-header",
		className: r("flex items-center gap-3 p-4 pb-6 pr-10", t),
		...i,
		children: [e && /* @__PURE__ */ T("span", {
			"aria-hidden": "true",
			className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-[var(--surface-base)]",
			children: /* @__PURE__ */ T(e, { className: "h-5 w-5 text-[var(--primary-base)]" })
		}), /* @__PURE__ */ T("div", {
			className: "flex min-w-0 flex-1 flex-col",
			children: n
		})]
	});
}
function Ct({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ T("div", {
		"data-slot": "modal-body",
		className: r("flex-1 overflow-y-auto px-4 pb-4 text-[var(--content-default)]", e),
		...n,
		children: t
	});
}
function wt({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ T("div", {
		"data-slot": "modal-footer",
		className: r("flex justify-end gap-2 px-4 py-4", e),
		...n,
		children: t
	});
}
var $ = {
	Root: gt,
	Trigger: _t,
	Content: vt,
	Title: yt,
	Description: bt,
	Close: xt,
	Header: St,
	Body: Ct,
	Footer: wt
}, Tt = {
	info: {
		container: "bg-[var(--surface-overlay)]",
		icon: "text-[color:var(--content-secondary)]",
		DefaultIcon: D
	},
	success: {
		container: "bg-[var(--system-positive-weak)]",
		icon: "text-[color:var(--system-positive-strong)]",
		DefaultIcon: n
	},
	warning: {
		container: "bg-[var(--system-mid-weak)]",
		icon: "text-[color:var(--system-mid-strong)]",
		DefaultIcon: t
	},
	error: {
		container: "bg-[var(--system-negative-weak)]",
		icon: "text-[color:var(--system-negative-strong)]",
		DefaultIcon: O
	},
	neutral: {
		container: "bg-[var(--surface-overlay)]",
		icon: "text-[color:var(--content-secondary)]",
		DefaultIcon: null
	}
};
function Et({ tone: e = "info", title: t, children: n, icon: i, onDismiss: a, actions: o, className: s, ref: c, ...l }) {
	let u = Tt[e], d = e === "error" ? "alert" : "status", f = i === void 0 ? u.DefaultIcon ? /* @__PURE__ */ T(u.DefaultIcon, {
		className: "h-4 w-4",
		"aria-hidden": "true"
	}) : null : i, p = !!(t || o);
	return /* @__PURE__ */ E("div", {
		...l,
		ref: c,
		role: d,
		"data-slot": "notice",
		className: r("relative flex w-full gap-3 rounded-md p-3", p ? "items-start" : "items-center", "text-[color:var(--content-default)]", u.container, s),
		children: [
			f ? /* @__PURE__ */ T("span", {
				className: r("flex shrink-0 items-center justify-center", p && "mt-0.5", u.icon),
				children: f
			}) : null,
			/* @__PURE__ */ E("div", {
				className: "min-w-0 flex-1 space-y-1",
				children: [
					t ? /* @__PURE__ */ T(_, {
						variant: "body-medium-default",
						as: "p",
						className: "text-[color:var(--content-emphasised)]",
						children: t
					}) : null,
					n ? /* @__PURE__ */ T(_, {
						variant: "body-medium-lighter",
						as: "div",
						className: "text-[color:var(--content-secondary)]",
						children: n
					}) : null,
					o ? /* @__PURE__ */ T("div", {
						className: "flex flex-wrap items-center gap-2 pt-1",
						children: o
					}) : null
				]
			}),
			a ? /* @__PURE__ */ T("button", {
				type: "button",
				onClick: a,
				"aria-label": "Dismiss",
				className: r("shrink-0 cursor-pointer rounded bg-transparent p-0.5", "text-[color:var(--content-secondary)] opacity-70 transition-opacity", "hover:opacity-100 keyboard-focus:outline-none keyboard-focus:ring-2", "keyboard-focus:ring-[var(--ring)]"),
				children: /* @__PURE__ */ T(k, {
					className: "h-3.5 w-3.5",
					strokeWidth: 2,
					"aria-hidden": "true"
				})
			}) : null
		]
	});
}
//#endregion
//#region ../../packages/design-library/src/components/confirm-dialog.tsx
var Dt = "data-confirm-dialog-confirm";
function Ot({ open: e, title: t, message: n, children: r, error: i, icon: a, confirmLabel: o = "Confirm", cancelLabel: s = "Cancel", destructive: c = !1, isPending: l = !1, confirmDisabled: u = !1, onConfirm: d, onCancel: f }) {
	let p = l || u;
	return /* @__PURE__ */ T($.Root, {
		open: e,
		onOpenChange: (e) => {
			!e && !l && f();
		},
		children: /* @__PURE__ */ E($.Content, {
			size: "sm",
			hideCloseButton: !0,
			onOpenAutoFocus: (e) => {
				if (u) return;
				let t = e.currentTarget?.querySelector(`[${Dt}]`);
				t && (e.preventDefault(), t.focus());
			},
			onEscapeKeyDown: (e) => {
				e.preventDefault(), e.stopPropagation(), l || f();
			},
			children: [
				/* @__PURE__ */ T($.Header, {
					icon: a ?? (c ? O : void 0),
					children: /* @__PURE__ */ T($.Title, { children: t })
				}),
				/* @__PURE__ */ E($.Body, { children: [
					/* @__PURE__ */ T($.Description, { children: n }),
					r,
					i == null ? null : /* @__PURE__ */ T("div", {
						className: "mt-3",
						children: /* @__PURE__ */ T(Et, {
							tone: "error",
							children: i
						})
					})
				] }),
				/* @__PURE__ */ E($.Footer, { children: [/* @__PURE__ */ T(h, {
					variant: "outlined",
					onClick: f,
					disabled: l,
					children: s
				}), /* @__PURE__ */ T(h, {
					variant: c ? "danger" : "primary",
					onClick: () => {
						p || d();
					},
					disabled: p,
					loading: l,
					[Dt]: "",
					children: o
				})] })
			]
		})
	});
}
//#endregion
export { k as _, We as a, ct as c, ot as d, Ke as f, Se as g, q as h, pt as i, Qe as l, De as m, Et as n, ut as o, Re as p, $ as r, tt as s, Ot as t, Xe as u, O as v };
