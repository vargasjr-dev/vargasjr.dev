import { n as e } from "./routes-DW44XTQk.js";
//#region src/domains/account/provider.ts
var t = "workos", n = e.account.providerCallback;
//#endregion
export { t as n, n as t };
