//#region src/runtime/electron-bridge.ts
function e() {
	if (typeof window > "u") return;
	let e = window.cadet;
	return e?.platform === "electron" ? e : void 0;
}
//#endregion
export { e as t };
