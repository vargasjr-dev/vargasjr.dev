//#region src/utils/domains.ts
var e = "mycadet.ai", t = "www.mycadet.ai";
function n(e, t) {
	return e === t || e.endsWith(`.${t}`);
}
function r(t) {
	return n(t, e);
}
//#endregion
//#region src/utils/routes.ts
var i = {
	index: "/",
	assistant: "/assistant",
	onboarding: {
		hatching: "/account/onboarding/hatching",
		privacy: "/assistant/onboarding/privacy",
		research: "/assistant/onboarding/research"
	},
	account: {
		root: "/account",
		consent: "/account/consent",
		onboarding: {
			start: "/account/onboarding/start",
			hosting: "/account/onboarding/hosting",
			apiKey: "/account/onboarding/api-key"
		},
		login: "/account/login",
		doctor: "/account/doctor",
		selectAssistant: "/account/select-assistant",
		assistants: "/account/assistants",
		assistantDetail: (e) => `/account/assistants/${e}`,
		signup: "/account/signup",
		pair: "/account/pair",
		providerSignup: "/account/provider/signup",
		providerCallback: "/account/provider/callback",
		oauth: {
			popupComplete: "/account/oauth/popup-complete",
			complete: "/account/oauth/complete",
			desktopComplete: "/account/oauth/desktop-complete"
		}
	},
	docs: {
		hostingOptions: "/docs/hosting-options",
		localHosting: "/docs/hosting-options/local-hosting",
		legal: {
			privacyPolicy: "/docs/privacy-policy",
			termsOfUse: "/docs/terms-of-use"
		}
	}
};
function a(e) {
	return `https://${t}${e}`;
}
//#endregion
export { r as i, i as n, e as r, a as t };
