import { i as e, n as t, t as n } from "./request-Dbjf-LtL.js";
import { l as r, p as i, r as a } from "./schemas-D8_brjAQ.js";
import { t as o } from "./organization-DMy3nLTu.js";
//#region src/assistant/assistant-schema.ts
var s = r({
	id: i().min(1),
	name: i().optional(),
	created: i().optional()
}), c = r({
	results: a(s),
	next: i().nullable().optional()
});
//#endregion
//#region src/assistant/api.ts
async function l(e = {}) {
	let n = await o(e.signal);
	if (!n.ok) return n;
	let r = [];
	for (let i = 0; i < 20; i++) {
		let i = await t(`/v1/assistants/?hosting=all&limit=100&offset=${r.length}`, c, {
			organizationId: n.data,
			signal: e.signal
		});
		if (!i.ok) return i;
		if (r.push(...i.data.results), !i.data.next || i.data.results.length === 0) return {
			ok: !0,
			status: i.status,
			data: r
		};
	}
	return {
		ok: !1,
		status: 200,
		error: { detail: "Assistant list exceeded the page cap." }
	};
}
async function u(t) {
	let n = await o();
	return n.ok ? e("/v1/assistants/hatch/?mode=create", s, t ? { name: t } : {}, { organizationId: n.data }) : n;
}
async function d(e, t = {}) {
	return n(`/v1/assistants/${encodeURIComponent(e)}/retire/`, { signal: t.signal });
}
//#endregion
export { l as n, d as r, u as t };
