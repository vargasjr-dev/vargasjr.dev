import { c as e, s as t } from "./chunk-5KNZJZUH-DggPzR22.js";
import { n, t as r } from "./loader-circle-Ch7lYSrj.js";
import { n as i, t as a } from "./circle-check-CBLio8rp.js";
import { r as o } from "./i18n-BRf-wfgm.js";
import { t as s } from "./button-BrPHE1Q9.js";
import { r as c } from "./remote-web-pairing-DV2Q8AE4.js";
import { n as l } from "./routes-DW44XTQk.js";
import { t as u } from "./return-to-BrgpQtYw.js";
import { useCallback as d, useEffect as f, useMemo as p, useState as m } from "react";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
var _ = n("smartphone", [["rect", {
	width: "14",
	height: "20",
	x: "5",
	y: "2",
	rx: "2",
	ry: "2",
	key: "1yt0o3"
}], ["path", {
	d: "M12 18h.01",
	key: "mhygvu"
}]]), v = "/v1/assistant/remote-web/pairing-token", y = 5, b = class extends Error {
	status;
	code;
	constructor(e, t, n = null) {
		super(t), this.name = "RemoteWebPairingError", this.status = e, this.code = n;
	}
};
function x(e) {
	let t = e?.error?.code;
	return typeof t == "string" ? t : null;
}
function S(e) {
	let t = e;
	return t?.status === "approved" && typeof t.accessToken == "string" && (typeof t.accessTokenExpiresAt == "string" || typeof t.accessTokenExpiresAt == "number") && (typeof t.refreshAfter == "string" || typeof t.refreshAfter == "number");
}
async function C(e, t) {
	let n = await fetch(v, {
		method: "POST",
		credentials: "include",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ deviceCode: e }),
		signal: t
	}), r = await n.json().catch(() => null);
	if (n.status === 202) {
		let e = r ?? {};
		return {
			status: "pending",
			expiresAt: typeof e.expiresAt == "string" ? e.expiresAt : "",
			intervalSeconds: typeof e.intervalSeconds == "number" && e.intervalSeconds > 0 ? e.intervalSeconds : y
		};
	}
	if (!n.ok) throw new b(n.status, `Pairing token exchange failed: ${n.status}`, x(r));
	if (!S(r)) throw new b(502, "Pairing token exchange returned an invalid response");
	return r;
}
//#endregion
//#region src/domains/account/pages/pairing-page.tsx
function w(e) {
	switch (e.kind) {
		case "awaiting_code": return {
			title: "Pair a device",
			body: "On the machine running your assistant, run \"cadet pair\", then enter the code it prints below the QR code here."
		};
		case "verifying": return {
			title: "Pairing",
			body: "Connecting this device to your assistant."
		};
		case "approved": return {
			title: "Connected",
			body: "Opening your assistant."
		};
		case "expired": return {
			title: "Pairing expired",
			body: "This pairing code is invalid or expired. Run cadet pair on the machine running your assistant to get a new one."
		};
		case "error": return {
			title: "Pairing failed",
			body: e.message
		};
		case "polling": return {
			title: "Waiting for approval",
			body: "Confirm this code on the machine running your assistant."
		};
	}
}
function T({ state: e }) {
	return e.kind === "approved" ? /* @__PURE__ */ h(a, {
		className: "h-5 w-5 text-[var(--system-positive-strong)]",
		"aria-hidden": !0
	}) : e.kind === "awaiting_code" ? /* @__PURE__ */ h(_, {
		className: "h-5 w-5 text-[var(--system-info-strong)]",
		"aria-hidden": !0
	}) : e.kind === "verifying" || e.kind === "polling" ? /* @__PURE__ */ h(r, {
		className: "h-5 w-5 animate-spin text-[var(--system-info-strong)]",
		"aria-hidden": !0
	}) : /* @__PURE__ */ h(i, {
		className: "h-5 w-5 text-[var(--system-negative-strong)]",
		"aria-hidden": !0
	});
}
function E() {
	try {
		let e = new URL(window.location.href);
		for (let t of [
			"deviceCode",
			"device_code",
			"userCode",
			"user_code"
		]) e.searchParams.delete(t);
		e.hash = "", window.history.replaceState(null, "", `${e.pathname}${e.search}`);
	} catch {}
}
function D() {
	let { t: n } = o("account"), r = t(), i = e(), a = p(() => u(new URLSearchParams(r.search).get("returnTo"), l.assistant), [r.search]), _ = p(() => c(`${r.pathname}${r.search}${r.hash}`), [
		r.pathname,
		r.search,
		r.hash
	]), [v, y] = m(() => _.deviceCode ? {
		deviceCode: _.deviceCode,
		userCode: _.userCode
	} : null), [x, S] = m(() => _.deviceCode ? { kind: "verifying" } : { kind: "awaiting_code" }), [D, O] = m(""), k = d(() => {
		let e = D.trim();
		e && (y({
			deviceCode: e,
			userCode: null
		}), S({ kind: "verifying" }));
	}, [D]);
	f(() => {
		if (!v?.deviceCode) return;
		let e = new AbortController(), t = null, n = async () => {
			try {
				let r = await C(v.deviceCode, e.signal);
				if (r.status === "pending") {
					S({
						kind: "polling",
						expiresAt: r.expiresAt || null
					}), t = setTimeout(() => void n(), Math.max(1, r.intervalSeconds) * 1e3);
					return;
				}
				E(), S({ kind: "approved" }), t = setTimeout(() => i(a, { replace: !0 }), 250);
			} catch (t) {
				if (e.signal.aborted) return;
				if (t instanceof b && t.status === 401) {
					S({ kind: "expired" });
					return;
				}
				if (t instanceof b && t.code === "GUARDIAN_REPAIR_REQUIRED") {
					S({
						kind: "error",
						message: "The assistant's trust database needs repair. Run guardian repair on the machine hosting the assistant, then retry this same pairing link — the code stays valid."
					});
					return;
				}
				S({
					kind: "error",
					message: "The assistant could not complete pairing. Try starting a new pairing."
				});
			}
		};
		return n(), () => {
			e.abort(), t && clearTimeout(t);
		};
	}, [
		v?.deviceCode,
		i,
		a
	]);
	let A = d(() => {
		i(l.account.selectAssistant, { replace: !0 });
	}, []), j = w(x);
	return /* @__PURE__ */ h("main", {
		className: "flex min-h-svh items-center justify-center bg-[var(--surface-base)] px-6 py-10 text-[var(--content-default)]",
		children: /* @__PURE__ */ g("section", {
			className: "w-full max-w-md rounded-lg border border-[var(--border-subtle)] bg-[var(--surface-lift)] p-8 shadow-[var(--shadow-sm)]",
			children: [
				/* @__PURE__ */ g("div", {
					className: "mb-5 flex items-center gap-3",
					children: [/* @__PURE__ */ h(T, { state: x }), /* @__PURE__ */ h("h1", {
						className: "text-title-medium text-[var(--content-emphasised)]",
						children: j.title
					})]
				}),
				x.kind === "polling" && v?.userCode ? /* @__PURE__ */ g("div", {
					className: "mb-5 rounded-md border border-[var(--border-subtle)] bg-[var(--surface-sunken)] p-4 text-center",
					children: [/* @__PURE__ */ h("div", {
						className: "text-label-small-default uppercase tracking-wide text-[var(--content-tertiary)]",
						children: n("pairingPage.pairingCode")
					}), /* @__PURE__ */ h("div", {
						className: "mt-2 font-mono text-3xl font-semibold tracking-[0.18em] text-[var(--content-emphasised)]",
						children: v.userCode
					})]
				}) : null,
				/* @__PURE__ */ h("p", {
					className: "text-body-medium-lighter leading-6 text-[var(--content-secondary)]",
					children: j.body
				}),
				x.kind === "awaiting_code" ? /* @__PURE__ */ g("form", {
					className: "mt-6 flex flex-col gap-3",
					onSubmit: (e) => {
						e.preventDefault(), k();
					},
					children: [/* @__PURE__ */ h("input", {
						type: "text",
						value: D,
						onChange: (e) => O(e.target.value),
						placeholder: n("pairingPage.pairingCode"),
						"aria-label": n("pairingPage.pairingCode"),
						className: "rounded-md border border-[var(--border-subtle)] bg-[var(--surface-sunken)] px-3 py-2 font-mono text-body-medium-default tracking-wide text-[var(--content-default)]"
					}), /* @__PURE__ */ h(s, {
						type: "submit",
						variant: "primary",
						fullWidth: !0,
						children: n("pairingPage.pair")
					})]
				}) : null,
				x.kind === "polling" && x.expiresAt ? /* @__PURE__ */ h("p", {
					className: "text-body-small-lighter mt-4 text-[var(--content-tertiary)]",
					children: n("pairingPage.expiresAt", { time: new Date(x.expiresAt).toLocaleTimeString() })
				}) : null,
				x.kind === "polling" ? /* @__PURE__ */ h(s, {
					variant: "outlined",
					fullWidth: !0,
					className: "mt-6",
					onClick: A,
					children: n("pairingPage.cancel")
				}) : null,
				x.kind === "expired" ? /* @__PURE__ */ h(s, {
					variant: "outlined",
					fullWidth: !0,
					className: "mt-6",
					onClick: () => {
						y(null), O(""), S({ kind: "awaiting_code" });
					},
					children: n("pairingPage.enterNewCode")
				}) : null
			]
		})
	});
}
//#endregion
export { D as PairingPage };
