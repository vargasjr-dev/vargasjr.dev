//#region src/i18n/locales/zh-TW/account.json
var e = { loading: "載入中" }, t = {
	headlineLead: "認識您的新",
	headlineRoles: {
		personalIntelligence: "個人智慧",
		softwareEngineer: "軟體工程師",
		financeOps: "財務營運",
		householdManager: "家庭管理員",
		gtmEngineer: "市場推廣工程師",
		productLead: "產品負責人"
	},
	subtitle: "最為強大的助理，能處理您的工作與生活管理任務。",
	continue: "繼續",
	downloadMac: "下載 macOS 版",
	haveAccountPrompt: "已有帳號？<signIn>登入</signIn>"
}, n = {
	title: "目前已暫停註冊",
	message: "很抱歉，Cadet 目前不接受新用戶註冊。歡迎稍後再試。你也可以自行託管 Cadet。<selfHostingLink>點此</selfHostingLink>進一步了解自行託管。",
	haveAccountPrompt: "已有帳號？<signIn>登入</signIn>"
}, r = {
	loading: "載入中...",
	welcomeTitle: "歡迎使用 Cadet",
	welcomeSubtitle: "請登入以開始使用。",
	signIn: "登入",
	signedInTitle: "歡迎！",
	signedInTitleNamed: "歡迎，{name}！",
	signedInSubtitle: "您已登入。",
	goToAssistant: "前往您的助理",
	signOut: "登出"
}, i = {
	signUp: "註冊",
	signIn: "登入"
}, a = { title: "正在登出..." }, o = {
	backToWelcome: "返回歡迎頁面",
	completing: "正在完成登入..."
}, s = { errorCode: "錯誤：{code}" }, c = {
	signupClosedTitle: "目前已暫停註冊",
	signupClosedSubtitle: "很抱歉，Cadet 目前不接受新用戶註冊。歡迎稍後再試。",
	backToSignIn: "返回登入",
	failedTitle: "驗證失敗",
	failedSubtitle: "社群登入時發生問題。請再試一次或使用其他方式。",
	completingTitle: "正在完成登入...",
	completingSubtitle: "請稍候，我們正在完成您的驗證。"
}, l = {
	completingTitle: "正在完成註冊...",
	completingSubtitle: "請稍候，我們正在載入您的資訊。",
	headingLine1: "就快完成了，",
	headingLine2: "還差一步",
	firstNameQuestion: "我該如何稱呼您？",
	firstNamePlaceholder: "名字",
	lastNameQuestion: "您的姓氏是？",
	lastNamePlaceholder: "姓氏",
	roleQuestion: "您的角色",
	rolePlaceholder: "例如：軟體工程師",
	submitting: "正在設定…",
	submit: "繼續 →",
	completeAccountTitle: "完成您的帳號設定",
	completeAccountSubtitle: "我們需要更多詳細資訊來完成您的帳號設定。",
	backToSignIn: "← 返回登入",
	emailPlaceholder: "電子郵件",
	usernamePlaceholder: "使用者名稱",
	completeSignup: "完成註冊",
	completingSignup: "正在完成..."
}, u = {
	genericFailure: "發生錯誤。請再試一次。",
	signupClosed: "很抱歉，Cadet 目前不接受新用戶註冊。歡迎稍後再試。",
	providerSignup: "該登入尚未連結 Cadet 帳號。請先註冊，然後登入。",
	loginIncomplete: "您的帳號需要額外步驟才能完成登入。請在網頁上登入，然後再試一次。",
	desktopUpdateRequired: "此版本的 Cadet 桌面應用程式無法登入。請更新應用程式，然後再試一次。",
	loopbackStateMismatch: "登入失敗：狀態不符。請再試一次。",
	loopbackNoToken: "登入失敗：未收到工作階段權杖。請再試一次。",
	loopbackInvalidToken: "登入失敗：工作階段權杖無效。"
}, d = {
	title: "歡迎使用 Cadet",
	body: "您的專屬智慧助理近在咫尺。",
	cancel: "取消",
	logIn: "登入",
	continueWithoutAccount: "不登入繼續",
	comingSoon: "即將推出！"
}, f = {
	listAriaLabel: "助理",
	create: "建立助理",
	rowActionsAriaLabel: "{name} 的動作",
	retire: "停用助理",
	addRemote: "新增遠端助理",
	currentWithHost: "目前 · {host}",
	remoteWithHost: "遠端 · {host}",
	removeFromDevice: "從此裝置移除…",
	unnamedAssistant: "該助理",
	hatchAssistant: "孵化新助理",
	localAssistant: "在這部電腦上"
}, p = {
	loading: "正在載入助理…",
	error: "無法載入助理。",
	errorTitle: "無法連線你的助手",
	errorBody: "它剛剛沒有回應。如果你的助手剛啟動，請稍候片刻再重試。",
	notReady: "你的助理尚未就緒。",
	notReadyTitle: "你的助理尚未就緒。",
	notReadyBody: "它目前無法使用。請稍後重試，或從你的 Cadet 帳號啟動它。",
	wake: "喚醒",
	waking: "喚醒中…",
	wakeFailed: "喚醒目前沒有成功，請稍後再試。",
	empty: "沒有可用的助理。",
	unauthenticated: "請登入以繼續。",
	retry: "重試",
	switchAssistant: "切換助理",
	title: "助理",
	selection: "選擇一個助理。",
	unavailable: "此助理無法使用。",
	assistantSwitchFailed: "無法切換至該助理。"
}, m = {
	cancel: "取消",
	add: "新增",
	adding: "正在新增…",
	connect: "連線",
	connecting: "正在連線…",
	continue: "繼續",
	back: "返回",
	loginToUse: "登入以使用",
	tryAgain: "再試一次"
}, h = {
	title: "連接遠端助理",
	instruction: "請從助理的「配對裝置」設定中貼上配對連結，或直接貼上其位址，然後在助理端核准請求。",
	linkGuidance: "此連結來自配對 QR 碼。若要連接此裝置，請在此處貼上來自助理裝置的配對連結。",
	legacyLinkGuidance: "此連結來自舊版應用程式，已無法使用。請在助理裝置上產生新的配對連結並貼到此處。",
	addressLabel: "位址或配對連結",
	addressPlaceholder: "https://your-assistant.ts.net",
	nameLabel: "名稱（選填）",
	approveOnHost: "請在助理裝置上核准此代碼以完成連接。",
	waitingForApproval: "等待核准中…",
	retrying: "助理尚未準備好配對。正在重試，直到代碼過期。",
	expiresIn: "將於 {time} 後過期",
	retryExpired: "配對代碼在助理準備好配對之前已過期。請重新開始以取得新的代碼。",
	submitError: "無法連接到該助理。請再試一次。",
	importedTitle: "配對已匯入",
	importedBody: "此配對僅限存取：它現在可用，但其存取權限會過期且無法自動續訂。過期後，請在助理裝置上產生新的配對連結並貼到此處以重新配對。"
}, g = { createAssistant: "建立您的助理" }, _ = {
	title: "託管",
	body: "選擇您希望助理駐留的位置。",
	needHelp: "需要協助決定嗎？",
	optionsAriaLabel: "託管選項"
}, v = {
	title: "連線模型供應商",
	body: "選擇您的助理應使用的模型供應商。",
	providerLabel: "供應商",
	modelLabel: "模型",
	baseUrlLabel: "基礎 URL",
	modelsLabel: "模型",
	modelsPlaceholder: "model-1, model-2",
	modelsHelp: "您的端點所公開，以逗號分隔的模型識別碼。",
	apiKeyLabel: "{provider} API 金鑰",
	apiKeyPlaceholder: "輸入您的 API 金鑰",
	noKeyPrompt: "沒有金鑰？",
	getKeyLink: "在此取得 API 金鑰"
}, y = {
	apiKeyFailed: "您的 API 金鑰無效",
	genericFailure: "發生了一些錯誤",
	ready: "您的助理已準備就緒！",
	updateApiKey: "更新 API 金鑰",
	waking: "正在喚醒…",
	wakingBody: "請稍候，您的助理啟動後會向您提出一些問題。",
	progressAriaLabel: "助理啟動進度",
	phase: {
		initializing: "正在準備中…",
		provisioning: "正在設定您的助理…",
		connecting: "正在連線至您的助理…",
		ready: "就緒"
	}
}, b = {
	pairingCode: "配對碼",
	pair: "配對",
	expiresAt: "{time} 到期。",
	cancel: "取消",
	enterNewCode: "輸入新代碼"
}, x = {
	authWaitSpinner: e,
	signupScreen: t,
	signupClosedScreen: n,
	accountPage: r,
	loginPage: i,
	logoutPage: a,
	platformLoopbackPage: o,
	oauthComplete: s,
	providerCallbackPage: c,
	providerSignupPage: l,
	authErrors: u,
	welcome: d,
	selectAssistantScreen: f,
	appShell: p,
	actions: m,
	connectAssistantDialog: h,
	startScreen: g,
	hostingScreen: _,
	apiKeyScreen: v,
	hatchingScreen: y,
	pairingPage: b
};
//#endregion
export { r as accountPage, m as actions, v as apiKeyScreen, p as appShell, u as authErrors, e as authWaitSpinner, h as connectAssistantDialog, x as default, y as hatchingScreen, _ as hostingScreen, i as loginPage, a as logoutPage, s as oauthComplete, b as pairingPage, o as platformLoopbackPage, c as providerCallbackPage, l as providerSignupPage, f as selectAssistantScreen, n as signupClosedScreen, t as signupScreen, g as startScreen, d as welcome };
