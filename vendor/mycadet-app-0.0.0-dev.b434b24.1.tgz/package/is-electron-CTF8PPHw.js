//#region src/runtime/is-electron.ts
function e() {
	return typeof window < "u" && window.cadet?.platform === "electron";
}
//#endregion
export { e as t };
