import type { ReactElement } from "react";
export declare function EmbeddedApp(props: { basename?: string }): ReactElement | null;
