//#region src/domains/onboarding/onboarding-navigation.ts
var e = { replace: !0 };
//#endregion
export { e as t };
