//#region src/domains/account/full-page-navigation.ts
function e(e) {
	return e.startsWith("http") || e.startsWith("/accounts/") || e.startsWith("/v1/") || e.startsWith("/_allauth/") || e.startsWith("/import");
}
//#endregion
export { e as t };
