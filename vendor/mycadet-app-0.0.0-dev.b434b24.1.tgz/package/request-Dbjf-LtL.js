import { t as e } from "./electron-bridge-VOSuV45z.js";
import { n as t, r as n, t as r } from "./session-token-HN3JX-0v.js";
import { l as i, n as a, p as o } from "./schemas-D8_brjAQ.js";
import { a as s } from "./i18n-BRf-wfgm.js";
//#region src/lib/cloud/mutation-headers.ts
async function c(r) {
	if (r.set("Content-Type", "application/json"), !e()) {
		await t();
		let e = n();
		e && r.set("X-CSRFToken", e);
	}
}
//#endregion
//#region src/lib/cloud/request.ts
var l = i({ detail: o() });
async function u(e, t, n = {}) {
	return h(e, t, n);
}
async function d(e, t, n, r = {}) {
	return h(e, t, r, n);
}
async function f(e, t, n, r = {}) {
	return h(e, t, r, n, "PATCH");
}
async function p(e, t = {}) {
	return h(e, a(), t, void 0, "DELETE");
}
async function m(e, t, n = {}) {
	try {
		let i = new Headers({
			Accept: "application/json",
			"Accept-Language": s()
		}), a = r();
		a && i.set("X-Session-Token", a), await c(i);
		let o = await fetch(e, {
			method: "POST",
			body: t,
			headers: i,
			credentials: "same-origin",
			signal: n.signal
		}), u = await o.json().catch(() => null);
		if (!o.ok) {
			let e = l.safeParse(u);
			return {
				ok: !1,
				status: o.status,
				error: { detail: e.success ? e.data.detail : `Cloud request failed (HTTP ${o.status}).` }
			};
		}
		return {
			ok: !0,
			status: o.status,
			data: null
		};
	} catch {
		return {
			ok: !1,
			status: 0,
			error: { detail: "Cloud request unavailable." }
		};
	}
}
async function h(e, t, n, i, a) {
	try {
		let o = new Headers({
			Accept: "application/json",
			"Accept-Language": s()
		}), u = r();
		u && o.set("X-Session-Token", u), n.organizationId && o.set("Cadet-Organization-Id", n.organizationId), (i !== void 0 || a === "DELETE") && await c(o);
		let d = await fetch(e, {
			method: a ?? (i === void 0 ? "GET" : "POST"),
			...i === void 0 ? {} : { body: JSON.stringify(i) },
			headers: o,
			credentials: "same-origin",
			signal: n.signal
		}), f = await d.json().catch(() => null);
		if (!d.ok) {
			let e = l.safeParse(f);
			return {
				ok: !1,
				status: d.status,
				error: { detail: e.success ? e.data.detail : `Cloud request failed (HTTP ${d.status}).` }
			};
		}
		let p = t.safeParse(f);
		return p.success ? {
			ok: !0,
			status: d.status,
			data: p.data
		} : {
			ok: !1,
			status: d.status,
			error: { detail: "Invalid cloud response." }
		};
	} catch {
		return {
			ok: !1,
			status: 0,
			error: { detail: "Cloud request unavailable." }
		};
	}
}
//#endregion
export { m as a, d as i, u as n, f as r, p as t };
